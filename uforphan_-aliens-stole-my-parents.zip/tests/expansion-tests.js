import { EventHub, EventTransaction } from "../src/expansion/event-hub.js";
import { Inventory } from "../src/expansion/inventory.js";
import { QuestEngine, STORY_QUESTS, QUEST_STATUS } from "../src/expansion/quest-engine.js";
import { CraftingSystem } from "../src/expansion/crafting.js";
import { ProgressionSystem } from "../src/expansion/progression-system.js";
import { EconomySystem } from "../src/expansion/economy-system.js";
import { ChallengeSystem } from "../src/expansion/challenge-system.js";
import { MissionBoard } from "../src/expansion/mission-board.js";
import { SideRoomGenerator } from "../src/expansion/level-generator.js";
import { validateLevelSet } from "../src/expansion/level-validator.js";
import { ExpansionProfile } from "../src/expansion/profile.js";
import { LEVELS } from "../src/levels.js";

let assertions=0;
function assert(value,message){assertions++;if(!value)throw new Error(`Expansion test failed: ${message}`);}
function equal(actual,expected,message){assert(actual===expected,`${message}; expected ${expected}, got ${actual}`);}

const hub=new EventHub();
let received=0;
const unsubscribe=hub.on("sample",()=>received++);
hub.emit("sample");unsubscribe();hub.emit("sample");equal(received,1,"event subscription lifecycle");
const transaction=new EventTransaction(hub,"test");transaction.emit("one",{value:1}).emit("two",{value:2});assert(transaction.commit(),"event transaction commits");assert(!transaction.commit(),"event transaction is single-use");

const inventory=new Inventory(hub,{capacity:5});
assert(inventory.add("ion_cell",4).ok,"inventory accepts a stack");
assert(inventory.has("ion_cell",4),"inventory count query");
assert(inventory.remove("ion_cell",2),"inventory removes requested count");
equal(inventory.count("ion_cell"),2,"inventory removal count");
assert(!inventory.remove("ion_cell",5),"inventory rejects insufficient removal");
assert(inventory.validate().valid,"inventory validation");

const quests=new QuestEngine(hub,STORY_QUESTS);
assert(quests.start("signal_in_the_static").ok,"available quest starts");
assert(!quests.start("family_frequency").ok,"quest prerequisites lock final mission");
quests.updateObjective("signal_in_the_static","scan_beacons",3);
quests.updateObjective("signal_in_the_static","find_transmitter",1);
equal(quests.get("signal_in_the_static").state.status,QUEST_STATUS.COMPLETED,"quest auto-completes all required objectives");

const crafting=new CraftingSystem(hub,inventory);
crafting.setStation("field_kit");
assert(!crafting.craft("med_patch").ok,"crafting checks missing materials");
inventory.add("resonant_crystal",1);
inventory.add("ion_cell",1);
assert(crafting.craft("med_patch").ok,"crafting consumes ingredients and creates output");

const progression=new ProgressionSystem();
const gain=progression.addXP(1000);
assert(gain.levels>0,"experience grants levels");
assert(progression.skillPoints>0,"level-ups award skill points");
assert(progression.purchase("light_feet").ok,"skill purchase spends points");

const economy=new EconomySystem(inventory);
economy.earn(100,"test");
assert(economy.buy("ion_cell",1).ok,"shop purchase succeeds with enough credits");
assert(!economy.buy("resonant_crystal",100).ok,"shop stock is enforced");

const challenges=new ChallengeSystem(hub);
assert(challenges.start("drone_sweep",{health:3}).ok,"challenge starts");
challenges.addProgress("kills",6);
equal(challenges.results[0].success,true,"challenge completes on target");

const board=new MissionBoard();
assert(board.accept(board.offers[0].id).ok,"mission board accepts an available bounty");

const generator=new SideRoomGenerator(42);
const room=generator.generate({rooms:8,difficulty:2});
assert(generator.validate(room).valid,"generated side room validates");
const levelSet=validateLevelSet(LEVELS);
assert(levelSet.valid,"all authored levels pass geometry validation");
equal(LEVELS.length,8,"four expansion chapters are appended");

const profile=new ExpansionProfile();
assert(profile.inventory instanceof Inventory,"profile creates a persistent inventory");
assert(profile.quests.get("signal_in_the_static"),"profile registers story quests");
profile.progression.addXP(100);
assert(profile.serialize().progression.lifetimeXp>=100,"profile serializes progression state");

console.log(`UFOrphan expansion tests passed: ${assertions} assertions across ${LEVELS.length} levels.`);

// Exercise the actual world/profile bridge rather than only isolated utilities.
import { World } from "../src/world.js";
import { Player } from "../src/player.js";
import { SaveManager } from "../src/save.js";
const silentAudio={jump(){},hurt(){},blast(){},collect(){},win(){},click(){},unlock(){}};
const silentParticles={burst(){},update(){},draw(){}};
const worldProfile=new ExpansionProfile();
const expansionWorld=new World(4,silentAudio,silentParticles,worldProfile);
const testPlayer=new Player(300,420);
worldProfile.applyPlayer(testPlayer);
expansionWorld.update(testPlayer);
const npcResult=expansionWorld.interact(testPlayer);
assert(npcResult?.type==="npc","world interaction reaches nearby NPCs");
assert(worldProfile.npcsMet.has("noa"),"NPC meeting is persisted in the profile");
assert(expansionWorld.expansion.map.visibleMarkers().length>=1,"sector map reveals nearby markers");

const protectedPlayer=new Player(20,20);
protectedPlayer.shieldTicks=30;
protectedPlayer.takeDamage(silentAudio,silentParticles);
equal(protectedPlayer.health,3,"shield absorbs a hit");
protectedPlayer.shieldTicks=0;
protectedPlayer.invulnerable=0;
protectedPlayer.takeDamage(silentAudio,silentParticles);
equal(protectedPlayer.health,2,"unshielded hit removes one heart");

let stored=JSON.stringify({version:"1.0.0",unlockedLevel:3,bestStars:{0:7},sound:false});
globalThis.localStorage={getItem(){return stored;},setItem(_key,value){stored=value;}};
const migratedSave=new SaveManager();
equal(migratedSave.data.unlockedLevel,3,"legacy save chapter progress migrates");
equal(migratedSave.data.version,"2.0.0","legacy save version is upgraded");
assert(migratedSave.data.expansion,"legacy save gains an expansion profile slot");

console.log(`World integration checks passed; total assertions: ${assertions}.`);

const persistedProfile=new ExpansionProfile({
  inventory:{capacity:24,slots:[{id:"ion_cell",count:7}],equipment:{weapon:"plasma_lens"}},
  progression:{xp:12,level:2,skillPoints:1,skills:{light_feet:1}},
  npcsMet:["pip","noa"],completedLevels:[0,1],statistics:{stars:12,keys:3,enemies:4,seconds:55}
});
equal(persistedProfile.inventory.count("ion_cell"),7,"profile restores item stacks");
equal(persistedProfile.inventory.equipment.weapon,"plasma_lens","profile restores equipped weapon");
equal(persistedProfile.statistics.stars,12,"profile restores session statistics");
equal(persistedProfile.npcsMet.size,2,"profile restores known characters");
assert(persistedProfile.serialize().completedLevels.includes(1),"profile serializes chapter completion");

const beaconWorld=new World(5,silentAudio,silentParticles,new ExpansionProfile());
beaconWorld.expansion.beacons[0].active=true;
const freshBeaconWorld=new World(5,silentAudio,silentParticles,new ExpansionProfile());
assert(!freshBeaconWorld.expansion.beacons[0].active,"beacon activation does not mutate shared level definitions");
console.log(`Persistence checks passed; total assertions: ${assertions}.`);

const storyProfile=new ExpansionProfile();
assert(storyProfile.quests.start("signal_in_the_static").ok,"signal quest can be accepted");
storyProfile.quests.updateObjective("signal_in_the_static","scan_beacons",3);
storyProfile.quests.updateObjective("signal_in_the_static","find_transmitter",1);
assert(storyProfile.quests.start("mall_cop_duty").ok,"security quest can be accepted");
storyProfile.quests.updateObjective("mall_cop_duty","disable_drones",4);
storyProfile.quests.updateObjective("mall_cop_duty","return_badge",1);
assert(storyProfile.quests.start("scrap_symphony").ok,"mechanic quest can be accepted");
storyProfile.quests.updateObjective("scrap_symphony","collect_coils",5);
storyProfile.quests.updateObjective("scrap_symphony","collect_crystals",2);
equal(storyProfile.quests.get("family_frequency").state.status,QUEST_STATUS.AVAILABLE,"final quest unlocks after its three prerequisites");
assert(storyProfile.crafting.unlocked.has("plasma_lens"),"scrap quest unlocks plasma lens recipe");
assert(storyProfile.quests.start("family_frequency").ok,"family frequency quest can be accepted");
storyProfile.quests.updateObjective("family_frequency","align_dishes",3);
storyProfile.quests.updateObjective("family_frequency","send_signal",1);
equal(storyProfile.quests.get("family_frequency").state.status,QUEST_STATUS.COMPLETED,"family signal completes after all dishes are aligned");

const noHitChallenge=new ChallengeSystem(hub);
noHitChallenge.start("drone_sweep",{health:3});
noHitChallenge.recordDamage(1);
noHitChallenge.addProgress("kills",6);
equal(noHitChallenge.results[0].flawless,false,"challenge records damage for flawless condition");

import { STORY, SPEAKERS } from "../src/dialogue.js";
equal(STORY.chapters.length,8,"story covers all 8 chapters");
equal(STORY.chapterBeats.length,8,"chapter opening multi-speaker beats exist for all 8 chapters");
equal(Object.keys(STORY.fieldBeats).length,8,"field radio transmissions exist for all 8 chapters");
assert(SPEAKERS.fiona&&SPEAKERS.warden,"dialogue speakers roster includes hero and final boss");

const sonicProfile=new ExpansionProfile();
sonicProfile.inventory.add("sonic_module",1);
assert(sonicProfile.inventory.equip("sonic_module","weapon").ok,"sonic_module can be equipped to weapon slot");
const sonicPlayer=new Player(120,420);
sonicProfile.applyPlayer(sonicPlayer);
equal(sonicPlayer.weapon,"sonic_burst","equipping sonic_module activates sonic_burst mode");
const sonicWorld=new World(0,silentAudio,silentParticles,sonicProfile);
const blastInput={isDown:()=>false,wasPressed:(action)=>action==="blast"};
sonicPlayer.update(blastInput,sonicWorld,silentAudio,silentParticles);
assert(sonicWorld.projectiles.length>=3,"sonic_burst fires a 3-way spread of shots");

const dashPlayer=new Player(120,420);
const dashInput={isDown:()=>false,wasPressed:(action)=>action==="dash"};
dashPlayer.update(dashInput,sonicWorld,silentAudio,silentParticles);
assert(dashPlayer.dashTicks>0,"Star-Dash activates when dash action is pressed");
assert(dashPlayer.invulnerable>=dashPlayer.dashTicks,"Star-Dash grants brief dash invulnerability");

sonicWorld.pushComms("dad","Testing radio check!");
assert(sonicWorld.comms?.speaker?.name===SPEAKERS.dad.name&&sonicWorld.comms?.text==="Testing radio check!","world.pushComms activates a speaker-tagged radio transmission");

import { SECTOR_ATMOSPHERES, EXO_ANOMALIES } from "../src/expansion/ufo-science.js";
equal(SECTOR_ATMOSPHERES.length,8,"planetary atmospheric telemetry covers all 8 chapters");
equal(Object.keys(EXO_ANOMALIES).length,8,"exo-science anomalies exist for all 8 chapters");

const exoProfile=new ExpansionProfile();
exoProfile.economy.earn(500,"test");
assert(exoProfile.upgrades.purchase("graviton_thrusters",exoProfile.economy).ok,"graviton_thrusters upgrade can be purchased");
assert(exoProfile.upgrades.purchase("seti_array",exoProfile.economy).ok,"seti_array upgrade can be purchased");
const exoPlayer=new Player(410,420);
exoProfile.applyPlayer(exoPlayer);
equal(exoPlayer.dashCooldownMult,0.7,"graviton_thrusters reduces dash cooldown multiplier");
equal(exoPlayer.scanRadius,440,"seti_array expands 1420 MHz scan radius");

const exoWorld=new World(0,silentAudio,silentParticles,exoProfile);
assert(exoWorld.expansion.exo.triggerScan(exoPlayer),"SETI sonar scan triggers cleanly");
assert(exoWorld.expansion.exo.anomalies[0].analyzed,"nearby E.T. anomaly is analyzed by SETI scan");
assert(exoProfile.codex.unlocked.has("alcubierre_wake"),"analyzing Alcubierre eddy unlocks corresponding science Codex entry");

const abductor=exoWorld.expansion.exo.saucers.find(s=>s.kind==="abductor");
assert(Boolean(abductor),"level spawns an overhead UFO patrol saucer");
exoWorld.projectiles.push({x:abductor.x,y:abductor.y+5,w:10,h:10,vx:0,vy:0,life:20,owner:"player"},{x:abductor.x,y:abductor.y+5,w:10,h:10,vx:0,vy:0,life:20,owner:"player"});
exoWorld.expansion.exo.update(exoPlayer);
assert(abductor.invertedTicks>0,"blaster hits invert an abductor saucer into an anti-gravity updraft");
assert(exoProfile.inventory.has("e115_shard",1),"inverting a saucer yields an E-115 Moscovium shard");

import { XENO_ARTIFACT_CATALOG, XenoArtifactCollection } from "../src/expansion/xeno-artifacts.js";
equal(XENO_ARTIFACT_CATALOG.length,16,"sixteen Xeno-Artifacts cataloged across eight chapters");
equal(new Set(XENO_ARTIFACT_CATALOG.map(a=>a.id)).size,16,"every Xeno-Artifact ID is unique");
for(let lvl=0;lvl<LEVELS.length;lvl++){
  const items=XENO_ARTIFACT_CATALOG.filter(a=>a.levelIndex===lvl);
  equal(items.length,2,`chapter ${lvl+1} contains two Xeno-Artifacts`);
  assert(items.every(a=>a.x>0&&a.x<LEVELS[lvl].width&&a.fieldNote.length>40),`chapter ${lvl+1} Xeno-Artifacts are in bounds with alien field guide descriptions`);
}

const artifactProfile=new ExpansionProfile();
const artWorld=new World(0,silentAudio,silentParticles,artifactProfile);
const firstArt=XENO_ARTIFACT_CATALOG.find(a=>a.levelIndex===0);
const collectorPlayer=new Player(firstArt.x-10,firstArt.y-16);
artWorld.update(collectorPlayer);
assert(artifactProfile.artifacts.has(firstArt.id),"walking onto an in-world Xeno-Artifact collects it");
equal(artifactProfile.artifacts.progress().found,1,"collected Xeno-Artifact increments collection progress");
assert(artifactProfile.artifacts.markRead(firstArt.id),"collected artifact can be marked read in the Field Guide");

const restoredArtifactProfile=new ExpansionProfile(artifactProfile.serialize());
assert(restoredArtifactProfile.artifacts.has(firstArt.id),"serialized Xeno-Artifacts restore across saves");
assert(restoredArtifactProfile.artifacts.list("collected")[0].read===true,"Field Guide read status persists across restore");

for(const entry of XENO_ARTIFACT_CATALOG.slice(0,8))restoredArtifactProfile.artifacts.collect(entry.id);
assert(restoredArtifactProfile.achievements.isUnlocked("xeno_curator"),"collecting eight unique Xeno-Artifacts unlocks xeno_curator achievement");

const emptyCol=new XenoArtifactCollection();
equal(emptyCol.list("uncollected").length,16,"uncollected filter returns full catalog before discovery");
console.log(`Narrative & Xeno-Artifact checks passed; total assertions: ${assertions}.`);

