import assert from "node:assert/strict";
import { World } from "../src/world.js";
import { Player } from "../src/player.js";
import { SaveManager } from "../src/save.js";
import { ExpansionProfile } from "../src/expansion/profile.js";
import { decryptText } from "../src/dialogue.js";
import {
  createMockAudio,
  createMockCanvasContext,
  createMockClock,
  createMockInput,
  createMockParticles,
  createMockStorage
} from "./mocks/runtime-mocks.js";
import { MOCK_INPUT_SCRIPTS, MOCK_PROFILES } from "./mocks/fixtures.js";

let assertions = 0;
const check = (cond, msg) => {
  assertions++;
  assert.ok(cond, msg);
};

// 1. Mock Profile Fixtures & Endgame Loadout Verification
const midProfile = new ExpansionProfile(MOCK_PROFILES.midGameExplorer);
const midPlayer = new Player(80, 420);
midProfile.applyPlayer(midPlayer);
check(midPlayer.weapon === "sonic_burst", "midGameExplorer fixture equips sonic_burst");
check(midPlayer.scanRadius === 440, "midGameExplorer fixture activates SETI array scan radius");

const endProfile = new ExpansionProfile(MOCK_PROFILES.endgameScienceMaster);
const endPlayer = new Player(80, 420);
endProfile.applyPlayer(endPlayer);
check(endPlayer.maxHealth === 5, "endgameScienceMaster fixture stacks toughened + heart_module to 5 hearts");
check(endPlayer.extraJumpUnlocked === true, "endgameScienceMaster fixture unlocks double jump boots");
check(endPlayer.dashCooldownMult === 0.7, "endgameScienceMaster fixture applies graviton_thrusters dash multiplier");

// 2. Scripted Input + Audio/Particle Spies + Deterministic Clock
const audioSpy = createMockAudio();
const particleSpy = createMockParticles();
const clock = createMockClock();
const inputScript = createMockInput(MOCK_INPUT_SCRIPTS.scoutSweep);
const world = new World(0, audioSpy, particleSpy, midProfile);
const hero = new Player(410, 441);
midProfile.applyPlayer(hero);
hero.update(createMockInput(), world, audioSpy, particleSpy);

for (let i = 0; i < MOCK_INPUT_SCRIPTS.scoutSweep.length; i++) {
  hero.update(inputScript, world, audioSpy, particleSpy);
  world.update(hero);
  inputScript.advanceFrame();
  clock.stepFrames(1);
}

check(audioSpy.count("scan") >= 1, "mock input script triggers SETI scan audio cue");
check(audioSpy.count("dash") >= 1, "mock input script triggers Star-Dash audio cue");
check(audioSpy.count("blast") >= 1, "mock input script fires Sonic Burst weapon audio cue");
check(audioSpy.count("jump") >= 1, "mock input script triggers jump audio cue");
check(particleSpy.totalBursts() >= 2, "mock particle spy captures scan and dash bursts");
check(world.expansion.exo.anomalies[0].analyzed === true, "scripted SETI scan analyzes backyard Alcubierre eddy");
check(world.projectiles.length >= 3, "scripted blast spawns 3 Sonic Burst projectiles");
check(clock.frame === MOCK_INPUT_SCRIPTS.scoutSweep.length, "mock clock tracks simulated frames cleanly");

// 3. Headless Canvas2D Rendering Spy Across Normal, Low-G, and Boss Worlds
const ctx = createMockCanvasContext();
for (const levelIdx of [0, 5, 7]) {
  ctx.reset();
  const profile = new ExpansionProfile(levelIdx === 7 ? MOCK_PROFILES.endgameScienceMaster : MOCK_PROFILES.midGameExplorer);
  const w = new World(levelIdx, createMockAudio(), createMockParticles(), profile);
  const p = new Player(100, 420);
  profile.applyPlayer(p);
  w.pushComms("fiona", `Telemetry check chapter ${levelIdx + 1}`);
  if (levelIdx === 7) profile.challenges.start("drone_sweep", p);
  w.update(p);
  w.draw(ctx);
  p.draw(ctx, w.camera);

  check(ctx.drawCount() > 50, `headless Canvas2D spy renders chapter ${levelIdx + 1} (${ctx.drawCount()} draw ops)`);
  const rendered = ctx.textsRendered();
  check(rendered.some((t) => t.includes("g ·")), `chapter ${levelIdx + 1} renders live Exo-Telemetry gravity readout`);
  check(rendered.some((t) => t.includes("DASH") || t.includes("CHARGING")), `chapter ${levelIdx + 1} renders Dash meter`);
}

// 4. Multi-Phase Boss Simulation Using Mock Audio/Particles
const bossWorld = new World(7, createMockAudio(), createMockParticles(), endProfile);
const bossHero = new Player(2150, 420);
bossWorld.boss.health = Math.ceil(bossWorld.boss.maxHealth * 0.25); // Force Critical / Unbound final phase
for (let f = 0; f < 40; f++) {
  bossWorld.update(bossHero);
}
check(Boolean(bossWorld.boss.phaseName), "boss mock simulation enters named BossPhaseController phase");
check(
  bossWorld.projectiles.some((proj) => proj.owner === "enemy") || bossWorld.comms !== null,
  "boss simulation emits attack projectiles or comms transitions"
);

// 5. Storage Mock Resilience (Normal Persistence + Write Failure Safety)
const healthyStorage = createMockStorage();
globalThis.localStorage = healthyStorage;
const saver = new SaveManager();
saver.completeLevel(4, 9);
check(healthyStorage.stats.writes >= 1, "mock storage records SaveManager writes");
check(JSON.parse(healthyStorage.getItem("uforphan-save-v1")).unlockedLevel >= 5, "mock storage persists unlocked chapter index");

const failingStorage = createMockStorage({}, { failWrites: true });
globalThis.localStorage = failingStorage;
const resilientSaver = new SaveManager();
const writeOk = resilientSaver.write();
check(writeOk === false && failingStorage.stats.failures >= 1, "SaveManager handles mock storage write failures safely");

// 6. Xeno-Artifact Headless Rendering & Pickup Telemetry Spy
import { XENO_ARTIFACT_CATALOG, drawXenoArtifact } from "../src/expansion/xeno-artifacts.js";
const glyphCtx = createMockCanvasContext();
for (const sample of XENO_ARTIFACT_CATALOG) {
  drawXenoArtifact(glyphCtx, { ...sample, collected: false }, 42, 0);
}
check(glyphCtx.drawCount() >= 32, `headless Canvas2D renders all 16 Xeno-Artifact glyphs (${glyphCtx.drawCount()} draw ops)`);

const relicAudio = createMockAudio();
const relicParticles = createMockParticles();
const relicProfile = new ExpansionProfile();
const relicWorld = new World(0, relicAudio, relicParticles, relicProfile);
const targetRelic = XENO_ARTIFACT_CATALOG.find((item) => item.levelIndex === 0);
const relicHunter = new Player(targetRelic.x - 10, targetRelic.y - 16);
const creditsBefore = relicProfile.economy.credits;
relicWorld.update(relicHunter);
check(relicProfile.artifacts.has(targetRelic.id), "mock runtime collects Xeno-Artifact when hero touches hitbox");
check(relicAudio.count("collect") >= 1, "mock audio spy captures Xeno-Artifact pickup cue");
check(relicParticles.totalBursts() >= 1, "mock particle spy captures Xeno-Artifact pickup burst");
check(relicProfile.economy.credits > creditsBefore, "recovering Xeno-Artifact awards Ranger Credits");
check(Boolean(relicWorld.comms?.text?.includes(targetRelic.catalogCode)), "Xeno-Artifact recovery pushes Field Guide comms alert");

// 7. D3 Signal Stability Telemetry Monitor & Curve Generation
import * as d3 from "d3";
import { SignalStabilityMonitor } from "../src/expansion/signal-stability.js";
const sigMonitor = new SignalStabilityMonitor(24);
const calmHero = new Player(40, 441);
const calmReading = sigMonitor.sample(relicWorld, calmHero, true);
check(calmReading.stability >= 8 && calmReading.stability <= 99.8, "SignalStabilityMonitor computes bounded stability reading");

const abductorSaucer = relicWorld.expansion.exo.saucers.find((s) => s.kind === "abductor");
abductorSaucer.invertedTicks = 0;
const beamHero = new Player(abductorSaucer.x - 10, 420);
const jammedReading = sigMonitor.sample(relicWorld, beamHero, true);
check(jammedReading.stability < calmReading.stability, "UFO abductor tractor beam interference measurably lowers signal stability");

const xScale = d3.scaleLinear().domain([sigMonitor.samples[0].index, sigMonitor.samples.at(-1).index]).range([6, 224]);
const yScale = d3.scaleLinear().domain([0, 100]).range([43, 5]);
const pathGen = d3.line().x((d) => xScale(d.index)).y((d) => yScale(d.stability)).curve(d3.curveMonotoneX);
const svgPath = pathGen(sigMonitor.samples);
check(typeof svgPath === "string" && svgPath.startsWith("M") && svgPath.length > 20, "D3 line generator builds continuous Signal Stability waveform path");

// 8. F-Key Scan Pulse Radiating From Fiona & Xeno-Artifact Discovery Highlight
const scanAudio = createMockAudio();
const scanParticles = createMockParticles();
const scanProfile = new ExpansionProfile();
const scanWorld = new World(0, scanAudio, scanParticles, scanProfile);
const targetScanRelic = scanWorld.expansion.artifacts[0];
const scanHero = new Player(targetScanRelic.x - 160, targetScanRelic.y - 16);
const fPressInput = createMockInput([{ press: ["scan"] }, { down: ["right"] }, { down: ["right"] }]);
for (let step = 0; step < 30; step++) {
  scanHero.update(fPressInput, scanWorld, scanAudio, scanParticles);
  scanWorld.update(scanHero);
  fPressInput.advanceFrame();
}
check(Boolean(scanWorld.expansion.exo.scanWave), "pressing scan radiates a wave centered on Fiona");
check(
  Math.abs(scanWorld.expansion.exo.scanWave.x - (scanHero.x + scanHero.w / 2)) < 1,
  "scan wave continuously tracks Fiona's center while radiating"
);
check(
  (targetScanRelic.scanPingTicks || 0) > 0,
  "scan pulse activates Xeno-Artifact resonance lock when passing nearby relic"
);
const pulseCtx = createMockCanvasContext();
scanWorld.expansion.exo.draw(pulseCtx, 0);
drawXenoArtifact(pulseCtx, targetScanRelic, 12, 0);
check(
  pulseCtx.textsRendered().some((text) => text.includes(targetScanRelic.catalogCode)),
  "pinged Xeno-Artifact renders discovery catalog lock label on canvas"
);

// 9. Hold-'F' Scan Charging Progress & Release Wind-Down
const holdAudio = createMockAudio();
const holdParticles = createMockParticles();
const holdProfile = new ExpansionProfile();
const holdWorld = new World(0, holdAudio, holdParticles, holdProfile);
const holdHero = new Player(120, 441);
const holdInput = createMockInput();
holdInput.hold("scan", true);
for (let f = 0; f < 15; f++) {
  holdHero.update(holdInput, holdWorld, holdAudio, holdParticles);
  holdWorld.update(holdHero);
}
check(
  Math.abs(holdWorld.expansion.exo.getScanProgress() - 0.5) < 0.05 && !holdWorld.expansion.exo.scanWave,
  "holding scan half-way fills circular progress toward 50% before firing pulse"
);
for (let f = 0; f < 15; f++) {
  holdHero.update(holdInput, holdWorld, holdAudio, holdParticles);
  holdWorld.update(holdHero);
}
check(
  Boolean(holdWorld.expansion.exo.scanWave) && holdAudio.count("scan") >= 1,
  "completing 100% hold fires SETI scan pulse and audio cue"
);

// 10. Cosmic Weather: Low Gravity Zones, Ion Storm Visibility & Signal Stability Scrambling
const weatherAudio = createMockAudio();
const weatherParticles = createMockParticles();
const weatherProfile = new ExpansionProfile();
const weatherWorld = new World(0, weatherAudio, weatherParticles, weatherProfile);
const lowGPlayer = new Player(1220, 400); // Inside Ch01 wake-low-g zone (1080..1600)
weatherWorld.update(lowGPlayer);
const lowGState = weatherWorld.expansion.weather.currentState();
check(
  lowGState.type === "low_gravity" && Math.abs(weatherWorld.gravityMultiplier() - 0.58) < 0.01,
  "Low Gravity Zone lowers world gravityMultiplier to 0.58g and sets active zone state"
);
check(
  lowGPlayer.speedMultiplier > 1.0,
  "Low Gravity Zone boosts horizontal movement speedMultiplier"
);

const ionWorld = new World(7, weatherAudio, weatherParticles, new ExpansionProfile());
const ionPlayer = new Player(260, 400); // Outside warden-low-g zone, experiencing Ion Storm base weather
ionWorld.update(ionPlayer);
const ionState = ionWorld.expansion.weather.currentState();
check(
  ionState.type === "ion" && ionState.visibility < 0.7 && ionPlayer.speedMultiplier < 1,
  "Ion Storm reduces atmospheric visibility and dampens movement speedMultiplier"
);
const weatherSignal = new SignalStabilityMonitor(24);
const ionReading = weatherSignal.sample(ionWorld, ionPlayer, true);
check(
  ionReading.status.code === "ION SCRAMBLE" && ionReading.weatherScramble >= 0.45,
  "Ion Storm scrambles Signal Stability HUD into ION SCRAMBLE alert state"
);
const weatherCtx = createMockCanvasContext();
weatherWorld.expansion.weather.drawZones(weatherCtx, weatherWorld.camera);
ionWorld.expansion.weather.draw(weatherCtx, 260, 400);
check(
  weatherCtx.textsRendered().some((t) => t.includes("LOW-G WAKE")),
  "Cosmic Weather renders world-space weather zone labels and atmospheric visibility shrouds"
);

// 11. Enhanced Visuals & Animations: Squash/Stretch, Shockwave Rings, Enemy/Boss & World Render
import { ParticleSystem } from "../src/particles.js";
const fxParticles = new ParticleSystem();
const fxWorld = new World(3, createMockAudio(), fxParticles, new ExpansionProfile());
const fxPlayer = new Player(100, 441);
fxPlayer.onGround = true;
const fxJumpInput = createMockInput([{ press: ["jump", "dash"] }]);
fxPlayer.update(fxJumpInput, fxWorld, createMockAudio(), fxParticles);
check(
  fxPlayer.scaleX !== 1 && fxPlayer.scaleY !== 1,
  "jump and Star-Dash trigger Fiona squash/stretch deformation"
);
check(
  fxParticles.rings.length >= 1,
  "Star-Dash emits expanding shockwave ring particles"
);
fxParticles.update();
const fxCtx = createMockCanvasContext();
fxWorld.draw(fxCtx);
fxPlayer.draw(fxCtx, fxWorld.camera);
fxParticles.draw(fxCtx);
check(
  fxCtx.drawCount() >= 80,
  `full animated World + Player + Enemy + Boss + Particle canvas pass succeeds (${fxCtx.drawCount()} draw ops)`
);

// 12. Distress Beacon Sub-System: Periodic Ping Audio, Light Pulses & Exit Gate Progression
const sosAudio = createMockAudio();
const sosParticles = createMockParticles();
const sosProfile = new ExpansionProfile();
const sosWorld = new World(0, sosAudio, sosParticles, sosProfile); // Ch01 has SOS-01
const sosHero = new Player(120, 441);
sosWorld.keys.forEach((k) => (k.collected = true));
check(
  !sosWorld.canExit(),
  "chapter with active Distress Beacon keeps exit locked even after keys are collected"
);
for (let f = 0; f < 30; f++) {
  sosWorld.update(sosHero);
}
const activeSos = sosWorld.expansion.distress.unresolved()[0];
check(
  sosAudio.count("distress") >= 1 && activeSos.pulses.length >= 1,
  "Distress Beacon emits periodic ping sound and visual light pulse waves"
);
const sosEdgeCtx = createMockCanvasContext();
sosWorld.draw(sosEdgeCtx);
check(
  sosEdgeCtx.textsRendered().some((t) => t.includes("SOS")),
  "offscreen Distress Beacon renders directional SOS edge bearing indicator"
);
sosHero.x = activeSos.x - 10;
sosHero.y = activeSos.y - 10;
const creditsBeforeSos = sosProfile.economy.credits;
const sosInteractRes = sosWorld.interact(sosHero);
check(
  sosInteractRes?.type === "distress" && sosWorld.canExit(),
  "following signal source and stabilizing Distress Beacon unlocks chapter exit"
);
check(
  sosProfile.economy.credits > creditsBeforeSos,
  "resolving Distress Beacon awards credits and XP"
);

const clearChapterWorld = new World(1, createMockAudio(), createMockParticles(), new ExpansionProfile());
clearChapterWorld.keys.forEach((k) => (k.collected = true));
check(
  clearChapterWorld.canExit(),
  "chapters without Distress Beacons unlock exit normally once keys are collected"
);

// 13. Smooth Camera Damping, Footstep Dust, Projectile Trails & Animated Pickups
const animWorld = new World(0, createMockAudio(), createMockParticles(), new ExpansionProfile());
const animPlayer = new Player(480, 441);
animWorld.update(animPlayer);
const camFrame1 = animWorld.camera;
animPlayer.x = 760;
animPlayer.facing = 1;
animWorld.update(animPlayer);
const camFrame2 = animWorld.camera;
check(
  camFrame2 > camFrame1 && camFrame2 < animPlayer.x - 100,
  "camera smoothly damps toward look-ahead target after initial frame snap"
);
animWorld.projectiles.push({ x: 640, y: 400, vx: 9, vy: -1, owner: "player", life: 30, damage: 1 });
animWorld.expansion.loot.dropFrom("drone", 620, 420);
const animCtx = createMockCanvasContext();
animWorld.draw(animCtx);
animPlayer.muzzleTicks = 4;
animPlayer.draw(animCtx, animWorld.camera);
check(
  animCtx.drawCount() >= 40,
  `animated projectiles, diamond loot crystals, and articulated blaster render cleanly (${animCtx.drawCount()} draw ops)`
);

// 14. Alien Field Guide Terminal Decryption Effect
const mockClasses = new Set();
const mockLoreEl = {
  textContent: "",
  classList: {
    add: (cls) => mockClasses.add(cls),
    remove: (cls) => mockClasses.delete(cls)
  }
};
let decryptDone = false;
const targetLore = "Casimir resonance detected inside backyard garden gnome.";
const decryptJob = decryptText(mockLoreEl, targetLore, {
  delayMs: 25,
  durationMs: 320,
  onComplete: () => {
    decryptDone = true;
  }
});
check(
  mockClasses.has("is-decrypting") && mockLoreEl.textContent.length > 0 && mockLoreEl.textContent !== targetLore,
  "decryptText initializes scrambled terminal cipher state with is-decrypting class"
);
decryptJob.cancel();
check(
  !mockClasses.has("is-decrypting") && mockLoreEl.textContent === targetLore && decryptDone,
  "decryptText cleanly resolves exact lore text, clears class, and fires onComplete on cancel"
);

console.log(`UFOrphan mock test suite passed: ${assertions} assertions across mocks & scenarios.`);
