# Manual acceptance checklist

## Launch and navigation
- [ ] Page loads at desktop width without horizontal overflow.
- [ ] Page loads at mobile width and touch controls are visible.
- [ ] Main menu appears on first load.
- [ ] Start Rescue begins the currently unlocked chapter.
- [ ] How to Play explains movement, jumping, blasting and keycards.
- [ ] Pause button and Escape both pause the game.
- [ ] Resume returns to the active level.
- [ ] Restart Level resets the chapter.

## Movement
- [ ] Left and right keys move Fiona in the expected direction.
- [ ] A and D are alternate movement keys.
- [ ] Space, W and Up jump when Fiona is grounded.
- [ ] Fiona cannot jump repeatedly while airborne.
- [ ] Fiona collides with the sides of platforms.
- [ ] Fiona lands on top of platforms.
- [ ] Camera follows Fiona through a scrolling level.
- [ ] Fiona cannot walk beyond the level's left or right bounds.

## Combat and hazards
- [ ] X and J fire a star-blast.
- [ ] The blast cooldown prevents continuous firing.
- [ ] Player projectiles damage enemies.
- [ ] Enemy projectiles damage Fiona.
- [ ] Contact with an enemy reduces health.
- [ ] Contact with a hazard reduces health.
- [ ] Temporary invulnerability prevents repeated immediate damage.
- [ ] Zero health displays the game-over panel.

## Collectibles and progression
- [ ] Stardust increments the HUD counter.
- [ ] Keycards increment the keycard counter.
- [ ] Portal remains unavailable while keycards remain.
- [ ] Final portal remains unavailable while the boss is alive.
- [ ] Completing a chapter unlocks the next chapter.
- [ ] Best stardust count persists after refresh.
- [ ] Sound preference persists after refresh.
- [ ] Reset Save clears progression.

## Final encounter
- [ ] Boss health bar is visible.
- [ ] Boss periodically fires projectiles.
- [ ] Player blasts reduce boss health.
- [ ] Defeating the boss unlocks the exit.
- [ ] Final victory panel appears after reaching the exit.
