import { LEVELS } from "../src/levels.js";
import { validateLevelSet } from "../src/expansion/level-validator.js";
const report=validateLevelSet(LEVELS);
if(!report.valid)throw new Error(JSON.stringify(report,null,2));
for(const level of LEVELS){
  if(!level.expansion && Number(level.chapter)>=5)throw new Error(`${level.id} is missing expansion runtime data`);
  if(level.expansion?.npcs?.some(npc=>!npc.id||!npc.kind))throw new Error(`${level.id} has invalid NPC data`);
}
console.log(`Level validation passed for ${report.summary.levels} chapters.`);
