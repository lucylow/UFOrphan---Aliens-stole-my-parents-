// Run in a browser console after the game has loaded.
import("../src/levels.js").then(({LEVELS}) => {
  console.assert(LEVELS.length >= 4, "Expected at least four chapters");
  for (const level of LEVELS) {
    console.assert(level.width >= 960, `${level.id}: world should be wider than the viewport`);
    console.assert(level.platforms.length > 0, `${level.id}: missing platforms`);
    console.assert(level.exit && level.checkpoint, `${level.id}: missing progression objects`);
    console.assert(level.stars.length > 0, `${level.id}: missing stardust`);
    console.assert(level.keys.length > 0, `${level.id}: missing keycards`);
    for (const [x,y,w,h] of level.platforms) {
      console.assert(w > 0 && h > 0 && x >= 0 && y >= 0, `${level.id}: invalid platform`);
    }
  }
  console.info("UFOrphan level data smoke test complete.");
});
