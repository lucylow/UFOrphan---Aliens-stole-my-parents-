/**
 * Browser smoke tests for standalone UFOrphan runtime utilities.
 * Import this module from the devtools console or a local test page.
 */
import { intersects, overlapArea, centerOf, distance, containsPoint } from "../src/collision.js";
import { EventBus } from "../src/event-bus.js";
import { TimerManager } from "../src/timer-manager.js";
import { StateMachine } from "../src/state-machine.js";
import { Random } from "../src/random.js";
import { Camera } from "../src/camera.js";
import { AnimationClip } from "../src/animation.js";
import { ObjectPool } from "../src/object-pool.js";
import { InputRecorder } from "../src/input-recorder.js";
import { ScoreManager } from "../src/score-manager.js";
import { validateLevel } from "../src/level-validator.js";
import { LEVELS } from "../src/levels.js";

function assert(condition,message) {
  if(!condition)throw new Error(`UFOrphan test failed: ${message}`);
}
function equal(actual,expected,message) {
  assert(actual===expected,`${message}; expected ${expected}, got ${actual}`);
}

export function runUtilityTests() {
  const a={x:0,y:0,w:10,h:10},b={x:5,y:5,w:10,h:10};
  assert(intersects(a,b),"rectangle intersection");
  equal(overlapArea(a,b),25,"overlap area");
  equal(centerOf(a).x,5,"rectangle center");
  equal(distance({x:0,y:0},{x:3,y:4}),5,"euclidean distance");
  assert(containsPoint(a,{x:5,y:5}),"point containment");

  const bus=new EventBus();let received=0;
  const off=bus.on("score",()=>received++);
  bus.emit("score",{amount:10});off();bus.emit("score",{amount:10});
  equal(received,1,"event unsubscribe");

  const timers=new TimerManager();let fired=0;
  timers.after(2,()=>fired++);timers.update();timers.update();
  equal(fired,1,"frame timer");

  const machine=new StateMachine({initial:"menu",transitions:{menu:["play"],play:["pause"],pause:["play"]}});
  machine.transition("play");machine.transition("pause");
  equal(machine.state,"pause","state transition");

  const randomA=new Random(123),randomB=new Random(123);
  equal(randomA.next(),randomB.next(),"seeded random reproducibility");

  const camera=new Camera({width:100,height:100,worldWidth:300});
  camera.follow({x:200,y:50,w:10,h:10});
  for(let i=0;i<50;i++)camera.update();
  assert(camera.x>0&&camera.x<=200,"camera follows and clamps");

  const clip=new AnimationClip({frames:["a","b"],frameDuration:1,loop:false});
  clip.update();clip.update();
  equal(clip.frame,"b","animation final frame");

  const pool=new ObjectPool(()=>({value:0}));
  const item=pool.acquire({value:5});pool.release(item);
  equal(pool.activeCount,0,"pool release");

  const recorder=new InputRecorder();recorder.start();recorder.record({left:true});
  const replay=recorder.stop();const replayCopy=new InputRecorder();replayCopy.import(replay);
  assert(replayCopy.next().left,"input replay");

  const score=new ScoreManager();score.star("one");score.star("one");
  equal(score.score,100,"duplicate score protection");

  for(const level of LEVELS)assert(validateLevel(level).valid,`level ${level.id} validates`);
  return {passed:true,assertions:20};
}

console.info("Run runUtilityTests() to execute UFOrphan utility assertions.");
