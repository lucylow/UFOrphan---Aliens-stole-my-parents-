import { runUtilityTests } from "./runtime-tests.js";
const result=runUtilityTests();
if(!result.passed)throw new Error("Original utility test suite failed");
console.log(`Original utility tests passed: ${result.assertions} assertions.`);
