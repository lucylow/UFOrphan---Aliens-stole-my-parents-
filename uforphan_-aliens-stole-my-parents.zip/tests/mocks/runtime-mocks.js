/**
 * Reusable mock factories, spies, and test doubles for headless Node simulation
 * of UFOrphan's canvas rendering, audio synthesis, particle bursts, input scripts,
 * localStorage persistence, and frame timing.
 */

export function createMockCanvasContext() {
  const calls = [];
  const gradientStub = { addColorStop() {} };
  const record = (op, args = []) => calls.push({ op, args });

  return {
    calls,
    fillStyle: "#000000",
    strokeStyle: "#000000",
    lineWidth: 1,
    globalAlpha: 1,
    font: "10px monospace",
    textAlign: "left",
    shadowColor: "transparent",
    shadowBlur: 0,
    imageSmoothingEnabled: false,
    save() { record("save"); },
    restore() { record("restore"); },
    translate(x, y) { record("translate", [x, y]); },
    rotate(angle) { record("rotate", [angle]); },
    scale(x, y) { record("scale", [x, y]); },
    beginPath() { record("beginPath"); },
    closePath() { record("closePath"); },
    moveTo(x, y) { record("moveTo", [x, y]); },
    lineTo(x, y) { record("lineTo", [x, y]); },
    bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) { record("bezierCurveTo", [cp1x, cp1y, cp2x, cp2y, x, y]); },
    quadraticCurveTo(cpx, cpy, x, y) { record("quadraticCurveTo", [cpx, cpy, x, y]); },
    arc(x, y, r, s, e) { record("arc", [x, y, r, s, e]); },
    ellipse(x, y, rx, ry, rot, s, e) { record("ellipse", [x, y, rx, ry, rot, s, e]); },
    rect(x, y, w, h) { record("rect", [x, y, w, h]); },
    roundRect(x, y, w, h, r) { record("roundRect", [x, y, w, h, r]); },
    fillRect(x, y, w, h) { record("fillRect", [x, y, w, h]); },
    strokeRect(x, y, w, h) { record("strokeRect", [x, y, w, h]); },
    clearRect(x, y, w, h) { record("clearRect", [x, y, w, h]); },
    fill() { record("fill"); },
    stroke() { record("stroke"); },
    fillText(text, x, y, maxW) { record("fillText", [String(text), x, y, maxW]); },
    createLinearGradient() { return gradientStub; },
    createRadialGradient() { return gradientStub; },
    drawCount(op) {
      return op ? calls.filter((c) => c.op === op).length : calls.length;
    },
    textsRendered() {
      return calls.filter((c) => c.op === "fillText").map((c) => c.args[0]);
    },
    reset() {
      calls.length = 0;
    }
  };
}

export function createMockAudio() {
  const events = [];
  const cue = (name) => (...args) => events.push({ name, args, index: events.length });

  return {
    enabled: true,
    events,
    unlock: cue("unlock"),
    toggle() {
      this.enabled = !this.enabled;
      return this.enabled;
    },
    jump: cue("jump"),
    collect: cue("collect"),
    blast: cue("blast"),
    dash: cue("dash"),
    radio: cue("radio"),
    scan: cue("scan"),
    distress: cue("distress"),
    beam: cue("beam"),
    hurt: cue("hurt"),
    win: cue("win"),
    click: cue("click"),
    count(name) {
      return events.filter((e) => e.name === name).length;
    },
    reset() {
      events.length = 0;
    }
  };
}

export function createMockParticles() {
  const bursts = [];
  return {
    items: [],
    bursts,
    burst(x, y, color, count = 8, speed = 2.5) {
      bursts.push({ x, y, color, count, speed });
    },
    update() {},
    draw() {},
    totalBursts() {
      return bursts.length;
    },
    reset() {
      bursts.length = 0;
    }
  };
}

export function createMockInput(timeline = []) {
  const held = new Set();
  const pressed = new Set();
  let frame = 0;

  return {
    get frame() {
      return frame;
    },
    hold(action, active = true) {
      if (active) held.add(action);
      else held.delete(action);
    },
    press(action) {
      pressed.add(action);
    },
    isDown(action) {
      const scripted = timeline[frame]?.down || [];
      return held.has(action) || scripted.includes(action);
    },
    wasPressed(action) {
      const scripted = timeline[frame]?.press || [];
      return pressed.has(action) || scripted.includes(action);
    },
    advanceFrame() {
      pressed.clear();
      frame++;
    },
    clearAll() {
      held.clear();
      pressed.clear();
    }
  };
}

export function createMockStorage(initial = {}, { failWrites = false } = {}) {
  const store = new Map(
    Object.entries(initial).map(([k, v]) => [k, typeof v === "string" ? v : JSON.stringify(v)])
  );
  const stats = { reads: 0, writes: 0, failures: 0 };

  return {
    stats,
    getItem(key) {
      stats.reads++;
      return store.has(key) ? store.get(key) : null;
    },
    setItem(key, value) {
      stats.writes++;
      if (failWrites) {
        stats.failures++;
        throw new Error("Mock storage write failure");
      }
      store.set(key, String(value));
    },
    removeItem(key) {
      store.delete(key);
    },
    snapshot() {
      return Object.fromEntries(store.entries());
    }
  };
}

export function createMockClock(startMs = 1_700_000_000_000) {
  let nowMs = startMs;
  let frame = 0;
  return {
    now: () => nowMs,
    get frame() {
      return frame;
    },
    advance(ms) {
      nowMs += ms;
      return nowMs;
    },
    stepFrames(count = 1, stepMs = 1000 / 60) {
      frame += count;
      nowMs += Math.round(count * stepMs);
      return frame;
    }
  };
}
