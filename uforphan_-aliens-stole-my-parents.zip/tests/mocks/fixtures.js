/**
 * Prebuilt profile snapshots and deterministic scenario fixtures for testing
 * UFOrphan progression, UFO science interactions, boss phases, and rendering.
 */

export const MOCK_PROFILES = Object.freeze({
  freshRanger: {
    inventory: { capacity: 24, slots: [], equipment: { weapon: null, boots: null, shield: null } },
    progression: { xp: 0, level: 1, skillPoints: 0, skills: {} },
    economy: { credits: 100 },
    completedLevels: []
  },
  midGameExplorer: {
    inventory: {
      capacity: 24,
      slots: [
        { id: "stardust", count: 18 },
        { id: "ion_cell", count: 6 },
        { id: "copper_coil", count: 5 },
        { id: "resonant_crystal", count: 2 },
        { id: "sonic_module", count: 1 },
        { id: "med_patch", count: 2 }
      ],
      equipment: { weapon: "sonic_module", boots: null, shield: null }
    },
    progression: { xp: 45, level: 3, skillPoints: 1, skills: { light_feet: 1, charged_shot: 1 } },
    economy: { credits: 340 },
    upgrades: { owned: ["seti_array"], temporary: [] },
    companions: { unlocked: ["mothlet", "pebble", "zip"], active: "pebble" },
    completedLevels: [0, 1, 2],
    statistics: { stars: 26, keys: 6, enemies: 11, seconds: 240 }
  },
  endgameScienceMaster: {
    inventory: {
      capacity: 24,
      slots: [
        { id: "stardust", count: 44 },
        { id: "e115_shard", count: 5 },
        { id: "plasma_lens", count: 1 },
        { id: "sonic_module", count: 1 },
        { id: "double_jump", count: 1 },
        { id: "family_photo", count: 1 }
      ],
      equipment: { weapon: "plasma_lens", boots: "double_jump", shield: null }
    },
    progression: { xp: 10, level: 6, skillPoints: 2, skills: { light_feet: 2, toughened: 1, charged_shot: 2 } },
    economy: { credits: 920 },
    upgrades: {
      owned: ["reinforced_boots", "focus_lens", "heart_module", "magnet_coil", "graviton_thrusters", "seti_array"],
      temporary: []
    },
    companions: { unlocked: ["mothlet", "pebble", "zip"], active: "zip" },
    codex: {
      unlocked: [
        "fiona",
        "pip",
        "rivet",
        "mothlet",
        "pebble",
        "zip",
        "wow_signal",
        "alcubierre_wake",
        "element_115",
        "drake_equation",
        "roche_limit",
        "panspermia_flora"
      ]
    },
    completedLevels: [0, 1, 2, 3, 4, 5, 6],
    statistics: { stars: 72, keys: 16, enemies: 35, seconds: 680 }
  }
});

/** Deterministic multi-frame input scripts covering dash, scan, blast, and movement. */
export const MOCK_INPUT_SCRIPTS = Object.freeze({
  scoutSweep: [
    { down: ["right"], press: ["scan"] },
    { down: ["right"], press: [] },
    { down: ["right"], press: ["dash"] },
    { down: ["right"], press: [] },
    { down: [], press: ["blast"] },
    { down: [], press: ["jump"] }
  ],
  platformHop: [
    { down: ["right"], press: ["jump"] },
    { down: ["right"], press: [] },
    { down: ["right"], press: [] },
    { down: ["right"], press: ["jump"] }
  ]
});
