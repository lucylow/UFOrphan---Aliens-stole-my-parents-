import { escapeHTML, formatNumber, percent } from "../core/utils.js";
export const el=(tag,attrs={},children="")=>{const node=document.createElement(tag);for(const [key,value] of Object.entries(attrs)){if(key==="class")node.className=value;else if(key.startsWith("on")&&typeof value==="function")node.addEventListener(key.slice(2).toLowerCase(),value);else if(value!==false&&value!=null)node.setAttribute(key,value===true?"":String(value));}if(typeof children==="string")node.innerHTML=children;else if(children)node.append(children);return node;};
export const button=(label,action,kind="secondary")=>el("button",{class:`ft-button ft-${kind}`,type:"button",onclick:action},escapeHTML(label));
export const card=(title,content,icon="✦")=>el("section",{class:"ft-card"},`<div class="ft-card-head"><span class="ft-card-icon">${escapeHTML(icon)}</span><h3>${escapeHTML(title)}</h3></div><div class="ft-card-body">${content}</div>`);
export const stat=(label,value,icon="✦")=>`<div class="ft-stat"><span>${icon}</span><div><strong>${escapeHTML(value)}</strong><small>${escapeHTML(label)}</small></div></div>`;
export const progress=(value,total)=>`<div class="ft-progress"><span style="width:${percent(value,total)}%"></span></div>`;
export const empty=(title,description)=>`<div class="ft-empty"><span>✧</span><strong>${escapeHTML(title)}</strong><p>${escapeHTML(description)}</p></div>`;
export const pill=(label,kind="neutral")=>`<span class="ft-pill ft-pill-${kind}">${escapeHTML(label)}</span>`;
export const money=value=>`${formatNumber(value)} CR`;
