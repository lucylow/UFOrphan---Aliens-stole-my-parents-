import { renderDashboard } from "./dashboard.js";
import { renderInventory } from "./inventory.js";
import { renderMissions } from "./missions.js";
import { renderMap } from "./map.js";
import { renderCodex } from "./codex.js";
import { renderEquipment } from "./equipment.js";
import { renderCrafting } from "./crafting.js";
import { renderShop } from "./shop.js";
import { renderAchievements } from "./achievements.js";
import { renderStatistics } from "./statistics.js";
import { renderProfiles } from "./profiles.js";
import { renderSettings } from "./settings.js";
const VIEWS={dashboard:renderDashboard,inventory:renderInventory,missions:renderMissions,map:renderMap,codex:renderCodex,equipment:renderEquipment,crafting:renderCrafting,shop:renderShop,achievements:renderAchievements,statistics:renderStatistics,profiles:renderProfiles,settings:renderSettings};
export function renderView(app,host,actions){const view=VIEWS[app.router.current()]||VIEWS.dashboard;view(app,host,actions);}
