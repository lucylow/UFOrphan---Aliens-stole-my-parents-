import { hit } from "./player.js";

export class Enemy {
  constructor(type, x, y) {
    this.type = type;
    this.x = x;
    this.y = y;
    this.w = type === "drone" ? 34 : 31;
    this.h = type === "drone" ? 25 : 28;
    this.startX = x;
    this.vx = type === "drone" ? 1.15 : 0.8;
    this.range = type === "drone" ? 95 : 65;
    this.health = type === "drone" ? 2 : 1;
    this.phase = Math.random() * 6;
    this.hitFlash = 0;
    this.dead = false;
  }

  update(world, player) {
    this.phase += 0.08;
    if (this.hitFlash > 0) this.hitFlash--;
    this.x += this.vx;
    if (Math.abs(this.x - this.startX) > this.range) this.vx *= -1;
    if (this.type === "drone") this.y += Math.sin(this.phase) * 0.55;
    if (hit(this, player)) player.takeDamage(world.audio, world.particles);
  }

  damage(world, amount = 1) {
    this.health -= amount;
    this.hitFlash = 8;
    world.particles.burst(this.x + this.w / 2, this.y + this.h / 2, "#ff8bcb", 8);
    if (this.health <= 0) {
      this.dead = true;
      world.particles?.ring?.(this.x + this.w / 2, this.y + this.h / 2, "#ff8bcb", 24, 14);
    }
  }

  draw(ctx, camera = 0) {
    const x = this.x - camera;
    const y = this.y;
    const flashed = this.hitFlash > 0;
    const hitShakeX = flashed ? Math.sin(this.hitFlash * 2.4) * 2.5 : 0;
    ctx.save();
    if (this.type === "drone") {
      const cx = x + 17 + hitShakeX;
      const cy = y + 12;
      const tilt = Math.max(-0.18, Math.min(0.18, this.vx * 0.12));
      ctx.fillStyle = "rgba(6, 10, 26, 0.28)";
      ctx.beginPath();
      ctx.ellipse(cx, cy + 23, 12 + Math.sin(this.phase * 2) * 1.5, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.translate(cx, cy);
      ctx.rotate(tilt);

      // Spinning top hover rotor blades
      const rotorW = 6 + Math.abs(Math.cos(this.phase * 7)) * 12;
      ctx.fillStyle = "rgba(166, 232, 255, 0.55)";
      ctx.fillRect(-rotorW, -13, rotorW * 2, 2);
      ctx.fillStyle = "#526b9d";
      ctx.fillRect(-1.5, -13, 3, 4);

      // Antigrav underside thruster glow
      const glowAlpha = 0.25 + (Math.sin(this.phase * 2.5) + 1) * 0.18;
      ctx.fillStyle = `rgba(110, 242, 233, ${glowAlpha})`;
      ctx.beginPath();
      ctx.ellipse(0, 11, 11, 3.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Main hull & metallic highlight
      ctx.fillStyle = flashed ? "#ffffff" : "#89a4e0";
      ctx.beginPath();
      ctx.ellipse(0, 0, 17, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = flashed ? "#ffffff" : "rgba(232, 242, 255, 0.35)";
      ctx.beginPath();
      ctx.ellipse(-3, -4, 9, 3.5, -0.15, 0, Math.PI * 2);
      ctx.fill();

      // Sweeping scanner eyes
      const eyeShift = Math.sin(this.phase * 1.3) * 1.8;
      ctx.fillStyle = "#ff688f";
      ctx.fillRect(-8 + eyeShift, -3, 5, 4);
      ctx.fillRect(4 + eyeShift, -3, 5, 4);

      // Swaying stabilizer struts
      const sway = Math.sin(this.phase * 1.8) * 1.8;
      ctx.strokeStyle = "#6ef2e9";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-12, 9);
      ctx.lineTo(-16 + sway, 17);
      ctx.moveTo(12, 9);
      ctx.lineTo(16 - sway, 17);
      ctx.stroke();
    } else {
      const squish = Math.sin(this.phase * 1.6) * 2.1;
      const hop = Math.max(0, Math.sin(this.phase * 1.6)) * 3.5;
      const cx = x + 15 + hitShakeX;
      const cy = y + 17 - hop;

      // Ground shadow shrinks during hop
      ctx.fillStyle = "rgba(6, 10, 26, 0.34)";
      ctx.beginPath();
      ctx.ellipse(cx, y + 27, 13 - hop * 0.6, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = flashed ? "#ffffff" : "#9e6bd2";
      ctx.beginPath();
      ctx.ellipse(cx, cy + squish * 0.4, 15 + squish, 11 - squish * 0.45, 0, 0, Math.PI * 2);
      ctx.fill();
      // Glossy top rim
      ctx.fillStyle = flashed ? "#ffffff" : "rgba(255, 224, 250, 0.32)";
      ctx.beginPath();
      ctx.ellipse(cx - 4, cy - 4 + squish * 0.2, 6, 3, -0.25, 0, Math.PI * 2);
      ctx.fill();

      const look = this.vx >= 0 ? 1.5 : -1.5;
      ctx.fillStyle = "#f7b8ed";
      ctx.fillRect(cx - 8 + look, cy - 5, 5, 4);
      ctx.fillRect(cx + 3 + look, cy - 5, 5, 4);
      ctx.fillStyle = "#d6a5ee";
      const footStride = Math.sin(this.phase * 3.2) * 2;
      ctx.fillRect(cx - 11 - footStride, y + 24 - hop * 0.5, 5, 4);
      ctx.fillRect(cx + 6 + footStride, y + 24 - hop * 0.5, 5, 4);
    }
    ctx.restore();
  }
}

export class Boss {
  constructor(data) {
    this.x = data.x;
    this.y = data.y;
    this.baseY = data.y;
    this.w = 90;
    this.h = 88;
    this.health = data.health;
    this.maxHealth = data.health;
    this.phase = 0;
    this.cooldown = 80;
    this.hitFlash = 0;
    this.phaseName = "";
    this.dead = false;
  }

  update(world, player) {
    this.phase += 0.035;
    if (this.hitFlash > 0) this.hitFlash--;
    this.y = this.baseY + Math.sin(this.phase) * 22;
    if (!world.expansion?.bossController) {
      this.cooldown--;
      if (this.cooldown <= 0) {
        world.projectiles.push({
          x: this.x,
          y: this.y + 40,
          w: 10,
          h: 10,
          vx: -4.4,
          vy: Math.sin(this.phase) * 1.5,
          life: 100,
          owner: "enemy"
        });
        this.cooldown = 85;
      }
    }
    if (hit(this, player)) player.takeDamage(world.audio, world.particles);
  }

  damage(world, amount = 1) {
    this.health -= amount;
    this.hitFlash = 7;
    world.particles.burst(this.x + 45, this.y + 40, "#ffcf6c", 12);
    if (this.health <= 0) {
      this.dead = true;
      world.particles.burst(this.x + 45, this.y + 40, "#ff668d", 24, 5.2);
      world.particles?.ring?.(this.x + 45, this.y + 40, "#ff668d", 68, 24);
      world.audio?.win?.();
    }
  }

  draw(ctx, camera = 0) {
    const x = this.x - camera;
    const y = this.y;
    const enraged = this.health / Math.max(1, this.maxHealth) < 0.5;
    const pulse = (Math.sin(this.phase * (enraged ? 4.5 : 2.2)) + 1) * 0.5;
    const clawSwing = Math.sin(this.phase * 2.5) * 4;

    ctx.save();
    // Hovering graviton field rings below boss hull
    for (let r = 0; r < 2; r++) {
      const ringT = (this.phase * 0.6 + r * 0.5) % 1;
      ctx.strokeStyle = `rgba(${enraged ? "255, 102, 141" : "141, 244, 238"}, ${(1 - ringT) * 0.45})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(x + 45, y + 76 + ringT * 18, 28 + ringT * 14, 5, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Main carapace
    ctx.fillStyle = this.hitFlash > 0 ? "#ffffff" : enraged ? "#b05e9c" : "#9b75c9";
    ctx.beginPath();
    ctx.roundRect(x, y, 90, 70, 18);
    ctx.fill();

    // Glowing crown visor + chest reactor core
    ctx.fillStyle = "#d5c6ff";
    ctx.fillRect(x + 12, y + 12, 66, 12);
    ctx.fillStyle = enraged ? "#ff668d" : "#73f0ed";
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 10 + pulse * 8;
    ctx.beginPath();
    ctx.arc(x + 45, y + 40, 7 + pulse * 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Animated scanning eyes
    const eyeSweep = Math.sin(this.phase * 2.4) * 3;
    ctx.fillStyle = "#ff668d";
    ctx.fillRect(x + 18 + eyeSweep, y + 28, 15, 8);
    ctx.fillRect(x + 57 + eyeSweep, y + 28, 15, 8);

    ctx.fillStyle = "#5b477e";
    ctx.fillRect(x + 35, y + 54, 20, 7);

    // Articulated plasma claws + rotating outer energy shield arcs
    ctx.strokeStyle = enraged ? "#ff8fd8" : "#8df4ee";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x + 12, y + 65);
    ctx.lineTo(x + 2 - clawSwing, y + 83);
    ctx.moveTo(x + 78, y + 65);
    ctx.lineTo(x + 88 + clawSwing, y + 83);
    ctx.stroke();

    ctx.strokeStyle = enraged ? "rgba(255, 102, 141, 0.45)" : "rgba(115, 240, 237, 0.36)";
    ctx.lineWidth = 2;
    for (let s = 0; s < 2; s++) {
      const a0 = this.phase * (enraged ? 2.4 : 1.3) + s * Math.PI;
      ctx.beginPath();
      ctx.arc(x + 45, y + 36, 56, a0, a0 + 0.9);
      ctx.stroke();
    }
    ctx.restore();
  }
}
