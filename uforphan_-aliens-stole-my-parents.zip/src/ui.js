import { SignalStabilityMonitor, SignalStabilityChart } from "./expansion/signal-stability.js";

export class UI {
  constructor() {
    this.overlay = document.getElementById("overlay");
    this.panelTitle = document.getElementById("panelTitle");
    this.panelText = document.getElementById("panelText");
    this.panelEyebrow = document.getElementById("panelEyebrow");
    this.panelSymbol = document.getElementById("panelSymbol");
    this.panelExtra = document.getElementById("panelExtra");
    this.panelActions = document.getElementById("panelActions");
    this.startButton = document.getElementById("startButton");
    this.howButton = document.getElementById("howButton");
    this.health = document.getElementById("healthValue");
    this.stars = document.getElementById("starValue");
    this.keys = document.getElementById("keyValue");
    this.artifacts = document.getElementById("artifactValue");
    this.relicsStat = document.getElementById("relicsStat");
    this.scanRingFill = document.getElementById("scanRingFill");
    this.artifactScanLabel = document.getElementById("artifactScanLabel");
    this.levelName = document.getElementById("levelName");
    this.objective = document.getElementById("objective");
    this.title = document.getElementById("screenTitle");
    this.subtitle = document.getElementById("screenSubtitle");
    this.chapter = document.getElementById("chapterLabel");
    this.chapterPill = document.getElementById("chapterPill");
    this.saveStatus = document.getElementById("saveStatus");
    this.lastStats = {};
    this.signalMonitor = new SignalStabilityMonitor(44);
    const signalMount = document.getElementById("signalStabilityMount");
    this.signalChart = signalMount ? new SignalStabilityChart(signalMount) : null;
    this.signalChart?.render(this.signalMonitor, 0);
  }

  setStatText(key, el, nextText) {
    if (!el) return;
    const prev = this.lastStats[key];
    if (prev !== nextText) {
      el.textContent = nextText;
      this.lastStats[key] = nextText;
      if (prev !== undefined && el.classList) {
        el.classList.remove("is-pop");
        void el.offsetWidth;
        el.classList.add("is-pop");
      }
    }
  }

  resetSignal(levelIndex = 0) {
    this.signalMonitor.reset(levelIndex);
    this.signalChart?.render(this.signalMonitor, levelIndex);
  }

  showPanel({ eyebrow = "MISSION CONTROL", title, text, symbol = "✦", extra = null, actions = [] }) {
    this.panelEyebrow.textContent = eyebrow;
    this.panelTitle.textContent = title;
    this.panelText.textContent = text;
    this.panelSymbol.textContent = symbol;
    if (this.panelExtra) {
      this.panelExtra.innerHTML = "";
      if (extra) this.panelExtra.append(extra);
    }
    this.panelActions.innerHTML = "";
    for (const action of actions) {
      const button = document.createElement("button");
      button.className = action.primary ? "primary-button" : "secondary-button";
      button.textContent = action.label;
      button.addEventListener("click", action.onClick);
      this.panelActions.append(button);
    }
    this.overlay.classList.remove("hidden");
  }

  hidePanel() {
    this.overlay.classList.add("hidden");
  }

  updateHUD(player, world) {
    this.setStatText("health", this.health, `${player.health}/${player.maxHealth}`);
    this.setStatText("stars", this.stars, `${player.stars}/${world.stars.length}`);
    this.setStatText("keys", this.keys, `${player.keys}/${world.keys.length}`);
    if (this.artifacts && world.profile?.artifacts) {
      const artProg = world.profile.artifacts.progress();
      this.setStatText("artifacts", this.artifacts, `${artProg.found}/${artProg.total}`);
    }
    const exo = world.expansion?.exo;
    const scanProgress = exo?.getScanProgress?.() ?? 0;
    const isCharging = (exo?.scanHoldTicks || 0) > 0;
    const isPulsing = Boolean(exo?.scanWave);
    if (this.scanRingFill) {
      const circumference = 69.115;
      this.scanRingFill.style.strokeDashoffset = (circumference * (1 - scanProgress)).toFixed(2);
    }
    if (this.relicsStat) {
      this.relicsStat.classList.toggle("is-charging", isCharging);
      this.relicsStat.classList.toggle("is-pulsing", isPulsing && !isCharging);
    }
    if (this.artifactScanLabel) {
      this.artifactScanLabel.textContent = isCharging
        ? `SCANNING ${Math.round(scanProgress * 100)}%`
        : isPulsing
          ? "PULSE ACTIVE"
          : "XENO-ARTIFACTS";
    }
    const lv = world.profile?.progression?.level;
    const compId = world.expansion?.companion?.active;
    const compName = compId ? compId.toUpperCase() : "";
    const wState = world.expansion?.weather?.currentState?.();
    const metaParts = [world.data.name];
    if (lv) metaParts.push(`LV ${lv}`);
    if (compName) metaParts.push(compName);
    if (wState && wState.type !== "clear") {
      metaParts.push(wState.zoneLabel || wState.code);
    }
    this.levelName.textContent = metaParts.join(" · ");
    const remaining = world.keys.filter((k) => !k.collected).length;
    const sosRemaining = world.expansion?.distress?.unresolved?.().length || 0;
    if (remaining && sosRemaining) {
      this.objective.textContent = `Follow SOS beacon · ${remaining} keycard${remaining === 1 ? "" : "s"} left`;
    } else if (sosRemaining) {
      this.objective.textContent = "Follow SOS signal pulse";
    } else {
      this.objective.textContent = remaining
        ? `${remaining} keycard${remaining === 1 ? "" : "s"} left`
        : world.boss && !world.boss.dead
          ? "Defeat the boss"
          : "Reach the portal";
    }
    this.chapter.textContent = `CHAPTER ${world.data.chapter} · ${world.data.subtitle.toUpperCase()}`;
    this.chapterPill.textContent = `CHAPTER ${world.data.chapter}`;
    this.title.textContent = world.data.name;
    this.subtitle.textContent = world.data.subtitle;
    this.signalMonitor.sample(world, player);
    this.signalChart?.render(this.signalMonitor, world.index);
  }

  setSaved(ok) {
    this.saveStatus.textContent = ok ? "LOCAL SAVE" : "SAVE UNAVAILABLE";
  }
}
