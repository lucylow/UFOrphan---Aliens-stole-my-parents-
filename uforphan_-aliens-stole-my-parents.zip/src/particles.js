export class ParticleSystem {
  constructor() {
    this.items = [];
    this.rings = [];
  }

  burst(x, y, color, count = 10, speed = 3, kind = "spark") {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const force = 0.5 + Math.random() * speed;
      const life = 18 + Math.random() * 20;
      this.items.push({
        x,
        y,
        vx: Math.cos(angle) * force,
        vy: Math.sin(angle) * force,
        life,
        max: life,
        size: 2 + Math.random() * 3.5,
        color,
        kind: i % 3 === 0 ? "glow" : kind,
        gravity: kind === "dust" ? -0.02 : 0.08
      });
    }
  }

  ring(x, y, color = "#73f0ed", maxRadius = 26, life = 18) {
    this.rings.push({ x, y, color, maxRadius, life, max: life });
  }

  sparkle(x, y, color = "#ffd76d", count = 8) {
    this.burst(x, y, color, count, 2.4, "star");
    this.ring(x, y, color, 24, 16);
  }

  update() {
    for (const p of this.items) {
      p.x += p.vx;
      p.y += p.vy;
      p.vx *= 0.98;
      p.vy += p.gravity ?? 0.08;
      p.life--;
    }
    this.items = this.items.filter((p) => p.life > 0);

    for (const r of this.rings) {
      r.life--;
    }
    this.rings = this.rings.filter((r) => r.life > 0);
  }

  draw(ctx) {
    for (const r of this.rings) {
      const progress = 1 - r.life / r.max;
      const radius = 4 + progress * r.maxRadius;
      ctx.save();
      ctx.globalAlpha = Math.max(0, (1 - progress) * 0.72);
      ctx.strokeStyle = r.color;
      ctx.lineWidth = Math.max(1, 2.5 * (1 - progress));
      ctx.beginPath();
      ctx.arc(r.x, r.y, radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    for (const p of this.items) {
      const alpha = Math.max(0, p.life / p.max);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      if (p.kind === "star") {
        const s = p.size * (0.55 + alpha * 0.45);
        ctx.translate(p.x, p.y);
        ctx.rotate((p.max - p.life) * 0.14);
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(0, -s * 1.4);
        ctx.lineTo(s * 0.42, -s * 0.42);
        ctx.lineTo(s * 1.4, 0);
        ctx.lineTo(s * 0.42, s * 0.42);
        ctx.lineTo(0, s * 1.4);
        ctx.lineTo(-s * 0.42, s * 0.42);
        ctx.lineTo(-s * 1.4, 0);
        ctx.lineTo(-s * 0.42, -s * 0.42);
        ctx.closePath();
        ctx.fill();
      } else if (p.kind === "glow") {
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 0.58, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === "dust") {
        ctx.globalAlpha = alpha * 0.55;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 0.75, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.translate(p.x, p.y);
        ctx.rotate(Math.atan2(p.vy, p.vx));
        ctx.fillRect(-p.size * 0.9, -p.size * 0.28, p.size * 1.8, p.size * 0.56);
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }
}
