export const SPEAKERS = Object.freeze({
  fiona: { name: "FIONA GALLEGAR", role: "12-Year-Old Space Ranger", badge: "F", color: "#73f0ed" },
  mum: { name: "HELEN GALLEGAR", role: "Mum (Orbiting)", badge: "M", color: "#ff9be4" },
  dad: { name: "ARTHUR GALLEGAR", role: "Dad (Still Hungry)", badge: "D", color: "#ffd76d" },
  cat: { name: "CAPTAIN WHISKERS", role: "House Cat / Acting Admiral", badge: "C", color: "#a9e58a" },
  pip: { name: "PIP", role: "Retired Security Bot", badge: "P", color: "#83e9df" },
  rivet: { name: "RIVET", role: "Pirate Mechanic", badge: "R", color: "#e8a46f" },
  moth: { name: "MOTH-7", role: "Defected Navigation Drone", badge: "7", color: "#b99aff" },
  noa: { name: "NOA", role: "Crystal Gardener", badge: "N", color: "#a9e58a" },
  commander: { name: "COMMANDER ZELK", role: "Abduction Logistics Lead", badge: "!", color: "#ff668d" },
  warden: { name: "THE CORE WARDEN", role: "Eclipse Central AI", badge: "W", color: "#ff668d" }
});

export const STORY = {
  intro: {
    title: "Aliens stole my parents.",
    text: "Fiona Gallegar was halfway through a bowl of cereal when a purple tractor beam lifted her parents, the house cat, and the family minivan into the sky. The cat came back. The parents did not.",
    lines: ["MUM?! DAD?!", "Fiona, stay back! It's an alien ship!", "I am absolutely not staying back."]
  },
  chapters: [
    {
      title: "The Backyard Beacon",
      text: "A strange signal is pulsing beside the old trampoline. Fiona grabs her homemade star-blaster and follows it into the night."
    },
    {
      title: "Moon Mall",
      text: "The signal leads to a shopping complex built into a moon. The aliens have excellent retail space and terrible security."
    },
    {
      title: "The Scrap Belt",
      text: "A pirate crew has sold the family ship for parts. Fiona must cross a field of drifting junk to reach the cruiser."
    },
    {
      title: "The Mothership",
      text: "At last, the mothership. The abduction commander stands between Fiona and the family reunion."
    },
    {
      title: "The Crystal Grove",
      text: "Beyond the mothership, a valley of singing crystals holds the booster frequency needed to guide the Gallegars all the way home."
    },
    {
      title: "The Orbital Archive",
      text: "Every abduction slip, docking receipt, and lost badge in the sector is filed under low-gravity fluorescent lights."
    },
    {
      title: "The Bio-Dome",
      text: "Sentient greenery has tangled around the auxiliary navigation crew, humming anxiously to the ship's distress beacon."
    },
    {
      title: "The Eclipse Core",
      text: "Deep inside the Eclipse engine, the Core Warden waits behind three unaligned dishes and a lifetime of stubborn paperwork."
    }
  ],
  chapterBeats: [
    [
      { speaker: "mum", text: "Fiona, sweetheart, stay inside! Do not chase an interstellar cruiser in your sneakers!" },
      { speaker: "dad", text: "Also, if you do follow us, grab the thermos! The ship only serves glowing kelp juice!" },
      { speaker: "fiona", text: "Homemade star-blaster is charged. Signal is locked by the trampoline. Hold tight—I'm coming." }
    ],
    [
      { speaker: "pip", text: "Attention, shopper: oxygen is 80% off on Concourse B. Running is strictly discouraged." },
      { speaker: "fiona", text: "Wait—did they seriously build an outlet mall inside an asteroid crater?" },
      { speaker: "mum", text: "They gave us a gift voucher while locking the brig, Fiona. Use keycards on the exit lift!" }
    ],
    [
      { speaker: "rivet", text: "Hey kid! Somebody just pawned a slightly dented teal minivan with a 'My Kid Is An Honor Ranger' sticker." },
      { speaker: "fiona", text: "Hey! That's ours! Tell me nobody bolted it to a pirate tug." },
      { speaker: "dad", text: "Bad news on the bumper, kiddo—cross the scrap belt and catch their flagship before jump!" }
    ],
    [
      { speaker: "commander", text: "Intruder alert! Detention Wing reports one small human armed with a modified flashlight!" },
      { speaker: "fiona", text: "It's a Star Blaster, and you owe my parents a Tuesday night back." },
      { speaker: "cat", text: "*Purrs smugly over the ship's intercom from the captain's chair.*" }
    ],
    [
      { speaker: "fiona", text: "Commander's down—Wait, why is the minivan's warp compass spinning backwards?!" },
      { speaker: "noa", text: "The Core Warden jammed Earth's frequency. Tune three singing relays in my grove and the crystals will carry your voice." },
      { speaker: "moth", text: "Tip from an ex-employee: press E at campfires, workbenches, and beacons to craft gear and tune relays." }
    ],
    [
      { speaker: "moth", text: "Welcome to the Orbital Archive. Gravity is optional; overdue filing fees are not." },
      { speaker: "pip", text: "My lost security badge fell somewhere past the restricted stack! Find it and unlock the transmitter nodes." },
      { speaker: "fiona", text: "Three transmitters, one missing badge, and floating jumps. Easy." }
    ],
    [
      { speaker: "noa", text: "Careful near the vents—the dome's flora only lashes out because the Warden's frequency hurts its roots." },
      { speaker: "mum", text: "We can hear you getting closer on the dash radio! Even Captain Whiskers perked an ear up." },
      { speaker: "fiona", text: "Hang on just a little longer. One more relay sector after this garden." }
    ],
    [
      { speaker: "warden", text: "Halt, Fiona Gallegar. Your parents' abduction was Form 44-B compliant. Turning back is strongly advised." },
      { speaker: "fiona", text: "Then consider this an emergency appeal. Align the three array dishes, shut down the Core, and bring everyone home." },
      { speaker: "dad", text: "Show 'em how we handle bureaucracy, kiddo!" }
    ]
  ],
  fieldBeats: {
    0: [
      { id: "ch1-dad", x: 760, speaker: "dad", text: "Static check! Can you see the Moon Mall lights above the treeline yet?" },
      { id: "ch1-cat", x: 1520, speaker: "cat", text: "*Meow.* Translation: Checkpoint beacon synced. Keep moving right." }
    ],
    1: [
      { id: "ch2-pa", x: 960, speaker: "pip", text: "Reminder: Rogue drones are NOT covered under Moon Mall's extended warranty." },
      { id: "ch2-mum", x: 1960, speaker: "mum", text: "Halfway across the concourse! Watch the floor gaps near the food court." }
    ],
    2: [
      { id: "ch3-rivet", x: 1020, speaker: "rivet", text: "Watch the drifting drones—if you clear contracts for me, I'll unlock a Sonic spread module!" },
      { id: "ch3-dad", x: 2150, speaker: "dad", text: "We spotted the Mothership docked just beyond the scrap cruiser!" }
    ],
    3: [
      { id: "ch4-cmd", x: 1220, speaker: "commander", text: "Wait—did you just sprint past Security Deck B?! Nobody reads the signs anymore!" },
      { id: "ch4-boss", x: 1850, speaker: "fiona", text: "There's the Abduction Commander. Time to unplug his tractor beam." }
    ],
    4: [
      { id: "ch5-noa", x: 950, speaker: "noa", text: "Hear that hum? Every relay you tune wakes up the valley's chorus." }
    ],
    5: [
      { id: "ch6-moth", x: 1120, speaker: "moth", text: "Careful around the archive arc lasers—time your jump or Star-Dash with Shift!" }
    ],
    6: [
      { id: "ch7-mum", x: 1350, speaker: "mum", text: "Dad tried to parallel park the minivan inside the cargo bay. Please hurry." }
    ],
    7: [
      { id: "ch8-warden", x: 1540, speaker: "warden", text: "Dish alignment detected. Redirecting ion-storm reserves to Core Arena." }
    ]
  },
  ending: {
    title: "Family, reassembled.",
    text: "The commander's Core powers down. The ship's tractor beam switches off, and Fiona's parents tumble into a very awkward hug. The cat has already claimed the captain's chair.",
    lines: [
      "We knew you'd find us.",
      "Obviously. I had a map.",
      "You drew that map on a pizza box.",
      "It was a very good pizza box."
    ]
  }
};

export function typewriter(text, element, speed = 18) {
  element.textContent = "";
  let index = 0;
  let cancelled = false;
  let timer = null;
  const finish = () => {
    cancelled = true;
    if (timer) clearInterval(timer);
    element.textContent = text;
  };
  const promise = new Promise((resolve) => {
    timer = setInterval(() => {
      if (cancelled) {
        resolve();
        return;
      }
      element.textContent = text.slice(0, ++index);
      if (index >= text.length) {
        clearInterval(timer);
        resolve();
      }
    }, speed);
  });
  promise.cancel = finish;
  return promise;
}

const CIPHER_GLYPHS = "0123456789ABCDEF◈⌖⌁✦█▒░";

export function decryptText(element, text, options = {}) {
  const {
    delayMs = 0,
    durationMs = 480,
    onComplete = null
  } = options;
  const target = String(text ?? "");
  if (!element) return { cancel() {} };

  const reducedMotion =
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (reducedMotion || !target.length) {
    element.textContent = target;
    element.classList?.remove("is-decrypting");
    onComplete?.();
    return { cancel() {} };
  }

  let cancelled = false;
  let rafId = null;
  let timerId = null;
  let startTime = null;
  const nowFn = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
  const scheduleFrame =
    typeof requestAnimationFrame === "function"
      ? (cb) => requestAnimationFrame(cb)
      : (cb) => setTimeout(() => cb(nowFn()), 16);
  const cancelFrame =
    typeof cancelAnimationFrame === "function"
      ? (id) => cancelAnimationFrame(id)
      : (id) => clearTimeout(id);

  const scrambleWindow = (resolvedCount) => {
    const lead = Math.min(target.length, resolvedCount + 6);
    let out = target.slice(0, resolvedCount);
    for (let i = resolvedCount; i < lead; i++) {
      const ch = target[i];
      if (ch === " " || ch === "\n" || ch === "·") {
        out += ch;
      } else {
        out += CIPHER_GLYPHS[(i * 7 + Math.floor(nowFn() / 32)) % CIPHER_GLYPHS.length];
      }
    }
    return out;
  };

  element.classList?.add("is-decrypting");
  element.textContent = scrambleWindow(0);

  const finish = () => {
    if (cancelled) return;
    cancelled = true;
    if (timerId !== null) clearTimeout(timerId);
    if (rafId !== null) cancelFrame(rafId);
    element.textContent = target;
    element.classList?.remove("is-decrypting");
    onComplete?.();
  };

  const step = (ts) => {
    if (cancelled) return;
    if (startTime === null) startTime = ts;
    const elapsed = ts - startTime;
    const progress = Math.max(0, Math.min(1, elapsed / Math.max(1, durationMs)));
    const resolved = Math.floor(progress * target.length);
    if (resolved >= target.length || progress >= 1) {
      finish();
      return;
    }
    element.textContent = scrambleWindow(resolved);
    rafId = scheduleFrame(step);
  };

  if (delayMs > 0) {
    timerId = setTimeout(() => {
      timerId = null;
      if (!cancelled) rafId = scheduleFrame(step);
    }, delayMs);
  } else {
    rafId = scheduleFrame(step);
  }

  return { cancel: finish };
}

