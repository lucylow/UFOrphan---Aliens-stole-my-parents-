export const GAME = Object.freeze({
  width: 960,
  height: 540,
  gravity: 0.62,
  friction: 0.82,
  maxFall: 13,
  tile: 40,
  playerSpeed: 4.2,
  jumpPower: 12.8,
  blastCooldown: 22,
  saveKey: "uforphan-save-v1",
  version: "2.0.0"
});

export const COLORS = Object.freeze({
  space: "#080d23",
  stars: "#d9e9ff",
  ground: "#27355d",
  groundTop: "#6d83b9",
  cyan: "#73f0ed",
  pink: "#ff77bd",
  gold: "#ffd76d",
  danger: "#ff5e78",
  white: "#f3f5ff"
});

export const INPUT = Object.freeze({
  left: ["ArrowLeft", "KeyA"],
  right: ["ArrowRight", "KeyD"],
  jump: ["Space", "ArrowUp", "KeyW"],
  blast: ["KeyX", "KeyJ"],
  dash: ["ShiftLeft", "ShiftRight", "KeyK"],
  weaponCycle: ["KeyQ"],
  scan: ["KeyF"],
  pause: ["Escape", "KeyP"],
  interact: ["KeyE", "Enter"]
});
