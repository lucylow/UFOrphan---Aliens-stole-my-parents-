import { INPUT } from "./config.js";

export class Input {
  constructor() {
    this.down = new Set();
    this.pressed = new Set();
    this.touch = { left:false, right:false, jump:false, blast:false, interact:false, dash:false, scan:false };
    this.touchPressed = new Set();
    this.bind();
  }

  bind() {
    window.addEventListener("keydown", (event) => {
      const tag = event.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || event.target?.isContentEditable) return;
      if (window.UFOrphanFieldTerminal?.isOpen?.()) return;
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "Space"].includes(event.code)) event.preventDefault();
      if (!this.down.has(event.code)) this.pressed.add(event.code);
      this.down.add(event.code);
    });
    window.addEventListener("keyup", (event) => this.down.delete(event.code));
    window.addEventListener("blur", () => this.clearAll());
    document.querySelectorAll("[data-control]").forEach((button) => {
      const name = button.dataset.control;
      const start = (event) => {
        event.preventDefault();
        if (!this.touch[name]) this.touchPressed.add(name);
        this.touch[name] = true;
      };
      const end = (event) => {
        event.preventDefault();
        this.touch[name] = false;
      };
      button.addEventListener("pointerdown", start);
      button.addEventListener("pointerup", end);
      button.addEventListener("pointercancel", end);
      button.addEventListener("pointerleave", end);
    });
  }

  clearAll() {
    this.down.clear();
    this.pressed.clear();
    this.touchPressed.clear();
    for (const key of Object.keys(this.touch)) this.touch[key] = false;
  }

  isDown(action) {
    return INPUT[action].some((code) => this.down.has(code)) || Boolean(this.touch[action]);
  }

  wasPressed(action) {
    return INPUT[action].some((code) => this.pressed.has(code)) || this.touchPressed.has(action);
  }

  endFrame() {
    this.pressed.clear();
    this.touchPressed.clear();
  }
}
