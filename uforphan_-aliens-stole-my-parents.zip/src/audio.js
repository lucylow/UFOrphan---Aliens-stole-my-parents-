export class AudioSystem {
  constructor() {
    this.enabled = true;
    this.context = null;
  }

  unlock() {
    if (!this.context) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) this.context = new AudioContext();
    }
    if (this.context?.state === "suspended") {
      this.context.resume?.().catch?.(() => {});
    }
  }

  toggle() { this.enabled = !this.enabled; return this.enabled; }

  tone(frequency, duration = 0.08, type = "sine", volume = 0.04, slide = 0) {
    if (!this.enabled) return;
    this.unlock();
    if (!this.context) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, now);
    if (slide) oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, frequency + slide), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  jump() { this.tone(260, .11, "triangle", .035, 240); }
  collect() { this.tone(620, .12, "sine", .04, 350); }
  blast() { this.tone(180, .13, "sawtooth", .025, 420); }
  dash() { this.tone(320, .1, "triangle", .03, 280); }
  radio() { this.tone(740, .06, "sine", .02, 180); }
  scan() {
    this.tone(1180, .12, "sine", .03, 240);
    setTimeout(() => this.tone(1420, .16, "triangle", .025, 180), 75);
  }
  distress(proximity = 0.5) {
    const vol = 0.008 + Math.max(0, Math.min(1, proximity)) * 0.028;
    this.tone(980, .09, "sine", vol, 120);
    setTimeout(() => this.tone(1320, .11, "sine", vol * 0.85, 80), 95);
  }
  beam() { this.tone(410, .15, "sine", .022, -160); }
  hurt() { this.tone(150, .24, "square", .035, -90); }
  win() { [440,550,660,880].forEach((n,i)=>setTimeout(()=>this.tone(n,.18,"sine",.035),i*100)); }
  click() { this.tone(500,.04,"sine",.025); }
}
