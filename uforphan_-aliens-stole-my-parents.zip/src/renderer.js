import { GAME } from "./config.js";

export class Renderer {
  constructor(canvas) {
    this.canvas=canvas;this.ctx=canvas.getContext("2d");
    this.ctx.imageSmoothingEnabled=false;
  }
  clear() {
    this.ctx.clearRect(0,0,GAME.width,GAME.height);
  }
  draw(world, player, particles) {
    this.clear();
    const shake = world.expansion?.combat?.shake || 0;
    const sx = shake > 0.3 ? (Math.random() - 0.5) * shake : 0;
    const sy = shake > 0.3 ? (Math.random() - 0.5) * shake : 0;
    this.ctx.save();
    this.ctx.translate(sx, sy);
    world.draw(this.ctx);
    this.ctx.save();
    this.ctx.translate(-world.camera, 0);
    particles.draw(this.ctx);
    this.ctx.restore();
    player.draw(this.ctx, world.camera);
    this.ctx.restore();
    this.drawVignette();
  }
  drawVignette() {
    const g=this.ctx.createRadialGradient(480,260,180,480,260,650);
    g.addColorStop(0,"rgba(0,0,0,0)");
    g.addColorStop(1,"rgba(0,0,0,.24)");
    this.ctx.fillStyle=g;this.ctx.fillRect(0,0,GAME.width,GAME.height);
  }
}
