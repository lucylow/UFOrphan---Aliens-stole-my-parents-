import { Input } from "./input.js";
import { AudioSystem } from "./audio.js";
import { SaveManager } from "./save.js";
import { ParticleSystem } from "./particles.js";
import { Player } from "./player.js";
import { World } from "./world.js";
import { Renderer } from "./renderer.js";
import { UI } from "./ui.js";
import { LEVELS, LEVEL_COUNT } from "./levels.js";
import { STORY, SPEAKERS, typewriter, decryptText } from "./dialogue.js";
import { ExpansionProfile } from "./expansion/profile.js";
import { COMPANIONS } from "./expansion/companion-system.js";
import { ITEM_CATALOG } from "./expansion/inventory.js";
import { UPGRADES } from "./expansion/upgrade-system.js";
import { CHALLENGES } from "./expansion/challenge-system.js";
import { SECTOR_ATMOSPHERES } from "./expansion/ufo-science.js";

const SECTOR_MAP = {
  backyard: "backyard",
  moonbase: "moon_mall",
  asteroid: "scrap_belt",
  mothership: "mothership",
  "crystal-grove": "crystal_grove",
  "orbital-archive": "orbital_archive",
  "bio-dome": "bio_dome",
  "eclipse-core": "eclipse_core"
};

const CODEX_LEVEL_TRIGGERS = {
  0: "tractor_beam",
  1: "moon_mall",
  3: "mothership_captain",
  4: "resonance_crystal",
  5: "memory_vault",
  6: "bio_dome",
  7: "eclipse_engine"
};

const canvas = document.getElementById("game");
const input = new Input();
const audio = new AudioSystem();
const save = new SaveManager();
let profile = new ExpansionProfile(save.data.expansion || {});
const particles = new ParticleSystem();
const renderer = new Renderer(canvas);
const ui = new UI();

let world = null;
let player = null;
let levelIndex = 0;
let mode = "menu";
let modeBeforeTerminal = null;
let activeTypewriter = null;
let activeDecryptions = [];
let lastTime = 0;
let accumulator = 0;
let titleTicks = 0;
const STEP = 1000 / 60;

function cancelTypewriter() {
  if (activeTypewriter?.cancel) activeTypewriter.cancel();
  activeTypewriter = null;
  for (const dec of activeDecryptions) dec?.cancel?.();
  activeDecryptions = [];
}

audio.enabled = save.data.sound;
const soundButton = document.getElementById("soundButton");
soundButton.textContent = audio.enabled ? "♫" : "♪";
soundButton.addEventListener("click", () => {
  const enabled = audio.toggle();
  save.setSound(enabled);
  soundButton.textContent = enabled ? "♫" : "♪";
});
document.getElementById("pauseButton").addEventListener("click", togglePause);
document.getElementById("chaptersButton").addEventListener("click", showChapterSelect);

function getTerminalApp() {
  return window.UFOrphanFieldTerminal?.app || null;
}

function bindProfileToTerminal(activeProfile) {
  activeProfile.events.on("item:added", (event) => {
    const term = getTerminalApp();
    if (!term) return;
    const { id, count = 1 } = event.payload;
    term.inventory.add(id, count, "field-pickup");
    if (id === "stardust") term.economy.earn(count * 5, "stardust");
  });

  activeProfile.events.on("combat:kill", () => {
    const combo = world?.expansion?.combat?.combo || 0;
    if (combo >= 2) activeProfile.economy.earn(combo * 3, "combo");
    const term = getTerminalApp();
    if (!term) return;
    term.economy.earn(12, "combat-salvage");
  });

  activeProfile.events.on("challenge:ended", (event) => {
    const { id, success, flawless } = event.payload || {};
    const def = CHALLENGES.find((item) => item.id === id);
    if (success && def) {
      for (const [rewardKey, amount] of Object.entries(def.reward || {})) {
        if (rewardKey === "credits") activeProfile.economy.earn(amount, "challenge");
        else activeProfile.inventory.add(rewardKey, amount);
      }
      activeProfile.progression.addXP(60);
      world?.pushComms?.(
        "fiona",
        `${def.name} complete!${flawless ? " Flawless run!" : ""} Rewards added to field pack.`
      );
    } else if (def) {
      world?.pushComms?.("fiona", `${def.name} timed out—retry anytime from Sector Challenges.`);
    }
    persistProfile();
  });

  activeProfile.events.on("npc:met", (event) => {
    const term = getTerminalApp();
    if (!term) return;
    if (event.payload.kind === "rivet") term.codex.unlock("patch7");
  });

  activeProfile.events.on("beacon:activated", () => {
    const term = getTerminalApp();
    if (!term) return;
    term.codex.unlock("tractor_beam");
    term.economy.earn(25, "beacon-sync");
  });

  activeProfile.events.on("exo:analyzed", (event) => {
    const term = getTerminalApp();
    if (term && event.payload?.codexId) {
      term.codex.unlock(event.payload.codexId);
      term.economy.earn(15, "exo-scan");
    }
    persistProfile();
  });

  activeProfile.events.on("artifact:collected", () => {
    const term = getTerminalApp();
    if (term) term.economy.earn(15, "xeno-artifact");
    persistProfile();
  });
}

bindProfileToTerminal(profile);

function syncSectorToTerminal(index) {
  const term = getTerminalApp();
  const level = LEVELS[index];
  if (!term || !level) return;
  const sectorId = SECTOR_MAP[level.id];
  if (sectorId) term.map.discover(sectorId);
  const codexId = CODEX_LEVEL_TRIGGERS[index];
  if (codexId) term.codex.unlock(codexId);
}

function syncCombatModifiers() {
  if (!world?.expansion?.combat) return;
  const dmgRank = profile.progression.rank("charged_shot");
  const drawRank = profile.progression.rank("quick_draw");
  const lensMult = profile.upgrades.owned.has("focus_lens") ? 1.5 : 1;
  world.expansion.combat.modifiers.damage = (1 + dmgRank * 0.5) * lensMult;
  world.expansion.combat.modifiers.cooldown = Math.max(0.65, 1 - drawRank * 0.12);
}

function showStoryBeat(beats, level, onDone) {
  let step = 0;

  const renderBeat = () => {
    cancelTypewriter();
    const beat = beats[step];
    const speaker = SPEAKERS[beat.speaker] || SPEAKERS.fiona;
    const isLast = step >= beats.length - 1;

    const bar = document.createElement("div");
    bar.className = "story-speaker-bar";
    bar.innerHTML = `
      <div class="story-speaker-badge" style="background:${speaker.color}">${speaker.badge}</div>
      <div class="story-speaker-meta">
        <strong>${speaker.name}</strong>
        <small>${speaker.role}</small>
      </div>
      <span class="story-step-counter">${step + 1} / ${beats.length}</span>
    `;

    ui.showPanel({
      eyebrow: `CHAPTER ${level.chapter} · ${level.name.toUpperCase()}`,
      title: level.subtitle,
      text: "",
      symbol: "✦",
      extra: bar,
      actions: [
        {
          label: isLast ? "LAUNCH SECTOR →" : "NEXT LINE →",
          primary: true,
          onClick: () => {
            audio.click();
            cancelTypewriter();
            if (isLast) {
              onDone();
            } else {
              step += 1;
              renderBeat();
            }
          }
        },
        {
          label: "SKIP SCENE",
          onClick: () => {
            audio.click();
            cancelTypewriter();
            onDone();
          }
        }
      ]
    });
    activeTypewriter = typewriter(beat.text, ui.panelText, 14);
  };

  renderBeat();
}

function bootLevel(index, showIntroBanner = false) {
  cancelTypewriter();
  levelIndex = Math.max(0, Math.min(index, LEVEL_COUNT - 1));
  if (levelIndex >= 1) profile.companions.unlock("pebble");
  if (levelIndex >= 2) profile.companions.unlock("zip");
  particles.items = [];
  world = new World(levelIndex, audio, particles, profile);
  syncCombatModifiers();
  player = new Player(55, 420);
  player.onDamage = () => {
    profile.challenges.recordDamage();
    profile.statistics.damage();
  };
  profile.applyPlayer(player);
  player.health = player.maxHealth;
  syncSectorToTerminal(levelIndex);
  input.clearAll();
  mode = "playing";
  ui.hidePanel();
  ui.resetSignal(levelIndex);
  ui.updateHUD(player, world);
  audio.unlock();

  if (showIntroBanner) {
    mode = "paused";
    const beats = STORY.chapterBeats?.[levelIndex];
    if (beats?.length) {
      showStoryBeat(beats, LEVELS[levelIndex], () => {
        mode = "playing";
        ui.hidePanel();
      });
    } else {
      ui.showPanel({
        eyebrow: `CHAPTER ${LEVELS[levelIndex].chapter}`,
        title: LEVELS[levelIndex].name,
        text: LEVELS[levelIndex].dialogue.join(" "),
        symbol: "✦",
        actions: [
          {
            label: "LET'S GO →",
            primary: true,
            onClick: () => {
              audio.click();
              mode = "playing";
              ui.hidePanel();
            }
          }
        ]
      });
    }
  }
}

function respawnAtCheckpoint() {
  if (!world || !player) {
    bootLevel(levelIndex);
    return;
  }
  const spawn = world.checkpointSpawn();
  player.x = spawn.x;
  player.y = spawn.y;
  player.lastSafePos = { x: spawn.x, y: spawn.y };
  player.vx = 0;
  player.vy = 0;
  player.dead = false;
  profile.applyPlayer(player);
  player.health = player.maxHealth;
  player.invulnerable = 90;
  input.clearAll();
  mode = "playing";
  ui.hidePanel();
  ui.updateHUD(player, world);
  particles.burst(player.x + player.w / 2, player.y + player.h / 2, "#73f0ed", 16);
}

function startGame() {
  const startIndex = Math.min(save.data.unlockedLevel, LEVEL_COUNT - 1);
  bootLevel(startIndex >= 0 ? startIndex : 0, true);
}

function showChapterSelect() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const grid = document.createElement("div");
  grid.className = "chapter-grid";
  const unlockedMax = Math.min(LEVEL_COUNT - 1, save.data.unlockedLevel || 0);

  LEVELS.forEach((level, idx) => {
    const unlocked = idx <= unlockedMax;
    const best = save.data.bestStars?.[idx] || 0;
    const totalStars = level.stars.length;
    const card = document.createElement("button");
    card.type = "button";
    card.className = "chapter-card";
    card.disabled = !unlocked;
    card.innerHTML = `
      <div class="chapter-card-top">
        <span>CH ${level.chapter}</span>
        <span>${unlocked ? `★ ${best}/${totalStars}` : "LOCKED"}</span>
      </div>
      <strong>${level.name}</strong>
      <small>${level.subtitle}</small>
    `;
    card.addEventListener("click", () => {
      audio.click();
      bootLevel(idx, true);
    });
    grid.append(card);
  });

  ui.showPanel({
    eyebrow: "STAR CHART",
    title: "Select a chapter.",
    text: "Replay any unlocked sector to collect missed stardust, talk to locals, or test new gear.",
    symbol: "⌖",
    extra: grid,
    actions: [
      {
        label: world ? "RESUME" : "BACK",
        primary: true,
        onClick: () => {
          if (world) {
            mode = "playing";
            ui.hidePanel();
          } else {
            showMenu();
          }
        }
      }
    ]
  });
}

function togglePause() {
  if (window.UFOrphanFieldTerminal?.isOpen?.()) return;
  cancelTypewriter();
  if (mode === "playing") {
    input.clearAll();
    mode = "paused";
    ui.showPanel({
      eyebrow: "PAUSED",
      title: "Catch your breath, space ranger.",
      text: "Review supplies, swap gear, launch timed sector challenges, or jump back in.",
      symbol: "Ⅱ",
      actions: [
        { label: "RESUME", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } },
        { label: "FIELD PACK", onClick: showInventory },
        { label: "SUPPLY SHOP", onClick: showShop },
        { label: "FIELD GUIDE", onClick: () => showArtifactGuide() },
        { label: "EXO-LAB", onClick: showScienceLab },
        { label: "CHALLENGES", onClick: showChallenges },
        { label: "MISSION LOG", onClick: showMissions },
        { label: "CHAPTERS", onClick: showChapterSelect },
        { label: "RESTART LEVEL", onClick: () => bootLevel(levelIndex) },
        { label: "MAIN MENU", onClick: showMenu }
      ]
    });
  } else if (mode === "paused") {
    mode = "playing";
    ui.hidePanel();
  }
}

function showMenu() {
  cancelTypewriter();
  input.clearAll();
  mode = "menu";
  world = null;
  player = null;
  const hasProgress = (save.data.unlockedLevel || 0) > 0;
  const actions = [
    { label: hasProgress ? "CONTINUE RESCUE →" : "START RESCUE →", primary: true, onClick: startGame },
    { label: "CHAPTERS", onClick: showChapterSelect },
    { label: "HOW TO PLAY", onClick: showInstructions }
  ];
  if (hasProgress) {
    actions.push({
      label: "RESET SAVE",
      onClick: () => {
        save.reset();
        profile = new ExpansionProfile();
        bindProfileToTerminal(profile);
        showMenu();
      }
    });
  }
  ui.showPanel({
    eyebrow: "A VERY BAD NIGHT",
    title: STORY.intro.title,
    text: STORY.intro.text,
    symbol: "✦",
    actions
  });
}

function showInstructions() {
  cancelTypewriter();
  ui.showPanel({
    eyebrow: "FIELD MANUAL",
    title: "A few things Fiona should know.",
    text: "Move with ← → or A / D; jump with SPACE, W or ↑; Star-Dash through hazards and tractor beams with SHIFT or K; blast drones and saucers with X or J; sweep 1420 MHz SETI scans with F; cycle weapons with Q. Press E near NPCs, stations, anomalies, and beacons. Press I for Pack, B for Shop, G for Alien Field Guide, L for Exo-Lab, M for Missions, and T for Terminal.",
    symbol: "⌁",
    actions: [
      {
        label: "GOT IT",
        primary: true,
        onClick: () => {
          if (world) {
            mode = "playing";
            ui.hidePanel();
          } else {
            showMenu();
          }
        }
      }
    ]
  });
}

function persistProfile() {
  save.data.expansion = profile.serialize();
  ui.setSaved(save.write());
}

function buildFieldPackExtra() {
  const wrap = document.createDocumentFragment();

  // Companion Selector
  const compTitle = document.createElement("p");
  compTitle.className = "pack-section-title";
  compTitle.textContent = "ACTIVE COMPANION";
  const compRow = document.createElement("div");
  compRow.className = "companion-row";
  for (const [id, comp] of Object.entries(COMPANIONS)) {
    const unlocked = profile.companions.unlocked.has(id);
    const active = profile.companions.active === id;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `companion-chip${active ? " is-active" : ""}`;
    btn.disabled = !unlocked;
    btn.innerHTML = `<strong>${comp.name}${active ? " ✓" : ""}</strong><small>${unlocked ? comp.description : "Unlock in later chapters"}</small>`;
    btn.addEventListener("click", () => {
      audio.click();
      profile.companions.equip(id);
      persistProfile();
      if (player && world) ui.updateHUD(player, world);
      showInventory();
    });
    compRow.append(btn);
  }
  wrap.append(compTitle, compRow);

  // Ranger Skills (when points or ranks exist)
  const prog = profile.progression;
  if (prog.skillPoints > 0 || Object.keys(prog.skills).length > 0) {
    const skillTitle = document.createElement("p");
    skillTitle.className = "pack-section-title";
    skillTitle.textContent = `RANGER TRAINING · LV ${prog.level} · ${prog.skillPoints} PT${prog.skillPoints === 1 ? "" : "S"}`;
    const skillGrid = document.createElement("div");
    skillGrid.className = "pack-grid";
    for (const group of prog.tree()) {
      for (const skill of group.skills) {
        const card = document.createElement("div");
        card.className = "pack-item-card";
        const maxed = skill.rank >= skill.max;
        card.innerHTML = `
          <div class="pack-item-head">
            <strong>${skill.name}</strong>
            <span class="pack-item-count">${skill.rank}/${skill.max}</span>
          </div>
          <p class="pack-item-meta">${skill.description}</p>
        `;
        if (!maxed && skill.nextCost !== null) {
          const trainBtn = document.createElement("button");
          trainBtn.type = "button";
          trainBtn.className = "pack-item-btn";
          trainBtn.disabled = prog.skillPoints < skill.nextCost;
          trainBtn.textContent = `TRAIN (${skill.nextCost} PT)`;
          trainBtn.addEventListener("click", () => {
            const res = prog.purchase(skill.id);
            if (res.ok) {
              audio.collect();
              if (player) profile.applyPlayer(player);
              syncCombatModifiers();
              persistProfile();
              if (player && world) ui.updateHUD(player, world);
              showInventory();
            }
          });
          card.append(trainBtn);
        }
        skillGrid.append(card);
      }
    }
    wrap.append(skillTitle, skillGrid);
  }

  // Inventory Items
  const items = profile.inventory.list();
  const invTitle = document.createElement("p");
  invTitle.className = "pack-section-title";
  invTitle.textContent = `SUPPLIES & GEAR (${profile.inventory.slotsUsed()}/${profile.inventory.capacity})`;
  wrap.append(invTitle);

  if (items.length) {
    const grid = document.createElement("div");
    grid.className = "pack-grid";
    for (const slot of items) {
      const card = document.createElement("div");
      card.className = "pack-item-card";
      card.innerHTML = `
        <div class="pack-item-head">
          <strong>${slot.item.name}</strong>
          <span class="pack-item-count">× ${slot.count}</span>
        </div>
        <p class="pack-item-meta">${slot.item.description}</p>
      `;

      if (slot.item.type === "consumable" && player) {
        const useBtn = document.createElement("button");
        useBtn.type = "button";
        useBtn.className = "pack-item-btn";
        const healthFull = slot.id === "med_patch" && player.health >= player.maxHealth;
        useBtn.disabled = healthFull;
        useBtn.textContent = healthFull ? "FULL HEARTS" : "USE";
        useBtn.addEventListener("click", () => {
          const res = profile.inventory.use(slot.id, { player });
          if (res.ok) {
            audio.collect();
            persistProfile();
            ui.updateHUD(player, world);
            showInventory();
          }
        });
        card.append(useBtn);
      } else if (slot.id === "plasma_lens" || slot.id === "sonic_module" || slot.id === "double_jump") {
        const slotName = slot.id === "double_jump" ? "boots" : "weapon";
        const equipped = profile.inventory.equipment[slotName] === slot.id;
        const eqBtn = document.createElement("button");
        eqBtn.type = "button";
        eqBtn.className = "pack-item-btn";
        eqBtn.textContent = equipped ? "EQUIPPED ✓" : "EQUIP";
        eqBtn.addEventListener("click", () => {
          audio.click();
          if (equipped) profile.inventory.unequip(slotName);
          else profile.inventory.equip(slot.id, slotName);
          if (player) profile.applyPlayer(player);
          persistProfile();
          showInventory();
        });
        card.append(eqBtn);
      }
      grid.append(card);
    }
    wrap.append(grid);
  }
  return wrap;
}

function cycleWeapon() {
  if (mode !== "playing" || !player || !world) return;
  const available = [null];
  if (profile.inventory.has("plasma_lens")) available.push("plasma_lens");
  if (profile.inventory.has("sonic_module")) available.push("sonic_module");
  if (available.length <= 1) {
    world.pushComms?.("fiona", "Only Star Blaster unlocked right now. Craft Plasma Lens or earn Sonic Module to swap!");
    return;
  }
  const current = profile.inventory.equipment.weapon || null;
  const next = available[(available.indexOf(current) + 1) % available.length];
  if (next) profile.inventory.equip(next, "weapon");
  else profile.inventory.unequip("weapon");
  profile.applyPlayer(player);
  persistProfile();
  audio.click();
  const label = next === "sonic_module" ? "Sonic Burst (3-way)" : next === "plasma_lens" ? "Plasma Lens" : "Star Blaster";
  world.pushComms?.("fiona", `Blaster switched to ${label}.`);
}

function showInventory() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const items = profile.inventory.list();
  const text = items.length
    ? "Manage Fiona's companion, ranger training, consumables, and gear."
    : "Your field pack is empty. Collect stardust, materials, and supplies while exploring.";

  ui.showPanel({
    eyebrow: "FIELD PACK",
    title: `${profile.inventory.slotsUsed()} / ${profile.inventory.capacity} SLOTS`,
    text,
    symbol: "▣",
    extra: buildFieldPackExtra(),
    actions: [
      { label: "SUPPLY SHOP", onClick: showShop },
      { label: "FIELD GUIDE", onClick: () => showArtifactGuide() },
      { label: "EXO-LAB", onClick: showScienceLab },
      { label: "CHALLENGES", onClick: showChallenges },
      {
        label: "FIELD TERMINAL",
        onClick: () => {
          ui.hidePanel();
          window.UFOrphanFieldTerminal?.open?.("inventory");
        }
      },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function showScienceLab() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const atmo = SECTOR_ATMOSPHERES[levelIndex] || SECTOR_ATMOSPHERES[0];
  const anomalies = world?.expansion?.exo?.anomalies || [];
  const codexEntries = profile.codex
    .list()
    .filter((entry) => ["technology", "phenomena", "creatures", "places"].includes(entry.category));

  const wrap = document.createDocumentFragment();
  const telemetry = document.createElement("div");
  telemetry.className = "chronicle-grid";
  telemetry.innerHTML = `
    <div class="chronicle-stat"><strong>${atmo.gravityG}</strong><small>SURFACE GRAVITY · ${atmo.body}</small></div>
    <div class="chronicle-stat"><strong>${atmo.carrierMHz}</strong><small>SETI H-LINE CARRIER · ${atmo.atmosphere}</small></div>
  `;
  wrap.append(telemetry);

  if (anomalies.length) {
    const anomTitle = document.createElement("p");
    anomTitle.className = "pack-section-title";
    anomTitle.textContent = "SECTOR PHENOMENA";
    const anomGrid = document.createElement("div");
    anomGrid.className = "pack-grid";
    for (const a of anomalies) {
      const card = document.createElement("div");
      card.className = "pack-item-card";
      card.innerHTML = `
        <div class="pack-item-head">
          <strong>${a.title}</strong>
          <span class="pack-item-count">${a.analyzed ? "SCANNED ✓" : "UNSCANNED"}</span>
        </div>
        <p class="pack-item-meta">${a.analyzed ? a.scienceNote : `Concept: ${a.concept} — Press F or E near node to analyze.`}</p>
      `;
      anomGrid.append(card);
    }
    wrap.append(anomTitle, anomGrid);
  }

  const sciTitle = document.createElement("p");
  sciTitle.className = "pack-section-title";
  sciTitle.textContent = `EXO-SCIENCE CODEX (${codexEntries.length} DISCOVERED)`;
  const sciGrid = document.createElement("div");
  sciGrid.className = "pack-grid";
  for (const entry of codexEntries) {
    const card = document.createElement("div");
    card.className = "pack-item-card";
    card.innerHTML = `
      <div class="pack-item-head">
        <strong>${entry.title}</strong>
        <span class="pack-item-count">${entry.category.toUpperCase()}</span>
      </div>
      <p class="pack-item-meta">${entry.text}</p>
    `;
    sciGrid.append(card);
  }
  wrap.append(sciTitle, sciGrid);

  ui.showPanel({
    eyebrow: `EXO-SCIENCE LAB · CH ${LEVELS[levelIndex]?.chapter || "01"}`,
    title: atmo.body,
    text: `${atmo.hypothesis} Shoot overhead purple patrol saucers to invert their Element-115 tractor beam polarity.`,
    symbol: "⌖",
    extra: wrap,
    actions: [
      { label: "FIELD GUIDE", onClick: () => showArtifactGuide() },
      { label: "SUPPLY SHOP", onClick: showShop },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function showArtifactGuide(filter = "all") {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";

  const prog = profile.artifacts.progress();
  const entries = profile.artifacts.list(filter);
  let markedAny = false;
  for (const item of entries) {
    if (item.collected && !item.read) {
      if (profile.artifacts.markRead(item.id)) markedAny = true;
    }
  }
  if (markedAny) persistProfile();

  const wrap = document.createDocumentFragment();

  const bar = document.createElement("div");
  bar.className = "quest-progress";
  bar.innerHTML = `<span style="width:${prog.percent}%"></span>`;
  wrap.append(bar);

  const filterRow = document.createElement("div");
  filterRow.className = "guide-filter-row";
  const tabs = [
    { id: "all", label: `ALL (${prog.total})` },
    { id: "collected", label: `RECOVERED (${prog.found})` },
    { id: "uncollected", label: `UNRECOVERED (${prog.total - prog.found})` }
  ];
  for (const tab of tabs) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `guide-filter-btn${filter === tab.id ? " is-active" : ""}`;
    btn.textContent = tab.label;
    btn.addEventListener("click", () => {
      audio.click();
      showArtifactGuide(tab.id);
    });
    filterRow.append(btn);
  }
  wrap.append(filterRow);

  if (entries.length) {
    const grid = document.createElement("div");
    grid.className = "pack-grid";
    entries.forEach((entry, idx) => {
      const ch = LEVELS[entry.levelIndex];
      const card = document.createElement("div");
      card.className = "pack-item-card guide-entry-card is-decrypting";
      card.style.setProperty("--entry-delay", `${Math.min(idx, 10) * 40}ms`);

      const specText = entry.collected
        ? `${entry.classification} · ${entry.originWorld} · ${entry.massKg} · ${entry.frequencyGHz}`
        : `CH ${ch?.chapter || "01"} · ${ch?.name?.toUpperCase() || "SECTOR"} · ${entry.classification}`;
      const loreText = entry.collected
        ? entry.fieldNote
        : `Sweep high platforms in ${ch?.name || "this sector"} or pulse F (1420 MHz SETI scan) to lock onto ${entry.frequencyGHz}.`;

      if (entry.collected) {
        card.innerHTML = `
          <div class="pack-item-head">
            <strong style="color:${entry.tint}">${entry.name}</strong>
            <span class="pack-item-count">${entry.catalogCode}</span>
          </div>
          <p class="guide-spec-line"></p>
          <p class="pack-item-meta guide-lore-text"></p>
        `;
      } else {
        card.innerHTML = `
          <div class="pack-item-head">
            <strong>UNRECOVERED SPECIMEN</strong>
            <span class="pack-item-count">${entry.catalogCode}</span>
          </div>
          <p class="guide-spec-line"></p>
          <p class="pack-item-meta guide-lore-text"></p>
        `;
      }

      const specEl = card.querySelector(".guide-spec-line");
      const loreEl = card.querySelector(".guide-lore-text");
      const baseDelay = Math.min(idx, 10) * 45;
      let pending = 2;
      const markDone = () => {
        pending--;
        if (pending <= 0) card.classList.remove("is-decrypting");
      };

      const specJob = decryptText(specEl, specText, {
        delayMs: baseDelay,
        durationMs: 260,
        onComplete: markDone
      });
      const loreJob = decryptText(loreEl, loreText, {
        delayMs: baseDelay + 60,
        durationMs: entry.collected ? 500 : 340,
        onComplete: markDone
      });
      activeDecryptions.push(specJob, loreJob);

      card.addEventListener("click", () => {
        specJob.cancel();
        loreJob.cancel();
      });
      grid.append(card);
    });
    wrap.append(grid);
  } else {
    const empty = document.createElement("p");
    empty.className = "pack-item-meta";
    empty.textContent = filter === "collected"
      ? "No Xeno-Artifacts recovered yet. Watch for floating emerald and holographic relics across sectors."
      : "Every Xeno-Artifact in the catalog has been recovered and logged!";
    wrap.append(empty);
  }

  ui.showPanel({
    eyebrow: "ALIEN FIELD GUIDE · GALACTIC SPECIMEN INDEX",
    title: `${prog.found} / ${prog.total} SPECIMENS LOGGED`,
    text: "Field curator notes cataloging extraterrestrial propulsion hardware, bureaucratic fossils, and anomalous housewares recovered along Fiona's route.",
    symbol: "◈",
    extra: wrap,
    actions: [
      { label: "EXO-LAB", onClick: showScienceLab },
      { label: "FIELD PACK", onClick: showInventory },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          cancelTypewriter();
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function formatUpgradeEffect(effect) {
  if (effect.dashCooldownMult) return "-30% Star-Dash recharge + +5% speed";
  if (effect.scanRadius) return "Doubles 1420 MHz SETI scan range + bonus E-115 shard";
  if (effect.speed) return `+${Math.round((effect.speed - 1) * 100)}% movement speed`;
  if (effect.damage) return "+50% blaster focus damage";
  if (effect.maxHealth) return `+${effect.maxHealth} max heart`;
  if (effect.pickupRadius) return "+50% item pickup magnet";
  return "Suit enhancement";
}

function showShop() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const wrap = document.createDocumentFragment();

  const creditBar = document.createElement("div");
  creditBar.className = "shop-credit-bar";
  creditBar.innerHTML = `<span>RANGER CREDITS</span><strong>${profile.economy.credits} CR</strong>`;
  wrap.append(creditBar);

  const upTitle = document.createElement("p");
  upTitle.className = "pack-section-title";
  upTitle.textContent = "PERMANENT SUIT UPGRADES";
  const upGrid = document.createElement("div");
  upGrid.className = "pack-grid";

  for (const [id, upgrade] of Object.entries(UPGRADES)) {
    const owned = profile.upgrades.owned.has(id);
    const card = document.createElement("div");
    card.className = "pack-item-card";
    card.innerHTML = `
      <div class="pack-item-head">
        <strong>${upgrade.name}</strong>
        <span class="pack-item-count">${owned ? "OWNED" : `${upgrade.price} CR`}</span>
      </div>
      <p class="pack-item-meta">${formatUpgradeEffect(upgrade.effect)}</p>
    `;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "pack-item-btn";
    btn.disabled = owned || profile.economy.credits < upgrade.price;
    btn.textContent = owned ? "INSTALLED ✓" : `INSTALL · ${upgrade.price} CR`;
    btn.addEventListener("click", () => {
      const res = profile.upgrades.purchase(id, profile.economy);
      if (res.ok) {
        audio.collect();
        if (player) {
          profile.applyPlayer(player);
          if (upgrade.effect.maxHealth) player.health = player.maxHealth;
        }
        syncCombatModifiers();
        persistProfile();
        if (player && world) ui.updateHUD(player, world);
        showShop();
      }
    });
    card.append(btn);
    upGrid.append(card);
  }
  wrap.append(upTitle, upGrid);

  const stockTitle = document.createElement("p");
  stockTitle.className = "pack-section-title";
  stockTitle.textContent = "FIELD SUPPLIES & SALVAGE";
  const stockGrid = document.createElement("div");
  stockGrid.className = "pack-grid";

  for (const entry of profile.economy.stock.values()) {
    const item = ITEM_CATALOG[entry.id];
    const price = profile.economy.price(entry.id);
    const card = document.createElement("div");
    card.className = "pack-item-card";
    card.innerHTML = `
      <div class="pack-item-head">
        <strong>${item?.name || entry.id}</strong>
        <span class="pack-item-count">${entry.stock} LEFT</span>
      </div>
      <p class="pack-item-meta">${item?.description || ""}</p>
    `;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "pack-item-btn";
    btn.disabled = entry.stock <= 0 || profile.economy.credits < price;
    btn.textContent = entry.stock <= 0 ? "SOLD OUT" : `BUY · ${price} CR`;
    btn.addEventListener("click", () => {
      const res = profile.economy.buy(entry.id, 1);
      if (res.ok) {
        audio.collect();
        persistProfile();
        showShop();
      }
    });
    card.append(btn);
    stockGrid.append(card);
  }
  wrap.append(stockTitle, stockGrid);

  ui.showPanel({
    eyebrow: "ORBITAL SUPPLY",
    title: "Gear & Provisions",
    text: "Spend credits earned from stardust, enemy combos, beacons, and challenges.",
    symbol: "◈",
    extra: wrap,
    actions: [
      { label: "FIELD PACK", onClick: showInventory },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function showChallenges() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const list = document.createElement("div");
  list.className = "pack-grid";
  const activeId = profile.challenges.active?.id;

  for (const ch of CHALLENGES) {
    const wins = profile.challenges.results.filter((r) => r.id === ch.id && r.success);
    const flawless = wins.some((r) => r.flawless);
    const rewardText = Object.entries(ch.reward)
      .map(([k, v]) => (k === "credits" ? `${v} CR` : `${ITEM_CATALOG[k]?.name || k} ×${v}`))
      .join(" · ");
    const card = document.createElement("div");
    card.className = "pack-item-card";
    card.innerHTML = `
      <div class="pack-item-head">
        <strong>${ch.name}</strong>
        <span class="pack-item-count">${ch.duration}S</span>
      </div>
      <p class="pack-item-meta">${ch.description}<br>Reward: ${rewardText}${wins.length ? ` · Cleared ×${wins.length}${flawless ? " (Flawless)" : ""}` : ""}</p>
    `;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "pack-item-btn";
    btn.disabled = !world || !player || Boolean(activeId);
    btn.textContent = activeId === ch.id ? "ACTIVE NOW" : activeId ? "ANOTHER ACTIVE" : world ? "START RUN" : "ENTER A SECTOR FIRST";
    btn.addEventListener("click", () => {
      if (!world || !player) return;
      const res = profile.challenges.start(ch.id, player);
      if (res.ok) {
        audio.click();
        world.pushComms?.("fiona", `${ch.name} started—${ch.duration}s on the clock!`);
        mode = "playing";
        ui.hidePanel();
      }
    });
    card.append(btn);
    list.append(card);
  }

  ui.showPanel({
    eyebrow: "TIMED TRIALS",
    title: "Sector Challenges",
    text: "Take on optional high-speed runs while exploring any sector to earn credits and rare parts.",
    symbol: "⏱",
    extra: list,
    actions: [
      { label: "FIELD PACK", onClick: showInventory },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function showMissions() {
  cancelTypewriter();
  input.clearAll();
  if (mode === "playing") mode = "paused";
  const quests = profile.quests.list();
  const list = document.createElement("div");
  list.className = "quest-list";

  for (const quest of quests) {
    const card = document.createElement("div");
    card.className = "quest-card";
    const summary = profile.quests.objectiveSummary(quest.id);
    const totalDone = summary.reduce((n, o) => n + Math.min(o.target, o.progress), 0);
    const totalReq = Math.max(1, summary.reduce((n, o) => n + o.target, 0));
    const pct = Math.round((totalDone / totalReq) * 100);
    card.innerHTML = `
      <div class="quest-head">
        <strong>${quest.title}</strong>
        <span class="quest-status">${quest.state.status.toUpperCase()}</span>
      </div>
      <p class="quest-desc">${quest.description}</p>
      <div class="quest-objectives">
        ${summary
          .map(
            (item) =>
              `<div class="quest-obj-row"><span>${item.done ? "✓" : "○"} ${item.description}</span><span>${item.progress}/${item.target}</span></div>`
          )
          .join("")}
      </div>
      <div class="quest-progress"><span style="width:${pct}%"></span></div>
    `;
    list.append(card);
  }

  ui.showPanel({
    eyebrow: "MISSION LOG",
    title: "Promises made across the galaxy",
    text: quests.length
      ? "Talk to locals across sectors to accept story contracts and unlock blueprints."
      : "No missions discovered yet. Talk to the locals.",
    symbol: "☷",
    extra: quests.length ? list : null,
    actions: [
      {
        label: "OPEN TERMINAL JOURNAL",
        onClick: () => {
          ui.hidePanel();
          window.UFOrphanFieldTerminal?.open?.("missions");
        }
      },
      {
        label: "CLOSE",
        primary: true,
        onClick: () => {
          mode = world ? "playing" : "menu";
          ui.hidePanel();
        }
      }
    ]
  });
}

function showInteraction(result) {
  if (!result) return;
  cancelTypewriter();
  input.clearAll();
  mode = "paused";
  if (result.type === "npc") {
    persistProfile();
    const speaker = SPEAKERS[result.npc.kind];
    let speakerBar = null;
    if (speaker) {
      speakerBar = document.createElement("div");
      speakerBar.className = "story-speaker-bar";
      speakerBar.innerHTML = `
        <div class="story-speaker-badge" style="background:${speaker.color}">${speaker.badge}</div>
        <div class="story-speaker-meta">
          <strong>${speaker.name}</strong>
          <small>${speaker.role}</small>
        </div>
      `;
    }
    const questText = result.questResult?.ok ? "\n\nNEW MISSION ADDED TO YOUR LOG." : "";
    ui.showPanel({
      eyebrow: result.role.toUpperCase(),
      title: speaker ? speaker.name : result.npc.kind.toUpperCase(),
      text: result.line + questText,
      symbol: "✦",
      extra: speakerBar,
      actions: [
        { label: "FIELD PACK", onClick: showInventory },
        { label: "MISSION LOG", onClick: showMissions },
        { label: "CONTINUE", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } }
      ]
    });
  } else if (result.type === "station") {
    const recipes = result.recipes || [];
    const list = document.createElement("div");
    list.className = "recipe-list";
    for (const recipe of recipes) {
      const card = document.createElement("div");
      card.className = "recipe-card";
      const ingredientsText = Object.entries(recipe.ingredients)
        .map(([id, needed]) => {
          const name = ITEM_CATALOG[id]?.name || id;
          const owned = profile.inventory.count(id);
          return `${name} ${owned}/${needed}`;
        })
        .join(" · ");
      card.innerHTML = `
        <div class="recipe-head">
          <strong>${recipe.name}</strong>
          <span class="recipe-status">${recipe.canCraft ? "READY" : "LOCKED"}</span>
        </div>
        <p class="pack-item-meta">${ingredientsText}</p>
      `;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "pack-item-btn";
      btn.disabled = !recipe.canCraft;
      btn.textContent = recipe.canCraft ? "CRAFT" : "MISSING MATERIALS";
      btn.addEventListener("click", () => {
        const crafted = profile.crafting.craft(recipe.id);
        if (crafted?.ok) audio.collect();
        persistProfile();
        showInteraction({
          type: "station",
          station: result.station,
          recipes: profile.crafting.availableRecipes()
        });
      });
      card.append(btn);
      list.append(card);
    }

    ui.showPanel({
      eyebrow: "CRAFTING STATION",
      title: result.station.type.replace("_", " ").toUpperCase(),
      text: recipes.length
        ? "Combine salvaged parts into field gear and consumables."
        : "No blueprints unlocked for this station yet. Complete sector contracts to unlock more.",
      symbol: "⚒",
      extra: recipes.length ? list : null,
      actions: [
        { label: "CLOSE", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } }
      ]
    });
  } else if (result.type === "beacon") {
    persistProfile();
    audio.collect();
    const isBadge = result.beacon?.kind === "badge";
    const isDish = result.beacon?.kind === "dish";
    ui.showPanel({
      eyebrow: isBadge ? "RECOVERED ITEM" : isDish ? "ARRAY DISH" : "RELAY BEACON",
      title: isBadge ? "Mall Security Badge found" : isDish ? "Dish aligned" : "Signal strengthened",
      text: isBadge
        ? "Pip's lost Moon Mall security badge! Mall Cop Duty objective updated."
        : isDish
          ? "The dish locks onto the family frequency. Align all three to send the rescue signal."
          : "The relay hums to life. Somewhere, a navigation display just gained a little more hope.",
      symbol: "⌁",
      actions: [{ label: "CONTINUE", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } }]
    });
  } else if (result.type === "distress") {
    persistProfile();
    const b = result.beacon;
    ui.showPanel({
      eyebrow: `DISTRESS SIGNAL LOCKED · ${b.code}`,
      title: b.name,
      text: `${b.hintText}\n\nEarned +${b.rewardCredits || 45} CR and +${b.rewardXp || 40} XP.`,
      symbol: "⌖",
      actions: [{ label: "CONTINUE", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } }]
    });
  } else if (result.type === "anomaly") {
    persistProfile();
    const a = result.anomaly;
    ui.showPanel({
      eyebrow: `EXO-SCIENCE · ${a.concept.toUpperCase()}`,
      title: a.title,
      text: `${a.scienceNote}\n\nEarned +${a.rewardCredits} CR and +30 XP toward Ranger Training.`,
      symbol: "⌖",
      actions: [
        { label: "EXO-LAB", onClick: showScienceLab },
        { label: "CONTINUE", primary: true, onClick: () => { mode = "playing"; ui.hidePanel(); } }
      ]
    });
  }
}

function showFinalEnding(choiceId) {
  cancelTypewriter();
  profile.ending.choose(choiceId);
  persistProfile();
  const epilogue = profile.ending.resolve({ secretsFound: profile.codex.unlocked.size });
  getTerminalApp()?.codex.unlock("family_frequency");

  const artProg = profile.artifacts.progress();
  const chronicle = document.createElement("div");
  chronicle.className = "chronicle-grid";
  chronicle.innerHTML = `
    <div class="chronicle-stat"><strong>${Math.max(profile.completedLevels.size, LEVEL_COUNT)} / ${LEVEL_COUNT}</strong><small>SECTORS CLEARED</small></div>
    <div class="chronicle-stat"><strong>${profile.statistics.stars}</strong><small>STARDUST GATHERED</small></div>
    <div class="chronicle-stat"><strong>${artProg.found} / ${artProg.total}</strong><small>XENO-ARTIFACTS LOGGED</small></div>
    <div class="chronicle-stat"><strong>${profile.quests.list("completed").length}</strong><small>CONTRACTS COMPLETED</small></div>
    <div class="chronicle-stat"><strong>${profile.codex.unlocked.size}</strong><small>CODEX ENTRIES UNLOCKED</small></div>
    <div class="chronicle-stat"><strong>${profile.achievements.progress().points} PT</strong><small>RANGER MERIT SCORE</small></div>
  `;

  const dialogueQuote = STORY.ending.lines.map((line) => `"${line}"`).join(" — ");
  ui.showPanel({
    eyebrow: "MISSION ACCOMPLISHED · VOYAGE CHRONICLE",
    title: epilogue.title,
    text: `${STORY.ending.text}\n\n${dialogueQuote}\n\n${epilogue.text}`,
    symbol: "♥",
    extra: chronicle,
    actions: [
      { label: "CHAPTER SELECT", primary: true, onClick: showChapterSelect },
      {
        label: "PLAY AGAIN",
        onClick: () => {
          save.reset();
          profile = new ExpansionProfile();
          bindProfileToTerminal(profile);
          bootLevel(0, true);
        }
      },
      { label: "MAIN MENU", onClick: showMenu }
    ]
  });
}

function levelComplete() {
  mode = "transition";
  profile.challenges.addProgress("finish", 1);
  const stars = world.stars.filter((s) => s.collected).length;
  save.completeLevel(levelIndex, stars);
  profile.completeLevel(levelIndex);
  profile.progression.addXP(80 + stars * 10);
  profile.codex.unlockByTrigger(`level:${levelIndex}`);
  syncSectorToTerminal(levelIndex);
  persistProfile();

  if (levelIndex === LEVEL_COUNT - 1) {
    save.data.totalRescued = true;
    save.write();
    audio.win();
    ui.showPanel({
      eyebrow: "THE ECLIPSE CORE CLEARED",
      title: STORY.ending.title,
      text: `${STORY.ending.text}\n\nChoose what the Gallegar family does next:`,
      symbol: "♥",
      actions: [
        { label: "RETURN HOME", primary: true, onClick: () => showFinalEnding("home") },
        { label: "EXPLORE THE STARS", onClick: () => showFinalEnding("wander") },
        { label: "REBUILD THE NETWORK", onClick: () => showFinalEnding("repair") }
      ]
    });
  } else {
    audio.win();
    ui.showPanel({
      eyebrow: "SECTOR CLEARED",
      title: "One step closer to home.",
      text: `${LEVELS[levelIndex].name} complete. Fiona collected ${stars} of ${world.stars.length} stardust fragments. ${STORY.chapters[levelIndex + 1]?.text || "The signal points deeper into the galaxy. Fiona keeps moving."}`,
      symbol: "✦",
      actions: [
        { label: "NEXT CHAPTER →", primary: true, onClick: () => bootLevel(levelIndex + 1, true) },
        { label: "REPLAY", onClick: () => bootLevel(levelIndex) }
      ]
    });
  }
}

function gameOver() {
  mode = "gameover";
  profile.statistics.death();
  const hasCheckpoint = Boolean(world?.checkpoint?.active);
  const actions = [];
  if (hasCheckpoint) {
    actions.push({ label: "RESUME CHECKPOINT", primary: true, onClick: respawnAtCheckpoint });
    actions.push({ label: "RESTART CHAPTER", onClick: () => bootLevel(levelIndex) });
  } else {
    actions.push({ label: "TRY AGAIN", primary: true, onClick: () => bootLevel(levelIndex) });
  }
  actions.push({ label: "MAIN MENU", onClick: showMenu });

  ui.showPanel({
    eyebrow: "SIGNAL LOST",
    title: "Fiona needs a minute.",
    text: hasCheckpoint
      ? "The galaxy is still out there, and your checkpoint beacon is still lit. Jump right back in."
      : "The galaxy is still out there, and so are your parents. Give it another try.",
    symbol: "♡",
    actions
  });
}

function update() {
  if (mode !== "playing" || !world || !player) return;
  player.update(input, world, audio, particles);
  world.update(player);
  if (input.wasPressed("interact")) showInteraction(world.interact(player));
  particles.update();
  if (player.dead) {
    gameOver();
    return;
  }
  const portal = { ...world.exit };
  if (
    player.x + player.w > portal.x &&
    player.x < portal.x + portal.w &&
    player.y + player.h > portal.y &&
    player.y < portal.y + portal.h &&
    world.canExit()
  ) {
    levelComplete();
    return;
  }
  ui.updateHUD(player, world);
}

function render() {
  if (world && player) renderer.draw(world, player, particles);
  else drawTitleScene();
}

function drawTitleScene() {
  titleTicks += 0.04;
  const ctx = renderer.ctx;
  renderer.clear();
  const g = ctx.createLinearGradient(0, 0, 960, 540);
  g.addColorStop(0, "#0e183c");
  g.addColorStop(1, "#372056");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 960, 540);
  for (let i = 0; i < 120; i++) {
    ctx.fillStyle = i % 7 === 0 ? "#73f0ed" : i % 11 === 0 ? "#ffd76d" : "#d9e9ff";
    ctx.globalAlpha = 0.25 + ((Math.sin(titleTicks + i) + 1) * 0.25);
    ctx.fillRect((i * 137) % 960, (i * 79) % 470, i % 9 === 0 ? 3 : 2, i % 9 === 0 ? 3 : 2);
  }
  ctx.globalAlpha = 1;

  // Suburban rooftop silhouettes along the horizon
  for (let i = 0; i < 6; i++) {
    ctx.fillStyle = i % 2 ? "#1e2950" : "#182243";
    ctx.fillRect(i * 175 - 20, 405 + (i % 2) * 14, 130, 66);
    ctx.fillStyle = "rgba(255, 215, 109, 0.45)";
    ctx.fillRect(i * 175 + 24, 424 + (i % 2) * 14, 12, 14);
  }

  ctx.fillStyle = "#27355d";
  ctx.fillRect(0, 470, 960, 70);
  ctx.fillStyle = "#7187bd";
  ctx.fillRect(0, 470, 960, 5);

  const ufoY = 120 + Math.sin(titleTicks) * 7;
  const beamAlpha = 0.12 + (Math.sin(titleTicks * 1.5) + 1) * 0.04;
  ctx.fillStyle = `rgba(115,240,237,${beamAlpha})`;
  ctx.beginPath();
  ctx.moveTo(420, ufoY);
  ctx.lineTo(540, ufoY);
  ctx.lineTo(640, 470);
  ctx.lineTo(320, 470);
  ctx.fill();

  // Rising luminous dust motes & tractor-beam wave rings inside beam
  ctx.fillStyle = "rgba(169, 229, 138, 0.55)";
  for (let i = 0; i < 12; i++) {
    const t = ((titleTicks * 0.25 + i / 12) % 1);
    const my = 468 - t * (468 - (ufoY + 18));
    const spread = 50 + (1 - t) * 90;
    const mx = 480 + Math.sin(i * 2.1 + titleTicks) * spread * 0.6;
    ctx.fillRect(mx, my, 3, 4);
  }
  ctx.strokeStyle = "rgba(115, 240, 237, 0.35)";
  ctx.lineWidth = 1.6;
  for (let r = 0; r < 3; r++) {
    const t = ((titleTicks * 0.3 + r / 3) % 1);
    const ry = 468 - t * (468 - (ufoY + 20));
    const rw = 44 + (1 - t) * 102;
    ctx.beginPath();
    ctx.ellipse(480, ry, rw, 6, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Drifting suburban fireflies in backyard foreground
  for (let f = 0; f < 8; f++) {
    const fx = 110 + f * 108 + Math.sin(titleTicks * 0.7 + f * 1.9) * 18;
    const fy = 446 + Math.cos(titleTicks * 0.9 + f * 2.3) * 12;
    ctx.fillStyle = `rgba(255, 215, 109, ${0.35 + (Math.sin(titleTicks * 2.2 + f) + 1) * 0.3})`;
    ctx.fillRect(fx, fy, 3, 3);
  }

  ctx.fillStyle = "#9bb5e8";
  ctx.beginPath();
  ctx.ellipse(480, ufoY, 120, 34, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#73f0ed";
  ctx.beginPath();
  ctx.ellipse(480, ufoY - 15, 48, 25, 0, Math.PI, Math.PI * 2);
  ctx.fill();

  // Rotating rim navigation bulbs on saucer hull
  for (let i = -4; i <= 4; i++) {
    const active = Math.floor(titleTicks * 5 + i + 8) % 3 === 0;
    ctx.fillStyle = active ? "#ffd76d" : "#ff77bd";
    ctx.fillRect(480 + i * 22 - 4, ufoY - 2, 8, 5);
  }

  // SETI 1420 MHz sonar rings radiating upward from Fiona
  for (let r = 0; r < 2; r++) {
    const wave = ((titleTicks * 0.35 + r * 0.5) % 1);
    ctx.strokeStyle = `rgba(115, 240, 237, ${(1 - wave) * 0.42})`;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(460, 420, 24 + wave * 170, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
  }

  // Fiona looking up at the beam with gently swaying ribbon
  const breath = Math.sin(titleTicks * 1.8) * 1.2;
  ctx.strokeStyle = "#ff77bd";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(446, 428 + breath);
  ctx.quadraticCurveTo(432, 434 + Math.sin(titleTicks * 3) * 3, 426, 444);
  ctx.stroke();

  ctx.fillStyle = "#ffd0ae";
  ctx.beginPath();
  ctx.arc(460, 420 + breath, 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#a65b43";
  ctx.fillRect(445, 405 + breath, 30, 10);
  ctx.fillStyle = "#54cbd0";
  ctx.fillRect(446, 436 + breath * 0.6, 28, 27);
  ctx.fillStyle = "#f2c66d";
  ctx.fillRect(448, 462, 9, 9);
  ctx.fillRect(464, 462, 9, 9);
}

function frame(time) {
  if (!lastTime) lastTime = time;
  accumulator += Math.min(100, time - lastTime);
  lastTime = time;
  while (accumulator >= STEP) {
    update();
    accumulator -= STEP;
  }
  render();
  input.endFrame();
  requestAnimationFrame(frame);
}

window.addEventListener("uforphan:terminal-open", () => {
  input.clearAll();
  if (mode === "playing") {
    modeBeforeTerminal = "playing";
    mode = "paused";
  } else {
    modeBeforeTerminal = null;
  }
});

window.addEventListener("uforphan:terminal-close", () => {
  if (modeBeforeTerminal === "playing" && mode === "paused" && ui.overlay.classList.contains("hidden")) {
    mode = "playing";
  }
  modeBeforeTerminal = null;
});

window.addEventListener("keydown", (event) => {
  const tag = event.target?.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
  if (window.UFOrphanFieldTerminal?.isOpen?.()) return;

  if (event.code === "KeyP" || event.code === "Escape") {
    if (mode === "playing" || mode === "paused") {
      event.preventDefault();
      togglePause();
    }
  } else if (event.code === "KeyI") {
    event.preventDefault();
    showInventory();
  } else if (event.code === "KeyB") {
    event.preventDefault();
    showShop();
  } else if (event.code === "KeyG") {
    event.preventDefault();
    showArtifactGuide();
  } else if (event.code === "KeyL") {
    event.preventDefault();
    showScienceLab();
  } else if (event.code === "KeyM") {
    event.preventDefault();
    showMissions();
  } else if (event.code === "KeyQ") {
    if (mode === "playing") {
      event.preventDefault();
      cycleWeapon();
    }
  } else if (event.code === "KeyT") {
    event.preventDefault();
    window.UFOrphanFieldTerminal?.open?.();
  }
});

document.getElementById("startButton").addEventListener("click", startGame);
document.getElementById("howButton").addEventListener("click", showInstructions);
document.getElementById("inventoryButton").addEventListener("click", showInventory);
document.getElementById("missionsButton").addEventListener("click", showMissions);
const relicsStat = document.getElementById("relicsStat");
relicsStat?.addEventListener("click", () => showArtifactGuide());
relicsStat?.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    showArtifactGuide();
  }
});
window.addEventListener("beforeunload", persistProfile);
showMenu();
requestAnimationFrame(frame);
