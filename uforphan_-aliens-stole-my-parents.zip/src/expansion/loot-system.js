import {
   uid,
   EXPANSION_EVENTS
}
 from "./constants.js";

export const LOOT_TABLES={

    drone:[{
    id:"ion_cell",
    weight:55,
    min:1,
    max:2
  }
  ,
  {
    id:"relay_chip",
    weight:25,
    min:1,
    max:1
  }
  ,
  {
    id:"stardust",
    weight:20,
    min:2,
    max:4
  }
  ],

    brute:[{
    id:"copper_coil",
    weight:45,
    min:1,
    max:3
  }
  ,
  {
    id:"ion_cell",
    weight:35,
    min:1,
    max:2
  }
  ,
  {
    id:"resonant_crystal",
    weight:20,
    min:1,
    max:1
  }
  ],

    boss:[{
    id:"resonant_crystal",
    weight:50,
    min:2,
    max:4
  }
  ,
  {
    id:"relay_chip",
    weight:35,
    min:2,
    max:3
  }
  ,
  {
    id:"plasma_lens",
    weight:15,
    min:1,
    max:1
  }
  ]

}
;

export class SeededRandom {

    constructor(seed=Date.now()){
    this.seed=(seed>>>0)||1;

  }

    next(){
    this.seed=(1664525*this.seed+1013904223)>>>0;
    return this.seed/4294967296;

  }

    int(min,
  max){
    return Math.floor(this.next()*(max-min+1))+min;

  }

    pickWeighted(entries){
    const total=entries.reduce((sum,
    item)=>sum+item.weight,
    0);
    let roll=this.next()*total;
    for(const item of entries){
      roll-=item.weight;
      if(roll<=0)return item;

    }
    return entries[entries.length-1];

  }


}

export class LootSystem {

    constructor(hub,
  inventory,
  seed=12345){
    this.hub=hub;
    this.inventory=inventory;
    this.random=new SeededRandom(seed);
    this.drops=[];
    this.collected=[];
    this.pity={
      rare:0
    }
    ;

  }

    dropFrom(source,
  x,
  y){
    const table=LOOT_TABLES[source]||LOOT_TABLES.drone;
    const entry=this.random.pickWeighted(table);
    const count=this.random.int(entry.min,
    entry.max);
    const drop={
      id:uid("drop"),
      item:entry.id,
      count,
      x,
      y,
      vx:this.random.next()*2-1,
      vy:-2.2,
      life:1200,
      bob:this.random.next()*6
    }
    ;
    this.drops.push(drop);
    return drop;

  }

    update(player,
  world){
    const px=player.x+player.w/2;
    const py=player.y+player.h/2;
    for(const drop of this.drops){
      const radius=player.pickupRadius||25;
      const dx=px-drop.x;
      const dy=py-drop.y;
      const d=Math.hypot(dx,dy);
      if(d<radius*1.65&&d>1){
        drop.vx+=(dx/d)*0.45;
        drop.vy+=(dy/d)*0.45;
      }else{
        drop.vy=Math.min(4,drop.vy+.12);
      }
      drop.vx*=0.94;
      drop.x+=drop.vx;
      drop.y+=drop.vy;
      drop.life--;
      drop.bob+=.08;
      if(Math.hypot(px-drop.x,py-drop.y)<radius){
        const result=this.inventory.add(drop.item,
        drop.count);
        if(result.added===drop.count){
          drop.life=0;
          this.collected.push({
            item:drop.item,
            count:drop.count,
            at:Date.now()
          }
          );
          this.hub?.emit(EXPANSION_EVENTS.ITEM_ADDED,
          {
            id:drop.item,
            count:drop.count,
            source:"loot"
          }
          );
          world.particles.burst(drop.x,
          drop.y,
          "#ffd76d",
          8);

        }
        else drop.blocked=true;

      }

    }

        this.drops=this.drops.filter(drop=>drop.life>0);

  }

    draw(ctx,
  camera){
    for(const drop of this.drops){
      const bobY=Math.sin(drop.bob)*3;
      const pulse=1+Math.sin(drop.bob*2)*0.12;
      ctx.save();
      ctx.translate(drop.x-camera,drop.y+bobY);
      ctx.scale(pulse,pulse);
      const col=drop.blocked?"#ff778c":"#ffd76d";
      ctx.strokeStyle="rgba(255, 255, 255, 0.38)";
      ctx.lineWidth=1.2;
      ctx.beginPath();
      ctx.arc(0,0,10,drop.bob,drop.bob+Math.PI*1.1);
      ctx.stroke();

      ctx.fillStyle=col;
      ctx.shadowColor=col;
      ctx.shadowBlur=11;
      ctx.beginPath();
      ctx.moveTo(0,-8);
      ctx.lineTo(8,0);
      ctx.lineTo(0,8);
      ctx.lineTo(-8,0);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur=0;
      ctx.fillStyle="#182343";
      ctx.font="bold 9px 'JetBrains Mono', monospace";
      ctx.textAlign="center";
      ctx.fillText(drop.count,0,3);
      ctx.restore();

    }

  }

    serialize(){
    return {
      seed:this.random.seed,
      collected:this.collected.slice(-100)
    }
    ;

  }

    restore(data={

  }
  ){
    this.random.seed=data.seed||this.random.seed;
    this.collected=data.collected||[];

  }


}
