import {
   NPCSystem
}
 from "./npc-system.js";

import {
   EnvironmentSystem,
   DynamicPlatformSystem
}
 from "./environment.js";

import {
   LootSystem
}
 from "./loot-system.js";

import {
   CombatSystem
}
 from "./combat-system.js";

import {
   CompanionSystem
}
 from "./companion-system.js";

import {
   MapSystem
}
 from "./map-system.js";

import {
   GameDirector
}
 from "./game-director.js";

import {
   WorldEventSystem
}
 from "./world-event-system.js";

import {
   WeatherSystem
}
 from "./weather-system.js";

import {
   CheckpointSystem
}
 from "./checkpoint-system.js";

import {
   BossPhaseController
}
 from "./boss-phases.js";

import {
   PhotoMode
}
 from "./photo-mode.js";

import {
   ExoScienceSystem
}
 from "./ufo-science.js";

import {
   drawXenoArtifact
}
 from "./xeno-artifacts.js";

import {
   DistressBeaconSystem
}
 from "./distress-beacon.js";

export class ExpansionRuntime {

    constructor(world,
  profile) {

        this.world=world;

        this.profile=profile;

        const definition=world.data.expansion||{

    }
    ;

        this.npcs=new NPCSystem(profile.events,
    definition.npcs||[]);

        this.beacons=(definition.beacons||[]).map(beacon=>({...beacon}));

        this.environment=new EnvironmentSystem(profile.events,
    definition.environment||{

    }
    );

        this.platforms=new DynamicPlatformSystem(definition.movingPlatforms||[]);

        this.loot=new LootSystem(profile.events,
    profile.inventory,
    (world.index+1)*9271);

        this.combat=new CombatSystem(profile.events);

        this.companion=profile.companions;

        this.map=new MapSystem(profile.events,
    world.data);

        this.director=new GameDirector();

        this.worldEvents=new WorldEventSystem(profile.events);

        this.weather=new WeatherSystem(definition.weather==="low-gravity"?"low_gravity":definition.weather||"clear",
    world.index+11,
    {levelIndex:world.index});

        this.checkpoints=new CheckpointSystem();

        this.photoMode=new PhotoMode();

        this.bossController=world.boss?new BossPhaseController(definition.bossType||"warden",
    profile.events):null;

        this.exo=new ExoScienceSystem(world, profile);

        this.artifacts=profile.artifacts.forLevel(world.index);

        this.distress=new DistressBeaconSystem(world.index, profile, definition.distressBeacons||null);

        this.lastPlayer=null;

        this.previousPlatforms=this.platforms.snapshot();

        this.platforms.platforms.forEach(platform=>world.platforms.push(platform));

        this.interactionHint=null;

        this.lastCheckpoint=false;

        this.profile.events.on("combat:kill",
    event=>{

            const target=event.payload.target;

            this.loot.dropFrom(target==="boss"?"boss":target==="brute"?"brute":"drone",
      event.payload.x||world.camera+480,
      390);


    }
    );

        this.profile.events.on("world:checkpoint",
    ()=>this.lastCheckpoint=true);

        this.profile.events.on("world-event:started", (event) => {
      if (event.payload.id === "supply_pod") {
        const dropX = Math.min(this.world.width - 120, Math.max(120, this.world.playerX + 90));
        this.loot.dropFrom("drone", dropX, 140);
        this.loot.drops.push({
          id: `pod-${Date.now()}`,
          item: "med_patch",
          count: 1,
          x: dropX + 24,
          y: 130,
          vx: 0,
          vy: 0.6,
          life: 1400,
          bob: 0
        });
      } else if (event.payload.id === "alien_patrol") {
        this.exo.spawnPatrolSaucer({ x: this.world.playerX || 260, y: 420 });
      }
      this.world.pushComms?.("moth", `Orbital sensor alert: ${event.payload.title} active.`);
    });

        this.profile.events.on("region:entered", (event) => {
      this.world.pushComms?.("fiona", `Entering ${event.payload.name}. Stay sharp.`);
    });

        this.profile.events.on("boss:phase", (event) => {
      const speaker = this.world.data.id === "eclipse-core" ? "warden" : "commander";
      this.world.pushComms?.(speaker, `Switching to ${event.payload.name} protocol!`);
    });


  }

    update(player) {

        this.previousPlatforms=this.platforms.snapshot();

        this.platforms.update();

        this.platforms.carryPlayer(player,
    this.previousPlatforms);

        this.environment.update(player,
    this.world);

        this.companion.update(player,
    this.world);

        this.npcs.update(player);

        this.loot.update(player,
    this.world);

        this.map.update(player);

        this.combat.update();

        this.director.update(player,
    this.world);

        this.worldEvents.update();
        if (!this.worldEvents.active && this.world.elapsed > 240 && this.world.elapsed % 180 === 0) {
      const eventId = this.worldEvents.chooseForContext({
        time: this.world.elapsed / 60,
        threat: this.world.enemies.length / 6,
        explored: Math.min(1, player.x / Math.max(1, this.world.width)),
        region: this.world.data.background === "crystal" ? "crystal" : "sector"
      });
      if (eventId) this.worldEvents.start(eventId);
    }

        this.profile.challenges.update();

        this.profile.upgrades.update();

        if(this.bossController&&this.world.boss&&!this.world.boss.dead)this.bossController.update(this.world.boss,
    this.world,
    player);

        this.lastPlayer=player;

        this.exo.update(player);

        this.distress.update(player, this.world);

        const pickupR = Math.max(30, player.pickupRadius || 25);
        const heroX = player.x + player.w / 2;
        const heroY = player.y + player.h / 2;
        for (const art of this.artifacts) {
          if (art.collected) continue;
          if (Math.hypot(heroX - art.x, heroY - art.y) < pickupR) {
            art.collected = true;
            const res = this.profile.artifacts.collect(art.id);
            if (res.firstDiscovery) {
              this.world.audio?.collect?.();
              this.world.particles?.burst?.(art.x, art.y, art.tint || "#a9e58a", 18, 3.8);
              this.profile.economy?.earn?.(art.credits || 45, "xeno-artifact");
              this.profile.progression?.addXP?.(art.xp || 35);
              const left = this.artifacts.filter((item) => !item.collected).length;
              const tail = left === 0 ? " Sector relic log complete!" : "";
              this.world.pushComms?.(
                "fiona",
                `Xeno-Artifact recovered: ${art.name} (${art.catalogCode}). Press G for Field Guide!${tail}`,
                260
              );
            }
          }
        }

        this.profile.statistics.update(player);

        this.profile.applyPlayer(player);

        this.weather.update(1/60, player, this.world);

        this.weather.apply(player);

        if(this.world.checkpoint.active&&!this.lastCheckpoint){

            this.checkpoints.activate(`level-${this.world.index}`,
      player,
      this.world);

            this.profile.events.emit("world:checkpoint",
      {
        level:this.world.index
      }
      );

            this.lastCheckpoint=true;


    }

    if (this.npcs.nearby) {
      this.interactionHint = {
        x: this.npcs.nearby.x,
        y: this.npcs.nearby.y - 26,
        label: "E  TALK"
      };
    } else {
      const nearStation = (this.world.data.expansion?.stations || []).find(
        (item) => Math.abs(item.x - player.x) < 55 && Math.abs(item.y - player.y) < 70
      );
      const nearBeacon = this.beacons.find(
        (item) => !item.active && Math.abs(item.x - player.x) < 60
      );
      const nearDistress = this.distress.nearBeacon(player, 68);
      const nearAnomaly = this.exo.nearAnomaly(player);
      if (nearStation) {
        this.interactionHint = {
          x: nearStation.x,
          y: nearStation.y - 36,
          label: "E  CRAFT"
        };
      } else if (nearDistress) {
        this.interactionHint = {
          x: nearDistress.x,
          y: nearDistress.y - 46,
          label: "E  LOCK SOS"
        };
      } else if (nearBeacon) {
        this.interactionHint = {
          x: nearBeacon.x,
          y: nearBeacon.y - 42,
          label: nearBeacon.kind === "dish" ? "E  ALIGN DISH" : "E  ACTIVATE"
        };
      } else if (nearAnomaly) {
        this.interactionHint = {
          x: nearAnomaly.x,
          y: nearAnomaly.y - 38,
          label: "E / F  SCAN"
        };
      } else {
        this.interactionHint = null;
      }
    }
  }

  interact(player) {
    const npc = this.npcs.interact(player, this.profile.quests);
    if (npc) {
      return { type: "npc", ...npc };
    }

    const station = (this.world.data.expansion?.stations || []).find(
      (item) => Math.abs(item.x - player.x) < 55 && Math.abs(item.y - player.y) < 70
    );
    if (station) {
      this.profile.crafting.setStation(station.type);
      return {
        type: "station",
        station,
        recipes: this.profile.crafting.availableRecipes()
      };
    }

    const beacon = this.beacons.find(
      (item) => !item.active && Math.abs(item.x - player.x) < 60
    );
    if (beacon) {
      beacon.active = true;
      this.profile.quests.addProgressByTag("beacon", 1);
      if (beacon.kind === "transmitter") this.profile.quests.addProgressByTag("transmitter", 1);
      if (beacon.kind === "badge") {
        this.profile.inventory.add("old_badge", 1);
        this.profile.quests.addProgressByTag("badge_returned", 1);
      }
      if (beacon.kind === "dish") {
        this.profile.quests.addProgressByTag("dish_aligned", 1);
        if (this.beacons.filter((item) => item.kind === "dish" && item.active).length === 3) {
          this.profile.quests.addProgressByTag("signal_sent", 1);
        }
      }
      this.profile.events.emit("beacon:activated", {
        id: beacon.id,
        kind: beacon.kind || "relay"
      });
      return { type: "beacon", beacon };
    }

    const resolvedDistress = this.distress.interact(player, this.world);
    if (resolvedDistress) {
      return { type: "distress", beacon: resolvedDistress };
    }

    const nearAnomaly = this.exo.nearAnomaly(player);
    if (nearAnomaly) {
      const analyzed = this.exo.analyzeAnomaly(nearAnomaly, player);
      if (analyzed) return { type: "anomaly", anomaly: analyzed };
    }

    return null;
  }

  drawStations(ctx, camera = 0) {
    const stations = this.world.data.expansion?.stations || [];
    for (const station of stations) {
      const x = station.x - camera;
      const y = station.y;
      ctx.save();
      if (station.type === "campfire") {
        ctx.fillStyle = "#5c4a48";
        ctx.fillRect(x - 14, y + 22, 28, 8);
        const flicker = Math.sin(this.world.elapsed * 0.2) * 3;
        ctx.fillStyle = "#ff9d4d";
        ctx.beginPath();
        ctx.moveTo(x - 10, y + 22);
        ctx.lineTo(x, y + 2 - flicker);
        ctx.lineTo(x + 10, y + 22);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#ffe68a";
        ctx.beginPath();
        ctx.moveTo(x - 5, y + 22);
        ctx.lineTo(x, y + 10 - flicker * 0.5);
        ctx.lineTo(x + 5, y + 22);
        ctx.closePath();
        ctx.fill();
        for (let i = 0; i < 3; i++) {
          const cycle = ((this.world.elapsed * 0.045 + i * 0.34) % 1);
          const emberX = x + Math.sin(cycle * 6 + i * 2) * 7;
          const emberY = y + 8 - cycle * 22;
          ctx.globalAlpha = (1 - cycle) * 0.85;
          ctx.fillStyle = i % 2 === 0 ? "#ffd76d" : "#ff9d4d";
          ctx.fillRect(emberX - 1, emberY - 1, 2.2, 2.2);
        }
      } else {
        const sweep = (Math.sin(this.world.elapsed * 0.09) + 1) * 0.5;
        const ledBlink = Math.sin(this.world.elapsed * 0.16) > 0;
        ctx.fillStyle = "#314672";
        ctx.beginPath();
        ctx.roundRect(x - 18, y + 4, 36, 26, 4);
        ctx.fill();
        ctx.fillStyle = "#73f0ed";
        ctx.fillRect(x - 16, y + 4, 32, 5);
        ctx.fillStyle = "#162547";
        ctx.fillRect(x - 12, y + 12, 24, 9);
        ctx.fillStyle = "#ffd76d";
        ctx.fillRect(x - 10 + sweep * 14, y + 14, 6, 4);
        ctx.fillStyle = ledBlink ? "#a9e58a" : "#3a566b";
        ctx.fillRect(x + 11, y + 14, 3, 3);
      }
      ctx.restore();
    }
  }

  drawBeacons(ctx, camera = 0) {
    const pulse = (Math.sin(this.world.elapsed * 0.1) + 1) * 0.5;
    for (const beacon of this.beacons) {
      const x = beacon.x - camera;
      const y = beacon.y;
      ctx.save();
      if (beacon.kind === "badge") {
        const bob = beacon.active ? 0 : Math.sin(this.world.elapsed * 0.08) * 3;
        ctx.globalAlpha = beacon.active ? 0.35 : 1;
        ctx.fillStyle = "#ffd76d";
        ctx.shadowColor = "#ffd76d";
        ctx.shadowBlur = beacon.active ? 0 : 10;
        ctx.beginPath();
        ctx.roundRect(x - 10, y + 8 + bob, 20, 24, 4);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#182344";
        ctx.fillRect(x - 5, y + 14 + bob, 10, 4);
        ctx.fillRect(x - 5, y + 21 + bob, 10, 3);
      } else if (beacon.kind === "dish") {
        ctx.fillStyle = "#334770";
        ctx.fillRect(x - 4, y + 4, 8, 36);
        ctx.fillStyle = "#4d679b";
        ctx.fillRect(x - 14, y + 34, 28, 6);
        ctx.strokeStyle = beacon.active ? "#73f0ed" : "#ffd76d";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(x + 2, y - 4, 15, Math.PI * 0.75, Math.PI * 1.75);
        ctx.stroke();
        ctx.fillStyle = beacon.active ? "#73f0ed" : "#ffd76d";
        ctx.beginPath();
        ctx.arc(x + 4, y - 6, 4, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = "#334770";
        ctx.fillRect(x - 4, y - 6, 8, 46);
        ctx.fillStyle = "#4d679b";
        ctx.fillRect(x - 14, y + 34, 28, 6);
        const color = beacon.active ? "#73f0ed" : "#ffd76d";
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = beacon.active ? 14 : 6 + pulse * 8;
        ctx.beginPath();
        ctx.arc(x, y - 10, 7, 0, Math.PI * 2);
        ctx.fill();
        if (!beacon.active) {
          ctx.strokeStyle = `rgba(255, 215, 109, ${0.25 + pulse * 0.45})`;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(x, y - 10, 12 + pulse * 6, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      ctx.restore();
    }
  }

  draw(ctx, camera = 0) {
    this.platforms.draw(ctx, camera);
    this.environment.draw(ctx, camera, false);
    this.weather.drawZones(ctx, camera);
    this.drawStations(ctx, camera);
    this.drawBeacons(ctx, camera);
    this.distress.draw(ctx, camera, this.world.elapsed);
    for (const art of this.artifacts) {
      if (!art.collected) drawXenoArtifact(ctx, art, this.world.elapsed, camera);
    }
    this.exo.draw(ctx, camera);
    this.npcs.draw(ctx, camera);
    this.loot.draw(ctx, camera);
    this.companion.draw(ctx, camera);
    this.combat.draw(ctx, camera);

    if (this.interactionHint) {
      const bob = Math.sin(this.world.elapsed * 0.12) * 2.5;
      const hx = this.interactionHint.x - camera;
      const hy = this.interactionHint.y + bob;
      const label = this.interactionHint.label || "E  TALK";
      const boxW = Math.max(84, label.length * 8 + 18);
      ctx.save();
      ctx.fillStyle = "rgba(10, 18, 44, 0.9)";
      ctx.strokeStyle = "rgba(115, 240, 237, 0.6)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(hx - boxW / 2, hy - 22, boxW, 24, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#f3f5ff";
      ctx.font = "bold 11px 'JetBrains Mono', monospace";
      ctx.textAlign = "center";
      ctx.fillText(label, hx, hy - 6);
      ctx.restore();
    }
  }

  drawScreen(ctx) {
    this.environment.drawWeather(ctx);
    const focusX = Math.max(80, Math.min(880, (this.world.playerX || 200) - (this.world.camera || 0)));
    const focusY = this.world.playerY || 360;
    this.weather.draw(ctx, focusX, focusY);
    if (this.worldEvents.active?.id === "meteor_shower") {
      ctx.save();
      ctx.strokeStyle = "rgba(255, 224, 139, 0.45)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        const mx = ((i * 197 + this.world.elapsed * 7) % 1040) - 40;
        const my = (i * 89 + this.world.elapsed * 5) % 420;
        ctx.beginPath();
        ctx.moveTo(mx, my);
        ctx.lineTo(mx - 22, my + 16);
        ctx.stroke();
      }
      ctx.restore();
    }
    this.worldEvents.draw(ctx);
    this.distress.drawScreen(ctx, this.lastPlayer, this.world);
    this.exo.drawTelemetry(ctx);
    const ch = this.profile.challenges.state();
    if (ch) {
      ctx.save();
      ctx.fillStyle = "rgba(10, 16, 40, 0.84)";
      ctx.strokeStyle = "rgba(115, 240, 237, 0.5)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(16, 50, 206, 26, 8);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#73f0ed";
      ctx.font = "bold 10px 'JetBrains Mono', monospace";
      ctx.textAlign = "left";
      ctx.fillText(`${ch.name.toUpperCase()} · ${Math.ceil(ch.remaining)}s · ${ch.progress}/${ch.goal}`, 24, 67);
      ctx.restore();
    }
    this.combat.drawComboHud(ctx, ch ? 82 : 44);
  }

    serialize() {

        return {

            npcs:this.npcs.serialize(),
      beacons:this.beacons.map(beacon=>({id:beacon.id,active:beacon.active})),
      environment:this.environment.serialize(),

            loot:this.loot.serialize(),
      combat:this.combat.serialize(),
      map:this.map.serialize(),

            director:this.director.snapshot(),
      worldEvents:this.worldEvents.serialize(),

            weather:this.weather.serialize(),
      checkpoints:this.checkpoints.serialize(),
      distress:this.distress.serialize()

    }
    ;


  }

    restore(data={

  }
  ) {

        this.npcs.restore(data.npcs||[]);
        for(const state of data.beacons||[]){
      const beacon=this.beacons.find(item=>item.id===state.id);
      if(beacon)beacon.active=Boolean(state.active);
    }

        this.environment.restore(data.environment||{

    }
    );

        this.loot.restore(data.loot||{

    }
    );

        this.combat.restore(data.combat||{

    }
    );

        this.map.restore(data.map||{

    }
    );

        this.director.restore(data.director||{

    }
    );

        this.worldEvents.restore(data.worldEvents||{

    }
    );

        this.weather.restore(data.weather||{

    }
    );

        this.checkpoints.restoreData(data.checkpoints||{

    }
    );

        this.distress.restore(data.distress||[]);


  }


}
