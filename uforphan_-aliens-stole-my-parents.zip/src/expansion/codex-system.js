import {
   EXPANSION_EVENTS
}
 from "./constants.js";

export const CODEX_ENTRIES=[
  {
  id:"fiona",
  category:"people",
  title:"Fiona Gallegar",
  text:"A stubborn young explorer who refuses to let a tractor beam decide where her family belongs.",
  unlock:"start"
}
,

  {
  id:"pip",
  category:"people",
  title:"Pip",
  text:"A retired Moon Mall security bot whose badge opens more doors than its owner remembers.",
  unlock:"meet:pip"
}
,

  {
  id:"rivet",
  category:"people",
  title:"Rivet",
  text:"A pirate mechanic with a soft spot for broken machines and impossible projects.",
  unlock:"meet:rivet"
}
,

  {
  id:"mothlet",
  category:"creatures",
  title:"Mothlet",
  text:"A tiny navigation drone that defected after reading the employee handbook.",
  unlock:"companion:mothlet"
}
,

  {
  id:"ion_storm",
  category:"phenomena",
  title:"Ion Storm",
  text:"Electrical weather that bends trajectories and makes old antenna arrays sing.",
  unlock:"region:ion-storm"
}
,

  {
  id:"mothership",
  category:"places",
  title:"The Mothership",
  text:"A modular command vessel with a surprisingly small cafeteria and a very large detention wing.",
  unlock:"level:3"
}
,

  {
  id:"crystal_grove",
  category:"places",
  title:"Crystal Grove",
  text:"A quiet valley where resonant crystals grow toward sound and remember old melodies.",
  unlock:"level:6"
}
,

  {
  id:"family_signal",
  category:"technology",
  title:"Family Frequency",
  text:"A low-power transmission pattern tuned to the familiar rhythms of home.",
  unlock:"quest:family_frequency"
}
,

  {
  id:"pebble",
  category:"creatures",
  title:"Pebble",
  text:"A cheerful asteroid guardian drone that intercepts stray laser fire out of sheer politeness.",
  unlock:"companion:pebble"
}
,

  {
  id:"zip",
  category:"creatures",
  title:"Zip",
  text:"A hyperactive solar spark that doubles stardust output whenever Fiona stays light on her feet.",
  unlock:"companion:zip"
}
,

  {
  id:"minivan",
  category:"technology",
  title:"The Gallegar Minivan",
  text:"A teal family wagon last spotted in Moon Mall orbit with two folding chairs and an intact bumper sticker.",
  unlock:"level:0"
}
,

  {
  id:"captain_cat",
  category:"creatures",
  title:"Captain Whiskers",
  text:"Returned from the tractor beam within four minutes, yet refuses to surrender his command chair privileges.",
  unlock:"level:2"
}
,

  {
  id:"commander",
  category:"people",
  title:"Commander Zelk",
  text:"Head of Abduction Logistics who insisted every kidnapping include a Moon Mall voucher and three signatures.",
  unlock:"level:4"
}
,

  {
  id:"core_warden",
  category:"people",
  title:"The Core Warden",
  text:"Eclipse Core's automated bureaucrat, convinced an entire family counts as 'unreturned cosmic stationery.'",
  unlock:"level:7"
}
,

  {
  id:"wow_signal",
  category:"technology",
  title:"1420 MHz Hydrogen Line",
  text:"SETI astrophysicists monitor 1420.405 MHz because neutral hydrogen fills the cosmos—making it every alien civilization's natural intercom channel.",
  unlock:"anomaly:wow_signal"
}
,

  {
  id:"alcubierre_wake",
  category:"phenomena",
  title:"Alcubierre Warp Metric",
  text:"Instead of accelerating past light speed, UFO cruisers compress spacetime ahead and expand it behind—letting even a minivan surf a warp bubble intact.",
  unlock:"anomaly:alcubierre_wake"
}
,

  {
  id:"element_115",
  category:"technology",
  title:"Moscovium-115 Lattice",
  text:"The island of nuclear stability around Z=115 provides dense graviton waves for saucer hovering—though firing a blaster at one flips its polarity into an anti-gravity updraft.",
  unlock:"anomaly:element_115"
}
,

  {
  id:"drake_equation",
  category:"phenomena",
  title:"The Gallegar Factor",
  text:"Frank Drake estimated communicating worlds across the Milky Way. Fiona added one extra term: the odds an alien mall offers discount coupons to abductees.",
  unlock:"anomaly:drake_equation"
}
,

  {
  id:"roche_limit",
  category:"places",
  title:"Tidal Roche Horizon",
  text:"When fragile moons drift inside a planet's Roche limit, tidal shear pulls them into glittering orbital rings like the Scrap Belt.",
  unlock:"anomaly:roche_limit"
}
,

  {
  id:"panspermia_flora",
  category:"creatures",
  title:"Lithopanspermia Spores",
  text:"Extremophile microbes and tardigrade-hardy seeds can hitch rides on ejecta rocks between worlds, explaining why Bio-Dome vines respond to stellar music.",
  unlock:"anomaly:panspermia_flora"
}

];

export class CodexSystem {

    constructor(hub,
  saved=[]){
    this.hub=hub;
    this.entries=new Map(CODEX_ENTRIES.map(entry=>[entry.id,
    entry]));
    this.unlocked=new Set(["fiona"]);
    this.read=new Set();
    this.restore(saved);

  }

    unlock(id){
    if(!this.entries.has(id)||this.unlocked.has(id))return false;
    this.unlocked.add(id);
    this.hub?.emit("codex:unlocked",
    {
      id,
      entry:this.entries.get(id)
    }
    );
    return true;

  }

    unlockByTrigger(trigger){
    let count=0;
    for(const entry of this.entries.values())if(entry.unlock===trigger&&this.unlock(entry.id))count++;
    return count;

  }

    markRead(id){
    if(!this.unlocked.has(id))return false;
    this.read.add(id);
    return true;

  }

    list(category=null){
    return [...this.entries.values()].filter(entry=>this.unlocked.has(entry.id)&&(!category||entry.category===category)).map(entry=>({
      ...entry,
      read:this.read.has(entry.id)
    }
    ));

  }

    progress(){
    return {
      unlocked:this.unlocked.size,
      total:this.entries.size,
      percent:Math.round(this.unlocked.size/this.entries.size*100)
    }
    ;

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      read:[...this.read]
    }
    ;

  }

    restore(data={

  }
  ){
    for(const id of data.unlocked||[])if(this.entries.has(id))this.unlocked.add(id);
    for(const id of data.read||[])if(this.entries.has(id))this.read.add(id);

  }


}
