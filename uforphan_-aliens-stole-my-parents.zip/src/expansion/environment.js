import {
   clamp,
   intersects,
   EXPANSION_EVENTS
}
 from "./constants.js";

export class EnvironmentSystem {

    constructor(hub,
  definition={

  }
  ){
    this.hub=hub;
    this.weather=definition.weather||"clear";
    this.hazards=(definition.hazards||[]).map((hazard,
    index)=>({
      id:hazard.id||`env-${index}`,
      active:true,
      phase:0,
      cooldown:0,
      damage:hazard.damage??1,
      ...hazard
    }
    ));
    this.zones=(definition.zones||[]).map(zone=>({
      ...zone,
      entered:false
    }
    ));
    this.wind=definition.wind||{
      x:0,
      y:0
    }
    ;
    this.time=0;
    this.modifiers={
      gravity:1,
      friction:1,
      visibility:1
    }
    ;
    this.particles=[];

  }

    update(player,
  world){
    this.time++;
    this.updateWeather();
    for(const hazard of this.hazards){
      hazard.phase++;
      if(hazard.cooldown>0)hazard.cooldown--;
      if(hazard.active&&hazard.cooldown===0&&intersects(player,
      hazard)){
        if(hazard.kind==="vent")player.vx+=Math.sign(hazard.force||1)*1.5;
        if(hazard.kind==="geyser"&&hazard.phase%180<70){
          player.takeDamage(world.audio,
          world.particles);
          hazard.cooldown=80;

        }
        if(hazard.kind==="electric"&&hazard.phase%120<60){
          player.takeDamage(world.audio,
          world.particles);
          hazard.cooldown=90;

        }

      }

    }

        for(const zone of this.zones){
      const inside=intersects(player,
      zone);
      if(inside&&!zone.entered){
        zone.entered=true;
        this.hub?.emit(EXPANSION_EVENTS.REGION_ENTERED,
        {
          zone:zone.id,
          name:zone.name
        }
        );

      }
      if(!inside)zone.entered=false;

    }

  }

    updateWeather(){
    const cycle=this.time%2400;
    if(this.weather==="ion-storm"){
      this.modifiers.gravity=cycle>500&&cycle<1700?1.12:1;
      this.modifiers.visibility=cycle>500&&cycle<1700?.68:1;
      this.wind.x=Math.sin(this.time*.018)*.18;

    }
    else if(this.weather==="low-gravity"){
      this.modifiers.gravity=.62;
      this.wind.x=Math.sin(this.time*.008)*.06;

    }
    else{
      this.modifiers.gravity=1;
      this.modifiers.visibility=1;
      this.wind.x=0;

    }

  }

    applyToPlayer(player){
    player.vx+=this.wind.x;
    player.vy+=this.wind.y;
    player.vy=clamp(player.vy,
    -18,
    16);

  }

  draw(ctx, camera = 0, includeScreenWeather = true) {
    this.drawHazards(ctx, camera);
    if (includeScreenWeather) this.drawWeather(ctx);
  }

    drawHazards(ctx,
  camera){
    for(const hazard of this.hazards){
      const x=hazard.x-camera,
      y=hazard.y;
      ctx.save();
      if(hazard.kind==="geyser"){
        const erupting=hazard.phase%180<70;
        ctx.fillStyle=erupting?"rgba(255,115,125,.65)":"rgba(255,115,125,.18)";
        ctx.fillRect(x,
        y,
        hazard.w,
        hazard.h);
        // Rising thermal plume circles during eruption
        if(erupting){
          ctx.fillStyle="rgba(255, 204, 150, 0.55)";
          for(let i=0;i<3;i++){
            const py=y+hazard.h-((this.time*3+i*18)%Math.max(12,hazard.h));
            const px=x+hazard.w*0.5+Math.sin(this.time*0.2+i)*6;
            ctx.beginPath();
            ctx.arc(px,py,3.5,0,Math.PI*2);
            ctx.fill();
          }
        }
      }
      else if(hazard.kind==="electric"){
        const active=hazard.phase%120<60;
        ctx.strokeStyle=active?"#8cf4ff":"rgba(140, 244, 255, 0.35)";
        ctx.lineWidth=active?3:1.5;
        ctx.beginPath();
        ctx.moveTo(x,y);
        const midX=x+hazard.w*0.5+Math.sin(this.time*0.7+hazard.x)*5;
        const midY=y+hazard.h*0.5+Math.cos(this.time*0.8)*4;
        ctx.lineTo(midX,midY);
        ctx.lineTo(x+hazard.w,y+hazard.h);
        ctx.moveTo(x+hazard.w,y);
        ctx.lineTo(midX-3,midY+2);
        ctx.lineTo(x,y+hazard.h);
        ctx.stroke();
        // Node emitter caps
        ctx.fillStyle=active?"#ffffff":"#73f0ed";
        ctx.fillRect(x-2,y-2,5,5);
        ctx.fillRect(x+hazard.w-3,y+hazard.h-3,5,5);
      }
      else{
        ctx.fillStyle="#a5b4d8";
        ctx.fillRect(x,
        y,
        hazard.w,
        hazard.h);
        // Animated vent airflow streaks
        const dir=Math.sign(hazard.force||1);
        ctx.strokeStyle="rgba(166, 224, 255, 0.52)";
        ctx.lineWidth=1.5;
        for(let i=0;i<3;i++){
          const offset=((this.time*2.5+i*12)%Math.max(18,hazard.w));
          const lx=dir>=0?x+offset:x+hazard.w-offset;
          const ly=y+6+i*(hazard.h/3.5);
          ctx.beginPath();
          ctx.moveTo(lx,ly);
          ctx.lineTo(lx+dir*10,ly);
          ctx.stroke();
        }
      }
      ctx.restore();
    }

  }

    drawWeather(ctx){
    if(this.weather==="ion-storm"&&this.modifiers.visibility<1){
      ctx.fillStyle="rgba(101,213,239,.08)";
      ctx.fillRect(0,
      0,
      960,
      540);
      for(let i=0;
      i<18;
      i++){
        const x=(i*71+this.time*4)%980;
        ctx.strokeStyle="rgba(169,239,255,.28)";
        ctx.beginPath();
        ctx.moveTo(x,
        0);
        ctx.lineTo(x-35,
        80);
        ctx.stroke();

      }

    }

  }

    activate(id){
    const hazard=this.hazards.find(item=>item.id===id);
    if(!hazard)return false;
    hazard.active=!hazard.active;
    return hazard.active;

  }

    serialize(){
    return {
      weather:this.weather,
      time:this.time,
      hazards:this.hazards.map(({
        id,
        active,
        phase,
        cooldown
      }
      )=>({
        id,
        active,
        phase,
        cooldown
      }
      )),
      zones:this.zones.map(({
        id,
        entered
      }
      )=>({
        id,
        entered
      }
      ))
    }
    ;

  }

    restore(data={

  }
  ){
    this.time=data.time||0;
    for(const state of data.hazards||[]){
      const hazard=this.hazards.find(item=>item.id===state.id);
      if(hazard)Object.assign(hazard,
      state);

    }
    for(const state of data.zones||[]){
      const zone=this.zones.find(item=>item.id===state.id);
      if(zone)zone.entered=Boolean(state.entered);

    }

  }


}

export class DynamicPlatformSystem {

    constructor(definitions=[]){
    this.platforms=definitions.map((platform,
    index)=>({
      id:platform.id||`moving-${index}`,
      originX:platform.x,
      originY:platform.y,
      phase:index*.7,
      ...platform
    }
    ));

  }

    update(){
    for(const platform of this.platforms){
      platform.phase+=platform.speed||.02;
      platform.x=platform.originX+Math.sin(platform.phase)* (platform.rangeX||0);
      platform.y=platform.originY+Math.cos(platform.phase)*(platform.rangeY||0);

    }

  }

    carryPlayer(player,
  previous){
    for(const platform of this.platforms){
      if(player.onGround&&Math.abs(player.y+player.h-platform.y)<3&&player.x+player.w>platform.x&&player.x<platform.x+platform.w){
        player.x+=platform.x-previous.get(platform.id).x;
        player.y+=platform.y-previous.get(platform.id).y;

      }

    }

  }

    snapshot(){
    return new Map(this.platforms.map(platform=>[platform.id,
    {
      x:platform.x,
      y:platform.y
    }
    ]));

  }

    draw(ctx,
  camera){
    for(const p of this.platforms){
      const px=p.x-camera;
      ctx.save();
      // Hovering underside antigrav emitter glow
      const glow=0.22+(Math.sin(p.phase*3)+1)*0.12;
      ctx.fillStyle=`rgba(115, 240, 237, ${glow})`;
      ctx.beginPath();
      ctx.ellipse(px+p.w*0.25,p.y+p.h+4,12,3.5,0,0,Math.PI*2);
      ctx.ellipse(px+p.w*0.75,p.y+p.h+4,12,3.5,0,0,Math.PI*2);
      ctx.fill();

      ctx.fillStyle="#4a6a9b";
      ctx.beginPath();
      ctx.roundRect(px,p.y,p.w,p.h,4);
      ctx.fill();
      ctx.fillStyle="#93eff0";
      ctx.fillRect(px+2,p.y,p.w-4,4);
      ctx.fillStyle="#ffd76d";
      ctx.fillRect(px+6,p.y+8,6,3);
      ctx.fillRect(px+p.w-12,p.y+8,6,3);
      ctx.restore();
    }

  }


}
