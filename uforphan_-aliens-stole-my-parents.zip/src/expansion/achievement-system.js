import {
   EXPANSION_EVENTS
}
 from "./constants.js";

export const ACHIEVEMENTS=[
  {
  id:"first_steps",
  title:"First Steps",
  description:"Complete the first expansion chapter.",
  test:s=>s.levelsCompleted>=5,
  points:10
}
,

  {
  id:"pack_rat",
  title:"Pack Rat",
  description:"Carry at least ten different item stacks.",
  test:s=>s.inventorySlots>=10,
  points:15
}
,

  {
  id:"tinkerer",
  title:"Tinkerer",
  description:"Craft five items.",
  test:s=>s.crafts>=5,
  points:20
}
,

  {
  id:"friendly_face",
  title:"Friendly Face",
  description:"Meet every named expansion character.",
  test:s=>s.npcsMet>=4,
  points:20
}
,

  {
  id:"stardust_savant",
  title:"Stardust Savant",
  description:"Collect 100 stardust fragments.",
  test:s=>s.stars>=100,
  points:30
}
,

  {
  id:"no_hit",
  title:"Untouchable-ish",
  description:"Finish a challenge without taking damage.",
  test:s=>s.flawlessChallenges>=1,
  points:25
}
,

  {
  id:"signal_home",
  title:"Signal Home",
  description:"Complete the family frequency quest.",
  test:s=>s.familySignal===true,
  points:50
}
,

  {
  id:"galaxy_helper",
  title:"Galaxy Helper",
  description:"Complete eight side quests.",
  test:s=>s.questsCompleted>=8,
  points:40
}
,

  {
  id:"xeno_curator",
  title:"Xeno-Artifact Curator",
  description:"Recover eight unique Xeno-Artifacts across the galaxy.",
  test:s=>(s.artifacts||0)>=8,
  points:35
}

];

export class AchievementSystem {

    constructor(hub,
  saved=[]){
    this.hub=hub;
    this.unlocked=new Set(Array.isArray(saved)?saved:(saved.unlocked||[]));
    this.claimed=new Set(saved.claimed||[]);
    this.points=saved.points||0;
    this.queue=[];

  }

    evaluate(stats={

  }
  ){
    for(const achievement of ACHIEVEMENTS){
      if(this.unlocked.has(achievement.id))continue;
      let passed=false;
      try{
        passed=Boolean(achievement.test(stats));

      }
      catch{
        passed=false;

      }
      if(passed){
        this.unlocked.add(achievement.id);
        this.queue.push(achievement.id);
        this.points+=achievement.points;
        this.hub?.emit("achievement:unlocked",
        {
          ...achievement
        }
        );

      }

    }
    return this.queue.slice();

  }

    nextNotification(){
    const id=this.queue.shift();
    return id?ACHIEVEMENTS.find(item=>item.id===id)||null:null;

  }

    isUnlocked(id){
    return this.unlocked.has(id);

  }

    list(){
    return ACHIEVEMENTS.map(item=>({
      ...item,
      unlocked:this.unlocked.has(item.id)
    }
    ));

  }

    progress(){
    return {
      unlocked:this.unlocked.size,
      total:ACHIEVEMENTS.length,
      points:this.points
    }
    ;

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      claimed:[...this.claimed],
      points:this.points
    }
    ;

  }

    restore(data={

  }
  ){
    this.unlocked=new Set(Array.isArray(data)?data:(data.unlocked||[]));
    this.claimed=new Set(data.claimed||[]);
    this.points=data.points||0;

  }


}
