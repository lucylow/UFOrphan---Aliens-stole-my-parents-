/**
 * Cosmic Weather System: sector-wide atmospheric regimes, spatial weather pockets
 * (Ion Storms, Low Gravity Zones, Dust Fronts, Aurora), physics modifiers, and
 * visibility/signal scrambling integration.
 */

export const WEATHER = {
  clear: {
    name: "Clear Exosphere",
    code: "CLEAR",
    wind: 0,
    gravity: 1,
    visibility: 1,
    scramble: 0,
    speedMult: 1
  },
  ion: {
    name: "Ion Storm",
    code: "ION STORM",
    wind: 0.14,
    gravity: 1.06,
    visibility: 0.62,
    scramble: 0.78,
    speedMult: 0.93
  },
  low_gravity: {
    name: "Low Gravity Zone",
    code: "LOW-G",
    wind: 0.03,
    gravity: 0.58,
    visibility: 1,
    scramble: 0.06,
    speedMult: 1.06
  },
  dust: {
    name: "Silicate Dust Front",
    code: "DUST FRONT",
    wind: 0.2,
    gravity: 1,
    visibility: 0.56,
    scramble: 0.28,
    speedMult: 0.92
  },
  aurora: {
    name: "Magnetosphere Aurora",
    code: "AURORA",
    wind: 0,
    gravity: 0.92,
    visibility: 0.96,
    scramble: 0.1,
    speedMult: 1.04
  }
};

/** Chapter-specific cosmic weather surges and localized spatial weather zones. */
export const COSMIC_WEATHER_PRESETS = {
  0: {
    base: "clear",
    zones: [
      { id: "wake-low-g", type: "low_gravity", label: "LOW-G WAKE 0.58g", x: 1080, w: 520 }
    ]
  },
  1: {
    base: "low_gravity",
    zones: [
      { id: "mall-ion-squall", type: "ion", label: "ION STORM SQUALL", x: 1840, w: 560 }
    ]
  },
  2: {
    base: "dust",
    zones: [
      { id: "roche-low-g", type: "low_gravity", label: "ROCHE LOW-G ZONE", x: 1680, w: 620 }
    ]
  },
  3: {
    base: "clear",
    surgeWeather: "ion",
    surgePeriod: 18,
    surgeDuration: 7,
    zones: [
      { id: "core-ion-rift", type: "ion", label: "ION RIFT", x: 960, w: 460 }
    ]
  },
  4: {
    base: "aurora",
    zones: [
      { id: "crystal-low-g", type: "low_gravity", label: "PIEZO LOW-G WELL", x: 1520, w: 580 }
    ]
  },
  5: {
    base: "low_gravity",
    zones: [
      { id: "archive-ion-cell", type: "ion", label: "ARCHIVE ION STORM", x: 1380, w: 600 }
    ]
  },
  6: {
    base: "clear",
    zones: [
      { id: "spore-dust-front", type: "dust", label: "SPORE MIST FRONT", x: 900, w: 640 },
      { id: "canopy-low-g", type: "low_gravity", label: "ZERO-G CANOPY", x: 2140, w: 560 }
    ]
  },
  7: {
    base: "ion",
    surgeWeather: "ion",
    surgePeriod: 15,
    surgeDuration: 8,
    zones: [
      { id: "warden-low-g", type: "low_gravity", label: "GRAVITON LIFT ZONE", x: 1100, w: 460 }
    ]
  }
};

export class WeatherSystem {
  constructor(type = "clear", seed = 1, options = {}) {
    const hasLevel = typeof options.levelIndex === "number";
    const preset = hasLevel ? COSMIC_WEATHER_PRESETS[options.levelIndex] : null;
    const resolvedBase = WEATHER[type] ? type : (preset?.base || "clear");

    this.type = resolvedBase;
    this.baseType = resolvedBase;
    this.seed = seed;
    this.elapsed = 0;
    this.intensity = 0;
    this.transition = null;
    this.zones = (options.zones || preset?.zones || []).map((z) => ({ ...z }));
    this.surgeWeather = options.surgeWeather ?? preset?.surgeWeather ?? null;
    this.surgePeriod = options.surgePeriod ?? preset?.surgePeriod ?? 0;
    this.surgeDuration = options.surgeDuration ?? preset?.surgeDuration ?? 0;
    this.surgeActive = false;
    this.activeZoneId = null;
    this.announcedZones = new Set();
    this.effectiveState = {
      ...WEATHER[this.type],
      type: this.type,
      zoneLabel: null,
      inZone: false,
      surgeActive: false
    };
  }

  set(type, duration = 3) {
    if (!WEATHER[type]) return false;
    if (duration <= 0) {
      this.type = type;
      this.transition = null;
      this.syncEffectiveState(null, false);
      return true;
    }
    this.transition = {
      from: this.type,
      to: type,
      duration,
      elapsed: 0
    };
    return true;
  }

  activeZone(player) {
    if (!player || !this.zones.length) return null;
    const cx = player.x + (player.w || 27) / 2;
    return this.zones.find((z) => cx >= z.x && cx <= z.x + z.w) || null;
  }

  syncEffectiveState(zone = null, surgeActive = false) {
    let activeType = this.type;
    if (surgeActive && this.surgeWeather && WEATHER[this.surgeWeather]) {
      activeType = this.surgeWeather;
    }
    if (zone && WEATHER[zone.type]) {
      activeType = zone.type;
    }
    const spec = WEATHER[activeType] || WEATHER.clear;
    this.effectiveState = {
      ...spec,
      type: activeType,
      zoneLabel: zone?.label || null,
      inZone: Boolean(zone),
      surgeActive
    };
  }

  update(delta = 1 / 60, player = null, world = null) {
    this.elapsed += delta;
    if (this.transition) {
      this.transition.elapsed += delta;
      if (this.transition.elapsed >= this.transition.duration) {
        this.type = this.transition.to;
        this.transition = null;
      }
    }
    this.intensity = (Math.sin(this.elapsed * 0.17) + 1) / 2;

    let nextSurge = false;
    if (this.surgeWeather && this.surgePeriod > 0 && this.surgeDuration > 0) {
      const cyclePos = this.elapsed % this.surgePeriod;
      nextSurge = cyclePos >= this.surgePeriod - this.surgeDuration;
    }
    if (nextSurge && !this.surgeActive && world && !world.comms) {
      world.pushComms?.("moth", "Ion Storm surge incoming—Signal Stability scrambling!", 180);
    }
    this.surgeActive = nextSurge;

    const zone = this.activeZone(player);
    if (zone && zone.id !== this.activeZoneId) {
      this.activeZoneId = zone.id;
      if (!this.announcedZones.has(zone.id) && world && !world.comms) {
        this.announcedZones.add(zone.id);
        const note =
          zone.type === "low_gravity"
            ? `Entering ${zone.label}: gravitational field dropped to ${WEATHER.low_gravity.gravity.toFixed(2)}g!`
            : zone.type === "ion"
              ? `Entering ${zone.label}: electromagnetic squall scrambling telemetry!`
              : `Entering ${zone.label}: particulate visibility reduced.`;
        world.pushComms?.("fiona", note, 175);
      }
    } else if (!zone) {
      this.activeZoneId = null;
    }

    this.syncEffectiveState(zone, this.surgeActive);
    return this.modifiers();
  }

  modifiers() {
    return this.effectiveState || WEATHER[this.type];
  }

  currentState() {
    return this.modifiers();
  }

  apply(player) {
    if (!player) return;
    const weather = this.modifiers();
    player.vx += weather.wind * 0.05;
    if (weather.speedMult && weather.speedMult !== 1) {
      player.speedMultiplier = (player.speedMultiplier || 1) * weather.speedMult;
    }
  }

  /** Renders localized weather zones in world-space coordinates. */
  drawZones(ctx, camera = 0) {
    if (!this.zones.length) return;
    for (const z of this.zones) {
      const x = z.x - camera;
      if (x + z.w < -40 || x > 1000) continue;

      ctx.save();
      if (z.type === "low_gravity") {
        const grad = ctx.createLinearGradient(0, 70, 0, 480);
        grad.addColorStop(0, "rgba(115, 240, 237, 0.02)");
        grad.addColorStop(0.65, "rgba(115, 240, 237, 0.09)");
        grad.addColorStop(1, "rgba(169, 229, 138, 0.14)");
        ctx.fillStyle = grad;
        ctx.fillRect(x, 60, z.w, 420);

        ctx.strokeStyle = "rgba(115, 240, 237, 0.35)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(x, 80);
        ctx.lineTo(x, 480);
        ctx.moveTo(x + z.w, 80);
        ctx.lineTo(x + z.w, 480);
        ctx.stroke();

        // Rising zero-g motes
        ctx.fillStyle = "rgba(169, 229, 138, 0.55)";
        for (let i = 0; i < 10; i++) {
          const offset = ((i * 53 + Math.sin(this.elapsed * 2 + i) * 14) % z.w + z.w) % z.w;
          const mx = x + offset;
          const my = 470 - ((this.elapsed * 42 + i * 39) % 380);
          ctx.fillRect(mx, my, 3, 5);
        }
      } else if (z.type === "ion") {
        ctx.fillStyle = "rgba(182, 108, 255, 0.09)";
        ctx.fillRect(x, 60, z.w, 420);
        ctx.strokeStyle = "rgba(255, 119, 189, 0.36)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(x, 80);
        ctx.lineTo(x, 480);
        ctx.moveTo(x + z.w, 80);
        ctx.lineTo(x + z.w, 480);
        ctx.stroke();
      } else {
        ctx.fillStyle = "rgba(215, 184, 139, 0.09)";
        ctx.fillRect(x, 60, z.w, 420);
      }

      // Subtle zone boundary marker label
      ctx.fillStyle = z.type === "low_gravity" ? "#73f0ed" : z.type === "ion" ? "#ff9be4" : "#ffd76d";
      ctx.font = "bold 9px 'JetBrains Mono', monospace";
      ctx.textAlign = "center";
      ctx.fillText(z.label, x + z.w / 2, 76);
      ctx.restore();
    }
  }

  /** Renders screen-space atmospheric visibility shrouds, lightning streaks, dust, and auroras. */
  draw(ctx, focusX = 480, focusY = 360) {
    const state = this.modifiers();
    const t = this.elapsed * 60;

    if (state.type === "ion") {
      ctx.save();
      // Ion interference tint + reduced far-field clarity radial shroud around Fiona
      const shroud = ctx.createRadialGradient(focusX, focusY, 125, focusX, focusY, 560);
      shroud.addColorStop(0, "rgba(10, 16, 40, 0)");
      shroud.addColorStop(0.55, "rgba(20, 26, 68, 0.24)");
      shroud.addColorStop(1, "rgba(8, 12, 32, 0.56)");
      ctx.fillStyle = shroud;
      ctx.fillRect(0, 0, 960, 540);

      // Diagonal ionized plasma streaks
      ctx.strokeStyle = "rgba(140, 244, 255, 0.32)";
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 16; i++) {
        const x = (i * 89 + t * 5) % 1020;
        const y = (i * 67 + t * 8) % 560;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - 26, y + 48);
        ctx.stroke();
      }

      // Intermittent electrostatic scanline flicker
      if (Math.floor(t * 0.4) % 9 === 0) {
        const sy = (Math.floor(t * 17) % 440) + 40;
        ctx.fillStyle = "rgba(115, 240, 237, 0.14)";
        ctx.fillRect(0, sy, 960, 3);
      }
      ctx.restore();
    } else if (state.type === "dust") {
      ctx.save();
      const dustShroud = ctx.createRadialGradient(focusX, focusY, 110, focusX, focusY, 520);
      dustShroud.addColorStop(0, "rgba(215, 184, 139, 0.04)");
      dustShroud.addColorStop(0.55, "rgba(92, 68, 52, 0.28)");
      dustShroud.addColorStop(1, "rgba(32, 22, 18, 0.62)");
      ctx.fillStyle = dustShroud;
      ctx.fillRect(0, 0, 960, 540);

      ctx.fillStyle = "rgba(255, 224, 176, 0.26)";
      for (let i = 0; i < 22; i++) {
        const x = (i * 73 + t * 6.5) % 980;
        const y = (i * 41 + Math.sin(t * 0.05 + i) * 18) % 520;
        ctx.fillRect(x, y, 14, 2);
      }
      ctx.restore();
    } else if (state.type === "low_gravity") {
      ctx.save();
      ctx.fillStyle = "rgba(115, 240, 237, 0.28)";
      for (let i = 0; i < 16; i++) {
        const x = (i * 61 + Math.sin(t * 0.02 + i) * 18 + 960) % 960;
        const y = 540 - ((t * 1.4 + i * 37) % 540);
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    } else if (state.type === "aurora") {
      ctx.save();
      const gradient = ctx.createLinearGradient(0, 0, 960, 0);
      gradient.addColorStop(0, "rgba(92,245,221,.05)");
      gradient.addColorStop(0.5, `rgba(173,111,245,${0.08 + this.intensity * 0.1})`);
      gradient.addColorStop(1, "rgba(169,229,138,.06)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 960, 220);
      ctx.restore();
    }
  }

  serialize() {
    return {
      type: this.type,
      seed: this.seed,
      elapsed: this.elapsed
    };
  }

  restore(data = {}) {
    this.type = WEATHER[data.type] ? data.type : "clear";
    this.seed = data.seed || 1;
    this.elapsed = data.elapsed || 0;
    this.syncEffectiveState(null, false);
  }
}
