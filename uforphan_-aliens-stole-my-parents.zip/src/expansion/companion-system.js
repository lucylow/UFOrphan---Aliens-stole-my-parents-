import {
   distance,
   EXPANSION_EVENTS
}
 from "./constants.js";

export const COMPANIONS={

    mothlet:{
    name:"Mothlet",
    ability:"scanner",
    description:"Highlights nearby hidden objects.",
    color:"#c7a9ff"
  }
  ,

    pebble:{
    name:"Pebble",
    ability:"guard",
    description:"Occasionally blocks an incoming projectile.",
    color:"#a8d6e9"
  }
  ,

    zip:{
    name:"Zip",
    ability:"spark",
    description:"Adds a little energy to collected stardust.",
    color:"#ffe08b"
  }


}
;

export class CompanionSystem {

    constructor(hub,
  definitions=[]){
    this.hub=hub;
    this.unlocked=new Set(["mothlet"]);
    this.active="mothlet";
    this.followers=definitions;
    this.phase=0;
    this.abilityCooldown=0;
    this.lastPosition={
      x:0,
      y:0
    }
    ;
    this.trail=[];
    this.guardPulseTicks=0;
    this.notifications=[];

  }

    unlock(id){
    if(!COMPANIONS[id])return false;
    this.unlocked.add(id);
    this.hub?.emit("companion:unlocked",
    {
      id
    }
    );
    return true;

  }

    equip(id){
    if(!this.unlocked.has(id))return false;
    this.active=id;
    return true;

  }

    update(player,
  world){
    this.phase+=.07;
    if(this.abilityCooldown>0)this.abilityCooldown--;
    const companion=COMPANIONS[this.active];
    if(!companion)return;
    const targetX=player.x-player.facing*38,
    targetY=player.y-20;
    this.lastPosition.x+=(targetX-this.lastPosition.x)*.12;
    this.lastPosition.y+=(targetY-this.lastPosition.y)*.12;
    if(this.guardPulseTicks>0)this.guardPulseTicks--;
    this.trail.push({x:this.lastPosition.x,y:this.lastPosition.y+Math.sin(this.phase)*5,life:10});
    if(this.trail.length>5)this.trail.shift();
    for(const t of this.trail)t.life--;
    if(companion.ability==="guard"&&this.abilityCooldown===0){
      const projectile=world.projectiles.find(item=>item.owner==="enemy"&&distance(item,
      player)<95);
      if(projectile){
        projectile.life=0;
        this.abilityCooldown=260;
        this.guardPulseTicks=18;
        this.hub?.emit("companion:guard",
        {
          id:this.active
        }
        );

      }

    }

  }

    bonusStars(){
    return this.active==="zip"?1:0;

  }

    draw(ctx,
  camera){
    const companion=COMPANIONS[this.active];
    if(!companion)return;
    const x=this.lastPosition.x-camera,
    y=this.lastPosition.y+Math.sin(this.phase)*5;
    ctx.save();
    for(let i=0;i<this.trail.length-1;i++){
      const node=this.trail[i];
      ctx.globalAlpha=Math.max(0,(i+1)/(this.trail.length*4.5));
      ctx.fillStyle=companion.color;
      ctx.beginPath();
      ctx.arc(node.x-camera,node.y,3+i*0.9,0,Math.PI*2);
      ctx.fill();
    }
    ctx.globalAlpha=1;
    if(this.guardPulseTicks>0){
      const p=1-this.guardPulseTicks/18;
      ctx.strokeStyle=`rgba(168, 214, 233, ${(1-p)*0.85})`;
      ctx.lineWidth=2;
      ctx.beginPath();
      ctx.arc(x,y,14+p*32,0,Math.PI*2);
      ctx.stroke();
    }
    if(this.active==="mothlet"){
      const flap=Math.sin(this.phase*4.2)*4;
      ctx.fillStyle="rgba(199, 169, 255, 0.52)";
      ctx.beginPath();
      ctx.ellipse(x-10,y-2+flap*0.35,8,5-Math.abs(flap)*0.2,-0.35,0,Math.PI*2);
      ctx.ellipse(x+10,y-2+flap*0.35,8,5-Math.abs(flap)*0.2,0.35,0,Math.PI*2);
      ctx.fill();
    }else if(this.active==="pebble"){
      ctx.strokeStyle="rgba(168, 214, 233, 0.65)";
      ctx.lineWidth=1.5;
      ctx.beginPath();
      ctx.arc(x,y,14,this.phase,this.phase+Math.PI*1.3);
      ctx.stroke();
    }else if(this.active==="zip"){
      ctx.fillStyle="#ffe08b";
      for(let i=0;i<3;i++){
        const a=this.phase*2.4+(i*Math.PI*2)/3;
        ctx.fillRect(x+Math.cos(a)*14-1.5,y+Math.sin(a)*14-1.5,3,3);
      }
    }
    ctx.fillStyle=companion.color;
    ctx.shadowColor=companion.color;
    ctx.shadowBlur=14;
    ctx.beginPath();
    ctx.arc(x,
    y,
    10,
    0,
    Math.PI*2);
    ctx.fill();
    ctx.shadowBlur=0;
    ctx.fillStyle="#1c2749";
    ctx.fillRect(x-4,
    y-2,
    3,
    3);
    ctx.fillRect(x+2,
    y-2,
    3,
    3);
    ctx.restore();

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      active:this.active
    }
    ;

  }

    restore(data={

  }
  ){
    this.unlocked=new Set(["mothlet",
    ...(data.unlocked||[])]);
    this.active=this.unlocked.has(data.active)?data.active:"mothlet";

  }


}
