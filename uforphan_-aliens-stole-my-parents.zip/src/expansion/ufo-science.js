import { COLORS, GAME } from "../config.js";

/** Planetary telemetry and E.T. atmospheric profiles for Chapters 01–08. */
export const SECTOR_ATMOSPHERES = [
  {
    body: "EARTH EXOSPHERE",
    gravityG: "1.00g",
    atmosphere: "78% N2 / 21% O2",
    carrierMHz: "1420.405 MHz",
    hypothesis: "Cherenkov blue ionization around the Gallegar trampoline points to a localized Alcubierre warp pinch."
  },
  {
    body: "LUNAR CRATER L4",
    gravityG: "0.74g",
    atmosphere: "Pressurized Mall Dome",
    carrierMHz: "1420.412 MHz",
    hypothesis: "Drake Equation commerce anomaly: retail signage uses binary-coded hydrogen-line carrier beacons."
  },
  {
    body: "ROCHE SCRAP BELT",
    gravityG: "0.86g",
    atmosphere: "Silicate & Ion Dust",
    carrierMHz: "1420.398 MHz",
    hypothesis: "Shattered moonlets orbit inside their parent planet's Roche limit, creating dense kinetic salvage rings."
  },
  {
    body: "CRUISER FLAGSHIP",
    gravityG: "0.95g",
    atmosphere: "Recycled Xenon-Air",
    carrierMHz: "1420.405 MHz",
    hypothesis: "Moscovium-115 graviton plates sustain synthetic deck gravity while towing kidnapped Earth vehicles."
  },
  {
    body: "SILICATE CRYSTAL GROVE",
    gravityG: "0.92g",
    atmosphere: "Piezo-Ionized Mist",
    carrierMHz: "432.142 Hz · 1.42 GHz",
    hypothesis: "Piezo-electric quartz spires amplify faint interstellar telemetry via mechanical harmonic resonance."
  },
  {
    body: "ORBITAL ARCHIVE",
    gravityG: "0.62g",
    atmosphere: "Low-G Vacuum Vault",
    carrierMHz: "1420.440 MHz",
    hypothesis: "Reduced 0.62g artificial deck calibration preserves centuries of interstellar flight logs on magnetic silica."
  },
  {
    body: "XENO BIO-DOME 07",
    gravityG: "0.90g",
    atmosphere: "O2 + Spore Aerosols",
    carrierMHz: "1420.390 MHz",
    hypothesis: "Lithopanspermia extremophiles hitchhiked on cometary ice and now synchronize bioluminescence to carrier waves."
  },
  {
    body: "ECLIPSE CORE REACTOR",
    gravityG: "1.00g",
    atmosphere: "Magnetized Plasma",
    carrierMHz: "1420.405 MHz LOCKED",
    hypothesis: "An oscillating Casimir-cavity core folds local spacetime between Sol and Sector 8 for remote tractor locks."
  }
];

/** Curated E.T. & UFO science field phenomena across all 8 chapters. */
export const EXO_ANOMALIES = {
  0: [
    {
      id: "backyard-warp-pinch",
      x: 420,
      y: 440,
      title: "Alcubierre Warp Eddy",
      concept: "Spacetime Contraction Wake",
      scienceNote: "Residual purple shear marks where the saucer compressed space in front of the Gallegar minivan without breaking c locally.",
      codexId: "alcubierre_wake",
      speaker: "fiona",
      comms: "Science log: purple spacetime ripples by the hedge—they towed Mum and Dad inside a mini warp bubble!",
      rewardCredits: 35
    },
    {
      id: "backyard-hline-ping",
      x: 1720,
      y: 440,
      title: "1420 MHz H-Line Echo",
      concept: "SETI Hydrogen Spin-Flip Band",
      scienceNote: "A pulsing 1420.405 MHz carrier reflection—the universal SETI 'waterhole' frequency matching neutral hydrogen atoms.",
      codexId: "wow_signal",
      speaker: "dad",
      comms: "Wait, Fiona—our minivan radio just locked onto 1420.4 MHz! Follow that hydrogen-line echo!",
      rewardCredits: 40
    }
  ],
  1: [
    {
      id: "mall-drake-kiosk",
      x: 780,
      y: 440,
      title: "Drake Equation Census Node",
      concept: "Exoplanet Civilization Index",
      scienceNote: "A Moon Mall directory estimating communicative worlds in the Orion Spur—mostly debating parking validation.",
      codexId: "drake_equation",
      speaker: "pip",
      comms: "Drake Factor Update: 1 in 4 surveyed civilizations has at least one overpriced orbital food court.",
      rewardCredits: 40
    },
    {
      id: "mall-e115-pod",
      x: 2080,
      y: 440,
      title: "Element-115 Stabilizer Pod",
      concept: "Superheavy Graviton Lattice",
      scienceNote: "Dense Moscovium core samples powering overhead patrol saucers. Disrupting saucers with lasers flips them to anti-gravity!",
      codexId: "element_115",
      speaker: "fiona",
      comms: "Captured Element-115 readings! If a saucer's purple tractor beam tugs me, a blaster burst will invert its polarity!",
      rewardCredits: 45
    }
  ],
  2: [
    {
      id: "scrap-roche-fragment",
      x: 1050,
      y: 440,
      title: "Roche Horizon Monolith",
      concept: "Tidal Disruption Limit",
      scienceNote: "A fractured basalt core showing how tidal gravity tore an ancient moon into this drifting ring of scrap.",
      codexId: "roche_limit",
      speaker: "rivet",
      comms: "Good eye, kid—anything drifting inside that moon's Roche limit shreds into spare parts for my shop!",
      rewardCredits: 45
    },
    {
      id: "scrap-laser-sail",
      x: 2680,
      y: 440,
      title: "Solar-Sail Foil Wreckage",
      concept: "Photon Momentum Propulsion",
      scienceNote: "Ultra-thin metamaterial foil propelled solely by photon radiation pressure from nearby red-giant stars.",
      codexId: "alcubierre_wake",
      speaker: "fiona",
      comms: "Micro-thin solar sail foil! Zero fuel tanks—it surfed pure starlight across the belt.",
      rewardCredits: 45
    }
  ],
  3: [
    {
      id: "ship-e115-manifold",
      x: 840,
      y: 440,
      title: "Graviton Wave Injector",
      concept: "Artificial Deck Gravity",
      scienceNote: "Oscillating graviton waveguides generating 0.95g artificial down-force aboard Commander Zelk's flagship.",
      codexId: "element_115",
      speaker: "commander",
      comms: "Stop poking my graviton manifold! Calibration forms take four lunar cycles to re-file!",
      rewardCredits: 50
    },
    {
      id: "ship-fermi-beacon",
      x: 1520,
      y: 440,
      title: "Fermi Paradox Jammer",
      concept: "Electromagnetic Cloaking",
      scienceNote: "Explains why Earth telescopes missed the Mothership: active metamaterial phase cancellation bends 21cm radio waves around the hull.",
      codexId: "wow_signal",
      speaker: "moth",
      comms: "Metamaterial cloaking offline locally—your scanner just punched right through the Fermi jammer!",
      rewardCredits: 50
    }
  ],
  4: [
    {
      id: "grove-piezo-cluster",
      x: 610,
      y: 440,
      title: "Piezoelectric Crystal Node",
      concept: "Acoustic-to-EM Transduction",
      scienceNote: "Strained alien quartz lattices convert seismic footsteps directly into glowing 1.42 GHz rescue harmonics.",
      codexId: "wow_signal",
      speaker: "noa",
      comms: "Each crystal vibrates mechanically and radiates microwave harmonics—pure piezoelectric magic.",
      rewardCredits: 55
    },
    {
      id: "grove-warp-harmonics",
      x: 1620,
      y: 440,
      title: "Casimir Vacuum Resonator",
      concept: "Zero-Point Boundary Cavity",
      scienceNote: "Nanometer-spaced crystal plates harvest faint Casimir vacuum pressure to amplify Fiona's homeward beacon.",
      codexId: "alcubierre_wake",
      speaker: "fiona",
      comms: "Casimir resonance spike logged—these crystal plates amplify energy right out of empty vacuum!",
      rewardCredits: 55
    }
  ],
  5: [
    {
      id: "archive-microgravity-lab",
      x: 640,
      y: 440,
      title: "0.62g Centrifuge Calibration",
      concept: "Centripetal & Low-G Mechanics",
      scienceNote: "Notice how jumps arc higher here: the Archive maintains 0.62g so delicate silica memory wafers never crack.",
      codexId: "roche_limit",
      speaker: "moth",
      comms: "Archive gravity is set to 0.62g—use extended parabolic leaps to clear the upper stacks!",
      rewardCredits: 55
    },
    {
      id: "archive-arecibo-slab",
      x: 2390,
      y: 440,
      title: "Binary Prime Plaque",
      concept: "Semiprime Pictogram Decoding",
      scienceNote: "An archived 23x73 semiprime bitmap echoing Earth's 1974 Arecibo message, annotated by Pip with 'NICE DRAWING!'",
      codexId: "drake_equation",
      speaker: "pip",
      comms: "1,679 bits! Even interstellar librarians recognize a classic 23-by-73 semiprime grid.",
      rewardCredits: 60
    }
  ],
  6: [
    {
      id: "dome-panspermia-pod",
      x: 680,
      y: 440,
      title: "Tardigrade Spore Cluster",
      concept: "Lithopanspermia Adaptation",
      scienceNote: "Radiation-hardened extremophiles survive vacuum transit inside meteoroids before blooming inside humid alien domes.",
      codexId: "panspermia_flora",
      speaker: "noa",
      comms: "Those spores rode an icy comet for ten millennia before waking up inside Bio-Dome 07!",
      rewardCredits: 60
    },
    {
      id: "dome-chlorophyll-spectrum",
      x: 1990,
      y: 440,
      title: "Infrared Flora Photopigments",
      concept: "Exoplanet Red-Edge Absorption",
      scienceNote: "Under dimmer red-dwarf stars, extraterrestrial plants evolve dark-teal pigments tuned to absorb infrared photons.",
      codexId: "panspermia_flora",
      speaker: "mum",
      comms: "Look at the teal leaves, Fiona—exoplanet botany absorbs low-energy red-star light!",
      rewardCredits: 60
    }
  ],
  7: [
    {
      id: "core-dyson-coil",
      x: 690,
      y: 440,
      title: "Dyson Micro-Collector Tap",
      concept: "Kardashev Type-II Conduit",
      scienceNote: "Channels stellar flux from an off-world swarm directly into the Core Warden's reactor ring.",
      codexId: "element_115",
      speaker: "warden",
      comms: "Hands off the Kardashev shunt, human! That collector sustains four thousand filing cabinets!",
      rewardCredits: 70
    },
    {
      id: "core-einstein-bridge",
      x: 1710,
      y: 440,
      title: "Einstein-Rosen Anchor Node",
      concept: "Folded Wormhole Return Path",
      scienceNote: "Aligning the three array dishes collapses the Warden's tether cleanly back to Earth's backyard coordinates.",
      codexId: "alcubierre_wake",
      speaker: "fiona",
      comms: "Wormhole return anchor stabilized! Almost at the Core Warden's chamber!",
      rewardCredits: 75
    }
  ]
};

/** Generate UFO Patrol Saucers safely anchored above ground platforms in every chapter. */
export function buildSaucersForLevel(level, levelIndex) {
  const specs = [
    [
      { x: 390, y: 120, range: 110, speed: 0.022, kind: "antigrav" },
      { x: 1690, y: 112, range: 140, speed: 0.024, kind: "abductor" }
    ],
    [
      { x: 700, y: 115, range: 130, speed: 0.024, kind: "abductor" },
      { x: 2120, y: 110, range: 130, speed: 0.026, kind: "antigrav" }
    ],
    [
      { x: 1020, y: 115, range: 130, speed: 0.025, kind: "abductor" },
      { x: 2740, y: 112, range: 140, speed: 0.027, kind: "abductor" }
    ],
    [
      { x: 890, y: 112, range: 150, speed: 0.026, kind: "abductor" },
      { x: 1460, y: 115, range: 130, speed: 0.025, kind: "antigrav" }
    ],
    [
      { x: 660, y: 112, range: 135, speed: 0.024, kind: "antigrav" },
      { x: 1980, y: 110, range: 145, speed: 0.025, kind: "abductor" }
    ],
    [
      { x: 1030, y: 108, range: 145, speed: 0.024, kind: "antigrav" },
      { x: 2420, y: 112, range: 135, speed: 0.026, kind: "abductor" }
    ],
    [
      { x: 640, y: 112, range: 130, speed: 0.025, kind: "abductor" },
      { x: 2010, y: 110, range: 145, speed: 0.027, kind: "antigrav" }
    ],
    [
      { x: 740, y: 108, range: 140, speed: 0.026, kind: "abductor" },
      { x: 1730, y: 108, range: 150, speed: 0.028, kind: "abductor" }
    ]
  ];
  const entries = specs[levelIndex % specs.length] || specs[0];
  return entries
    .filter((entry) => entry.x < level.width - 140)
    .map((entry, idx) => {
      const phase = idx * 1.9;
      const y = entry.y + 102;
      return {
        id: `saucer-${levelIndex}-${idx}`,
        baseX: entry.x,
        x: entry.x + Math.sin(phase) * entry.range,
        y,
        w: 58,
        h: 22,
        range: entry.range,
        speed: entry.speed,
        phase,
        kind: entry.kind,
        invertedTicks: 0,
        hitFlash: 0,
        hullHits: 2,
        beamWidth: 56
      };
    });
}

export class ExoScienceSystem {
  constructor(world, profile) {
    this.world = world;
    this.profile = profile;
    this.atmosphere = SECTOR_ATMOSPHERES[world.index] || SECTOR_ATMOSPHERES[0];
    this.anomalies = (EXO_ANOMALIES[world.index] || []).map((item) => ({
      ...item,
      analyzed: false
    }));
    this.saucers = buildSaucersForLevel(world.data, world.index);
    this.scanWave = null;
    this.scanCooldown = 0;
    this.scanHoldTicks = 0;
    this.scanHoldMax = 30;
    this.beamSoundCooldown = 0;
  }

  /** Returns normalized [0..1] circular progress for HUD feedback while holding F or emitting a scan pulse. */
  getScanProgress() {
    if (this.scanHoldTicks > 0) {
      return Math.min(1, this.scanHoldTicks / Math.max(1, this.scanHoldMax));
    }
    if (this.scanWave) {
      return 1;
    }
    return 0;
  }

  /** Handles hold-to-scan charging when F is held, plus instant trigger for single-frame synthetic scan presses. */
  handleScanInput(player, isHolding, wasPressed) {
    if (isHolding) {
      if (this.scanCooldown > 0) {
        this.scanHoldTicks = 0;
        return false;
      }
      this.scanHoldTicks = Math.min(this.scanHoldMax, this.scanHoldTicks + 1);
      if (this.scanHoldTicks >= this.scanHoldMax) {
        this.scanHoldTicks = 0;
        return this.triggerScan(player);
      }
      return false;
    }

    if (this.scanHoldTicks > 0) {
      this.scanHoldTicks = Math.max(0, this.scanHoldTicks - 2);
      return false;
    }

    if (wasPressed) {
      return this.triggerScan(player);
    }
    return false;
  }

  /** Trigger the 1420.4 MHz SETI sonar sweep radiating from Fiona. */
  triggerScan(player) {
    if (this.scanCooldown > 0) return false;
    const radius = player.scanRadius || 240;
    const originX = player.x + player.w / 2;
    const originY = player.y + player.h / 2;
    this.scanWave = {
      x: originX,
      y: originY,
      radius: 14,
      maxRadius: radius,
      life: 44,
      maxLife: 44
    };
    this.scanCooldown = 75;
    this.world.audio?.scan?.();
    this.world.particles?.burst?.(originX, originY, "#a9e58a", 10, 3.0);

    for (const art of this.world.expansion?.artifacts || []) {
      art._waveTriggered = false;
    }

    let discovered = 0;
    for (const anomaly of this.anomalies) {
      if (anomaly.analyzed) continue;
      const dist = Math.hypot(anomaly.x - originX, anomaly.y - originY);
      if (dist <= radius) {
        this.analyzeAnomaly(anomaly, player);
        discovered++;
      }
    }

    const uncollectedArtifacts = (this.world.expansion?.artifacts || []).filter((a) => !a.collected);
    const inRangeArtifact = uncollectedArtifacts.find(
      (art) => Math.hypot(art.x - originX, art.y - originY) <= radius * 1.25
    );
    if (inRangeArtifact) {
      inRangeArtifact.scanPingTicks = 210;
    }

    if (!discovered) {
      const nextKey = this.world.keys.find((k) => !k.collected);
      const nextAnomaly = this.anomalies.find((a) => !a.analyzed);
      const nextArtifact = inRangeArtifact || uncollectedArtifacts[0];
      if (inRangeArtifact) {
        const dx = Math.round(inRangeArtifact.x - originX);
        const dir = dx >= 0 ? "east" : "west";
        this.world.pushComms?.(
          "fiona",
          `Relic resonance lock! ${inRangeArtifact.catalogCode} (${inRangeArtifact.name}) glowing ${Math.abs(dx)}px ${dir}!`,
          210
        );
      } else if (nextAnomaly) {
        const dx = Math.round(nextAnomaly.x - player.x);
        const dir = dx >= 0 ? "east" : "west";
        this.world.pushComms?.(
          "moth",
          `1420 MHz H-Line lock: ${nextAnomaly.title} detected ${Math.abs(dx)}px ${dir}.`,
          190
        );
      } else if (nextArtifact) {
        nextArtifact.scanPingTicks = Math.max(nextArtifact.scanPingTicks || 0, 150);
        const dx = Math.round(nextArtifact.x - player.x);
        const dir = dx >= 0 ? "east" : "west";
        this.world.pushComms?.(
          "moth",
          `Xeno-Artifact harmonic lock: ${nextArtifact.catalogCode} (${nextArtifact.name}) detected ${Math.abs(dx)}px ${dir}.`,
          190
        );
      } else if (nextKey) {
        const dx = Math.round(nextKey.x - player.x);
        const dir = dx >= 0 ? "east" : "west";
        this.world.pushComms?.("moth", `Keycard signature pinging ${Math.abs(dx)}px ${dir}.`, 180);
      }
    }
    return true;
  }

  analyzeAnomaly(anomaly, player) {
    if (!anomaly || anomaly.analyzed) return null;
    anomaly.analyzed = true;
    this.world.audio?.collect?.();
    this.world.particles?.burst(anomaly.x, anomaly.y - 16, COLORS.cyan, 16, 3.6);
    this.profile?.economy?.earn?.(anomaly.rewardCredits || 35, "exo-science");
    this.profile?.progression?.addXP?.(30);
    if (anomaly.codexId) {
      this.profile?.codex?.unlockByTrigger?.(`anomaly:${anomaly.codexId}`);
    }
    this.profile?.events?.emit?.("exo:analyzed", {
      id: anomaly.id,
      title: anomaly.title,
      concept: anomaly.concept,
      codexId: anomaly.codexId
    });
    if (player && this.profile?.upgrades?.owned?.has?.("seti_array")) {
      this.profile?.inventory?.add?.("e115_shard", 1);
    }
    this.world.pushComms?.(anomaly.speaker || "fiona", anomaly.comms, 260);
    return anomaly;
  }

  nearAnomaly(player) {
    return this.anomalies.find(
      (a) => !a.analyzed && Math.abs(a.x - (player.x + player.w / 2)) < 48 && Math.abs(a.y - (player.y + player.h / 2)) < 58
    ) || null;
  }

  spawnPatrolSaucer(player) {
    const startX = Math.max(180, Math.min(this.world.width - 220, player.x + 240));
    this.saucers.push({
      id: `patrol-${Date.now()}`,
      baseX: startX,
      x: startX,
      y: 212,
      w: 58,
      h: 22,
      range: 190,
      speed: 0.032,
      phase: 0,
      kind: "abductor",
      invertedTicks: 0,
      hitFlash: 0,
      hullHits: 2,
      beamWidth: 62,
      temporary: 1200
    });
  }

  update(player) {
    if (this.scanCooldown > 0) this.scanCooldown--;
    if (this.beamSoundCooldown > 0) this.beamSoundCooldown--;
    const px = player.x + player.w / 2;
    const py = player.y + player.h / 2;

    const artifacts = this.world.expansion?.artifacts || [];
    for (const art of artifacts) {
      if (art.scanPingTicks > 0) art.scanPingTicks--;
    }

    if (this.scanWave) {
      this.scanWave.x = px;
      this.scanWave.y = py;
      this.scanWave.life--;
      const progress = 1 - this.scanWave.life / this.scanWave.maxLife;
      this.scanWave.radius = 14 + progress * this.scanWave.maxRadius;

      for (const art of artifacts) {
        if (art.collected || art._waveTriggered) continue;
        const dist = Math.hypot(art.x - this.scanWave.x, art.y - this.scanWave.y);
        if (dist <= this.scanWave.radius) {
          art._waveTriggered = true;
          art.scanPingTicks = 210;
          this.world.particles?.burst?.(art.x, art.y, art.tint || "#a9e58a", 14, 3.2);
        }
      }

      if (this.scanWave.life <= 0) this.scanWave = null;
    }

    for (const s of this.saucers) {
      s.phase += s.speed;
      s.x = s.baseX + Math.sin(s.phase) * s.range;
      if (s.invertedTicks > 0) s.invertedTicks--;
      if (s.hitFlash > 0) s.hitFlash--;
      if (typeof s.temporary === "number") s.temporary--;

      // Check player laser hits on saucer hull or suspended E-115 emitter core
      for (const proj of this.world.projectiles) {
        if (proj.owner !== "player" || proj.life <= 0) continue;
        const pw = proj.w || 10;
        const ph = proj.h || 10;
        if (
          proj.x + pw > s.x - s.w / 2 &&
          proj.x < s.x + s.w / 2 &&
          proj.y + ph > s.y &&
          proj.y < s.y + s.h + 18
        ) {
          proj.life = 0;
          s.hitFlash = 8;
          s.hullHits--;
          this.world.particles?.burst(s.x, s.y + 11, COLORS.cyan, 10, 3);
          if (s.hullHits <= 0) {
            s.hullHits = 2;
            s.invertedTicks = 380;
            this.profile?.economy?.earn?.(20, "ufo-invert");
            this.profile?.inventory?.add?.("e115_shard", 1);
            this.world.pushComms?.(
              "fiona",
              "Reversed the saucer's Moscovium-115 polarity! Tractor cone is now an anti-gravity updraft!",
              200
            );
          }
        }
      }

      // Apply Tractor Cone physics when Fiona steps inside beam column
      const isAntiGrav = s.kind === "antigrav" || s.invertedTicks > 0;
      const halfCone = s.beamWidth * 0.5;
      if (
        player.dashTicks <= 0 &&
        Math.abs(px - s.x) < halfCone + 4 &&
        py > s.y + s.h &&
        py < 485
      ) {
        if (isAntiGrav) {
          player.vy = Math.max(-7.6, player.vy - 0.86);
        } else {
          // Hostile violet tractor beam slowly levitates & drags unless dashed/disrupted
          player.vy = Math.max(-3.6, player.vy - 0.72);
          player.vx *= 0.94;
          if (this.beamSoundCooldown <= 0) {
            this.world.audio?.beam?.();
            this.beamSoundCooldown = 48;
          }
          if (py < s.y + s.h + 26) {
            player.takeDamage(this.world.audio, this.world.particles);
          }
        }
      }
    }

    this.saucers = this.saucers.filter((s) => typeof s.temporary !== "number" || s.temporary > 0);
  }

  draw(ctx, camera = 0) {
    // Draw field science anomalies
    for (const a of this.anomalies) {
      const ax = a.x - camera;
      const ay = a.y;
      const bob = Math.sin(this.world.elapsed * 0.08 + a.x) * 4;
      ctx.save();
      const color = a.analyzed ? "#5c75a8" : "#73f0ed";
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.globalAlpha = a.analyzed ? 0.42 : 0.9;

      // Rotating wireframe octagram + outer scanning arc
      ctx.translate(ax, ay - 16 + bob);
      ctx.save();
      ctx.rotate(-this.world.elapsed * 0.04);
      ctx.strokeStyle = a.analyzed ? "rgba(138, 156, 196, 0.3)" : "rgba(255, 155, 228, 0.55)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, 0, 17, 0, Math.PI * 1.2);
      ctx.stroke();
      ctx.restore();

      ctx.rotate(this.world.elapsed * 0.025);
      ctx.strokeRect(-10, -10, 20, 20);
      ctx.rotate(Math.PI / 4);
      ctx.strokeRect(-10, -10, 20, 20);

      ctx.fillStyle = a.analyzed ? "#8a9cc4" : "#ff9be4";
      ctx.beginPath();
      ctx.arc(0, 0, 4 + Math.sin(this.world.elapsed * 0.14) * 1.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Draw UFO Patrol Saucers & Volumetric Tractor Cones
    for (const s of this.saucers) {
      const sx = s.x - camera;
      const sy = s.y + Math.sin(this.world.elapsed * 0.07 + s.phase) * 4;
      const bankTilt = Math.cos(s.phase) * 0.08;
      const isAntiGrav = s.kind === "antigrav" || s.invertedTicks > 0;
      const beamColor = isAntiGrav ? "115, 240, 237" : "195, 118, 255";

      ctx.save();
      // Tractor Cone
      const grad = ctx.createLinearGradient(0, sy + 18, 0, 480);
      grad.addColorStop(0, `rgba(${beamColor}, 0.28)`);
      grad.addColorStop(1, `rgba(${beamColor}, 0.03)`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(sx - 14, sy + 18);
      ctx.lineTo(sx + 14, sy + 18);
      ctx.lineTo(sx + s.beamWidth * 0.56, 480);
      ctx.lineTo(sx - s.beamWidth * 0.56, 480);
      ctx.closePath();
      ctx.fill();

      // Rising ionized beam rings inside tractor cone
      ctx.strokeStyle = `rgba(${beamColor}, 0.45)`;
      ctx.lineWidth = 1.5;
      for (let r = 0; r < 3; r++) {
        const ringT = ((this.world.elapsed * 0.015 + r / 3) % 1);
        const ry = 470 - ringT * (470 - (sy + 24));
        const rw = 12 + (1 - ringT) * (s.beamWidth * 0.36);
        ctx.beginPath();
        ctx.ellipse(sx, ry, rw, 3.5, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Bank saucer hull gently into motion direction
      ctx.translate(sx, sy + 12);
      ctx.rotate(bankTilt);

      // Metallic Saucer Hull
      ctx.fillStyle = s.hitFlash > 0 ? "#ffffff" : "#8ba5dc";
      ctx.beginPath();
      ctx.ellipse(0, 0, s.w / 2, 10, 0, 0, Math.PI * 2);
      ctx.fill();

      // Glass Dome
      ctx.fillStyle = isAntiGrav ? "#73f0ed" : "#ff8fd8";
      ctx.beginPath();
      ctx.ellipse(0, -5, 15, 9, 0, Math.PI, Math.PI * 2);
      ctx.fill();

      // Suspended E-115 Graviton Emitter Core
      ctx.fillStyle = isAntiGrav ? "#73f0ed" : "#d895ff";
      ctx.beginPath();
      ctx.arc(0, 12, 6 + Math.sin(this.world.elapsed * 0.16) * 1.1, 0, Math.PI * 2);
      ctx.fill();

      // Rotating hull perimeter navigation lights
      for (let i = -2; i <= 2; i++) {
        const lit = Math.floor(this.world.elapsed / 8 + i + 4) % 3 === 0;
        ctx.fillStyle = lit ? "#ffd76d" : "#25345d";
        ctx.fillRect(i * 10 - 2, -1, 4, 3);
      }
      ctx.restore();
    }

    // Draw expanding multi-ring 1420 MHz scan pulse radiating from Fiona
    if (this.scanWave) {
      const alpha = Math.max(0, this.scanWave.life / this.scanWave.maxLife);
      const sx = this.scanWave.x - camera;
      const sy = this.scanWave.y;
      const r = this.scanWave.radius;

      ctx.save();
      // Subtle translucent pulse aura around the expanding wavefront
      const pulseGrad = ctx.createRadialGradient(sx, sy, Math.max(2, r * 0.45), sx, sy, r);
      pulseGrad.addColorStop(0, "rgba(115, 240, 237, 0)");
      pulseGrad.addColorStop(0.75, `rgba(169, 229, 138, ${alpha * 0.14})`);
      pulseGrad.addColorStop(1, `rgba(115, 240, 237, ${alpha * 0.24})`);
      ctx.fillStyle = pulseGrad;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.fill();

      // Primary 1420 MHz cyan wavefront
      ctx.strokeStyle = `rgba(115, 240, 237, ${alpha * 0.88})`;
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.stroke();

      // Secondary Xeno-Artifact emerald harmonic ring
      ctx.strokeStyle = `rgba(169, 229, 138, ${alpha * 0.72})`;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(sx, sy, r * 0.82, 0, Math.PI * 2);
      ctx.stroke();

      // Inner gold carrier echo ring
      ctx.strokeStyle = `rgba(255, 215, 109, ${alpha * 0.48})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(sx, sy, r * 0.62, 0, Math.PI * 2);
      ctx.stroke();

      // Radial sweep ticks along the primary scan ring
      ctx.strokeStyle = `rgba(169, 229, 138, ${alpha * 0.85})`;
      ctx.lineWidth = 1.6;
      const rotOffset = this.world.elapsed * 0.03;
      for (let k = 0; k < 8; k++) {
        const ang = rotOffset + (k * Math.PI) / 4;
        ctx.beginPath();
        ctx.moveTo(sx + Math.cos(ang) * (r - 6), sy + Math.sin(ang) * (r - 6));
        ctx.lineTo(sx + Math.cos(ang) * (r + 5), sy + Math.sin(ang) * (r + 5));
        ctx.stroke();
      }

      // Directional Xeno-Artifact bearing chevron pointing from Fiona to nearest uncollected relic
      const uncollected = (this.world.expansion?.artifacts || []).filter((a) => !a.collected);
      if (uncollected.length) {
        let nearest = uncollected[0];
        let bestDist = Math.hypot(nearest.x - this.scanWave.x, nearest.y - this.scanWave.y);
        for (const candidate of uncollected.slice(1)) {
          const d = Math.hypot(candidate.x - this.scanWave.x, candidate.y - this.scanWave.y);
          if (d < bestDist) {
            bestDist = d;
            nearest = candidate;
          }
        }
        const angle = Math.atan2(nearest.y - this.scanWave.y, nearest.x - this.scanWave.x);
        const guideR = Math.min(46, Math.max(26, r * 0.35));
        const gx = sx + Math.cos(angle) * guideR;
        const gy = sy + Math.sin(angle) * guideR;
        ctx.save();
        ctx.translate(gx, gy);
        ctx.rotate(angle);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = "#a9e58a";
        ctx.beginPath();
        ctx.moveTo(8, 0);
        ctx.lineTo(-5, -5);
        ctx.lineTo(-2, 0);
        ctx.lineTo(-5, 5);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }

      ctx.restore();
    }
  }

  drawTelemetry(ctx) {
    const gRatio = typeof this.world.gravityMultiplier === "function" ? this.world.gravityMultiplier() : 1;
    const effectiveG = (parseFloat(this.atmosphere.gravityG) * gRatio).toFixed(2);
    const scanReady = this.scanCooldown <= 0;
    const x = GAME.width - 180;
    const y = 44;

    ctx.save();
    ctx.fillStyle = "rgba(10, 16, 40, 0.72)";
    ctx.strokeStyle = "rgba(115, 240, 237, 0.28)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(x, y, 164, 22, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "left";
    ctx.fillStyle = "#9fb2df";
    ctx.fillText(`${effectiveG}g · ${this.atmosphere.carrierMHz.slice(0, 8)}`, x + 8, y + 14);

    ctx.textAlign = "right";
    ctx.fillStyle = scanReady ? COLORS.cyan : "#6b789c";
    ctx.fillText(scanReady ? "F:SCAN" : "SYNC", x + 156, y + 14);
    ctx.restore();
  }
}
