import { EventHub } from "./event-hub.js";
import { Inventory } from "./inventory.js";
import { QuestEngine, STORY_QUESTS } from "./quest-engine.js";
import { CraftingSystem } from "./crafting.js";
import { ProgressionSystem } from "./progression-system.js";
import { EconomySystem } from "./economy-system.js";
import { CompanionSystem } from "./companion-system.js";
import { CodexSystem } from "./codex-system.js";
import { AchievementSystem } from "./achievement-system.js";
import { ChallengeSystem } from "./challenge-system.js";
import { MissionBoard } from "./mission-board.js";
import { UpgradeSystem } from "./upgrade-system.js";
import { EndingSystem } from "./ending-system.js";
import { QuestRewardService } from "./quest-rewards.js";
import { AccessibilitySystem } from "./accessibility-system.js";
import { TutorialSystem } from "./tutorial-system.js";
import { RunStatistics } from "./run-statistics.js";
import { XenoArtifactCollection } from "./xeno-artifacts.js";

/** Persistent player-wide systems shared between every chapter. */
export class ExpansionProfile {
  constructor(saved = {}) {
    this.events = new EventHub();
    this.inventory = new Inventory(this.events, saved.inventory || {});
    this.quests = new QuestEngine(this.events, STORY_QUESTS, saved.quests || {});
    this.crafting = new CraftingSystem(this.events, this.inventory);
    this.progression = new ProgressionSystem(saved.progression || {});
    this.economy = new EconomySystem(this.inventory, saved.economy || {});
    this.companions = new CompanionSystem(this.events);
    this.codex = new CodexSystem(this.events);
    this.achievements = new AchievementSystem(this.events);
    this.challenges = new ChallengeSystem(this.events);
    this.missions = new MissionBoard(saved.missions || {});
    this.upgrades = new UpgradeSystem();
    this.ending = new EndingSystem(saved.ending || {});
    this.rewards = new QuestRewardService(this.inventory, this.economy, this.progression);
    this.accessibility = new AccessibilitySystem(saved.accessibility || {});
    this.tutorials = new TutorialSystem(saved.tutorials || []);
    this.statistics = new RunStatistics();
    this.statistics.restore(saved.statistics || {});
    this.artifacts = new XenoArtifactCollection(this.events, saved.artifacts || {});
    this.npcsMet = new Set(saved.npcsMet || []);
    this.completedLevels = new Set(saved.completedLevels || []);

    this.inventory.restore(saved.inventory || {});
    this.quests.restore(saved.quests || {});
    this.crafting.restore(saved.crafting || {});
    this.companions.restore(saved.companions || {});
    this.codex.restore(saved.codex || {});
    this.achievements.restore(saved.achievements || {});
    this.challenges.restore(saved.challenges || {});
    this.missions.restore(saved.missions || {});
    this.upgrades.restore(saved.upgrades || {});
    this.ending.restore(saved.ending || {});
    this.rewards.restore(saved.claimedRewards || []);
    this.tutorials.restore(saved.tutorials || []);
    this.artifacts.restore(saved.artifacts || {});
    this.bindEvents();
  }

  bindEvents() {
    this.events.on("combat:kill", event => {
      if (event.payload.target === "drone") this.quests.addProgressByTag("drone_disabled", 1);
      this.missions.progress("drone", 1);
      this.challenges.addProgress("kills", 1);
      this.statistics.kill();
      this.evaluateAchievements();
    });

    this.events.on("quest:completed", event => {
      const quest = this.quests.get(event.payload.id);
      if (quest) this.rewards.claim(quest);
      this.progression.addXP(35);
      if (event.payload.id === "mall_cop_duty") this.crafting.unlock("shield_bubble");
      if (event.payload.id === "scrap_symphony") this.crafting.unlock("plasma_lens");
      if (event.payload.id === "family_frequency") this.crafting.unlock("double_jump");
      this.evaluateAchievements();
    });

    this.events.on("item:added", event => {
      const id = event.payload.id;
      const count = event.payload.count || 1;
      if (id === "copper_coil") this.quests.addProgressByTag("coil", count);
      if (id === "resonant_crystal") this.quests.addProgressByTag("crystal", count);
      this.evaluateAchievements();
    });

    this.events.on("npc:met", event => {
      this.npcsMet.add(event.payload.kind);
      this.codex.unlockByTrigger(`meet:${event.payload.kind}`);
      this.evaluateAchievements();
    });

    this.events.on("companion:unlocked", event => {
      this.codex.unlockByTrigger(`companion:${event.payload.id}`);
      this.evaluateAchievements();
    });

    this.events.on("item:crafted", () => this.evaluateAchievements());
    this.events.on("challenge:ended", event => {
      if (event.payload.success && event.payload.flawless) this.evaluateAchievements();
    });
    this.events.on("codex:unlocked", () => this.evaluateAchievements());
    this.events.on("artifact:collected", () => this.evaluateAchievements());
    this.events.on("world:checkpoint", () => this.events.emit("profile:checkpoint", {}));
  }

  evaluateAchievements(extra = {}) {
    const stats = {
      levelsCompleted: this.completedLevels.size,
      inventorySlots: this.inventory.slotsUsed(),
      crafts: this.crafting.history.length,
      npcsMet: this.npcsMet.size,
      stars: this.statistics.stars,
      flawlessChallenges: this.challenges.results.filter(result => result.flawless).length,
      familySignal: this.quests.get("family_frequency")?.state.status === "completed",
      questsCompleted: this.quests.list("completed").length,
      artifacts: this.artifacts.progress().found,
      ...extra
    };
    return this.achievements.evaluate(stats);
  }

  completeLevel(index) {
    this.completedLevels.add(index);
    this.evaluateAchievements();
  }

  applyPlayer(player) {
    const ranks = this.progression.skills;
    const owned = this.upgrades.owned;
    player.speedMultiplier = (1 + (ranks.light_feet || 0) * .06) * (owned.has("reinforced_boots") ? 1.08 : 1) * (owned.has("graviton_thrusters") ? 1.05 : 1);
    player.maxHealth = 3 + (ranks.toughened || 0) + (owned.has("heart_module") ? 1 : 0);
    player.health = Math.min(player.health, player.maxHealth);
    player.damageRecovery = Math.max(50, 90 - (ranks.recovery || 0) * 12);
    player.pickupRadius = owned.has("magnet_coil") ? 37.5 : 25;
    player.dashCooldownMult = owned.has("graviton_thrusters") ? 0.7 : 1;
    player.scanRadius = owned.has("seti_array") ? 440 : 240;
    player.extraJumpUnlocked = Boolean((ranks.extra_jump || 0) > 0 || this.inventory.equipment.boots === "double_jump");
    const eq = this.inventory.equipment.weapon;
    player.weapon = eq === "plasma_lens" ? "plasma_lens" : eq === "sonic_module" ? "sonic_burst" : "star_blaster";
  }

  serialize() {
    return {
      inventory: this.inventory.serialize(),
      quests: this.quests.serialize(),
      crafting: this.crafting.serialize(),
      progression: this.progression.serialize(),
      economy: this.economy.serialize(),
      companions: this.companions.serialize(),
      codex: this.codex.serialize(),
      achievements: this.achievements.serialize(),
      challenges: this.challenges.serialize(),
      missions: this.missions.serialize(),
      upgrades: this.upgrades.serialize(),
      ending: this.ending.serialize(),
      claimedRewards: this.rewards.serialize(),
      accessibility: this.accessibility.serialize(),
      tutorials: this.tutorials.serialize(),
      statistics: this.statistics.summary(),
      artifacts: this.artifacts.serialize(),
      npcsMet: [...this.npcsMet],
      completedLevels: [...this.completedLevels]
    };
  }
}
