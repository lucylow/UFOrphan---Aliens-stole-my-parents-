import * as d3 from "d3";
import { SECTOR_ATMOSPHERES } from "./ufo-science.js";

/**
 * Computes real-time 1420.4 MHz alien carrier stability from gameplay telemetry:
 * sector beacons/anomalies, UFO saucer tractor beams, SETI scans, and boss fields.
 */
export class SignalStabilityMonitor {
  constructor(capacity = 44) {
    this.capacity = capacity;
    this.tick = 0;
    this.sampleStride = 6;
    this.levelIndex = 0;
    this.samples = [];
    this.lastScanBoost = 0;
    this.reset(0);
  }

  reset(levelIndex = 0) {
    this.levelIndex = levelIndex;
    this.tick = 0;
    this.lastScanBoost = 0;
    this.samples = [];
    const base = 74 + (levelIndex % 3) * 3;
    for (let i = 0; i < this.capacity; i++) {
      const wave = Math.sin(i * 0.35) * 3.5 + Math.cos(i * 0.17) * 1.8;
      this.samples.push({
        index: i,
        stability: clamp(base + wave, 8, 99.9),
        driftMHz: Number((Math.sin(i * 0.4) * 0.008).toFixed(4))
      });
    }
  }

  computeReading(world, player) {
    const t = world?.elapsed || this.tick;
    const base = 74 + Math.min(12, (world?.index || 0) * 1.4);

    // Analyzed anomalies, active beacons, and collected artifacts stabilize local lock
    const anomaliesDone = (world?.expansion?.exo?.anomalies || []).filter((a) => a.analyzed).length;
    const beaconsLit = (world?.expansion?.beacons || []).filter((b) => b.active).length;
    const relicsInSector = (world?.expansion?.artifacts || []).filter((a) => a.collected).length;
    const lockBonus = anomaliesDone * 4.5 + beaconsLit * 3.2 + relicsInSector * 3.5;

    // Interference from nearby un-inverted UFO saucers & tractor cones
    let interference = 0;
    const px = player ? player.x + player.w / 2 : 0;
    const py = player ? player.y + player.h / 2 : 420;
    for (const s of world?.expansion?.exo?.saucers || []) {
      const dx = Math.abs(px - s.x);
      if (s.invertedTicks > 0 || s.kind === "antigrav") {
        if (dx < 180) interference -= lockBonus > 0 ? 3 : 2;
      } else {
        if (dx < s.beamWidth * 0.6 && py > s.y) interference += 34;
        else if (dx < 210) interference += Math.max(0, (210 - dx) / 210) * 18;
      }
    }

    // Active boss electromagnetic jamming
    if (world?.boss && !world.boss.dead) {
      interference += 11 + Math.sin(t * 0.11) * 5;
    }

    // Momentary damage dropout
    if (player && player.invulnerable > 65 && player.dashTicks <= 0) {
      interference += 18;
    }

    // Cosmic Weather interference (Ion Storms temporarily scramble telemetry & spike noise)
    const weatherState = world?.expansion?.weather?.currentState?.() || { scramble: 0, code: "CLEAR" };
    this.lastWeatherState = weatherState;
    let weatherScramble = 0;
    if (weatherState.scramble > 0.35) {
      weatherScramble =
        weatherState.scramble * 36 +
        Math.sin(t * 1.45) * 14 +
        Math.cos(t * 2.35) * 8;
    } else if (weatherState.scramble > 0) {
      weatherScramble = weatherState.scramble * 12;
    }

    // Active SETI scan wave resonance boost
    if (world?.expansion?.exo?.scanWave) {
      this.lastScanBoost = 12;
    } else if (this.lastScanBoost > 0) {
      this.lastScanBoost = Math.max(0, this.lastScanBoost - 0.8);
    }

    // Periodic Distress Beacon acoustic/light ping harmonics
    const distressPulse = world?.expansion?.distress?.activePulseLevel?.() || 0;
    const distressSpike = distressPulse * 11;

    // Natural multi-harmonic fluctuation + minor Star-Dash phase shift
    const dashRipple = player?.dashTicks > 0 ? Math.sin(t * 0.7) * 5 : 0;
    const harmonic =
      Math.sin(t * 0.085) * 4.2 +
      Math.cos(t * 0.21 + (world?.index || 0)) * 2.4 +
      Math.sin(t * 0.43) * (interference + weatherScramble > 12 ? 4.8 : 1.1);

    const stability = clamp(
      base + lockBonus + this.lastScanBoost + distressSpike - interference - weatherScramble + harmonic + dashRipple,
      8,
      99.8
    );

    const driftScale = weatherState.scramble > 0.45 ? 0.088 : 0.042;
    const driftMHz = Number(
      (((100 - stability) / 100) * driftScale * Math.sin(t * 0.19)).toFixed(4)
    );

    return { stability: Number(stability.toFixed(1)), driftMHz };
  }

  sample(world, player, force = false) {
    this.tick++;
    if (!force && this.tick % this.sampleStride !== 0) {
      return this.current();
    }
    const nextIdx = (this.samples[this.samples.length - 1]?.index ?? -1) + 1;
    const { stability, driftMHz } = this.computeReading(world, player);
    this.samples.push({ index: nextIdx, stability, driftMHz });
    if (this.samples.length > this.capacity) {
      this.samples.shift();
    }
    return this.current();
  }

  current() {
    const latest = this.samples[this.samples.length - 1] || {
      index: 0,
      stability: 80,
      driftMHz: 0
    };
    const weatherScramble = this.lastWeatherState?.scramble || 0;
    const weatherCode = this.lastWeatherState?.code || "CLEAR";
    const status =
      weatherScramble >= 0.45
        ? { code: "ION SCRAMBLE", glyph: "⚡", tone: "critical" }
        : latest.stability >= 72
          ? { code: "LOCKED", glyph: "●", tone: "nominal" }
          : latest.stability >= 45
            ? { code: "DRIFT", glyph: "▲", tone: "warn" }
            : { code: "JAMMED", glyph: "✖", tone: "critical" };
    return {
      ...latest,
      weatherScramble,
      weatherCode,
      status
    };
  }
}

/**
 * D3-powered live oscilloscope SVG widget mounted inside the game HUD.
 */
export class SignalStabilityChart {
  constructor(container) {
    this.container = container;
    this.width = 232;
    this.height = 48;
    this.margin = { top: 5, right: 8, bottom: 5, left: 6 };
    this.hoverIndex = null;
    this.lastRenderKey = "";

    this.root = d3.select(container);
    this.root.selectAll("*").remove();

    this.header = this.root.append("div").attr("class", "signal-hud-head");
    this.titleEl = this.header.append("span").attr("class", "signal-hud-title").text("SIGNAL STABILITY");
    this.metaEl = this.header.append("span").attr("class", "signal-hud-value").text("78.0% · ● LOCKED");

    const svgWrap = this.root.append("div").attr("class", "signal-svg-wrap");
    this.svg = svgWrap
      .append("svg")
      .attr("viewBox", `0 0 ${this.width} ${this.height}`)
      .attr("width", "100%")
      .attr("height", this.height)
      .attr("role", "img")
      .attr("aria-label", "Alien signal stability live waveform graph");

    const defs = this.svg.append("defs");
    this.areaGradient = defs
      .append("linearGradient")
      .attr("id", "signalAreaGrad")
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "0%")
      .attr("y2", "100%");
    this.gradStopTop = this.areaGradient
      .append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#73f0ed")
      .attr("stop-opacity", 0.36);
    this.gradStopBot = this.areaGradient
      .append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#73f0ed")
      .attr("stop-opacity", 0.02);

    this.xScale = d3.scaleLinear().range([this.margin.left, this.width - this.margin.right]);
    this.yScale = d3.scaleLinear().domain([0, 100]).range([this.height - this.margin.bottom, this.margin.top]);

    // Calibrated reference lines (25%, 50%, 75%)
    const gridGroup = this.svg.append("g").attr("class", "signal-grid");
    gridGroup
      .selectAll("line")
      .data([25, 50, 75])
      .join("line")
      .attr("x1", this.margin.left)
      .attr("x2", this.width - this.margin.right)
      .attr("y1", (d) => this.yScale(d))
      .attr("y2", (d) => this.yScale(d))
      .attr("stroke", (d) => (d === 50 ? "rgba(255, 215, 109, 0.28)" : "rgba(166, 184, 255, 0.14)"))
      .attr("stroke-width", 1)
      .attr("stroke-dasharray", (d) => (d === 50 ? "3,3" : "none"));

    this.areaPath = this.svg
      .append("path")
      .attr("fill", "url(#signalAreaGrad)");

    this.linePath = this.svg
      .append("path")
      .attr("fill", "none")
      .attr("stroke", "#73f0ed")
      .attr("stroke-width", 1.75)
      .attr("stroke-linecap", "round");

    this.pulseDot = this.svg
      .append("circle")
      .attr("r", 2.8)
      .attr("fill", "#73f0ed")
      .attr("stroke", "#080c1c")
      .attr("stroke-width", 1);

    // Interactive D3 hover probe crosshair
    this.crosshair = this.svg
      .append("line")
      .attr("y1", this.margin.top)
      .attr("y2", this.height - this.margin.bottom)
      .attr("stroke", "rgba(243, 245, 255, 0.45)")
      .attr("stroke-width", 1)
      .style("opacity", 0);

    this.subEl = this.root.append("div").attr("class", "signal-hud-sub").text("1420.405 MHz · Δ +0.0000 MHz");

    this.lineGen = d3
      .line()
      .x((d) => this.xScale(d.index))
      .y((d) => this.yScale(d.stability))
      .curve(d3.curveMonotoneX);

    this.areaGen = d3
      .area()
      .x((d) => this.xScale(d.index))
      .y0(this.yScale(0))
      .y1((d) => this.yScale(d.stability))
      .curve(d3.curveMonotoneX);

    this.latestSamples = [];
    this.svg
      .on("mousemove", (event) => {
        if (!this.latestSamples.length) return;
        const [mx] = d3.pointer(event);
        const target = this.xScale.invert(mx);
        const bisect = d3.bisector((d) => d.index).center;
        const idx = bisect(this.latestSamples, target);
        this.hoverIndex = idx;
        this.updateProbe(this.latestSamples[idx]);
      })
      .on("mouseleave", () => {
        this.hoverIndex = null;
        this.crosshair.style("opacity", 0);
      });
  }

  updateProbe(point) {
    if (!point) return;
    const cx = this.xScale(point.index);
    this.crosshair.attr("x1", cx).attr("x2", cx).style("opacity", 1);
    const sign = point.driftMHz >= 0 ? "+" : "";
    this.subEl.text(`SAMPLE #${point.index} · ${point.stability.toFixed(1)}% · Δ ${sign}${point.driftMHz.toFixed(4)} MHz`);
  }

  render(monitor, levelIndex = 0) {
    if (!monitor) return;
    const data = monitor.samples;
    if (!data.length) return;
    this.latestSamples = data;

    const latest = data[data.length - 1];
    const current = monitor.current();
    const renderKey = `${latest.index}:${latest.stability}:${levelIndex}:${current.status.code}:${this.hoverIndex ?? "live"}`;
    if (renderKey === this.lastRenderKey) return;
    this.lastRenderKey = renderKey;

    const firstIdx = data[0].index;
    const lastIdx = latest.index;
    this.xScale.domain([firstIdx, Math.max(firstIdx + 1, lastIdx)]);

    const isScrambled = current.weatherScramble >= 0.45;
    this.root.classed("is-scrambled", isScrambled);

    const toneColor =
      current.status.tone === "nominal"
        ? "#73f0ed"
        : current.status.tone === "warn"
          ? "#ffd76d"
          : "#ff668d";

    this.gradStopTop.attr("stop-color", toneColor);
    this.gradStopBot.attr("stop-color", toneColor);
    this.linePath.datum(data).attr("d", this.lineGen).attr("stroke", toneColor);
    this.areaPath.datum(data).attr("d", this.areaGen);
    this.pulseDot
      .attr("cx", this.xScale(latest.index))
      .attr("cy", this.yScale(latest.stability))
      .attr("fill", toneColor);

    this.metaEl
      .style("color", toneColor)
      .text(`${current.stability.toFixed(1)}% · ${current.status.glyph} ${current.status.code}`);

    if (this.hoverIndex !== null && data[this.hoverIndex]) {
      this.updateProbe(data[this.hoverIndex]);
    } else if (isScrambled) {
      const sign = current.driftMHz >= 0 ? "+" : "";
      this.subEl.text(`ION STORM · CARRIER SCRAMBLED · Δ ${sign}${current.driftMHz.toFixed(4)} MHz`);
    } else {
      const atmo = SECTOR_ATMOSPHERES[levelIndex] || SECTOR_ATMOSPHERES[0];
      const sign = current.driftMHz >= 0 ? "+" : "";
      this.subEl.text(`${atmo.carrierMHz.slice(0, 12)} · Δ ${sign}${current.driftMHz.toFixed(4)} MHz`);
    }
  }
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
