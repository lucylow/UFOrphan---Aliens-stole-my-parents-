import {
   intersects,
   clamp,
   EXPANSION_EVENTS
}
 from "./constants.js";

export const WEAPON_DEFINITIONS={

    star_blaster:{
    name:"Star Blaster",
    damage:1,
    cooldown:22,
    speed:8.5,
    color:"#73f0ed",
    spread:0,
    pierce:0
  }
  ,

    plasma_lens:{
    name:"Plasma Focus",
    damage:2,
    cooldown:18,
    speed:10,
    color:"#ff9be4",
    spread:0,
    pierce:1
  }
  ,

    sonic_burst:{
    name:"Sonic Burst",
    damage:1,
    cooldown:36,
    speed:7,
    color:"#f5d77b",
    spread:2,
    pierce:0
  }


}
;

export class CombatSystem {

    constructor(hub){
    this.hub=hub;
    this.combo=0;
    this.comboTimer=0;
    this.totalDamage=0;
    this.kills=0;
    this.damageNumbers=[];
    this.shake=0;
    this.weapon="star_blaster";
    this.modifiers={
      damage:1,
      cooldown:1,
      projectileSpeed:1
    }
    ;

  }

    configure(inventory){
    const eq=inventory?.equipment?.weapon;
    this.weapon=eq==="plasma_lens"?"plasma_lens":eq==="sonic_module"?"sonic_burst":"star_blaster";

  }

    fire(player,
  world,
  audio){
    const weapon=WEAPON_DEFINITIONS[this.weapon]||WEAPON_DEFINITIONS.star_blaster;
    const cooldown=Math.max(6,
    weapon.cooldown*this.modifiers.cooldown);
    if(player.cooldown>0)return false;
    const directions=weapon.spread?[-1,
    0,
    1]:[0];
    for(const spread of directions){
      world.projectiles.push({
        x:player.x+(player.facing>0?player.w:-12),
        y:player.y+15,
        w:weapon.pierce?16:10,
        h:weapon.pierce?7:10,
        vx:player.facing*weapon.speed*this.modifiers.projectileSpeed,
        vy:spread*1.1,
        life:65,
        owner:"player",
        damage:Math.ceil(weapon.damage*this.modifiers.damage),
        pierce:weapon.pierce,
        color:weapon.color
      }
      );

    }
    player.cooldown=cooldown;
    audio?.blast();
    return true;

  }

    onDamage(target,
  amount,
  x,
  y){
    this.totalDamage+=amount;
    this.combo++;
    this.comboTimer=180;
    this.damageNumbers.push({
      x,
      y,
      vx:(Math.random()-0.5)*0.9,
      vy:-1.4,
      value:amount,
      life:45
    }
    );
    this.shake=Math.min(12,
    this.shake+amount*1.4);
    this.hub?.emit("combat:damage",
    {
      amount,
      target:target.type||"enemy",
      combo:this.combo
    }
    );

  }

    onKill(target){
    this.kills++;
    this.combo+=2;
    this.hub?.emit("combat:kill",
    {
      target:target.type||"enemy",
      kills:this.kills,
      x:target.x,
      y:target.y
    }
    );

  }

    update(){
    if(this.comboTimer>0)this.comboTimer--;
    else this.combo=0;
    this.shake*=.82;
    for(const number of this.damageNumbers){
      number.x+=number.vx||0;
      number.y+=number.vy??-.45;
      number.vy=(number.vy??-.45)*0.92;
      number.life--;

    }
    this.damageNumbers=this.damageNumbers.filter(number=>number.life>0);

  }

    draw(ctx,
  camera){
    for(const number of this.damageNumbers){
      const age=45-number.life;
      const pop=age<8?0.75+(age/8)*0.45:1;
      ctx.save();
      ctx.globalAlpha=clamp(number.life/45,
      0,
      1);
      ctx.translate(number.x-camera,number.y);
      ctx.scale(pop,pop);
      ctx.shadowColor="rgba(255, 119, 189, 0.7)";
      ctx.shadowBlur=6;
      ctx.fillStyle=number.value>=2?"#ff9be4":"#ffe69b";
      ctx.font="bold 14px 'JetBrains Mono', monospace";
      ctx.textAlign="center";
      ctx.fillText(`-${number.value}`,0,0);
      ctx.restore();
    }
  }

  drawComboHud(ctx, y = 44) {
    if (this.combo >= 2 && this.comboTimer > 0) {
      const ratio = clamp(this.comboTimer / 180, 0, 1);
      ctx.save();
      ctx.fillStyle = "rgba(10, 16, 40, 0.84)";
      ctx.strokeStyle = "rgba(255, 215, 109, 0.55)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(16, y, 164, 24, 8);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffd76d";
      ctx.font = "bold 10px 'JetBrains Mono', monospace";
      ctx.textAlign = "left";
      ctx.fillText(`✦ ${this.combo}× COMBO`, 26, y + 15);
      ctx.fillStyle = "rgba(255, 215, 109, 0.25)";
      ctx.fillRect(120, y + 9, 50, 4);
      ctx.fillStyle = "#ffd76d";
      ctx.fillRect(120, y + 9, 50 * ratio, 4);
      ctx.restore();
    }
  }

    applyProjectile(projectile,
  target){
    if(!intersects(projectile,
    target))return false;
    const damage=projectile.damage||1;
    target.damage?.({
      particles:{
        burst(){

        }

      }

    }
    );
    if(typeof target.health==="number")target.health-=damage;
    projectile.pierce=(projectile.pierce||0)-1;
    return true;

  }

    summary(){
    return {
      kills:this.kills,
      totalDamage:this.totalDamage,
      bestCombo:this.combo
    }
    ;

  }

    serialize(){
    return {
      ...this.summary(),
      weapon:this.weapon
    }
    ;

  }

    restore(data={

  }
  ){
    this.kills=data.kills||0;
    this.totalDamage=data.totalDamage||0;
    this.weapon=data.weapon||"star_blaster";

  }


}
