import {
   ITEM_RARITY,
   ITEM_TYPES,
   EXPANSION_EVENTS,
   uid
}
 from "./constants.js";

export const ITEM_CATALOG={

    stardust:{
    name:"Stardust",
    type:"material",
    rarity:"common",
    stack:999,
    description:"A glittering trace of the cosmic trail."
  }
  ,

    relay_chip:{
    name:"Relay Chip",
    type:"material",
    rarity:"uncommon",
    stack:50,
    description:"A tiny circuit with a very large signal."
  }
  ,

    ion_cell:{
    name:"Ion Cell",
    type:"material",
    rarity:"common",
    stack:99,
    description:"A compact battery for alien machinery."
  }
  ,

    copper_coil:{
    name:"Copper Coil",
    type:"material",
    rarity:"common",
    stack:99,
    description:"Salvaged wire wound into a neat spiral."
  }
  ,

    resonant_crystal:{
    name:"Resonant Crystal",
    type:"material",
    rarity:"rare",
    stack:30,
    description:"It hums when nobody is looking."
  }
  ,

    med_patch:{
    name:"Med Patch",
    type:"consumable",
    rarity:"common",
    stack:10,
    description:"Restores one heart when used."
  }
  ,

    shield_bubble:{
    name:"Shield Bubble",
    type:"consumable",
    rarity:"uncommon",
    stack:5,
    description:"Prevents the next hit for a short time."
  }
  ,

    plasma_lens:{
    name:"Plasma Lens",
    type:"upgrade",
    rarity:"rare",
    stack:1,
    description:"Focuses the star-blaster into a stronger beam."
  }
  ,

    double_jump:{
    name:"Jump Servo",
    type:"upgrade",
    rarity:"epic",
    stack:1,
    description:"Adds one extra jump before landing."
  }
  ,

    family_photo:{
    name:"Family Photo",
    type:"quest",
    rarity:"legendary",
    stack:1,
    description:"A reminder of what this whole trip is for."
  }
  ,

    old_badge:{
    name:"Moon Mall Badge",
    type:"quest",
    rarity:"uncommon",
    stack:1,
    description:"Property of the mall's security department."
  }
  ,

    star_cookie:{
    name:"Star Cookie",
    type:"consumable",
    rarity:"uncommon",
    stack:5,
    description:"A little snack shaped like a constellation."
  }
  ,

    sonic_module:{
    name:"Sonic Module",
    type:"upgrade",
    rarity:"epic",
    stack:1,
    description:"Splits the star-blaster into a three-bolt sonic spread."
  }
  ,

    e115_shard:{
    name:"E-115 Shard",
    type:"material",
    rarity:"rare",
    stack:30,
    description:"Stabilized Element-115 lattice harvested from alien graviton drives."
  }


}
;

export class Inventory {

    constructor(hub,
  {
    capacity=24,
    items=[]
  }
  ={

  }
  ){
    this.hub=hub;
    this.capacity=capacity;
    this.slots=[];
    this.equipment={
      weapon:null,
      boots:null,
      shield:null
    }
    ;
    this.weightLimit=100;
    this.items=[];
    this.restore(items);

  }

    definition(id){
    return ITEM_CATALOG[id]||{
      name:id,
      type:"material",
      rarity:"common",
      stack:99,
      description:"An unidentified object."
    }
    ;

  }

    count(id){
    return this.slots.filter(slot=>slot.id===id).reduce((sum,
    slot)=>sum+slot.count,
    0);

  }

    has(id,
  count=1){
    return this.count(id)>=count;

  }

    add(id,
  count=1,
  metadata={

  }
  ){
    if(!Number.isInteger(count)||count<=0)return {
      ok:false,
      added:0,
      reason:"invalid-count"
    }
    ;
    const item=this.definition(id);
    let remaining=count;
    for(const slot of this.slots){
      if(slot.id===id&&slot.count<item.stack){
        const moved=Math.min(remaining,
        item.stack-slot.count);
        slot.count+=moved;
        remaining-=moved;
        if(!remaining)break;

      }

    }

        while(remaining>0&&this.slots.length<this.capacity){
      const moved=Math.min(remaining,
      item.stack);
      this.slots.push({
        uid:uid("slot"),
        id,
        count:moved,
        metadata:{
          ...metadata
        }

      }
      );
      remaining-=moved;

    }

        const added=count-remaining;
    if(added)this.hub?.emit(EXPANSION_EVENTS.ITEM_ADDED,
    {
      id,
      count:added,
      total:this.count(id)
    }
    );
    return {
      ok:remaining===0,
      added,
      remaining,
      reason:remaining?"inventory-full":null
    }
    ;

  }

    remove(id,
  count=1){
    if(!this.has(id,
    count))return false;
    let remaining=count;
    for(let i=this.slots.length-1;
    i>=0&&remaining>0;
    i--){
      const slot=this.slots[i];
      if(slot.id!==id)continue;
      const moved=Math.min(remaining,
      slot.count);
      slot.count-=moved;
      remaining-=moved;
      if(slot.count===0)this.slots.splice(i,
      1);

    }
    this.hub?.emit(EXPANSION_EVENTS.ITEM_REMOVED,
    {
      id,
      count
    }
    );
    return true;

  }

    use(id,
  context={

  }
  ){
    const item=this.definition(id);
    if(item.type!=="consumable"||!this.has(id))return {
      ok:false,
      reason:"not-usable"
    }
    ;
    let effect={
      ok:true
    }
    ;
    if(id==="med_patch"){
      if(!context.player||context.player.health>=context.player.maxHealth)return {
        ok:false,
        reason:"health-full"
      }
      ;
      context.player.health=Math.min(context.player.maxHealth,
      context.player.health+1);
      effect.restored=1;

    }
    else if(id==="shield_bubble"){
      if(!context.player)return {
        ok:false,
        reason:"no-player"
      }
      ;
      context.player.shieldTicks=600;
      effect.duration=600;

    }
    else if(id==="star_cookie"){
      if(!context.player)return {
        ok:false,
        reason:"no-player"
      }
      ;
      context.player.stars+=3;
      effect.stars=3;

    }
    else return {
      ok:false,
      reason:"no-effect"
    }
    ;
    this.remove(id,
    1);
    return effect;

  }

    equip(id,
  slot){
    if(!this.has(id))return {
      ok:false,
      reason:"missing"
    }
    ;
    const item=this.definition(id);
    if(item.type!=="upgrade")return {
      ok:false,
      reason:"not-equipment"
    }
    ;
    const valid={
      plasma_lens:"weapon",
      sonic_module:"weapon",
      double_jump:"boots"
    }
    ;
    if(valid[id]!==slot)return {
      ok:false,
      reason:"wrong-slot"
    }
    ;
    this.equipment[slot]=id;
    return {
      ok:true,
      slot,
      id
    }
    ;

  }

    unequip(slot){
    if(!(slot in this.equipment))return false;
    this.equipment[slot]=null;
    return true;

  }

    slotsUsed(){
    return this.slots.length;

  }

    freeSlots(){
    return Math.max(0,
    this.capacity-this.slots.length);

  }

    list(){
    return this.slots.map(slot=>({
      ...slot,
      item:this.definition(slot.id)
    }
    ));

  }

    sort(mode="rarity"){
    const rank=mode==="name"?(a,
    b)=>this.definition(a.id).name.localeCompare(this.definition(b.id).name):(a,
    b)=>(ITEM_RARITY[this.definition(b.id).rarity]||0)-(ITEM_RARITY[this.definition(a.id).rarity]||0);
    this.slots.sort(rank);

  }

    transferTo(other,
  id,
  count){
    if(!this.has(id,
    count))return {
      ok:false,
      reason:"missing"
    }
    ;
    const result=other.add(id,
    count);
    if(result.added)this.remove(id,
    result.added);
    return result;

  }

    serialize(){
    return {
      capacity:this.capacity,
      slots:this.slots.map(slot=>({
        ...slot,
        metadata:{
          ...slot.metadata
        }

      }
      )),
      equipment:{
        ...this.equipment
      }

    }
    ;

  }

    restore(saved){
    const source=Array.isArray(saved)?saved:(saved?.slots||[]);
    this.slots=source.filter(slot=>slot&&typeof slot.id==="string"&&Number(slot.count)>0).slice(0,
    this.capacity).map(slot=>({
      uid:slot.uid||uid("slot"),
      id:slot.id,
      count:Math.max(1,
      Math.floor(slot.count)),
      metadata:{
        ...(slot.metadata||{

        }
        )
      }

    }
    ));
    if(!Array.isArray(saved)&&saved?.equipment)this.equipment={
      ...this.equipment,
      ...saved.equipment
    }
    ;

  }

    validate(){
    const errors=[];
    if(this.slots.length>this.capacity)errors.push("capacity exceeded");
    for(const slot of this.slots){
      if(!slot.id||slot.count<1)errors.push("invalid slot");
      if(slot.count>this.definition(slot.id).stack)errors.push(`stack overflow: ${slot.id}`);

    }
    return {
      valid:errors.length===0,
      errors
    }
    ;

  }


}

export function itemRarityLabel(id){
  const item=ITEM_CATALOG[id];
  return item?`${item.rarity.toUpperCase()} · ${item.name}`:id;

}
