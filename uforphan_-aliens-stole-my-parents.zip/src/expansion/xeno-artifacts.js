/**
 * Persistent Xeno-Artifact collectibles and Alien Field Guide catalog across Chapters 01–08.
 */

export const XENO_ARTIFACT_CATALOG = [
  {
    id: "xa-lawn-deflector",
    catalogCode: "XA-01A",
    levelIndex: 0,
    x: 1445,
    y: 266,
    name: "Zero-Point Lawn Deflector",
    classification: "PROPULSION RELIC",
    rarity: "RARE",
    originWorld: "Epsilon Eridani B",
    massKg: "0.42 kg",
    frequencyGHz: "1.42 GHz",
    glyph: "gyro",
    tint: "#73f0ed",
    credits: 45,
    xp: 35,
    fieldNote:
      "Specimen recovered humming politely above an ornamental garden gnome. Internal Casimir vanes bend ambient vacuum fluctuations just enough to keep nocturnal abduction beams from scorching residential Bermuda grass."
  },
  {
    id: "xa-abduction-receipt",
    catalogCode: "XA-01B",
    levelIndex: 0,
    x: 2115,
    y: 444,
    name: "Carbon-Copy Abduction Receipt",
    classification: "BUREAUCRATIC FOSSIL",
    rarity: "UNCOMMON",
    originWorld: "Orion Logistics Hub 9",
    massKg: "0.08 kg",
    frequencyGHz: "0.88 GHz",
    glyph: "monolith",
    tint: "#ffd76d",
    credits: 45,
    xp: 35,
    fieldNote:
      "Etched onto heat-resistant aerogel and dropped during hasty liftoff. Itemizes 'Two Adults (Mildly Confused), One Teal Minivan, Zero Houseplants' under Sector Code 44-B. Signatures remain ominously blank."
  },
  {
    id: "xa-kiosk-translator",
    catalogCode: "XA-02A",
    levelIndex: 1,
    x: 510,
    y: 286,
    name: "Polyglot Vending Charm",
    classification: "ACOUSTIC DECODER",
    rarity: "RARE",
    originWorld: "Trappist-1e Concourse",
    massKg: "0.31 kg",
    frequencyGHz: "2.14 GHz",
    glyph: "prism",
    tint: "#ff9be4",
    credits: 50,
    xp: 40,
    fieldNote:
      "A pocket-sized piezoceramic transponder sold beside Moon Mall slushie fountains. Translates 190 galactic dialects accurately, though every noun for 'oxygen' renders suspiciously as 'subscription upgrade'."
  },
  {
    id: "xa-gravity-tumbler",
    catalogCode: "XA-02B",
    levelIndex: 1,
    x: 2820,
    y: 286,
    name: "Tidal-Locked Beverage Tumbler",
    classification: "GRAVITON HOUSEWARE",
    rarity: "UNCOMMON",
    originWorld: "Lunar Crater L4",
    massKg: "0.65 kg",
    frequencyGHz: "1.19 GHz",
    glyph: "obelisk",
    tint: "#a9e58a",
    credits: 50,
    xp: 40,
    fieldNote:
      "Employs a pinhead Moscovium ballast core so kelp smoothies stay level even during rotational docking maneuvers. Margin inscription reads: 'DO NOT MICROWAVE INSIDE WARP CORRIDOR'."
  },
  {
    id: "xa-roche-caliper",
    catalogCode: "XA-03A",
    levelIndex: 2,
    x: 1020,
    y: 266,
    name: "Roche-Limit Tidal Caliper",
    classification: "ASTROMETRIC INSTRUMENT",
    rarity: "RARE",
    originWorld: "Cygnus Scrap Guild",
    massKg: "1.14 kg",
    frequencyGHz: "3.06 GHz",
    glyph: "gyro",
    tint: "#73f0ed",
    credits: 55,
    xp: 45,
    fieldNote:
      "Calibrated brass-and-iridium dividers engineered by belt scavengers. Measures exact tidal shear across fractured moonlets so pirates know which hull plates will snap before auction."
  },
  {
    id: "xa-dyson-thimble",
    catalogCode: "XA-03B",
    levelIndex: 2,
    x: 2750,
    y: 266,
    name: "Pocket Dyson Collector",
    classification: "PHOTON HARVESTER",
    rarity: "ANOMALOUS",
    originWorld: "Tau Ceti Foundry",
    massKg: "0.19 kg",
    frequencyGHz: "4.85 GHz",
    glyph: "dish",
    tint: "#ffd76d",
    credits: 60,
    xp: 45,
    fieldNote:
      "A miniature origami swarm of 4,000 photovoltaic mirrors folded into the volume of a sewing thimble. Unfolds toward passing starlight and charges a flashlight until the sun burns out."
  },
  {
    id: "xa-feline-crown",
    catalogCode: "XA-04A",
    levelIndex: 3,
    x: 805,
    y: 296,
    name: "Acting Admiral's Telemetry Collar",
    classification: "BIOMETRIC BEACON",
    rarity: "ANOMALOUS",
    originWorld: "Sol III · Living Room",
    massKg: "0.12 kg",
    frequencyGHz: "1.42 GHz",
    glyph: "prism",
    tint: "#a9e58a",
    credits: 65,
    xp: 50,
    fieldNote:
      "Recovered near the Mothership bridge vent. Records four minutes of purring followed by Captain Whiskers overriding three tractor locks and ordering extra tuna paste to Earth orbit."
  },
  {
    id: "xa-kelp-thermos",
    catalogCode: "XA-04B",
    levelIndex: 3,
    x: 1595,
    y: 286,
    name: "Sub-Space Kelp Containment Flask",
    classification: "CULINARY CONTAINMENT",
    rarity: "UNCOMMON",
    originWorld: "Europa Deep Trade",
    massKg: "0.78 kg",
    frequencyGHz: "0.95 GHz",
    glyph: "monolith",
    tint: "#ff9be4",
    credits: 60,
    xp: 50,
    fieldNote:
      "Arthur Gallegar's handwritten tape sticks cleanly over an alien warning label. The interior stores fluorescent brine at zero thermal drift—an engineering triumph wasted on glowing sea-vegetable broth."
  },
  {
    id: "xa-piezo-tuning-fork",
    catalogCode: "XA-05A",
    levelIndex: 4,
    x: 510,
    y: 286,
    name: "Harmonic Lattice Tuning Fork",
    classification: "RESONANCE SPECIMEN",
    rarity: "RARE",
    originWorld: "Crystal Grove Basin",
    massKg: "0.53 kg",
    frequencyGHz: "2.84 GHz",
    glyph: "obelisk",
    tint: "#73f0ed",
    credits: 65,
    xp: 50,
    fieldNote:
      "Struck softly against quartz spires, these bifurcated silicate tines sustain an audible B-flat harmonic for eleven days while projecting soothing standing waves across local sub-space relays."
  },
  {
    id: "xa-casimir-bell",
    catalogCode: "XA-05B",
    levelIndex: 4,
    x: 1665,
    y: 266,
    name: "Vacuum-Gap Chime",
    classification: "QUANTUM ACOUSTICS",
    rarity: "ANOMALOUS",
    originWorld: "Vega Harmonic Shelf",
    massKg: "0.27 kg",
    frequencyGHz: "5.12 GHz",
    glyph: "gyro",
    tint: "#ff9be4",
    credits: 70,
    xp: 55,
    fieldNote:
      "Two mirror-smooth tungsten petals separated by thirty nanometers. Rings silently in human hearing range, yet shakes stray dust motes free by harvesting quantum vacuum pressure."
  },
  {
    id: "xa-chronos-stapler",
    catalogCode: "XA-06A",
    levelIndex: 5,
    x: 1055,
    y: 256,
    name: "Dilated-Time Desk Stapler",
    classification: "TEMPORAL OFFICEWARE",
    rarity: "RARE",
    originWorld: "Orbital Archive Annex",
    massKg: "0.91 kg",
    frequencyGHz: "1.77 GHz",
    glyph: "monolith",
    tint: "#ffd76d",
    credits: 70,
    xp: 55,
    fieldNote:
      "Standard issue inside the Low-G Restricted Stacks. Staples physical parchment onto closed timelike curves so overdue library notices technically arrive three Tuesdays before you ever borrowed the scroll."
  },
  {
    id: "xa-arecibo-microfilm",
    catalogCode: "XA-06B",
    levelIndex: 5,
    x: 2165,
    y: 251,
    name: "Arecibo 1679-Bit Micro-Plaque",
    classification: "SETI ARCHIVAL RECORD",
    rarity: "MYTHIC",
    originWorld: "Sol III · Puerto Rico",
    massKg: "0.05 kg",
    frequencyGHz: "1.42 GHz",
    glyph: "dish",
    tint: "#73f0ed",
    credits: 80,
    xp: 60,
    fieldNote:
      "An alien curator laminated Earth's 1974 binary pictogram inside sapphire foil with a neon sticky note attached: 'DELIGHTFUL PIXEL ART — TELL THE HUMANS TO USE HIGHER CONTRAST NEXT CENTURY'."
  },
  {
    id: "xa-tardigrade-amber",
    catalogCode: "XA-07A",
    levelIndex: 6,
    x: 475,
    y: 266,
    name: "Meteoroid Panspermia Pod",
    classification: "XENO-BIOLOGY",
    rarity: "RARE",
    originWorld: "Ross 128 Drift",
    massKg: "1.42 kg",
    frequencyGHz: "0.64 GHz",
    glyph: "helix",
    tint: "#a9e58a",
    credits: 75,
    xp: 60,
    fieldNote:
      "Vitrified silicate nodule sheltering cryptobiotic spores capable of enduring cosmic gamma bursts for 40,000 orbits—living proof that Bio-Dome ecosystems travel between stars on icy gravel."
  },
  {
    id: "xa-crimson-chloroplast",
    catalogCode: "XA-07B",
    levelIndex: 6,
    x: 2215,
    y: 266,
    name: "Infrared Leaf Prism",
    classification: "EXO-BOTANY",
    rarity: "ANOMALOUS",
    originWorld: "Proxima b Conservatory",
    massKg: "0.14 kg",
    frequencyGHz: "2.31 GHz",
    glyph: "helix",
    tint: "#ff9be4",
    credits: 75,
    xp: 60,
    fieldNote:
      "Preserved frond grown beneath dim red-dwarf illumination. Unlike Earth green chlorophyll, these indigo pigments sip near-infrared photons effortlessly and curl affectionately toward radio music."
  },
  {
    id: "xa-form44b-seal",
    catalogCode: "XA-08A",
    levelIndex: 7,
    x: 1215,
    y: 266,
    name: "Overridden Compliance Embosser",
    classification: "CORE AUTHENTICATOR",
    rarity: "MYTHIC",
    originWorld: "Eclipse Central Core",
    massKg: "2.05 kg",
    frequencyGHz: "6.40 GHz",
    glyph: "obelisk",
    tint: "#ffd76d",
    credits: 85,
    xp: 70,
    fieldNote:
      "The Core Warden's prized titanium stamp, engraved with every galactic zoning bylaw since the Paleogene epoch. Smudged heavily with dried strawberry cereal milk—almost certainly Fiona's doing."
  },
  {
    id: "xa-einstein-rosen-key",
    catalogCode: "XA-08B",
    levelIndex: 7,
    x: 2485,
    y: 266,
    name: "Folded-Metric Porch Key",
    classification: "SPACETIME KEYSTONE",
    rarity: "MYTHIC",
    originWorld: "Earth Orbit · Gallegar Lane",
    massKg: "0.09 kg",
    frequencyGHz: "1.42 GHz",
    glyph: "gyro",
    tint: "#73f0ed",
    credits: 100,
    xp: 80,
    fieldNote:
      "Looks suspiciously like the Gallegars' spare house key until viewed under UV light, where micro-engraved Lorentz coordinates bend through seven dimensions straight back to a quiet suburban driveway."
  }
];

export class XenoArtifactCollection {
  constructor(hub = null, saved = {}) {
    this.hub = hub;
    this.catalog = new Map(XENO_ARTIFACT_CATALOG.map((item) => [item.id, item]));
    this.collected = new Map();
    this.read = new Set();
    this.restore(saved);
  }

  forLevel(levelIndex) {
    return XENO_ARTIFACT_CATALOG.filter((item) => item.levelIndex === levelIndex).map((item) => ({
      ...item,
      collected: this.collected.has(item.id)
    }));
  }

  has(id) {
    return this.collected.has(id);
  }

  collect(id) {
    const artifact = this.catalog.get(id);
    if (!artifact) return { ok: false, reason: "unknown" };
    const firstDiscovery = !this.collected.has(id);
    if (firstDiscovery) {
      this.collected.set(id, {
        collectedAt: Date.now(),
        levelIndex: artifact.levelIndex
      });
      this.hub?.emit("artifact:collected", {
        id: artifact.id,
        artifact,
        totalCollected: this.collected.size,
        totalCatalog: this.catalog.size
      });
    }
    return { ok: true, firstDiscovery, artifact };
  }

  markRead(id) {
    if (!this.collected.has(id)) return false;
    this.read.add(id);
    return true;
  }

  list(filter = "all") {
    return XENO_ARTIFACT_CATALOG.map((item) => ({
      ...item,
      collected: this.collected.has(item.id),
      read: this.read.has(item.id),
      record: this.collected.get(item.id) || null
    })).filter((entry) => {
      if (filter === "collected") return entry.collected;
      if (filter === "uncollected") return !entry.collected;
      if (typeof filter === "number") return entry.levelIndex === filter;
      return true;
    });
  }

  progress() {
    const found = this.collected.size;
    const total = this.catalog.size;
    return {
      found,
      total,
      percent: total ? Math.round((found / total) * 100) : 0
    };
  }

  serialize() {
    return {
      collected: Object.fromEntries(this.collected.entries()),
      read: [...this.read]
    };
  }

  restore(saved = {}) {
    this.collected.clear();
    const entries = saved?.collected || {};
    for (const [id, record] of Object.entries(entries)) {
      if (this.catalog.has(id)) this.collected.set(id, { ...record });
    }
    this.read = new Set((saved?.read || []).filter((id) => this.catalog.has(id)));
  }
}

export function drawXenoArtifact(ctx, artifact, elapsed = 0, camera = 0) {
  if (!artifact || artifact.collected) return;
  const x = artifact.x - camera;
  const bob = Math.sin(elapsed * 0.07 + artifact.x * 0.03) * 4;
  const y = artifact.y + bob;
  const tint = artifact.tint || "#ff9be4";
  const pingTicks = artifact.scanPingTicks || 0;

  ctx.save();
  ctx.translate(x, y);

  // Expanding SETI resonance rings and targeting reticle when pinged by Fiona's 'F' scan pulse
  if (pingTicks > 0) {
    const pingAlpha = Math.min(1, pingTicks / 45);
    const wave = (elapsed * 0.05) % 1;
    ctx.save();
    ctx.globalAlpha = pingAlpha * (1 - wave) * 0.85;
    ctx.strokeStyle = "#a9e58a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 16 + wave * 28, 0, Math.PI * 2);
    ctx.stroke();

    ctx.globalAlpha = pingAlpha * 0.9;
    ctx.strokeStyle = "#73f0ed";
    ctx.lineWidth = 1.5;
    const b = 18;
    // Corner discovery brackets
    ctx.beginPath();
    ctx.moveTo(-b, -b + 6); ctx.lineTo(-b, -b); ctx.lineTo(-b + 6, -b);
    ctx.moveTo(b - 6, -b); ctx.lineTo(b, -b); ctx.lineTo(b, -b + 6);
    ctx.moveTo(-b, b - 6); ctx.lineTo(-b, b); ctx.lineTo(-b + 6, b);
    ctx.moveTo(b - 6, b); ctx.lineTo(b, b); ctx.lineTo(b, b - 6);
    ctx.stroke();

    ctx.fillStyle = "#a9e58a";
    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText(`${artifact.catalogCode} · RELIC`, 0, -24);
    ctx.restore();
  }

  ctx.shadowColor = tint;
  ctx.shadowBlur = pingTicks > 0 ? 22 : 14;

  // Outer containment halo + rotating orbital arc + harmonic motes
  ctx.strokeStyle = tint;
  ctx.lineWidth = pingTicks > 0 ? 2.2 : 1.6;
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, Math.PI * 2);
  ctx.stroke();

  const orbPhase = elapsed * 0.055;
  ctx.strokeStyle = "rgba(255, 255, 255, 0.45)";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, 0, 18, orbPhase, orbPhase + Math.PI * 0.85);
  ctx.stroke();

  ctx.fillStyle = "#ffffff";
  for (let m = 0; m < 2; m++) {
    const ma = orbPhase * 1.4 + m * Math.PI;
    ctx.fillRect(Math.cos(ma) * 18 - 1.2, Math.sin(ma) * 18 - 1.2, 2.5, 2.5);
  }

  if (artifact.glyph === "gyro") {
    ctx.rotate(elapsed * 0.04);
    ctx.strokeRect(-8, -8, 16, 16);
    ctx.rotate(Math.PI / 4);
    ctx.fillStyle = tint;
    ctx.fillRect(-5, -5, 10, 10);
  } else if (artifact.glyph === "helix") {
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-6, -9);
    ctx.bezierCurveTo(7, -3, -7, 3, 6, 9);
    ctx.moveTo(6, -9);
    ctx.bezierCurveTo(-7, -3, 7, 3, -6, 9);
    ctx.stroke();
    ctx.fillStyle = tint;
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();
  } else if (artifact.glyph === "dish") {
    ctx.strokeStyle = tint;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 2, 9, Math.PI * 1.1, Math.PI * 1.9);
    ctx.stroke();
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(0, -6, 3.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (artifact.glyph === "monolith") {
    ctx.fillStyle = "#19254c";
    ctx.fillRect(-6, -10, 12, 20);
    ctx.strokeRect(-6, -10, 12, 20);
    ctx.fillStyle = tint;
    ctx.fillRect(-2, -6, 4, 12);
  } else {
    // Prism / Obelisk crystal diamond
    ctx.fillStyle = tint;
    ctx.beginPath();
    ctx.moveTo(0, -11);
    ctx.lineTo(9, 0);
    ctx.lineTo(0, 11);
    ctx.lineTo(-9, 0);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(0, 0, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}
