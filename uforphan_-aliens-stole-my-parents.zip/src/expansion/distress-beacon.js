import { COLORS, GAME } from "../config.js";

/**
 * Chapters that feature active Distress Beacons which emit periodic acoustic pings
 * and light pulses, locking the sector exit until the signal source is reached and stabilized.
 */
export const DISTRESS_BEACON_CATALOG = {
  0: [
    {
      id: "sos-backyard-transponder",
      code: "SOS-01",
      name: "Minivan Distress Transponder",
      x: 1985,
      y: 312,
      interval: 120,
      rewardCredits: 45,
      rewardXp: 40,
      hintText: "Traced the minivan's emergency transponder on the upper ridge! Sector portal unlocked."
    }
  ],
  2: [
    {
      id: "sos-scrap-tug",
      code: "SOS-03",
      name: "Drifting Tug Distress Node",
      x: 2150,
      y: 282,
      interval: 115,
      rewardCredits: 55,
      rewardXp: 45,
      hintText: "Tugboat distress relay stabilized! Orbital departure lane cleared."
    }
  ],
  4: [
    {
      id: "sos-grove-resonator",
      code: "SOS-05",
      name: "Singing Valley Distress Core",
      x: 1665,
      y: 282,
      interval: 110,
      rewardCredits: 60,
      rewardXp: 50,
      hintText: "Crystal distress core synchronized with the valley chorus! Exit gate open."
    }
  ],
  6: [
    {
      id: "sos-dome-crew",
      code: "SOS-07",
      name: "Crew Capsule Distress Beacon",
      x: 2215,
      y: 282,
      interval: 105,
      rewardCredits: 70,
      rewardXp: 55,
      hintText: "Crew capsule distress beacon answered! Bio-Dome bulkhead unlocked."
    }
  ]
};

export class DistressBeaconSystem {
  constructor(levelIndex = 0, profile = null, definitions = null) {
    this.levelIndex = levelIndex;
    this.profile = profile;
    const defs = definitions || DISTRESS_BEACON_CATALOG[levelIndex] || [];
    this.beacons = defs.map((def, idx) => ({
      ...def,
      resolved: false,
      timer: 18 + idx * 30,
      flashTicks: 0,
      holdTicks: 0,
      pulses: [],
      edgePingAlpha: 0,
      edgeDirection: 1
    }));
    this.announcedIntro = false;
  }

  hasAny() {
    return this.beacons.length > 0;
  }

  unresolved() {
    return this.beacons.filter((b) => !b.resolved);
  }

  allResolved() {
    return this.beacons.every((b) => b.resolved);
  }

  nearBeacon(player, range = 66) {
    if (!player) return null;
    const px = player.x + player.w / 2;
    const py = player.y + player.h / 2;
    return (
      this.beacons.find(
        (b) => !b.resolved && Math.hypot(px - b.x, py - b.y) <= range
      ) || null
    );
  }

  nearestUnresolved(player) {
    const active = this.unresolved();
    if (!active.length) return null;
    if (!player) return { beacon: active[0], distance: 0 };
    const px = player.x + player.w / 2;
    const py = player.y + player.h / 2;
    let best = active[0];
    let bestDist = Math.hypot(px - best.x, py - best.y);
    for (const candidate of active.slice(1)) {
      const d = Math.hypot(px - candidate.x, py - candidate.y);
      if (d < bestDist) {
        best = candidate;
        bestDist = d;
      }
    }
    return { beacon: best, distance: bestDist };
  }

  resolveBeacon(beacon, world) {
    if (!beacon || beacon.resolved) return null;
    beacon.resolved = true;
    beacon.flashTicks = 30;
    beacon.pulses.push({
      radius: 10,
      maxRadius: 190,
      life: 44,
      maxLife: 44,
      color: COLORS.cyan
    });
    world?.audio?.collect?.();
    world?.particles?.burst?.(beacon.x, beacon.y - 14, COLORS.cyan, 18, 3.6);
    world?.particles?.ring?.(beacon.x, beacon.y - 14, COLORS.cyan, 44, 22);
    this.profile?.economy?.earn?.(beacon.rewardCredits || 45, "distress-beacon");
    this.profile?.progression?.addXP?.(beacon.rewardXp || 40);
    this.profile?.quests?.addProgressByTag?.("beacon", 1);
    this.profile?.events?.emit?.("distress:resolved", {
      id: beacon.id,
      code: beacon.code,
      name: beacon.name
    });
    world?.pushComms?.("fiona", beacon.hintText || `${beacon.name} stabilized!`, 240);
    return beacon;
  }

  update(player, world) {
    if (!this.beacons.length) return;

    if (!this.announcedIntro && world && world.elapsed > 36 && !world.comms && !this.allResolved()) {
      this.announcedIntro = true;
      world.pushComms?.(
        "moth",
        "Receiving periodic SOS ping ahead—follow the light pulses to unlock this sector's exit!",
        220
      );
    }

    const px = player ? player.x + player.w / 2 : 0;
    const py = player ? player.y + player.h / 2 : 420;
    const camera = world?.camera || 0;

    for (const b of this.beacons) {
      if (b.flashTicks > 0) b.flashTicks--;
      if (b.edgePingAlpha > 0) b.edgePingAlpha = Math.max(0, b.edgePingAlpha - 0.02);

      for (const pulse of b.pulses) {
        pulse.life--;
        const progress = 1 - pulse.life / pulse.maxLife;
        pulse.radius = 8 + progress * pulse.maxRadius;
      }
      b.pulses = b.pulses.filter((p) => p.life > 0);

      if (b.resolved) continue;

      const dist = player ? Math.hypot(px - b.x, py - b.y) : 900;
      const baseInterval = b.interval || 115;
      // Cadence accelerates smoothly as Fiona homes in on the distress signal
      const adaptiveDelay = dist < 440
        ? Math.max(46, Math.round(baseInterval * (0.42 + (dist / 440) * 0.58)))
        : baseInterval;

      b.timer--;
      if (b.timer <= 0) {
        b.timer = adaptiveDelay;
        b.flashTicks = 24;
        b.pulses.push({
          radius: 8,
          maxRadius: 210,
          life: 48,
          maxLife: 48,
          color: "#ff9b4d"
        });
        b.pulses.push({
          radius: 6,
          maxRadius: 130,
          life: 40,
          maxLife: 40,
          color: "#ffd76d"
        });

        const screenX = b.x - camera;
        if (screenX < 18 || screenX > GAME.width - 18) {
          b.edgePingAlpha = 1;
          b.edgeDirection = screenX < 18 ? -1 : 1;
        }

        const proximity = Math.max(0.18, Math.min(1, 1 - dist / 1450));
        world?.audio?.distress?.(proximity);
      }

      // Direct contact stabilization or active SETI scan wave lock
      if (player) {
        if (dist <= 34) {
          b.holdTicks++;
          if (b.holdTicks >= 12) {
            this.resolveBeacon(b, world);
            continue;
          }
        } else {
          b.holdTicks = 0;
        }

        const scanWave = world?.expansion?.exo?.scanWave;
        if (scanWave && dist <= 90 && Math.hypot(b.x - scanWave.x, b.y - scanWave.y) <= scanWave.radius + 16) {
          this.resolveBeacon(b, world);
        }
      }
    }
  }

  interact(player, world) {
    const near = this.nearBeacon(player, 68);
    if (!near) return null;
    return this.resolveBeacon(near, world);
  }

  /** Returns normalized ping intensity [0..1] for Signal Stability telemetry spikes. */
  activePulseLevel() {
    let peak = 0;
    for (const b of this.beacons) {
      if (b.resolved) continue;
      if (b.flashTicks > 0) peak = Math.max(peak, b.flashTicks / 24);
    }
    return peak;
  }

  draw(ctx, camera = 0, elapsed = 0) {
    for (const b of this.beacons) {
      const x = b.x - camera;
      const y = b.y;

      // Render expanding visual light pulse rings
      for (const pulse of b.pulses) {
        const alpha = Math.max(0, pulse.life / pulse.maxLife);
        ctx.save();
        ctx.globalAlpha = alpha * 0.78;
        ctx.strokeStyle = pulse.color || "#ff9b4d";
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.arc(x, y - 18, pulse.radius, 0, Math.PI * 2);
        ctx.stroke();

        // Warm light cone shimmer inside wavefront
        ctx.globalAlpha = alpha * 0.14;
        ctx.fillStyle = pulse.color || "#ff9b4d";
        ctx.beginPath();
        ctx.arc(x, y - 18, pulse.radius * 0.65, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      ctx.save();
      // Mast base & transmitter spire
      ctx.fillStyle = "#26365f";
      ctx.fillRect(x - 12, y + 10, 24, 8);
      ctx.fillStyle = "#486096";
      ctx.fillRect(x - 4, y - 18, 8, 28);

      // Signal strobe lantern dome
      const activeColor = b.resolved
        ? COLORS.cyan
        : b.flashTicks > 0
          ? "#ffd76d"
          : "#ff7f5c";
      const glowRadius = b.resolved ? 12 : b.flashTicks > 0 ? 24 : 8 + Math.sin(elapsed * 0.12) * 3;
      ctx.fillStyle = activeColor;
      ctx.shadowColor = activeColor;
      ctx.shadowBlur = glowRadius;
      ctx.beginPath();
      ctx.arc(x, y - 20, b.flashTicks > 0 && !b.resolved ? 8 : 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Status tag above beacon
      ctx.font = "bold 9px 'JetBrains Mono', monospace";
      ctx.textAlign = "center";
      ctx.fillStyle = b.resolved ? "#73f0ed" : "#ffd76d";
      ctx.fillText(b.resolved ? `${b.code} LOCKED` : `${b.code} · SOS`, x, y - 34);
      ctx.restore();
    }
  }

  /** Renders offscreen directional SOS light pulses & distance bearings on viewport edge. */
  drawScreen(ctx, player, world) {
    if (!this.beacons.length || this.allResolved()) return;
    const nearest = this.nearestUnresolved(player);
    if (!nearest) return;

    const { beacon, distance } = nearest;
    const camera = world?.camera || 0;
    const screenX = beacon.x - camera;
    const offscreenLeft = screenX < 18;
    const offscreenRight = screenX > GAME.width - 18;

    if (!offscreenLeft && !offscreenRight) return;

    const dir = offscreenLeft ? -1 : 1;
    const edgeX = dir < 0 ? 18 : GAME.width - 18;
    const edgeY = Math.max(105, Math.min(410, beacon.y - 18));
    const pulseAlpha = Math.max(0.28, beacon.edgePingAlpha);

    ctx.save();
    // Glowing directional pulse arcs radiating inward from viewport edge
    const bloom = ctx.createRadialGradient(edgeX, edgeY, 4, edgeX, edgeY, 64);
    bloom.addColorStop(0, `rgba(255, 155, 77, ${pulseAlpha * 0.55})`);
    bloom.addColorStop(1, "rgba(255, 155, 77, 0)");
    ctx.fillStyle = bloom;
    ctx.beginPath();
    ctx.arc(edgeX, edgeY, 64, 0, Math.PI * 2);
    ctx.fill();

    if (beacon.flashTicks > 0) {
      const r = 16 + (24 - beacon.flashTicks) * 1.8;
      ctx.strokeStyle = `rgba(255, 215, 109, ${(beacon.flashTicks / 24) * 0.85})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(edgeX, edgeY, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    const distM = Math.max(1, Math.round(distance / 12));
    const tagW = 86;
    const boxX = dir < 0 ? 22 : GAME.width - tagW - 22;
    const boxY = edgeY - 12;
    ctx.fillStyle = "rgba(18, 16, 40, 0.86)";
    ctx.strokeStyle = `rgba(255, 179, 92, ${0.45 + pulseAlpha * 0.45})`;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, tagW, 24, 7);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#ffd76d";
    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    const arrow = dir < 0 ? "◀ SOS" : "SOS ▶";
    ctx.fillText(`${arrow} · ${distM}m`, boxX + tagW / 2, boxY + 15);
    ctx.restore();
  }

  serialize() {
    return this.beacons.map((b) => ({ id: b.id, resolved: b.resolved }));
  }

  restore(saved = []) {
    for (const item of saved || []) {
      const target = this.beacons.find((b) => b.id === item.id);
      if (target) target.resolved = Boolean(item.resolved);
    }
  }
}
