import { GAME, COLORS } from "./config.js";
import { LEVELS } from "./levels.js";
import { Enemy, Boss } from "./enemies.js";
import { hit } from "./player.js";
import { ExpansionRuntime } from "./expansion/runtime.js";
import { STORY, SPEAKERS } from "./dialogue.js";

export class World {
  constructor(index, audio, particles, profile=null) {
    this.index=index;this.data=LEVELS[index];this.width=this.data.width;
    this.audio=audio;this.particles=particles;
    this.platforms=this.data.platforms.map(([x,y,w,h])=>({x,y,w,h}));
    this.stars=this.data.stars.map(([x,y])=>({x,y,r:9,collected:false,phase:Math.random()*5}));
    this.keys=this.data.keys.map(([x,y])=>({x,y,w:16,h:20,collected:false}));
    this.enemies=this.data.enemies.map(([type,x,y])=>new Enemy(type,x,y));
    this.hazards=this.data.hazards.map(([x,y,w,h])=>({x,y,w,h}));
    this.projectiles=[];this.checkpoint={x:this.data.checkpoint[0],y:this.data.checkpoint[1],active:false};
    this.exit={x:this.data.exit[0],y:this.data.exit[1],w:38,h:80};
    this.boss=this.data.boss?new Boss(this.data.boss):null;
    this.camera=0;this.elapsed=0;
    this.checkpointBannerTicks=0;
    this.playerX=55;
    this.playerY=420;
    this.dashCooldown=0;
    this.dashCooldownMax=52;
    this.comms=null;
    this.triggeredBeats=new Set();
    this.profile=profile;
    this.expansion=profile?new ExpansionRuntime(this,profile):null;
  }

  pushComms(speakerId, text, duration = 240) {
    if (!text) return;
    const speaker = SPEAKERS[speakerId] || SPEAKERS.fiona;
    this.comms = { speaker, text, ticks: duration, maxTicks: duration };
    this.audio?.radio?.();
  }

  update(player) {
    this.elapsed++;
    this.playerX=player.x+player.w/2;
    this.playerY=player.y+player.h/2;
    this.dashCooldown=player.dashCooldown||0;
    this.dashCooldownMax=Math.round(52*(player.dashCooldownMult||1));
    if(this.checkpointBannerTicks>0)this.checkpointBannerTicks--;
    if(this.comms){this.comms.ticks--;if(this.comms.ticks<=0)this.comms=null;}
    const beats=STORY.fieldBeats?.[this.index]||[];
    for(const beat of beats){
      if(!this.triggeredBeats.has(beat.id)&&player.x>=beat.x){
        this.triggeredBeats.add(beat.id);
        this.pushComms(beat.speaker,beat.text);
      }
    }
    this.enemies.forEach(e=>{if(!e.dead)e.update(this,player);});
    this.enemies=this.enemies.filter(e=>!e.dead);
    if(this.boss&&!this.boss.dead)this.boss.update(this,player);
    for(const p of this.projectiles) {
      p.x+=p.vx;p.y+=p.vy;p.life--;
      if(p.owner==="enemy"&&hit(p,player)) {player.takeDamage(this.audio,this.particles);p.life=0;}
      if(p.owner==="player") {
        for(const enemy of this.enemies) if(!enemy.dead&&hit(p,enemy)){const amount=p.damage||1;enemy.damage(this,amount);this.expansion?.combat.onDamage(enemy,amount,enemy.x+enemy.w/2,enemy.y);if(enemy.dead)this.expansion?.combat.onKill({type:enemy.type,x:enemy.x,y:enemy.y});if((p.pierce||0)>0)p.pierce--;else p.life=0;break;}
        if(this.boss&&!this.boss.dead&&hit(p,this.boss)){const amount=p.damage||1;this.boss.damage(this,amount);this.expansion?.combat.onDamage(this.boss,amount,this.boss.x+this.boss.w/2,this.boss.y);if(this.boss.dead)this.expansion?.combat.onKill({type:"boss",x:this.boss.x,y:this.boss.y});if((p.pierce||0)>0)p.pierce--;else p.life=0;}
      }
    }
    this.projectiles=this.projectiles.filter(p=>p.life>0&&p.x>-50&&p.x<this.width+50);
    const pickupRadius=player.pickupRadius||25;
    const bonus=this.expansion?.companion?.bonusStars?.()||0;
    for(const star of this.stars) {
      star.phase+=.06;
      if(!star.collected&&Math.hypot(player.x+player.w/2-star.x,player.y+player.h/2-star.y)<pickupRadius) {
        star.collected=true;player.stars+=1+bonus;this.profile?.statistics.collect("star",1+bonus);this.profile?.inventory.add("stardust",1+bonus);this.profile?.challenges.addProgress("stars",1+bonus);this.profile?.evaluateAchievements();this.audio.collect();
        if(this.particles?.sparkle)this.particles.sparkle(star.x,star.y,COLORS.gold,9);else this.particles.burst(star.x,star.y,COLORS.gold,8);
      }
    }
    for(const key of this.keys) if(!key.collected&&hit(player,{x:key.x,y:key.y,w:key.w,h:key.h})) {
      key.collected=true;player.keys++;this.profile?.statistics.collect("key",1);this.audio.collect();this.particles.burst(key.x,key.y,COLORS.cyan,10);this.particles?.ring?.(key.x+8,key.y+10,COLORS.cyan,28,16);
    }
    for(const hazard of this.hazards) if(hit(player,hazard)) player.takeDamage(this.audio,this.particles);
    if(!this.checkpoint.active&&player.x>this.checkpoint.x) {
      this.checkpoint.active=true;
      this.checkpointBannerTicks=130;
      this.audio?.collect?.();
      this.particles.burst(this.checkpoint.x,this.checkpoint.y,"#73f0ed",18);
      this.particles?.ring?.(this.checkpoint.x,this.checkpoint.y-20,"#73f0ed",38,22);
    }
    if(this.expansion)this.expansion.update(player);
    const lookAhead=(player.facing||1)*26;
    const targetCamera=Math.max(0,Math.min(this.width-GAME.width,player.x+lookAhead-GAME.width*.36));
    if(this.elapsed<=1)this.camera=targetCamera;
    else this.camera+=(targetCamera-this.camera)*0.16;
  }

  canExit() {
    const keysNeeded=this.keys.length;
    const keysCollected=this.keys.filter(k=>k.collected).length;
    const bossDone=!this.boss||this.boss.dead;
    const distressDone=this.expansion?.distress?this.expansion.distress.allResolved():true;
    return keysCollected>=keysNeeded&&bossDone&&distressDone;
  }

  gravityMultiplier() {
    if (!this.expansion) return 1;
    const weatherG = this.expansion.weather?.currentState?.().gravity ?? this.expansion.weather?.modifiers?.().gravity ?? 1;
    const envG = this.expansion.environment?.modifiers?.gravity ?? 1;
    if (weatherG < 1 && envG < 1) return Math.min(weatherG, envG);
    return weatherG * envG;
  }

  checkpointSpawn() {
    return {
      x: this.checkpoint.x,
      y: Math.max(60, this.checkpoint.y - 44)
    };
  }

  draw(ctx) {
    this.drawBackground(ctx);
    ctx.save();
    ctx.translate(-this.camera, 0);
    this.drawPlatforms(ctx);
    this.drawHazards(ctx);
    this.drawDecorations(ctx);
    this.drawCheckpoint(ctx);
    this.drawExit(ctx);
    this.stars.forEach((s) => {
      if (!s.collected) this.drawStar(ctx, s);
    });
    this.keys.forEach((k) => {
      if (!k.collected) this.drawKey(ctx, k);
    });
    this.enemies.forEach((e) => e.draw(ctx, 0));
    if (this.boss && !this.boss.dead) this.boss.draw(ctx, 0);
    this.projectiles.forEach((p) => this.drawProjectile(ctx, p));
    if (this.expansion) this.expansion.draw(ctx, 0);
    ctx.restore();
    if (this.expansion?.drawScreen) this.expansion.drawScreen(ctx);
    if (this.boss && !this.boss.dead) this.drawBossHUD(ctx);
    this.drawRadar(ctx);
    this.drawDashStatus(ctx);
    if (this.checkpointBannerTicks > 0) this.drawCheckpointToast(ctx);
    if (this.comms) this.drawComms(ctx);
  }

  drawDashStatus(ctx) {
    const ready = this.dashCooldown <= 0;
    const pct = ready ? 1 : 1 - this.dashCooldown / Math.max(1, this.dashCooldownMax || 52);
    ctx.save();
    ctx.fillStyle = "rgba(10, 16, 40, 0.72)";
    ctx.strokeStyle = ready ? "rgba(115, 240, 237, 0.45)" : "rgba(166, 184, 255, 0.2)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(16, 16, 98, 22, 8);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = ready ? COLORS.cyan : "#8c99be";
    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "left";
    ctx.fillText(ready ? "DASH READY" : "CHARGING", 23, 30);
    ctx.fillStyle = "rgba(115, 240, 237, 0.2)";
    ctx.fillRect(88, 24, 18, 5);
    ctx.fillStyle = ready ? COLORS.cyan : "#8c99be";
    ctx.fillRect(88, 24, 18 * pct, 5);
    ctx.restore();
  }

  drawComms(ctx) {
    const c = this.comms;
    const alpha = Math.min(1, c.ticks / 24, (c.maxTicks - c.ticks + 12) / 12);
    ctx.save();
    ctx.globalAlpha = Math.max(0, alpha);
    const boxW = Math.min(540, Math.max(300, c.text.length * 6.4 + 86));
    const boxY = GAME.height - 62;
    ctx.fillStyle = "rgba(8, 13, 34, 0.88)";
    ctx.strokeStyle = c.speaker.color;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(16, boxY, boxW, 46, 10);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = c.speaker.color;
    ctx.beginPath();
    ctx.roundRect(24, boxY + 9, 28, 28, 7);
    ctx.fill();
    ctx.fillStyle = "#081326";
    ctx.font = "bold 13px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText(c.speaker.badge, 38, boxY + 28);

    ctx.textAlign = "left";
    ctx.fillStyle = c.speaker.color;
    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.fillText(c.speaker.name, 62, boxY + 19);
    ctx.fillStyle = "#eef2ff";
    ctx.font = "500 12px 'Plus Jakarta Sans', sans-serif";
    ctx.fillText(c.text, 62, boxY + 36, boxW - 76);
    ctx.restore();
  }

  drawRadar(ctx) {
    const w = 164;
    const h = 22;
    const x = GAME.width - w - 16;
    const y = 16;
    const scale = (w - 16) / Math.max(1, this.width);
    ctx.save();
    ctx.fillStyle = "rgba(10, 16, 40, 0.72)";
    ctx.strokeStyle = "rgba(166, 184, 255, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "rgba(166, 184, 255, 0.22)";
    ctx.fillRect(x + 8, y + 10, w - 16, 2);

    // Checkpoint marker
    ctx.fillStyle = this.checkpoint.active ? COLORS.cyan : "#64739b";
    ctx.fillRect(x + 8 + this.checkpoint.x * scale - 1, y + 6, 2, 10);

    // Uncollected keycards
    for (const k of this.keys) {
      if (k.collected) continue;
      ctx.fillStyle = COLORS.gold;
      ctx.fillRect(x + 8 + k.x * scale - 2, y + 7, 4, 8);
    }

    // E.T. science anomalies
    for (const a of this.expansion?.exo?.anomalies || []) {
      if (a.analyzed) continue;
      ctx.fillStyle = "#ff9be4";
      ctx.fillRect(x + 8 + a.x * scale - 1.5, y + 8, 3, 6);
    }

    // Uncollected Xeno-Artifacts
    for (const art of this.expansion?.artifacts || []) {
      if (art.collected) continue;
      ctx.fillStyle = "#a9e58a";
      ctx.fillRect(x + 8 + art.x * scale - 1.5, y + 7, 3, 8);
    }

    // Unresolved Distress Beacons (pulsing amber SOS blips)
    for (const sos of this.expansion?.distress?.unresolved?.() || []) {
      ctx.fillStyle = sos.flashTicks > 0 ? "#ffd76d" : "#ff9b4d";
      ctx.fillRect(x + 8 + sos.x * scale - 2, y + 5, 4, 12);
    }

    // Exit portal
    ctx.fillStyle = this.canExit() ? COLORS.cyan : "#ff77bd";
    ctx.beginPath();
    ctx.arc(x + 8 + this.exit.x * scale, y + 11, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Fiona marker
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(x + 8 + this.playerX * scale, y + 11, 3.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  drawCheckpointToast(ctx) {
    const alpha = Math.min(1, this.checkpointBannerTicks / 24);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "rgba(10, 18, 44, 0.88)";
    ctx.strokeStyle = "rgba(115, 240, 237, 0.65)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(124, 16, 164, 24, 8);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#73f0ed";
    ctx.font = "bold 10px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText("✦ CHECKPOINT LIT", 206, 32);
    ctx.restore();
  }

  interact(player) {
    return this.expansion ? this.expansion.interact(player) : null;
  }

  drawBackground(ctx) {
    const gradient = ctx.createLinearGradient(0, 0, 0, GAME.height);
    gradient.addColorStop(0, this.data.sky[0]);
    gradient.addColorStop(1, this.data.sky[1]);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, GAME.width, GAME.height);

    // Subtle cosmic nebula bloom shifting gently with parallax
    const nebX = 340 - ((this.camera * 0.08) % 240);
    const nebula = ctx.createRadialGradient(nebX, 150, 20, nebX, 150, 340);
    nebula.addColorStop(0, "rgba(115, 240, 237, 0.07)");
    nebula.addColorStop(0.55, "rgba(154, 108, 255, 0.05)");
    nebula.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebula;
    ctx.fillRect(0, 0, GAME.width, GAME.height);

    for (let i = 0; i < 110; i++) {
      const layerSpeed = i % 3 === 0 ? 0.24 : 0.12;
      const x = ((i * 173 - Math.floor(this.camera * layerSpeed)) % (GAME.width + 40) + (GAME.width + 40)) % (GAME.width + 40) - 20;
      const y = (i * 83) % 360;
      const twinkle = 0.25 + ((Math.sin(this.elapsed * 0.045 + i) + 1) * 0.28);
      ctx.globalAlpha = twinkle;
      ctx.fillStyle = i % 8 === 0 ? COLORS.cyan : i % 11 === 0 ? COLORS.gold : "#e7eaff";
      ctx.fillRect(x, y, i % 6 === 0 ? 3 : 2, i % 6 === 0 ? 3 : 2);
    }

    // Occasional distant shooting star streak across deep sky
    const meteorTick = this.elapsed % 280;
    if (meteorTick < 32) {
      const mx = 840 - meteorTick * 18;
      const my = 42 + meteorTick * 5.2;
      ctx.globalAlpha = Math.sin((meteorTick / 32) * Math.PI) * 0.65;
      ctx.strokeStyle = "#d9f8ff";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(mx, my);
      ctx.lineTo(mx + 26, my - 8);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    this.drawPlanet(ctx);
  }

  drawPlanet(ctx) {
    const type = this.data.background;
    if (type === "suburb") {
      ctx.fillStyle = "#202d54";
      ctx.fillRect(0, 405, 960, 75);
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = i % 2 ? "#35446f" : "#29375e";
        ctx.fillRect(i * 190 - 30, 355, 145, 80);
        ctx.fillStyle = "#ffd76d";
        ctx.fillRect(i * 190 + 10, 380, 14, 17);
        // Chimney / rooftop antenna beacon
        ctx.fillStyle = "#485c92";
        ctx.fillRect(i * 190 + 82, 336, 3, 19);
        if (Math.floor(this.elapsed / 24 + i) % 2 === 0) {
          ctx.fillStyle = "#ff77bd";
          ctx.fillRect(i * 190 + 81, 334, 5, 3);
        }
      }
      ctx.fillStyle = "#7187b7";
      ctx.beginPath();
      ctx.arc(780, 125, 48, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255, 255, 255, 0.14)";
      ctx.beginPath();
      ctx.arc(766, 114, 16, 0, Math.PI * 2);
      ctx.fill();
      // Drifting moonlit cloud wisps
      ctx.fillStyle = "rgba(182, 206, 255, 0.08)";
      for (let c = 0; c < 3; c++) {
        const cx = ((c * 340 + this.elapsed * (0.28 + c * 0.06)) % 1120) - 100;
        const cy = 96 + c * 32;
        ctx.beginPath();
        ctx.ellipse(cx, cy, 74, 13, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Distant alien scout saucer gliding over suburbia with rim lights
      const ufoX = 240 + Math.sin(this.elapsed * 0.012) * 140;
      const ufoY = 92 + Math.cos(this.elapsed * 0.03) * 6;
      ctx.fillStyle = "rgba(115, 240, 237, 0.14)";
      ctx.beginPath();
      ctx.moveTo(ufoX - 10, ufoY + 4);
      ctx.lineTo(ufoX + 10, ufoY + 4);
      ctx.lineTo(ufoX + 34, 210);
      ctx.lineTo(ufoX - 34, 210);
      ctx.fill();
      ctx.fillStyle = "#9bb5e8";
      ctx.beginPath();
      ctx.ellipse(ufoX, ufoY, 26, 7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#73f0ed";
      ctx.beginPath();
      ctx.ellipse(ufoX, ufoY - 4, 11, 6, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = Math.floor(this.elapsed / 10) % 2 === 0 ? "#ffd76d" : "#ff77bd";
      ctx.fillRect(ufoX - 14, ufoY - 1, 4, 2);
      ctx.fillRect(ufoX + 10, ufoY - 1, 4, 2);
    } else {
      const palettes = {
        mall: "#1c5370",
        scrap: "#442d50",
        crystal: "#315a79",
        archive: "#2d426b",
        organic: "#2f684e",
        command: "#43254f",
        ship: "#2c3159"
      };
      ctx.fillStyle = palettes[type] || "#2c3159";
      ctx.beginPath();
      ctx.arc(780, 150, 92, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
      ctx.beginPath();
      ctx.arc(750, 126, 44, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(142,239,237,.28)";
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.ellipse(780, 150, 135, 35, -0.2, 0, Math.PI * 2);
      ctx.stroke();

      // Chapter-specific mid-ground silhouette animations
      if (type === "crystal") {
        for (let i = 0; i < 6; i++) {
          const sx = 95 + i * 165 - (this.camera * 0.14 % 165);
          const glow = 0.14 + (Math.sin(this.elapsed * 0.05 + i) + 1) * 0.08;
          ctx.fillStyle = `rgba(115, 240, 237, ${glow})`;
          ctx.beginPath();
          ctx.moveTo(sx - 18, 460);
          ctx.lineTo(sx, 330 - (i % 2) * 38);
          ctx.lineTo(sx + 18, 460);
          ctx.closePath();
          ctx.fill();
        }
      } else if (type === "organic") {
        ctx.fillStyle = "rgba(169, 229, 138, 0.35)";
        for (let i = 0; i < 12; i++) {
          const fx = (i * 88 + Math.sin(this.elapsed * 0.02 + i) * 20) % 960;
          const fy = 450 - ((this.elapsed * 0.9 + i * 37) % 320);
          ctx.beginPath();
          ctx.arc(fx, fy, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (type === "scrap") {
        ctx.fillStyle = "rgba(155, 130, 175, 0.28)";
        for (let i = 0; i < 5; i++) {
          const ax = (140 + i * 190 + this.elapsed * 0.25) % 980 - 20;
          const ay = 190 + Math.sin(this.elapsed * 0.02 + i * 1.4) * 24;
          ctx.fillRect(ax, ay, 18 + (i % 3) * 6, 12);
        }
      } else if (type === "mall") {
        for (let i = 0; i < 3; i++) {
          const sx = 170 + i * 310 - ((this.camera * 0.12) % 310);
          const sweep = Math.sin(this.elapsed * 0.025 + i * 1.8) * 58;
          ctx.fillStyle = i % 2 === 0 ? "rgba(115, 240, 237, 0.07)" : "rgba(255, 155, 228, 0.07)";
          ctx.beginPath();
          ctx.moveTo(sx - 8, 450);
          ctx.lineTo(sx + sweep - 55, 130);
          ctx.lineTo(sx + sweep + 55, 130);
          ctx.lineTo(sx + 8, 450);
          ctx.closePath();
          ctx.fill();
        }
      } else if (type === "ship" || type === "command" || type === "archive") {
        for (let i = 0; i < 4; i++) {
          const dx = ((i * 270 + this.elapsed * (0.9 + (i % 2) * 0.45)) % 1040) - 40;
          const dy = 110 + i * 48 + Math.sin(this.elapsed * 0.03 + i) * 6;
          ctx.fillStyle = "rgba(115, 240, 237, 0.35)";
          ctx.fillRect(dx, dy, 12, 3);
          ctx.fillStyle = "rgba(255, 215, 109, 0.5)";
          ctx.fillRect(dx + 12, dy, 3, 3);
        }
      }

      // Orbiting research satellite moonlet
      const moonX = 780 + Math.cos(this.elapsed * 0.01) * 135;
      const moonY = 150 + Math.sin(this.elapsed * 0.01) * 35;
      ctx.fillStyle = "#d9e9ff";
      ctx.beginPath();
      ctx.arc(moonX, moonY, 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  drawPlatforms(ctx) {
    for (const p of this.platforms) {
      ctx.fillStyle = "#25345d";
      ctx.fillRect(p.x, p.y, p.w, p.h);
      ctx.fillStyle = "#7994d0";
      ctx.fillRect(p.x, p.y, p.w, 5);
      ctx.fillStyle = "rgba(166, 224, 255, 0.28)";
      ctx.fillRect(p.x, p.y, p.w, 1.5);
      ctx.fillStyle = "rgba(130, 162, 230, 0.18)";
      for (let x = p.x + 12; x < p.x + p.w - 8; x += 28) {
        ctx.fillRect(x, p.y + 14, 12, 3);
      }
      if (p.w >= 90) {
        const pulseX = p.x + ((this.elapsed * 1.4 + p.x) % Math.max(24, p.w - 16));
        ctx.fillStyle = "rgba(115, 240, 237, 0.48)";
        ctx.fillRect(pulseX, p.y + 2, 10, 2);
      }
    }
  }

  drawHazards(ctx) {
    const flicker = (Math.sin(this.elapsed * 0.26) + 1) * 0.5;
    for (const h of this.hazards) {
      ctx.fillStyle = "#311d4b";
      ctx.fillRect(h.x, h.y, h.w, h.h);
      ctx.fillStyle = `rgba(255, 102, 140, ${0.14 + flicker * 0.14})`;
      ctx.fillRect(h.x, h.y - 12, h.w, 12);
      ctx.fillStyle = "#ff668c";
      for (let x = h.x; x < h.x + h.w; x += 16) {
        const tipLift = Math.sin(this.elapsed * 0.2 + x * 0.08) * 1.5;
        ctx.beginPath();
        ctx.moveTo(x, h.y);
        ctx.lineTo(x + 8, h.y - 13 - tipLift);
        ctx.lineTo(x + 16, h.y);
        ctx.fill();
      }
      const emberStep = ((this.elapsed * 0.045 + h.x * 0.01) % 1);
      ctx.fillStyle = `rgba(255, 166, 200, ${(1 - emberStep) * 0.7})`;
      ctx.fillRect(h.x + ((h.w * 0.35 + this.elapsed) % Math.max(10, h.w - 6)), h.y - 8 - emberStep * 14, 2.5, 2.5);
    }
  }

  drawDecorations(ctx) {
    for (let x = 80; x < this.width; x += 260) {
      const y = 440 + Math.sin(x) * 6;
      const glow = 0.24 + (Math.sin(this.elapsed * 0.07 + x) + 1) * 0.18;
      ctx.fillStyle = "rgba(109,240,237,.13)";
      ctx.fillRect(x, y, 22, 40);
      ctx.fillStyle = `rgba(109,240,237,${glow})`;
      ctx.fillRect(x + 7, y - 10, 8, 12);
      ctx.strokeStyle = `rgba(115, 240, 237, ${glow * 0.65})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(x + 11, y - 8, 7 + Math.sin(this.elapsed * 0.08 + x) * 3, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
    }
  }

  drawCheckpoint(ctx) {
    const c = this.checkpoint;
    const wave = c.active ? Math.sin(this.elapsed * 0.16) * 3.5 : 0;
    ctx.save();
    if (c.active) {
      const halo = 12 + Math.sin(this.elapsed * 0.12) * 3;
      ctx.fillStyle = "rgba(115, 240, 237, 0.18)";
      ctx.beginPath();
      ctx.arc(c.x + 2, c.y - 54, halo, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = c.active ? "#73f0ed" : "#64739b";
    ctx.fillRect(c.x, c.y - 55, 4, 55);
    ctx.beginPath();
    ctx.moveTo(c.x + 4, c.y - 54);
    ctx.lineTo(c.x + 35, c.y - 43 + wave);
    ctx.lineTo(c.x + 4, c.y - 32);
    ctx.fill();
    ctx.restore();
  }

  drawExit(ctx) {
    const ready = this.canExit();
    const pulse = (Math.sin(this.elapsed * 0.1) + 1) * 0.5;
    const cx = this.exit.x + 19;
    const cy = this.exit.y + 40;
    ctx.save();
    ctx.globalAlpha = ready ? 1 : 0.45;
    if (ready) {
      ctx.shadowColor = "#73f0ed";
      ctx.shadowBlur = 18 + pulse * 10;
    }
    ctx.fillStyle = ready ? "#73f0ed" : "#7a83a8";
    ctx.beginPath();
    ctx.ellipse(cx, cy, 22, 40, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#152247";
    ctx.beginPath();
    ctx.ellipse(cx, cy, 13, 31, 0, 0, Math.PI * 2);
    ctx.fill();

    if (ready) {
      // Swirling inner vortex rings & orbiting energy sparks when unlocked
      ctx.strokeStyle = "rgba(169, 229, 138, 0.8)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, 8 + pulse * 3, 21, 0, this.elapsed * 0.08, this.elapsed * 0.08 + Math.PI * 1.3);
      ctx.stroke();

      ctx.strokeStyle = "rgba(115, 240, 237, 0.65)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.ellipse(cx, cy, 5 + (1 - pulse) * 3, 14, 0, -this.elapsed * 0.1, -this.elapsed * 0.1 + Math.PI * 1.1);
      ctx.stroke();

      ctx.fillStyle = "#ffffff";
      for (let i = 0; i < 3; i++) {
        const a = this.elapsed * 0.07 + (i * Math.PI * 2) / 3;
        ctx.fillRect(cx + Math.cos(a) * 16 - 1.5, cy + Math.sin(a) * 33 - 1.5, 3, 3);
      }

      const chevBob = Math.sin(this.elapsed * 0.14) * 3;
      ctx.fillStyle = "#a9e58a";
      ctx.beginPath();
      ctx.moveTo(cx - 5, this.exit.y - 16 + chevBob);
      ctx.lineTo(cx + 5, this.exit.y - 16 + chevBob);
      ctx.lineTo(cx, this.exit.y - 9 + chevBob);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "#ffd76d";
      ctx.font = "bold 10px 'JetBrains Mono', monospace";
      ctx.textAlign = "center";
      ctx.fillText("LOCKED", cx, this.exit.y - 8);
    }
    ctx.restore();
  }

  drawBossHUD(ctx) {
    const ratio = Math.max(0, this.boss.health / this.boss.maxHealth);
    const label = this.data.id === "eclipse-core" ? "THE CORE WARDEN" : "ABDUCTION COMMANDER";
    const phase = this.boss.phaseName ? ` · ${this.boss.phaseName.toUpperCase()}` : "";
    ctx.save();
    ctx.fillStyle = "rgba(10, 16, 40, 0.82)";
    ctx.strokeStyle = "rgba(255, 102, 141, 0.5)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(300, 16, 360, 34, 10);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#f3f5ff";
    ctx.font = "bold 10px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText(`${label}${phase}`, 480, 30);
    ctx.fillStyle = "#261b3e";
    ctx.fillRect(318, 36, 324, 6);
    ctx.fillStyle = "#ff668d";
    ctx.fillRect(318, 36, 324 * ratio, 6);
    ctx.restore();
  }

  drawStar(ctx, s) {
    const pulse = Math.sin(s.phase) * 2;
    const hover = Math.sin(s.phase * 1.4) * 3;
    ctx.save();
    ctx.translate(s.x, s.y + hover);
    ctx.strokeStyle = "rgba(255, 215, 109, 0.25)";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(0, 0, 14 + pulse * 0.5, 0, Math.PI * 2);
    ctx.stroke();

    ctx.rotate(s.phase * 0.25);
    ctx.fillStyle = COLORS.gold;
    ctx.shadowColor = COLORS.gold;
    ctx.shadowBlur = 15;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5;
      const r = i % 2 ? 4 : 10 + pulse;
      ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  drawKey(ctx, k) {
    const bob = Math.sin(this.elapsed * 0.08 + k.x * 0.02) * 3.5;
    const gleam = 0.22 + (Math.sin(this.elapsed * 0.1 + k.x) + 1) * 0.16;
    ctx.save();
    ctx.strokeStyle = `rgba(115, 240, 237, ${gleam})`;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(k.x + 8, k.y + 10 + bob, 16, 0, Math.PI * 2);
    ctx.stroke();

    ctx.shadowColor = COLORS.cyan;
    ctx.shadowBlur = 11;
    ctx.fillStyle = COLORS.cyan;
    ctx.fillRect(k.x, k.y + bob, 7, 20);
    ctx.fillRect(k.x + 5, k.y + 2 + bob, 12, 5);
    ctx.fillRect(k.x + 11, k.y + 7 + bob, 5, 5);
    ctx.restore();
  }

  drawProjectile(ctx, p) {
    const color = p.color || (p.owner === "player" ? "#73f0ed" : "#ff6a94");
    const vx = p.vx ?? 1;
    const vy = p.vy ?? 0;
    const angle = Math.atan2(vy, vx);
    const speed = Math.hypot(vx, vy) || 1;
    const nx = vx / speed;
    const ny = vy / speed;

    ctx.save();
    for (let i = 1; i <= 2; i++) {
      ctx.globalAlpha = 0.42 / i;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(p.x - nx * i * 7, p.y - ny * i * 7, 3.4 - i * 0.9, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.translate(p.x, p.y);
    ctx.rotate(angle);
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.ellipse(-3, 0, 9, 3.8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(1.5, 0, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
