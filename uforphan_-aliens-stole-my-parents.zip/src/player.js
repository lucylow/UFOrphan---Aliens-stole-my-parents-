import { GAME } from "./config.js";

export class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.w = 27;
    this.h = 39;
    this.vx = 0;
    this.vy = 0;
    this.onGround = false;
    this.coyoteTicks = 0;
    this.jumpBufferTicks = 0;
    this.health = 3;
    this.invulnerable = 0;
    this.facing = 1;
    this.cooldown = 0;
    this.muzzleTicks = 0;
    this.stars = 0;
    this.keys = 0;
    this.anim = 0;
    this.idleTicks = 0;
    this.stepDustTicks = 0;
    this.scaleX = 1;
    this.scaleY = 1;
    this.dead = false;
    this.maxHealth = 3;
    this.shieldTicks = 0;
    this.extraJumpUnlocked = false;
    this.extraJumpAvailable = false;
    this.speedMultiplier = 1;
    this.damageRecovery = 90;
    this.weapon = "star_blaster";
    this.pickupRadius = 25;
    this.lastSafePos = { x, y };
    this.dashTicks = 0;
    this.dashCooldown = 0;
    this.dashCooldownMult = 1;
    this.scanRadius = 240;
    this.trail = [];
  }

  update(input, world, audio, particles) {
    if (this.dead) return;
    const wasOnGround = this.onGround;
    if (this.dashCooldown > 0) this.dashCooldown--;
    world?.expansion?.exo?.handleScanInput?.(this, input.isDown("scan"), input.wasPressed("scan"));

    if (input.wasPressed("dash") && this.dashCooldown <= 0 && this.dashTicks <= 0) {
      this.dashTicks = 11;
      this.dashCooldown = Math.round(52 * (this.dashCooldownMult || 1));
      this.invulnerable = Math.max(this.invulnerable, 12);
      this.vx = this.facing * 9.5;
      this.vy = Math.min(this.vy, 0) * 0.25;
      this.scaleX = 1.24;
      this.scaleY = 0.8;
      audio?.dash?.();
      particles?.burst(this.x + this.w / 2, this.y + this.h / 2, "#73f0ed", 10, 3.2);
      particles?.ring?.(this.x + this.w / 2, this.y + this.h / 2, "#73f0ed", 28, 14);
    }

    if (this.dashTicks > 0) {
      this.dashTicks--;
      this.vx = this.facing * 9.5;
      this.vy *= 0.25;
      this.trail.push({ x: this.x, y: this.y, facing: this.facing, life: 11 });
    } else {
      const left = input.isDown("left");
      const right = input.isDown("right");
      if (left !== right) {
        this.vx += left ? -0.78 : 0.78;
        this.facing = left ? -1 : 1;
      } else {
        this.vx *= GAME.friction;
      }
      const maxSpeed = GAME.playerSpeed * this.speedMultiplier;
      this.vx = Math.max(-maxSpeed, Math.min(maxSpeed, this.vx));
    }

    if (this.onGround) this.coyoteTicks = 6;
    else if (this.coyoteTicks > 0) this.coyoteTicks--;

    if (input.wasPressed("jump")) this.jumpBufferTicks = 6;
    else if (this.jumpBufferTicks > 0) this.jumpBufferTicks--;

    const canGroundJump = this.onGround || this.coyoteTicks > 0;
    const canDoubleJump = !canGroundJump && this.extraJumpUnlocked && this.extraJumpAvailable;
    if (this.jumpBufferTicks > 0 && (canGroundJump || canDoubleJump)) {
      this.vy = -GAME.jumpPower;
      this.dashTicks = 0;
      this.onGround = false;
      this.coyoteTicks = 0;
      this.jumpBufferTicks = 0;
      this.scaleX = 0.82;
      this.scaleY = 1.2;
      if (canGroundJump) {
        this.extraJumpAvailable = this.extraJumpUnlocked;
        particles?.burst(this.x + this.w / 2, this.y + this.h, "#a9bfff", 4, 1.4, "dust");
      } else {
        this.extraJumpAvailable = false;
        particles?.burst(this.x + this.w / 2, this.y + this.h, "#73f0ed", 8, 2.2);
        particles?.ring?.(this.x + this.w / 2, this.y + this.h, "#73f0ed", 22, 14);
      }
      audio.jump();
    }

    if (world.expansion) {
      world.expansion.combat.configure(world.profile.inventory);
      if (input.wasPressed("blast")) {
        if (world.expansion.combat.fire(this, world, audio)) {
          this.muzzleTicks = 5;
        }
      }
    } else if (input.wasPressed("blast") && this.cooldown <= 0) {
      world.projectiles.push({
        x: this.x + (this.facing > 0 ? this.w : -12),
        y: this.y + 15,
        w: 10,
        h: 10,
        vx: this.facing * 8.5,
        vy: 0,
        life: 65,
        owner: "player"
      });
      this.cooldown = GAME.blastCooldown;
      this.muzzleTicks = 5;
      audio.blast();
    }

    const gravScale = this.dashTicks > 0 ? 0.12 : (typeof world.gravityMultiplier === "function" ? world.gravityMultiplier() : 1);
    this.vy = Math.min(GAME.maxFall, this.vy + GAME.gravity * gravScale);
    this.x += this.vx;
    this.resolveHorizontal(world.platforms);
    this.y += this.vy;
    this.onGround = false;
    this.resolveVertical(world.platforms);
    if (this.onGround) {
      this.extraJumpAvailable = this.extraJumpUnlocked;
      this.lastSafePos = { x: this.x, y: this.y };
      if (!wasOnGround) {
        this.scaleX = 1.22;
        this.scaleY = 0.8;
        particles?.burst(this.x + this.w / 2, this.y + this.h, "#9fb2df", 5, 1.5, "dust");
      }
    }

    this.x = Math.max(0, Math.min(world.width - this.w, this.x));
    if (this.y > GAME.height + 100) {
      this.takeDamage(audio, particles, true);
      if (!this.dead) {
        this.x = this.lastSafePos.x;
        this.y = Math.max(40, this.lastSafePos.y - 8);
        this.vx = 0;
        this.vy = 0;
        this.dashTicks = 0;
        particles?.burst(this.x + this.w / 2, this.y + this.h / 2, "#73f0ed", 10);
      }
    }
    if (this.invulnerable > 0) this.invulnerable--;
    if (this.shieldTicks > 0) this.shieldTicks--;
    if (this.cooldown > 0) this.cooldown--;
    if (this.muzzleTicks > 0) this.muzzleTicks--;
    for (const ghost of this.trail) ghost.life--;
    this.trail = this.trail.filter((g) => g.life > 0);
    this.anim += Math.abs(this.vx) * 0.12;
    this.idleTicks++;
    if (this.onGround && Math.abs(this.vx) > 2.2) {
      this.stepDustTicks++;
      if (this.stepDustTicks >= 12) {
        this.stepDustTicks = 0;
        particles?.burst?.(this.x + this.w / 2 - this.facing * 6, this.y + this.h, "#9fb2df", 2, 0.9, "dust");
      }
    } else {
      this.stepDustTicks = 0;
    }
    this.scaleX += (1 - this.scaleX) * 0.22;
    this.scaleY += (1 - this.scaleY) * 0.22;
  }

  resolveHorizontal(platforms) {
    for (const p of platforms) {
      if (!hit(this, p)) continue;
      if (this.vx > 0) this.x = p.x - this.w;
      else if (this.vx < 0) this.x = p.x + p.w;
      this.vx = 0;
    }
  }

  resolveVertical(platforms) {
    for (const p of platforms) {
      if (!hit(this, p)) continue;
      if (this.vy > 0) {
        this.y = p.y - this.h;
        this.onGround = true;
      } else if (this.vy < 0) {
        this.y = p.y + p.h;
      }
      this.vy = 0;
    }
  }

  takeDamage(audio, particles, force = false) {
    if (this.invulnerable > 0 && !force) return;
    if (this.shieldTicks > 0 && !force) {
      this.shieldTicks = 0;
      this.invulnerable = 30;
      particles?.burst(this.x + this.w / 2, this.y + this.h / 2, "#73f0ed", 14);
      particles?.ring?.(this.x + this.w / 2, this.y + this.h / 2, "#73f0ed", 34, 18);
      return;
    }
    this.onDamage?.();
    this.health--;
    this.invulnerable = this.damageRecovery || 90;
    this.vy = -7;
    this.vx = -this.facing * 4;
    this.scaleX = 0.85;
    this.scaleY = 1.18;
    audio.hurt();
    particles.burst(this.x + this.w / 2, this.y + this.h / 2, "#ff668a", 12);
    particles?.ring?.(this.x + this.w / 2, this.y + this.h / 2, "#ff668a", 30, 16);
    if (this.health <= 0) this.dead = true;
  }

  draw(ctx, camera) {
    // Sleek translucent cyan afterimage trail during Star-Dash
    for (const ghost of this.trail) {
      const a = (ghost.life / 11) * 0.42;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.translate(Math.round(ghost.x - camera + this.w / 2), Math.round(ghost.y));
      ctx.scale(ghost.facing || this.facing, 1);
      rounded(ctx, -12, 3, 24, 33, 8, "#73f0ed");
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(-10, 14, 18, 3);
      ctx.restore();
    }

    const x = Math.round(this.x - camera);
    const y = Math.round(this.y);
    if (this.invulnerable > 0 && this.dashTicks <= 0 && Math.floor(this.invulnerable / 6) % 2 === 0) return;

    const moving = Math.abs(this.vx) > 0.35;
    const stride = this.onGround ? (moving ? Math.sin(this.anim * 2.2) * 3.4 : 0) : 2.2;
    const breath = this.onGround && !moving ? Math.sin(this.idleTicks * 0.08) * 1.1 : 0;
    const airPitch = this.onGround ? 0 : Math.max(-0.08, Math.min(0.08, this.vy * 0.01));
    const tilt = this.dashTicks > 0 ? 0.18 : Math.max(-0.1, Math.min(0.1, this.vx * 0.015 * this.facing)) + airPitch;

    ctx.save();
    // Anchor squash/stretch cleanly to Fiona's feet
    ctx.translate(x + this.w / 2, y + this.h);
    ctx.scale(this.facing * this.scaleX, this.scaleY);
    ctx.rotate(tilt);
    ctx.translate(0, -this.h);

    // Subtle ground contact shadow when grounded or near floor
    if (this.onGround) {
      ctx.fillStyle = "rgba(5, 8, 22, 0.34)";
      ctx.beginPath();
      ctx.ellipse(0, 39, 13, 3.2, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    if (this.shieldTicks > 0) {
      ctx.save();
      const shieldPulse = 25 + Math.sin(this.idleTicks * 0.16) * 2;
      ctx.strokeStyle = "rgba(115, 240, 237, 0.78)";
      ctx.fillStyle = "rgba(115, 240, 237, 0.12)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 20, shieldPulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // Jetpack thruster glow during Star-Dash or mid-air rise
    if (this.dashTicks > 0 || (!this.onGround && this.vy < -1.5)) {
      const jetLen = this.dashTicks > 0 ? 15 : 8 + (Math.sin(this.idleTicks * 0.7) + 1) * 3;
      ctx.fillStyle = "rgba(115, 240, 237, 0.75)";
      ctx.beginPath();
      ctx.moveTo(-16, 28);
      ctx.lineTo(-10, 28);
      ctx.lineTo(-15 - jetLen * 0.4, 30 + jetLen);
      ctx.closePath();
      ctx.fill();
    }

    // Trailing hair ribbon wave
    const ribbonWave = Math.sin(this.idleTicks * 0.16 - this.anim) * 3;
    ctx.strokeStyle = "#ff77bd";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-10, 8 + breath * 0.5);
    ctx.quadraticCurveTo(-18 - Math.abs(this.vx) * 1.4, 11 + ribbonWave, -22 - Math.abs(this.vx) * 1.8, 17 + ribbonWave * 0.6);
    ctx.stroke();

    // Backpack with animated status light
    rounded(ctx, -17, 15 + breath * 0.6, 8, 17, 3, "#526b9d");
    ctx.fillStyle = this.dashCooldown <= 0 ? "#73f0ed" : "#ffd76d";
    ctx.fillRect(-15, 18 + breath * 0.6, 3, 3);

    // Hair & Head
    rounded(ctx, -12, -2 + breath * 0.8, 25, 13, 6, "#a65b43");
    rounded(ctx, -11, 4 + breath * 0.8, 22, 20, 7, "#ffd0ae");
    // Blinking expressive eye
    const blinking = this.idleTicks % 170 > 165;
    ctx.fillStyle = "#273052";
    if (blinking) ctx.fillRect(2, 12 + breath * 0.8, 4, 1.5);
    else ctx.fillRect(3, 11 + breath * 0.8, 3, 3.5);
    ctx.fillStyle = "#e88c78";
    ctx.fillRect(-3, 18 + breath * 0.8, 7, 2);

    // Jacket & animated boots
    const jacketColor = this.weapon === "plasma_lens" ? "#7b6ef6" : this.weapon === "sonic_burst" ? "#f5c25b" : "#54cbd0";
    rounded(ctx, -12, 22 + breath * 0.4, 24, 13, 4, jacketColor);
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    ctx.fillRect(-8, 24 + breath * 0.4, 16, 2);
    ctx.fillStyle = "#f2c66d";
    ctx.fillRect(-8 - stride, 34, 7, 5);
    ctx.fillRect(3 + stride, 34, 7, 5);

    // Articulated front blaster arm with recoil kickback & subtle run swing
    const recoil = this.muzzleTicks * 0.9;
    const armSwing = this.muzzleTicks > 0 ? 0 : -stride * 0.7;
    ctx.fillStyle = "#ffd0ae";
    ctx.fillRect(5 - recoil + armSwing * 0.4, 24 + breath * 0.4, 7, 4);
    ctx.fillStyle = "#2b3e6d";
    ctx.fillRect(10 - recoil + armSwing * 0.4, 22 + breath * 0.4, 7, 5);
    ctx.fillStyle = this.weapon === "plasma_lens" ? "#ff9be4" : this.weapon === "sonic_burst" ? "#f5d77b" : "#73f0ed";
    ctx.fillRect(15 - recoil + armSwing * 0.4, 23 + breath * 0.4, 3, 2);

    // Hair fringe
    ctx.fillStyle = "#b66b4b";
    ctx.beginPath();
    ctx.moveTo(-12, 6 + breath * 0.8);
    ctx.lineTo(-10, -3 + breath * 0.8);
    ctx.lineTo(5, -5 + breath * 0.8);
    ctx.lineTo(12, 4 + breath * 0.8);
    ctx.lineTo(3, 3 + breath * 0.8);
    ctx.lineTo(-3, 8 + breath * 0.8);
    ctx.closePath();
    ctx.fill();

    // Helmet visor gleam + periodic sheen sweep
    ctx.strokeStyle = "#a9f6ef";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 12 + breath * 0.8, 13, -0.25, Math.PI + 0.25);
    ctx.stroke();
    const sheenPhase = (this.idleTicks % 140) / 140;
    if (sheenPhase < 0.22) {
      const sAng = -0.15 + (sheenPhase / 0.22) * 1.2;
      ctx.strokeStyle = "rgba(255, 255, 255, 0.72)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(0, 12 + breath * 0.8, 11.2, sAng, sAng + 0.45);
      ctx.stroke();
    }

    // Sonic bow-wave crescent while Star-Dashing
    if (this.dashTicks > 0) {
      ctx.strokeStyle = "rgba(169, 246, 239, 0.82)";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(11, 20, 18, -0.95, 0.95);
      ctx.stroke();
    }

    if (this.muzzleTicks > 0) {
      const mColor = this.weapon === "plasma_lens" ? "#ff9be4" : this.weapon === "sonic_burst" ? "#f5d77b" : "#73f0ed";
      ctx.fillStyle = mColor;
      ctx.shadowColor = mColor;
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.ellipse(20 - recoil, 24, 8, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(18 - recoil, 24, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
    ctx.restore();
  }
}

export function hit(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function rounded(ctx, x, y, w, h, r, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();
}
