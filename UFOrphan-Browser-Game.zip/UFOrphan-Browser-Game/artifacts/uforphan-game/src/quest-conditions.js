/**
 * Small condition evaluator used by quests and gated world interactions.
 * Conditions are data, not executable strings.
 */
export function evaluateCondition(condition,context={}) {
  if(!condition||typeof condition!=="object")return false;
  switch(condition.type) {
    case "flag": return Boolean(readPath(context.flags,condition.key));
    case "counter": return Number(readPath(context.counters,condition.key)||0)>=Number(condition.value||0);
    case "item": return Number(readPath(context.inventory,condition.key)||0)>=Number(condition.count||1);
    case "level": return Number(context.level||0)>=Number(condition.value||0);
    case "all": return Array.isArray(condition.conditions)&&condition.conditions.every(c=>evaluateCondition(c,context));
    case "any": return Array.isArray(condition.conditions)&&condition.conditions.some(c=>evaluateCondition(c,context));
    case "not": return !evaluateCondition(condition.condition,context);
    default: return false;
  }
}
function readPath(object,path) {
  if(!object||typeof path!=="string")return undefined;
  return path.split(".").reduce((value,key)=>value&&value[key],object);
}
export function evaluateRewards(rewards=[],context={}) {
  const result={items:{},counters:{},flags:{}};
  for(const reward of rewards) {
    if(!reward||typeof reward.amount!=="number")continue;
    const target=result[reward.target];
    if(target)target[reward.key]=(target[reward.key]||0)+reward.amount;
  }
  return {...context,inventory:{...context.inventory,...result.items},
    counters:{...context.counters,...result.counters},flags:{...context.flags,...result.flags}};
}
