import { EXPANSION_LEVELS } from "./levels-expansion.js";
// Level layouts are authored as world-space rectangles to keep collision geometry readable.
const BASE_LEVELS = [
  {
    id:"backyard", name:"THE BACKYARD", chapter:"01", subtitle:"The night the sky opened",
    objective:"Find the signal beacon", width:2500, sky:["#111b42","#342b65"],
    platforms:[
      [0,480,580,60],[660,480,300,60],[1040,480,360,60],[1490,480,440,60],[2040,480,460,60],
      [250,390,150,18],[520,330,130,18],[780,390,140,18],[1110,350,150,18],[1370,300,150,18],
      [1660,390,150,18],[1910,330,150,18],[2180,390,150,18]
    ],
    stars:[[290,350],[570,290],[825,350],[1150,310],[1420,260],[1710,350],[1960,290],[2240,350]],
    keys:[[900,435]], enemies:[["slime",720,438],["drone",1260,310],["slime",1770,438]],
    hazards:[[600,480,60,60],[970,480,70,60],[1400,480,90,60],[1930,480,110,60]],
    checkpoint:[1490,420], exit:[2370,400], boss:null,
    dialogue:["Mum! Dad!","Fiona, if you can hear this, we're on the ship!","I can hear you. And I am coming."],
    background:"suburb"
  },
  {
    id:"moonbase", name:"MOON MALL", chapter:"02", subtitle:"A shopping centre with a dark side",
    objective:"Steal an access keycard", width:3000, sky:["#0b2340","#174d68"],
    platforms:[
      [0,480,450,60],[520,480,370,60],[970,480,430,60],[1470,480,400,60],[1940,480,400,60],[2410,480,590,60],
      [170,380,170,18],[430,320,160,18],[700,390,170,18],[1020,330,170,18],[1300,390,170,18],
      [1580,320,170,18],[1840,390,170,18],[2110,320,170,18],[2440,390,180,18],[2730,320,170,18]
    ],
    stars:[[220,340],[490,280],[750,350],[1070,290],[1350,350],[1630,280],[1890,350],[2160,280],[2490,350],[2780,280]],
    keys:[[1150,435],[2240,435]], enemies:[["drone",620,350],["slime",1120,438],["drone",1740,280],["slime",2510,438]],
    hazards:[[450,480,70,60],[900,480,70,60],[1400,480,70,60],[1870,480,70,60],[2340,480,70,60]],
    checkpoint:[1940,420], exit:[2860,400], boss:null,
    dialogue:["Welcome to Moon Mall!","Everything is 80% off. Including oxygen.","That is not how oxygen works."],
    background:"mall"
  },
  {
    id:"asteroid", name:"THE SCRAP BELT", chapter:"03", subtitle:"Nothing here is up to code",
    objective:"Reach the pirate cruiser", width:3300, sky:["#241735","#5b315d"],
    platforms:[
      [0,480,400,60],[470,480,310,60],[860,480,340,60],[1280,480,340,60],[1700,480,350,60],[2140,480,360,60],[2580,480,720,60],
      [150,370,150,18],[390,300,160,18],[670,370,150,18],[940,300,160,18],[1190,370,150,18],
      [1480,300,160,18],[1770,370,160,18],[2070,300,160,18],[2370,370,160,18],[2670,300,160,18],[2970,370,160,18]
    ],
    stars:[[190,330],[440,260],[720,330],[990,260],[1240,330],[1530,260],[1820,330],[2120,260],[2420,330],[2720,260],[3020,330]],
    keys:[[1030,435],[1880,435],[2790,435]], enemies:[["drone",560,300],["slime",920,438],["drone",1560,260],["slime",2220,438],["drone",2830,260]],
    hazards:[[400,480,70,60],[780,480,80,60],[1200,480,80,60],[1620,480,80,60],[2050,480,90,60],[2500,480,80,60]],
    checkpoint:[2140,420], exit:[3180,400], boss:null,
    dialogue:["Pirates. Of course.","The galaxy has a serious management problem.","First: rescue parents. Then: file a complaint."],
    background:"scrap"
  },
  {
    id:"mothership", name:"THE MOTHERSHIP", chapter:"04", subtitle:"Family reunion, with lasers",
    objective:"Defeat the abduction commander", width:2400, sky:["#17162d","#39234c"],
    platforms:[[0,480,600,60],[650,480,500,60],[1200,480,500,60],[1750,480,650,60],[260,370,170,18],[720,330,170,18],[1100,380,170,18],[1510,320,170,18],[1940,380,170,18]],
    stars:[[300,330],[770,290],[1150,340],[1560,280],[1990,340]],
    keys:[[950,435],[1800,435]], enemies:[["drone",500,350],["drone",1350,300],["slime",1840,438]],
    hazards:[[600,480,50,60],[1150,480,50,60],[1700,480,50,60]],
    checkpoint:[1200,420], exit:[2260,400], boss:{x:2070,y:365,health:8},
    dialogue:["Fiona! You made it!","I told you I would.","Okay, reunion after the giant space robot."],
    background:"ship"
  }
];

export const LEVELS = [...BASE_LEVELS, ...EXPANSION_LEVELS];
export const LEVEL_COUNT = LEVELS.length;
