export class CutsceneSystem {

    constructor(){
    this.active=null;
    this.queue=[];
    this.elapsed=0;
    this.onFinish=null;

  }

    play(scene,
  {
    onFinish=null
  }
  ={

  }
  ){
    if(this.active)this.queue.push(scene);
    else{
      this.active=scene;
      this.elapsed=0;
      this.onFinish=onFinish;

    }
    return this.active;

  }

    update(delta=1/60){
    if(!this.active)return null;
    this.elapsed+=delta;
    const duration=this.active.duration||3;
    if(this.elapsed>=duration)this.finish();
    return this.frame();

  }

    frame(){
    if(!this.active)return null;
    const progress=Math.min(1,
    this.elapsed/(this.active.duration||3));
    const beat=(this.active.beats||[]).find(item=>progress>=item.at&&progress<item.until);
    return {
      id:this.active.id,
      progress,
      caption:beat?.text||this.active.caption||"",
      speaker:beat?.speaker||null,
      fadeIn:Math.min(1,
      progress*4),
      fadeOut:Math.min(1,
      (1-progress)*4)
    }
    ;

  }

    finish(){
    if(!this.active)return;
    const finished=this.active;
    this.active=null;
    this.elapsed=0;
    this.onFinish?.(finished);
    this.onFinish=null;
    if(this.queue.length)this.play(this.queue.shift());

  }

    skip(){
    if(!this.active)return false;
    this.finish();
    return true;

  }

    isPlaying(){
    return Boolean(this.active);

  }


}

export const EXPANSION_CUTSCENES={

    first_contact:{
    id:"first_contact",
    duration:7,
    beats:[{
      at:0,
      until:.28,
      speaker:"FIONA",
      text:"That is definitely not a weather balloon."
    }
    ,
    {
      at:.28,
      until:.62,
      speaker:"MUM",
      text:"Fiona, get inside!"
    }
    ,
    {
      at:.62,
      until:1,
      speaker:"FIONA",
      text:"I am going to need a bigger ladder."
    }
    ]
  }
  ,

    signal_home:{
    id:"signal_home",
    duration:8,
    beats:[{
      at:0,
      until:.3,
      speaker:"MOTH-7",
      text:"Signal lock established."
    }
    ,
    {
      at:.3,
      until:.65,
      speaker:"DAD",
      text:"We can hear you, kiddo."
    }
    ,
    {
      at:.65,
      until:1,
      speaker:"FIONA",
      text:"I knew the old radio would work."
    }
    ]
  }


}
;
