/** Small dictionary-backed localization layer with placeholder interpolation. */
export const STRINGS={

   en:{
    "menu.start":"Start rescue",
    "menu.continue":"Continue",
    "menu.options":"Options",
    "game.pause":"Paused",
    "game.resume":"Resume",
    "game.restart":"Restart level",
    "game.back":"Main menu",
    "quest.active":"Active missions",
    "quest.complete":"Mission complete",
    "quest.new":"New mission",
    "inventory.title":"Field pack",
    "inventory.full":"Your pack is full",
    "npc.interact":"Press E to talk",
    "portal.locked":"Portal locked",
    "portal.ready":"Portal ready",
    "map.title":"Sector map",
    "craft.title":"Workbench",
    "save.ok":"Progress saved",
    "save.error":"Could not save progress"
  }
  ,

   fr:{
    "menu.start":"Commencer le sauvetage",
    "menu.continue":"Continuer",
    "menu.options":"Options",
    "game.pause":"En pause",
    "game.resume":"Reprendre",
    "game.restart":"Recommencer le niveau",
    "game.back":"Menu principal",
    "quest.active":"Missions actives",
    "quest.complete":"Mission terminée",
    "quest.new":"Nouvelle mission",
    "inventory.title":"Sac de terrain",
    "inventory.full":"Votre sac est plein",
    "npc.interact":"Appuyez sur E pour parler",
    "portal.locked":"Portail verrouillé",
    "portal.ready":"Portail prêt",
    "map.title":"Carte du secteur",
    "craft.title":"Établi",
    "save.ok":"Progression enregistrée",
    "save.error":"Impossible d'enregistrer"
  }
  ,

   es:{
    "menu.start":"Iniciar rescate",
    "menu.continue":"Continuar",
    "menu.options":"Opciones",
    "game.pause":"En pausa",
    "game.resume":"Reanudar",
    "game.restart":"Reiniciar nivel",
    "game.back":"Menú principal",
    "quest.active":"Misiones activas",
    "quest.complete":"Misión completada",
    "quest.new":"Nueva misión",
    "inventory.title":"Mochila",
    "inventory.full":"La mochila está llena",
    "npc.interact":"Pulsa E para hablar",
    "portal.locked":"Portal bloqueado",
    "portal.ready":"Portal listo",
    "map.title":"Mapa del sector",
    "craft.title":"Banco de trabajo",
    "save.ok":"Progreso guardado",
    "save.error":"No se pudo guardar"
  }


}
;

export class Localization {

    constructor(language="en"){
    this.language=STRINGS[language]?language:"en";

  }

    setLanguage(language){
    if(!STRINGS[language])return false;
    this.language=language;
    return true;

  }

    t(key,
  params={

  }
  ){
    let value=STRINGS[this.language][key]??STRINGS.en[key]??key;
    for(const [name,
    replacement] of Object.entries(params))value=value.replaceAll(`{${name}}`,
    String(replacement));
    return value;

  }

    available(){
    return Object.keys(STRINGS);

  }


}
