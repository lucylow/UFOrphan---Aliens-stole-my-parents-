/** Seeded, bounded side-room generator. Main story levels remain hand-authored. */
import {
   SeededRandom
}
 from "./loot-system.js";

export class SideRoomGenerator {

    constructor(seed=2026){
    this.random=new SeededRandom(seed);
    this.bounds={
      width:1800,
      height:540
    }
    ;

  }

    generate({
    rooms=6,
    difficulty=1,
    theme="scrap"
  }
  ={

  }
  ){
    const platforms=[[0,
    480,
    360,
    60]],
    stars=[],
    keys=[],
    hazards=[],
    enemies=[];
    let cursor=320;
    for(let i=0;
    i<rooms;
    i++){
      const gap=this.random.int(55,
      100),
      width=this.random.int(160,
      280),
      height=this.random.int(300,
      410);
      cursor+=gap;
      platforms.push([cursor,
      480,
      width,
      60]);
      if(i%2===0)platforms.push([cursor+35,
      height,
      width*.55,
      16]);
      stars.push([cursor+width*.35,
      height-40]);
      if(i%3===1)keys.push([cursor+width*.6,
      435]);
      if(i%2===1)hazards.push([cursor-25,
      480,
      25,
      60]);
      if(i%difficulty===0)enemies.push([i%2?"drone":"slime",
      cursor+width*.45,
      438]);
      cursor+=width;

    }
    platforms.push([cursor,
    480,
    380,
    60]);
    return {
      id:`side-${theme}-${this.random.seed}`,
      name:"UNMAPPED SIDE ROUTE",
      chapter:"SIDE",
      subtitle:"A procedurally assembled detour",
      objective:"Find the hidden cache",
      width:cursor+380,
      sky:["#101b38",
      "#3b315a"],
      platforms,
      stars,
      keys,
      enemies,
      hazards,
      checkpoint:[cursor*.55,
      420],
      exit:[cursor+300,
      400],
      boss:null,
      background:theme,
      generated:true
    }
    ;

  }

    validate(level){
    const errors=[];
    if(level.width>this.bounds.width*5)errors.push("room exceeds supported width");
    if(!level.platforms.length)errors.push("room has no platforms");
    if(!level.exit||level.exit[0]>=level.width)errors.push("exit is outside room");
    for(const [x,
    y,
    w,
    h] of level.platforms)if(w<=0||h<=0||x<0||y<0)errors.push("invalid platform geometry");
    return {
      valid:errors.length===0,
      errors
    }
    ;

  }

    setSeed(seed){
    this.random=new SeededRandom(seed);

  }


}
