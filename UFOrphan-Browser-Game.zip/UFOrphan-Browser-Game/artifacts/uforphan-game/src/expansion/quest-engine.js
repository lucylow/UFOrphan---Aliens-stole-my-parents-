import {
   EXPANSION_EVENTS,
   uid,
   deepClone
}
 from "./constants.js";

export const QUEST_STATUS=Object.freeze({
  LOCKED:"locked",
  AVAILABLE:"available",
  ACTIVE:"active",
  COMPLETED:"completed",
  FAILED:"failed"
}
);

export class QuestEngine {

    constructor(hub,
  definitions=[],
  saveData={

  }
  ){

        this.hub=hub;
    this.definitions=new Map();
    this.states=new Map();
    this.activeLimit=8;
    this.activeIds=[];

        this.registerMany(definitions);
    this.restore(saveData.quests||{

    }
    );


  }

    register(definition){

        if(!definition?.id)throw new Error("Quest definitions need a stable id");

        if(this.definitions.has(definition.id))throw new Error(`Duplicate quest: ${definition.id}`);

        const normalized={
      title:definition.id,
      description:"",
      objectives:[],
      prerequisites:[],
      rewards:[],
      repeatable:false,
      ...deepClone(definition)
    }
    ;

        normalized.objectives=normalized.objectives.map((objective,
    index)=>({
      id:objective.id||`${normalized.id}-objective-${index+1}`,
      description:"",
      target:1,
      progress:0,
      optional:false,
      ...objective
    }
    ));

        this.definitions.set(normalized.id,
    normalized);

        this.states.set(normalized.id,
    {
      status:this.isUnlocked(normalized.id)?QUEST_STATUS.AVAILABLE:QUEST_STATUS.LOCKED,
      startedAt:null,
      completedAt:null,
      objectives:{

      }
      ,
      timesCompleted:0
    }
    );

        return normalized;


  }

    registerMany(definitions){
    for(const definition of definitions)this.register(definition);

  }

    isUnlocked(id){
    const quest=this.definitions.get(id);
    if(!quest)return false;
    return quest.prerequisites.every(required=>this.states.get(required)?.status===QUEST_STATUS.COMPLETED);

  }

    refreshAvailability(){
    for(const [id,
    state] of this.states)if(state.status===QUEST_STATUS.LOCKED&&this.isUnlocked(id))state.status=QUEST_STATUS.AVAILABLE;

  }

    start(id){
    const quest=this.definitions.get(id),
    state=this.states.get(id);
    if(!quest||!state)return {
      ok:false,
      reason:"unknown"
    }
    ;
    if(state.status===QUEST_STATUS.LOCKED)return {
      ok:false,
      reason:"locked"
    }
    ;
    if(state.status===QUEST_STATUS.ACTIVE)return {
      ok:false,
      reason:"active"
    }
    ;
    if(state.status===QUEST_STATUS.COMPLETED&&!quest.repeatable)return {
      ok:false,
      reason:"completed"
    }
    ;
    if(this.activeIds.length>=this.activeLimit)return {
      ok:false,
      reason:"limit"
    }
    ;

        state.status=QUEST_STATUS.ACTIVE;
    state.startedAt=Date.now();
    state.completedAt=null;
    state.objectives={

    }
    ;
    for(const objective of quest.objectives)state.objectives[objective.id]=0;
    if(!this.activeIds.includes(id))this.activeIds.push(id);
    this.hub?.emit(EXPANSION_EVENTS.QUEST_STARTED,
    {
      id,
      title:quest.title
    }
    );
    return {
      ok:true,
      quest
    }
    ;

  }

    updateObjective(questId,
  objectiveId,
  amount=1){
    const quest=this.definitions.get(questId),
    state=this.states.get(questId);
    if(!quest||!state||state.status!==QUEST_STATUS.ACTIVE)return false;
    const objective=quest.objectives.find(item=>item.id===objectiveId);
    if(!objective)return false;
    const next=Math.max(0,
    Math.min(objective.target,
    (state.objectives[objectiveId]||0)+amount));
    state.objectives[objectiveId]=next;
    this.hub?.emit(EXPANSION_EVENTS.QUEST_UPDATED,
    {
      questId,
      objectiveId,
      progress:next,
      target:objective.target
    }
    );
    if(this.isReady(questId))this.complete(questId);
    return true;

  }

    addProgressByTag(tag,
  amount=1){
    let changed=0;
    for(const id of this.activeIds){
      const quest=this.definitions.get(id);
      for(const objective of quest.objectives)if(objective.tag===tag){
        if(this.updateObjective(id,
        objective.id,
        amount))changed++;

      }

    }
    return changed;

  }

    isReady(id){
    const quest=this.definitions.get(id),
    state=this.states.get(id);
    return Boolean(quest&&state&&quest.objectives.filter(o=>!o.optional).every(o=>(state.objectives[o.id]||0)>=o.target));

  }

    complete(id){
    const quest=this.definitions.get(id),
    state=this.states.get(id);
    if(!quest||!state||state.status!==QUEST_STATUS.ACTIVE||!this.isReady(id))return false;
    state.status=QUEST_STATUS.COMPLETED;
    state.completedAt=Date.now();
    state.timesCompleted++;
    this.activeIds=this.activeIds.filter(item=>item!==id);
    this.hub?.emit(EXPANSION_EVENTS.QUEST_COMPLETED,
    {
      id,
      title:quest.title,
      rewards:quest.rewards
    }
    );
    this.refreshAvailability();
    return true;

  }

    fail(id,
  reason="failed"){
    const state=this.states.get(id);
    if(!state||state.status!==QUEST_STATUS.ACTIVE)return false;
    state.status=QUEST_STATUS.FAILED;
    this.activeIds=this.activeIds.filter(item=>item!==id);
    this.hub?.emit("quest:failed",
    {
      id,
      reason
    }
    );
    return true;

  }

    abandon(id){
    const state=this.states.get(id);
    if(!state||state.status!==QUEST_STATUS.ACTIVE)return false;
    state.status=QUEST_STATUS.AVAILABLE;
    this.activeIds=this.activeIds.filter(item=>item!==id);
    return true;

  }

    get(id){
    const definition=this.definitions.get(id),
    state=this.states.get(id);
    if(!definition||!state)return null;
    return {
      ...deepClone(definition),
      state:deepClone(state)
    }
    ;

  }

    list(status=null){
    return [...this.definitions.keys()].map(id=>this.get(id)).filter(quest=>!status||quest.state.status===status);

  }

    active(){
    return this.activeIds.map(id=>this.get(id)).filter(Boolean);

  }

    objectiveSummary(id){
    const quest=this.get(id);
    if(!quest)return [];
    return quest.objectives.map(objective=>({
      ...objective,
      progress:quest.state.objectives[objective.id]||0,
      done:(quest.state.objectives[objective.id]||0)>=objective.target
    }
    ));

  }

    serialize(){
    return Object.fromEntries([...this.states].map(([id,
    state])=>[id,
    deepClone(state)]));

  }

    restore(saved){
    for(const [id,
    state] of Object.entries(saved)){
      if(!this.states.has(id))continue;
      this.states.set(id,
      {
        ...this.states.get(id),
        ...deepClone(state)
      }
      );

    }
    this.activeIds=[...this.states].filter(([,
    state])=>state.status===QUEST_STATUS.ACTIVE).map(([id])=>id).slice(0,
    this.activeLimit);
    this.refreshAvailability();

  }


}

export const STORY_QUESTS=[
  {
  id:"signal_in_the_static",
  title:"Signal in the Static",
  description:"Trace the strange broadcast coming from the abandoned relay.",
  objectives:[{
    id:"scan_beacons",
    description:"Activate relay beacons",
    tag:"beacon",
    target:3
  }
  ,
  {
    id:"find_transmitter",
    description:"Recover the transmitter",
    tag:"transmitter",
    target:1
  }
  ],
  rewards:[{
    item:"relay_chip",
    count:2
  }
  ,
  {
    credits:80
  }
  ]
}
,

  {
  id:"mall_cop_duty",
  title:"Mall Cop Duty",
  description:"Help the moon mall's exhausted security bot restore order.",
  objectives:[{
    id:"disable_drones",
    description:"Disable rogue drones",
    tag:"drone_disabled",
    target:4
  }
  ,
  {
    id:"return_badge",
    description:"Return the security badge",
    tag:"badge_returned",
    target:1
  }
  ],
  rewards:[{
    item:"ion_cell",
    count:3
  }
  ]
}
,

  {
  id:"scrap_symphony",
  title:"Scrap Symphony",
  description:"Gather parts for a pirate mechanic's impossible instrument.",
  objectives:[{
    id:"collect_coils",
    description:"Find copper coils",
    tag:"coil",
    target:5
  }
  ,
  {
    id:"collect_crystals",
    description:"Find resonant crystals",
    tag:"crystal",
    target:2
  }
  ],
  rewards:[{
    item:"sonic_module",
    count:1
  }
  ]
}
,

  {
  id:"family_frequency",
  title:"Family Frequency",
  description:"Rebuild the signal that will guide Fiona's parents home.",
  prerequisites:["signal_in_the_static",
  "mall_cop_duty",
  "scrap_symphony"],
  objectives:[{
    id:"align_dishes",
    description:"Align the three antenna dishes",
    tag:"dish_aligned",
    target:3
  }
  ,
  {
    id:"send_signal",
    description:"Transmit the rescue signal",
    tag:"signal_sent",
    target:1
  }
  ],
  rewards:[{
    item:"family_photo",
    count:1
  }
  ]
}

];
