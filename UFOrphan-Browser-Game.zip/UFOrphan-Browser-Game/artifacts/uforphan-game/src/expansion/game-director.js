import {
   clamp
}
 from "./constants.js";

/** Lightweight pacing director: changes pressure without spawning unfair surprises. */
export class GameDirector {

    constructor(){
    this.threat=0;
    this.targetThreat=.25;
    this.stress=0;
    this.quietTimer=0;
    this.lastEncounter=0;
    this.encounterCount=0;
    this.history=[];

  }

    update(player,
  world){
    const healthRatio=player.health/player.maxHealth;
    const enemyPressure=world.enemies.length+(world.boss&&!world.boss.dead?2:0);
    const target=clamp(enemyPressure*.09+(1-healthRatio)*.35,
    .08,
    .85);
    this.targetThreat=target;
    this.threat+=(target-this.threat)*.015;
    this.stress=clamp(this.stress+(this.threat-.3)*.003,
    0,
    1);
    if(enemyPressure===0)this.quietTimer++;
    else this.quietTimer=0;

  }

    shouldSpawnEncounter(time){
    if(this.quietTimer<480||time-this.lastEncounter<900)return false;
    this.lastEncounter=time;
    this.quietTimer=0;
    this.encounterCount++;
    return this.stress<.8;

  }

    recommend(){
    if(this.stress>.7)return {
      type:"rest",
      message:"A quiet stretch ahead. Take a breath."
    }
    ;
    if(this.threat>.6)return {
      type:"warning",
      message:"Movement detected nearby."
    }
    ;
    if(this.quietTimer>240)return {
      type:"explore",
      message:"There may be something tucked off the main route."
    }
    ;
    return null;

  }

    record(event){
    this.history.push({
      event,
      time:Date.now(),
      threat:this.threat
    }
    );
    if(this.history.length>100)this.history.shift();

  }

    difficultyScale(base="normal"){
    const baseScale={
      story:.75,
      easy:.85,
      normal:1,
      hard:1.2,
      cosmic:1.4
    }
    [base]||1;
    return baseScale*(.85+this.threat*.3);

  }

    snapshot(){
    return {
      threat:this.threat,
      stress:this.stress,
      quietTimer:this.quietTimer,
      encounterCount:this.encounterCount
    }
    ;

  }

    restore(data={

  }
  ){
    this.threat=data.threat||0;
    this.stress=data.stress||0;
    this.quietTimer=data.quietTimer||0;
    this.encounterCount=data.encounterCount||0;

  }


}
