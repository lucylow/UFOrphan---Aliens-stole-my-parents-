/** Branching dialogue graph with guarded choices and consequence callbacks. */
export class DialogueGraph {

    constructor(nodes=[]){
    this.nodes=new Map(nodes.map(node=>[node.id,
    {
      ...node
    }
    ]));
    this.current=null;
    this.history=[];
    this.variables={

    }
    ;
    this.ended=false;

  }

    add(node){
    if(!node?.id||this.nodes.has(node.id))throw new Error("Dialogue node id must be unique");
    this.nodes.set(node.id,
    {
      choices:[],
      ...node
    }
    );
    return this;

  }

    start(id,
  context={

  }
  ){
    if(!this.nodes.has(id))return null;
    this.current=id;
    this.ended=false;
    this.history=[];
    this.context=context;
    return this.node();

  }

    node(){
    const node=this.nodes.get(this.current);
    if(!node)return null;
    return {
      ...node,
      choices:node.choices.filter(choice=>!choice.when||choice.when(this.context,
      this.variables))
    }
    ;

  }

    choose(index){
    const node=this.nodes.get(this.current);
    if(!node)return {
      ok:false,
      reason:"no-dialogue"
    }
    ;
    const choices=node.choices.filter(choice=>!choice.when||choice.when(this.context,
    this.variables));
    const choice=choices[index];
    if(!choice)return {
      ok:false,
      reason:"invalid-choice"
    }
    ;
    this.history.push({
      node:this.current,
      choice:choice.id||index
    }
    );
    choice.effect?.(this.context,
    this.variables);
    if(!choice.next){
      this.ended=true;
      this.current=null;
      return {
        ok:true,
        ended:true,
        choice
      }
      ;

    }
    if(!this.nodes.has(choice.next))return {
      ok:false,
      reason:"missing-node"
    }
    ;
    this.current=choice.next;
    return {
      ok:true,
      ended:false,
      node:this.node(),
      choice
    }
    ;

  }

    set(key,
  value){
    this.variables[key]=value;
    return value;

  }

    get(key,
  fallback=null){
    return this.variables[key]??fallback;

  }

    serialize(){
    return {
      current:this.current,
      history:this.history,
      variables:this.variables,
      ended:this.ended
    }
    ;

  }

    restore(data={

  }
  ){
    this.current=this.nodes.has(data.current)?data.current:null;
    this.history=data.history||[];
    this.variables={
      ...(data.variables||{

      }
      )
    }
    ;
    this.ended=Boolean(data.ended);

  }


}

export const PIP_DIALOGUE=[
 {
  id:"hello",
  speaker:"Pip",
  text:"Welcome to Moon Mall. Please enjoy our complimentary atmosphere.",
  choices:[{
    id:"badge",
    text:"Ask about your badge.",
    next:"badge_story"
  }
  ,
  {
    id:"help",
    text:"Can I help you?",
    next:"help"
  }
  ,
  {
    id:"bye",
    text:"Good luck out there.",
    next:null
  }
  ]
}
,

 {
  id:"badge_story",
  speaker:"Pip",
  text:"I misplaced it during the Great Pretzel Incident. It is somewhere near the loading bay.",
  choices:[{
    id:"accept",
    text:"I'll look for it.",
    next:"accept_badge"
  }
  ,
  {
    id:"back",
    text:"Anything else?",
    next:"hello"
  }
  ]
}
,

 {
  id:"accept_badge",
  speaker:"Pip",
  text:"A thousand thank-yous. Or at least one thousand tiny beeps.",
  choices:[{
    text:"See you soon.",
    next:null
  }
  ]
}
,

 {
  id:"help",
  speaker:"Pip",
  text:"Disable the rogue drones. They have been enforcing a very strict no-fun policy.",
  choices:[{
    text:"On it.",
    next:null
  }
  ]
}

];

export class DialogueLibrary {

    constructor(){
    this.graphs=new Map();
    this.flags=new Set();

  }

    register(id,
  nodes){
    this.graphs.set(id,
    new DialogueGraph(nodes));

  }

    begin(id,
  node="hello",
  context={

  }
  ){
    const graph=this.graphs.get(id);
    return graph?graph.start(node,
    context):null;

  }

    setFlag(flag){
    this.flags.add(flag);

  }

    hasFlag(flag){
    return this.flags.has(flag);

  }

    serialize(){
    return {
      flags:[...this.flags],
      graphs:Object.fromEntries([...this.graphs].map(([id,
      graph])=>[id,
      graph.serialize()]))
    }
    ;

  }

    restore(data={

  }
  ){
    this.flags=new Set(data.flags||[]);
    for(const [id,
    state] of Object.entries(data.graphs||{

    }
    ))this.graphs.get(id)?.restore(state);

  }


}
