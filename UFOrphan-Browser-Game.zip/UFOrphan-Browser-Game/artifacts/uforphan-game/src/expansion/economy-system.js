/** Simple credit wallet, shop stock, and transaction history. */
export const SHOP_STOCK=[
 {
  id:"med_patch",
  price:35,
  stock:8
}
,
{
  id:"shield_bubble",
  price:65,
  stock:4
}
,
{
  id:"ion_cell",
  price:18,
  stock:30
}
,

 {
  id:"copper_coil",
  price:22,
  stock:25
}
,
{
  id:"resonant_crystal",
  price:80,
  stock:8
}
,
{
  id:"relay_chip",
  price:55,
  stock:12
}

];

export class EconomySystem {

    constructor(inventory,
  saved={

  }
  ){
    this.inventory=inventory;
    this.credits=saved.credits??100;
    this.stock=new Map(SHOP_STOCK.map(item=>[item.id,
    {
      ...item
    }
    ]));
    this.history=saved.history||[];
    this.discount=saved.discount||0;

  }

    earn(amount,
  reason="mission"){
    if(amount<=0)return false;
    this.credits+=Math.floor(amount);
    this.history.push({
      type:"earn",
      amount:Math.floor(amount),
      reason,
      at:Date.now()
    }
    );
    return true;

  }

    price(id){
    const item=this.stock.get(id);
    return item?Math.max(1,
    Math.floor(item.price*(1-this.discount))):null;

  }

    buy(id,
  count=1){
    const item=this.stock.get(id);
    if(!item||count<1||item.stock<count)return {
      ok:false,
      reason:"out-of-stock"
    }
    ;
    const cost=this.price(id)*count;
    if(this.credits<cost)return {
      ok:false,
      reason:"not-enough-credits"
    }
    ;
    const result=this.inventory.add(id,
    count);
    if(result.added!==count){
      if(result.added)this.inventory.remove(id,
      result.added);
      return {
        ok:false,
        reason:"inventory-full"
      }
      ;

    }
    this.credits-=cost;
    item.stock-=count;
    this.history.push({
      type:"buy",
      id,
      count,
      cost,
      at:Date.now()
    }
    );
    return {
      ok:true,
      id,
      count,
      cost,
      balance:this.credits
    }
    ;

  }

    sell(id,
  count=1){
    const item=this.inventory.definition(id);
    if(!this.inventory.has(id,
    count))return {
      ok:false,
      reason:"missing"
    }
    ;
    if(["quest",
    "key"].includes(item.type))return {
      ok:false,
      reason:"protected-item"
    }
    ;
    const value=Math.max(1,
    Math.floor((this.price(id)||20)*.45))*count;
    this.inventory.remove(id,
    count);
    this.credits+=value;
    this.history.push({
      type:"sell",
      id,
      count,
      value,
      at:Date.now()
    }
    );
    return {
      ok:true,
      value,
      balance:this.credits
    }
    ;

  }

    setDiscount(value){
    this.discount=Math.max(0,
    Math.min(.5,
    value));

  }

    serialize(){
    return {
      credits:this.credits,
      stock:[...this.stock.values()],
      history:this.history.slice(-100),
      discount:this.discount
    }
    ;

  }

    restore(data={

  }
  ){
    this.credits=data.credits??this.credits;
    for(const item of data.stock||[])if(this.stock.has(item.id))this.stock.set(item.id,
    {
      ...this.stock.get(item.id),
      stock:item.stock
    }
    );
    this.history=data.history||[];
    this.discount=data.discount||0;

  }


}
