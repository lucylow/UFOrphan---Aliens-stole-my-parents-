/** World events provide timed objectives and ambient narrative beats. */
export const WORLD_EVENTS=[
 {
  id:"meteor_shower",
  title:"Meteor Shower",
  duration:18,
  trigger:"timer",
  effect:"meteors",
  cooldown:120
}
,

 {
  id:"supply_pod",
  title:"Supply Pod",
  duration:25,
  trigger:"exploration",
  effect:"cache",
  cooldown:180
}
,

 {
  id:"alien_patrol",
  title:"Alien Patrol",
  duration:20,
  trigger:"threat",
  effect:"patrol",
  cooldown:150
}
,

 {
  id:"aurora",
  title:"Crystal Aurora",
  duration:30,
  trigger:"region",
  effect:"visual",
  cooldown:240
}

];

export class WorldEventSystem {

    constructor(hub){
    this.hub=hub;
    this.active=null;
    this.cooldowns=new Map();
    this.elapsed=0;
    this.completed=[];

  }

    start(id){
    const event=WORLD_EVENTS.find(item=>item.id===id);
    if(!event||this.active||(this.cooldowns.get(id)||0)>0)return false;
    this.active={
      ...event,
      remaining:event.duration
    }
    ;
    this.elapsed=0;
    this.hub?.emit("world-event:started",
    {
      id,
      title:event.title
    }
    );
    return true;

  }

    update(delta=1/60){
    for(const [id,
    time] of this.cooldowns)this.cooldowns.set(id,
    Math.max(0,
    time-delta));
    if(!this.active)return null;
    this.active.remaining-=delta;
    this.elapsed+=delta;
    if(this.active.remaining<=0){
      const finished=this.active;
      this.completed.push(finished.id);
      this.cooldowns.set(finished.id,
      finished.cooldown);
      this.active=null;
      this.hub?.emit("world-event:ended",
      {
        id:finished.id
      }
      );
      return finished;

    }
    return this.active;

  }

    chooseForContext(context={

  }
  ){
    if(this.active)return null;
    const candidate=WORLD_EVENTS.find(event=>{
      if((this.cooldowns.get(event.id)||0)>0)return false;
      if(event.trigger==="timer")return context.time>180;
      if(event.trigger==="threat")return context.threat>.6;
      if(event.trigger==="exploration")return context.explored>0.5;
      if(event.trigger==="region")return context.region==="crystal";
      return false;

    }
    );
    return candidate?.id||null;

  }

    draw(ctx){
    if(!this.active)return;
    ctx.save();
    ctx.fillStyle="rgba(12,20,48,.65)";
    ctx.fillRect(340,
    18,
    280,
    36);
    ctx.fillStyle="#ffe19a";
    ctx.font="bold 14px sans-serif";
    ctx.textAlign="center";
    ctx.fillText(this.active.title,
    480,
    41);
    ctx.restore();

  }

    serialize(){
    return {
      completed:this.completed.slice(),
      cooldowns:[...this.cooldowns]
    }
    ;

  }

    restore(data={

  }
  ){
    this.completed=data.completed||[];
    this.cooldowns=new Map(data.cooldowns||[]);

  }


}
