import {
   uid
}
 from "./constants.js";

/** Small deterministic event hub used by the expansion's independent systems. */
export class EventHub {

    constructor(){
    this.listeners=new Map();
    this.history=[];
    this.maxHistory=200;
    this.dispatchDepth=0;

  }

    on(type,
  handler,
  options={

  }
  ){

        if(typeof handler!=="function")throw new TypeError("Event handler must be a function");

        const entry={
      id:uid("listener"),
      handler,
      once:Boolean(options.once),
      priority:Number(options.priority)||0,
      active:true
    }
    ;

        const list=this.listeners.get(type)||[];
    list.push(entry);
    list.sort((a,
    b)=>b.priority-a.priority);
    this.listeners.set(type,
    list);

        return ()=>this.off(type,
    entry.id);


  }

    once(type,
  handler,
  options={

  }
  ){
    return this.on(type,
    handler,
    {
      ...options,
      once:true
    }
    );

  }

    off(type,
  id){
    const list=this.listeners.get(type);
    if(!list)return false;
    const entry=list.find(item=>item.id===id);
    if(!entry)return false;
    entry.active=false;
    this.listeners.set(type,
    list.filter(item=>item.active));
    return true;

  }

    emit(type,
  payload={

  }
  ,
  meta={

  }
  ){

        const event={
      id:uid("event"),
      type,
      payload,
      time:meta.time??Date.now(),
      cancelled:false,
      stopPropagation:false
    }
    ;

        this.history.push({
      id:event.id,
      type,
      payload,
      time:event.time
    }
    );
    if(this.history.length>this.maxHistory)this.history.shift();

        const snapshot=[...(this.listeners.get(type)||[])];
    this.dispatchDepth++;

        try{
      for(const entry of snapshot){
        if(!entry.active)continue;
        entry.handler(event);
        if(entry.once)this.off(type,
        entry.id);
        if(event.stopPropagation)break;

      }

    }

        finally{
      this.dispatchDepth--;

    }

        return event;


  }

    clear(type){
    if(type)this.listeners.delete(type);
    else this.listeners.clear();

  }

    listenerCount(type){
    return type?(this.listeners.get(type)||[]).length:[...this.listeners.values()].reduce((sum,
    list)=>sum+list.length,
    0);

  }

    recent(type,
  count=20){
    const events=type?this.history.filter(event=>event.type===type):this.history;
    return events.slice(-count);

  }

    waitFor(type,
  predicate=()=>true,
  timeout=0){
    return new Promise((resolve,
    reject)=>{
      let timer=null;
      const off=this.on(type,
      event=>{
        if(!predicate(event.payload))return;
        off();
        if(timer)clearTimeout(timer);
        resolve(event);

      }
      );
      if(timeout>0)timer=setTimeout(()=>{
        off();
        reject(new Error(`Timed out waiting for ${type}`));

      }
      ,
      timeout);

    }
    );

  }


}

export class EventTransaction {

    constructor(hub,
  label="transaction"){
    this.hub=hub;
    this.label=label;
    this.events=[];
    this.closed=false;

  }

    emit(type,
  payload){
    if(this.closed)throw new Error("Transaction is closed");
    this.events.push({
      type,
      payload
    }
    );
    return this;

  }

    commit(){
    if(this.closed)return false;
    this.closed=true;
    for(const event of this.events)this.hub.emit(event.type,
    {
      ...event.payload,
      transaction:this.label
    }
    );
    return true;

  }

    rollback(){
    if(this.closed)return false;
    this.events.length=0;
    this.closed=true;
    return true;

  }


}

export function createEventBridge(hub,
handlers={

}
){

    const disposers=[];

    for(const [type,
  handler] of Object.entries(handlers))disposers.push(hub.on(type,
  handler));

    return ()=>disposers.splice(0).forEach(dispose=>dispose());


}
