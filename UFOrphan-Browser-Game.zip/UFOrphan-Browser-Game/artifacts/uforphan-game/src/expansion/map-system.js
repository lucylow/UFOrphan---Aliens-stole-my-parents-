import {
   EXPANSION_EVENTS
}
 from "./constants.js";

export class MapSystem {

    constructor(hub,
  level){
    this.hub=hub;
    this.width=level.width;
    this.height=540;
    this.markers=[];
    this.discovered=new Set();
    this.pins=[];
    this.player={
      x:0,
      y:0
    }
    ;
    this.buildFromLevel(level);

  }

    buildFromLevel(level){
    this.markers.push({
      id:"start",
      type:"start",
      x:40,
      y:450,
      label:"Landing zone"
    }
    );
    this.markers.push({
      id:"exit",
      type:"exit",
      x:level.exit[0],
      y:level.exit[1],
      label:"Exit portal"
    }
    );
    for(let i=0;
    i<level.keys.length;
    i++)this.markers.push({
      id:`key-${i}`,
      type:"key",
      x:level.keys[i][0],
      y:level.keys[i][1],
      label:`Keycard ${i+1}`
    }
    );
    if(level.checkpoint)this.markers.push({
      id:"checkpoint",
      type:"checkpoint",
      x:level.checkpoint[0],
      y:level.checkpoint[1],
      label:"Checkpoint"
    }
    );

  }

    update(player){
    this.player={
      x:player.x+player.w/2,
      y:player.y+player.h/2
    }
    ;
    for(const marker of this.markers){
      if(Math.hypot(marker.x-this.player.x,
      marker.y-this.player.y)<220&&!this.discovered.has(marker.id)){
        this.discovered.add(marker.id);
        this.hub?.emit("map:discovered",
        {
          id:marker.id,
          type:marker.type
        }
        );

      }

    }

  }

    addMarker(marker){
    if(!marker.id||this.markers.some(item=>item.id===marker.id))return false;
    this.markers.push({
      ...marker
    }
    );
    return true;

  }

    pin(x,
  y,
  label="Custom marker"){
    const pin={
      id:`pin-${this.pins.length+1}`,
      x,
      y,
      label
    }
    ;
    this.pins.push(pin);
    return pin;

  }

    removePin(id){
    const index=this.pins.findIndex(pin=>pin.id===id);
    if(index<0)return false;
    this.pins.splice(index,
    1);
    return true;

  }

    visibleMarkers(){
    return this.markers.filter(marker=>this.discovered.has(marker.id)||marker.type==="start");

  }

    miniMapState(viewWidth=220){
    const scale=viewWidth/this.width;
    return {
      width:viewWidth,
      height:this.height*scale,
      scale,
      player:{
        x:this.player.x*scale,
        y:this.player.y*scale
      }
      ,
      markers:this.visibleMarkers().map(marker=>({
        ...marker,
        x:marker.x*scale,
        y:marker.y*scale
      }
      ))
    }
    ;

  }

    serialize(){
    return {
      discovered:[...this.discovered],
      pins:this.pins.slice()
    }
    ;

  }

    restore(data={

  }
  ){
    this.discovered=new Set(data.discovered||[]);
    this.pins=data.pins||[];

  }


}
