export const EXPANSION_VERSION = "2.0.0";

export const EXPANSION_SAVE_KEY = "uforphan-expansion-v2";

export const EXPANSION_EVENTS = Object.freeze({

    QUEST_STARTED:"quest:started",
   QUEST_UPDATED:"quest:updated",
   QUEST_COMPLETED:"quest:completed",

    ITEM_ADDED:"item:added",
   ITEM_REMOVED:"item:removed",
   CRAFTED:"item:crafted",

    NPC_MET:"npc:met",
   SECRET_FOUND:"secret:found",
   REGION_ENTERED:"region:entered",

    BOSS_PHASE:"boss:phase",
   CHALLENGE_STARTED:"challenge:started",
   CHALLENGE_ENDED:"challenge:ended",

    CHECKPOINT:"world:checkpoint",
   LEVEL_FINISHED:"level:finished"

}
);

export const ITEM_RARITY = Object.freeze({
  common:1,
  uncommon:2,
  rare:3,
  epic:4,
  legendary:5
}
);

export const ITEM_TYPES = Object.freeze(["material",
"consumable",
"key",
"upgrade",
"quest",
"collectible"]);

export const DAMAGE_TYPES = Object.freeze(["kinetic",
"plasma",
"cryo",
"sonic",
"electric",
"void"]);

export const BIOMES = Object.freeze(["frontier",
"orbital",
"industrial",
"crystal",
"organic",
"command"]);

export const DEFAULT_EXPANSION_SETTINGS = Object.freeze({

    hints:true,
   screenShake:true,
   damageNumbers:true,
   reducedFlashes:false,

    subtitles:true,
   autoSave:true,
   difficulty:"normal",
   showQuestMarkers:true

}
);

export const clamp=(value,
min,
max)=>Math.max(min,
Math.min(max,
value));

export const distance=(a,
b)=>Math.hypot((a.x||0)-(b.x||0),
(a.y||0)-(b.y||0));

export const intersects=(a,
b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;

export const deepClone=value=>JSON.parse(JSON.stringify(value));

export const uid=(prefix="id")=>`${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
