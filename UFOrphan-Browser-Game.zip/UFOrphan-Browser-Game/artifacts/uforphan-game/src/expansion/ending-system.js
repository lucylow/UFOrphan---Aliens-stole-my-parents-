/** Tracks story branches and resolves one of three optional epilogues. */
export class EndingSystem {

    constructor(saved={

  }
  ){
    this.flags={
      ...(saved.flags||{

      }
      )
    }
    ;
    this.choice=saved.choice||null;
    this.resolved=false;

  }

    setFlag(id,
  value=true){
    this.flags[id]=Boolean(value);

  }

    choose(id){
    if(this.resolved)return false;
    if(!["home",
    "wander",
    "repair"].includes(id))return false;
    this.choice=id;
    this.resolved=true;
    return true;

  }

    resolve(stats={

  }
  ){
    if(this.choice==="home")return {
      title:"Home, At Last",
      text:"Fiona brings her parents home. The minivan is still in orbit, but the family is together."
    }
    ;
    if(this.choice==="wander")return {
      title:"One More Horizon",
      text:"The family decides to explore the stars together. They make a very strict rule about tractor beams."
    }
    ;
    if(this.choice==="repair")return {
      title:"A Galaxy Repaired",
      text:"Fiona helps the rescued crew rebuild the relay network so no family gets lost again."
    }
    ;
    return stats.secretsFound>5?{
      title:"The Hidden Frequency",
      text:"A forgotten signal reveals a second mystery waiting beyond the mapped galaxy."
    }
    :{
      title:"A Quiet Orbit",
      text:"The ship drifts toward home, carrying stories that will take years to tell."
    }
    ;

  }

    serialize(){
    return {
      flags:{
        ...this.flags
      }
      ,
      choice:this.choice,
      resolved:this.resolved
    }
    ;

  }

    restore(data={

  }
  ){
    this.flags={
      ...(data.flags||{

      }
      )
    }
    ;
    this.choice=data.choice||null;
    this.resolved=Boolean(data.resolved);

  }


}
