import {
   EXPANSION_EVENTS,
   distance,
   uid
}
 from "./constants.js";

export const NPC_CATALOG={

    pip:{
    name:"Pip",
    role:"retired security bot",
    color:"#83e9df",
    radius:64,
    lines:["Please do not run in the mall. The floor is lava. Metaphorically.",
    "I used to guard the food court. I miss the pretzels.",
    "If you find my badge, I can open the maintenance lift."],
    quest:"mall_cop_duty"
  }
  ,

    rivet:{
    name:"Rivet",
    role:"pirate mechanic",
    color:"#e8a46f",
    radius:70,
    lines:["I can fix anything. Except my reputation.",
    "Copper coils, crystals, and a little optimism. That's my recipe.",
    "The scrap belt has a shortcut behind the broken engine."],
    quest:"scrap_symphony"
  }
  ,

    moth:{
    name:"MOTH-7",
    role:"runaway navigation drone",
    color:"#b99aff",
    radius:62,
    lines:["My directive says capture. My conscience says absolutely not.",
    "The command deck has three shield relays. Disable them first.",
    "I have hidden a map fragment in the ventilation shaft."],
    quest:"signal_in_the_static"
  }
  ,

    noa:{
    name:"Noa",
    role:"crystal gardener",
    color:"#a9e58a",
    radius:66,
    lines:["These crystals grow toward music. It is very inconvenient.",
    "Please take care around the singing vines.",
    "The old antenna can be tuned from the ridge."],
    quest:"family_frequency"
  }


}
;

export class NPCSystem {

    constructor(hub,
  definitions=[]){
    this.hub=hub;
    this.npcs=definitions.map((definition,
    index)=>({
      id:definition.id||uid("npc"),
      ...definition,
      radius:definition.radius||(NPC_CATALOG[definition.kind]||NPC_CATALOG.pip).radius,
      phase:index*.9,
      met:false,
      dialogueIndex:0,
      available:true
    }
    ));
    this.nearby=null;
    this.lastInteraction=0;

  }

    update(player){
    this.nearby=null;
    let best=Infinity;
    for(const npc of this.npcs){
      npc.phase+=.025;
      const d=distance({
        x:player.x+player.w/2,
        y:player.y+player.h/2
      }
      ,
      {
        x:npc.x,
        y:npc.y
      }
      );
      if(d<npc.radius&&d<best){
        best=d;
        this.nearby=npc;

      }

    }

  }

    interact(player,
  quests){
    const npc=this.nearby;
    if(!npc||Date.now()-this.lastInteraction<180)return null;
    this.lastInteraction=Date.now();
    const catalog=NPC_CATALOG[npc.kind]||NPC_CATALOG.pip;
    const first=!npc.met;
    npc.met=true;
    const line=catalog.lines[npc.dialogueIndex%catalog.lines.length];
    npc.dialogueIndex++;
    this.hub?.emit(EXPANSION_EVENTS.NPC_MET,
    {
      npcId:npc.id,
      kind:npc.kind,
      first
    }
    );
    let questResult=null;
    if(catalog.quest){
      const quest=quests.get(catalog.quest);
      if(quest?.state.status==="available")questResult=quests.start(catalog.quest);

    }
    return {
      npc,
      line,
      role:catalog.role,
      quest:catalog.quest,
      questResult,
      first
    }
    ;

  }

    draw(ctx,
  camera){
    for(const npc of this.npcs){
      const catalog=NPC_CATALOG[npc.kind]||NPC_CATALOG.pip;
      const x=npc.x-camera,
      y=npc.y;
      ctx.save();
      ctx.translate(x,
      y+Math.sin(npc.phase)*3);
      ctx.fillStyle=catalog.color;
      ctx.beginPath();
      ctx.roundRect(-13,
      -24,
      26,
      30,
      8);
      ctx.fill();
      ctx.fillStyle="#17223f";
      ctx.fillRect(-7,
      -15,
      4,
      4);
      ctx.fillRect(4,
      -15,
      4,
      4);
      ctx.fillStyle="#d8e8ff";
      ctx.fillRect(-6,
      -5,
      12,
      3);
      ctx.fillStyle="#f5d67e";
      ctx.fillRect(-9,
      5,
      6,
      8);
      ctx.fillRect(3,
      5,
      6,
      8);
      if(!npc.met){
        ctx.fillStyle="#fff0a6";
        ctx.font="bold 12px sans-serif";
        ctx.textAlign="center";
        ctx.fillText("!",
        0,
        -34);

      }
      ctx.restore();

    }

  }

    serialize(){
    return this.npcs.map(npc=>({
      id:npc.id,
      met:npc.met,
      dialogueIndex:npc.dialogueIndex
    }
    ));

  }

    restore(saved=[]){
    for(const state of saved){
      const npc=this.npcs.find(item=>item.id===state.id);
      if(npc){
        npc.met=Boolean(state.met);
        npc.dialogueIndex=state.dialogueIndex||0;

      }

    }

  }


}
