/** Runtime accessibility preferences with safe defaults and no forced animation. */
export const ACCESSIBILITY_DEFAULTS={
  reducedMotion:false,
  highContrast:false,
  largeText:false,
  screenReaderHints:true,
  holdToJump:false,
  autoFire:false,
  flashReduction:false,
  shakeReduction:false
}
;

export class AccessibilitySystem {

    constructor(saved={

  }
  ){
    this.options={
      ...ACCESSIBILITY_DEFAULTS,
      ...saved
    }
    ;
    this.listeners=new Set();

  }

    set(key,
  value){
    if(!(key in ACCESSIBILITY_DEFAULTS))return false;
    this.options[key]=Boolean(value);
    for(const listener of this.listeners)listener(this.options);
    return true;

  }

    toggle(key){
    return this.set(key,
    !this.options[key]);

  }

    subscribe(listener){
    this.listeners.add(listener);
    return ()=>this.listeners.delete(listener);

  }

    apply(documentRef=globalThis.document){
    if(!documentRef?.documentElement)return;
    const root=documentRef.documentElement;
    root.classList.toggle("reduce-motion",
    this.options.reducedMotion);
    root.classList.toggle("high-contrast",
    this.options.highContrast);
    root.classList.toggle("large-text",
    this.options.largeText);

  }

    describe(){
    return Object.entries(this.options).map(([id,
    enabled])=>({
      id,
      enabled,
      label:id.replace(/[A-Z]/g,
      letter=>` ${letter.toLowerCase()}`).replace(/^./,
      letter=>letter.toUpperCase())
    }
    ));

  }

    serialize(){
    return {
      ...this.options
    }
    ;

  }


}
