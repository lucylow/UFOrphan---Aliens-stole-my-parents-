/** Contextual onboarding cards; each hint is shown at most once unless reset. */
export const TUTORIALS=[
 {
  id:"move",
  trigger:"level-start",
  title:"Find your feet",
  text:"Use A/D or the arrow keys to move. Momentum takes a moment to settle."
}
,

 {
  id:"jump",
  trigger:"first-platform",
  title:"Mind the gap",
  text:"Press SPACE, W, or ↑ to jump. Release between jumps."
}
,

 {
  id:"blast",
  trigger:"first-enemy",
  title:"A little cosmic self-defence",
  text:"Press X or J to fire the star-blaster. Projectiles travel in the direction Fiona faces."
}
,

 {
  id:"keycard",
  trigger:"first-key",
  title:"Keycards open portals",
  text:"Collect every keycard in a region before entering its exit portal."
}
,

 {
  id:"npc",
  trigger:"near-npc",
  title:"Not everyone is an enemy",
  text:"Move close to a character and press E to talk. Helping locals can unlock side missions."
}
,

 {
  id:"craft",
  trigger:"near-station",
  title:"Make useful things",
  text:"At a workbench, combine salvaged materials into upgrades and supplies."
}

];

export class TutorialSystem {

    constructor(saved=[]){
    this.seen=new Set(saved);
    this.queue=[];
    this.enabled=true;

  }

    trigger(id){
    if(!this.enabled||this.seen.has(id))return null;
    const tutorial=TUTORIALS.find(item=>item.trigger===id);
    if(!tutorial)return null;
    this.seen.add(id);
    this.queue.push(tutorial);
    return tutorial;

  }

    next(){
    return this.queue.shift()||null;

  }

    reset(){
    this.seen.clear();
    this.queue.length=0;

  }

    serialize(){
    return [...this.seen];

  }

    restore(data=[]){
    this.seen=new Set(data);

  }


}
