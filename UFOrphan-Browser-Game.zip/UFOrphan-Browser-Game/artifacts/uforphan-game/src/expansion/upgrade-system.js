/** Permanent and temporary upgrades are deliberately separate. */
export const UPGRADES={

    reinforced_boots:{
    name:"Reinforced Boots",
    slot:"boots",
    price:180,
    effect:{
      speed:1.08
    }

  }
  ,

    focus_lens:{
    name:"Focus Lens",
    slot:"weapon",
    price:260,
    effect:{
      damage:2
    }

  }
  ,

    heart_module:{
    name:"Heart Module",
    slot:"core",
    price:320,
    effect:{
      maxHealth:1
    }

  }
  ,

    magnet_coil:{
    name:"Magnet Coil",
    slot:"utility",
    price:210,
    effect:{
      pickupRadius:1.5
    }

  }


}
;

export class UpgradeSystem {

    constructor(saved=[]){
    this.owned=new Set(Array.isArray(saved)?saved:(saved.owned||[]));
    this.temporary=Array.isArray(saved)?[]:(saved.temporary||[]);

  }

    purchase(id,
  economy){
    const upgrade=UPGRADES[id];
    if(!upgrade||this.owned.has(id))return {
      ok:false,
      reason:"unavailable"
    }
    ;
    if(economy.credits<upgrade.price)return {
      ok:false,
      reason:"not-enough-credits"
    }
    ;
    economy.credits-=upgrade.price;
    this.owned.add(id);
    return {
      ok:true,
      upgrade
    }
    ;

  }

    apply(player){
    player.speedMultiplier=1;
    player.maxHealth=3;
    player.pickupRadius=25;
    for(const id of this.owned){
      const effect=UPGRADES[id]?.effect||{

      }
      ;
      if(effect.speed)player.speedMultiplier*=effect.speed;
      if(effect.maxHealth)player.maxHealth+=effect.maxHealth;
      if(effect.pickupRadius)player.pickupRadius*=effect.pickupRadius;

    }

  }

    addTemporary(id,
  duration){
    this.temporary.push({
      id,
      duration,
      remaining:duration
    }
    );

  }

    update(){
    for(const item of this.temporary)item.remaining--;
    this.temporary=this.temporary.filter(item=>item.remaining>0);

  }

    serialize(){
    return {
      owned:[...this.owned],
      temporary:this.temporary
    }
    ;

  }

    restore(data=[]){
    this.owned=new Set(Array.isArray(data)?data:(data.owned||[]));
    this.temporary=Array.isArray(data)?[]:(data.temporary||[]);

  }


}
