import {
   EXPANSION_EVENTS
}
 from "./constants.js";

export const RECIPES=[
  {
  id:"med_patch",
  name:"Med Patch",
  station:"field_kit",
  ingredients:{
    ion_cell:1,
    resonant_crystal:1
  }
  ,
  output:{
    id:"med_patch",
    count:2
  }
  ,
  time:2,
  xp:10
}
,

  {
  id:"shield_bubble",
  name:"Shield Bubble",
  station:"workbench",
  ingredients:{
    ion_cell:2,
    relay_chip:1
  }
  ,
  output:{
    id:"shield_bubble",
    count:1
  }
  ,
  time:4,
  xp:18
}
,

  {
  id:"plasma_lens",
  name:"Plasma Lens",
  station:"workbench",
  ingredients:{
    relay_chip:3,
    resonant_crystal:2,
    copper_coil:2
  }
  ,
  output:{
    id:"plasma_lens",
    count:1
  }
  ,
  time:8,
  xp:35
}
,

  {
  id:"double_jump",
  name:"Jump Servo",
  station:"workbench",
  ingredients:{
    ion_cell:4,
    copper_coil:3,
    resonant_crystal:1
  }
  ,
  output:{
    id:"double_jump",
    count:1
  }
  ,
  time:10,
  xp:40
}
,

  {
  id:"star_cookie",
  name:"Star Cookie",
  station:"campfire",
  ingredients:{
    stardust:3
  }
  ,
  output:{
    id:"star_cookie",
    count:2
  }
  ,
  time:3,
  xp:8
}

];

export class CraftingSystem {

    constructor(hub,
  inventory,
  {
    recipes=RECIPES
  }
  ={

  }
  ){
    this.hub=hub;
    this.inventory=inventory;
    this.recipes=new Map(recipes.map(recipe=>[recipe.id,
    recipe]));
    this.unlocked=new Set(["med_patch",
    "star_cookie"]);
    this.activeStation=null;
    this.history=[];

  }

    unlock(recipeId){
    if(!this.recipes.has(recipeId))return false;
    this.unlocked.add(recipeId);
    return true;

  }

    setStation(station){
    this.activeStation=station;
    return this.availableRecipes();

  }

    canCraft(id){
    const recipe=this.recipes.get(id);
    if(!recipe||!this.unlocked.has(id))return {
      ok:false,
      reason:"locked"
    }
    ;
    if(this.activeStation!==recipe.station)return {
      ok:false,
      reason:"wrong-station"
    }
    ;
    for(const [item,
    count] of Object.entries(recipe.ingredients))if(!this.inventory.has(item,
    count))return {
      ok:false,
      reason:`missing:${item}`
    }
    ;
    return {
      ok:true,
      recipe
    }
    ;

  }

    craft(id){
    const check=this.canCraft(id);
    if(!check.ok)return check;
    const recipe=check.recipe;
    for(const [item,
    count] of Object.entries(recipe.ingredients))if(!this.inventory.remove(item,
    count))throw new Error("Inventory changed during craft transaction");
    const output=this.inventory.add(recipe.output.id,
    recipe.output.count);
    if(output.added<recipe.output.count){
      this.inventory.remove(recipe.output.id,
      output.added);
      for(const [item,
      count] of Object.entries(recipe.ingredients))this.inventory.add(item,
      count);
      return {
        ok:false,
        reason:"inventory-full"
      }
      ;

    }
    const record={
      id,
      craftedAt:Date.now(),
      output:recipe.output
    }
    ;
    this.history.push(record);
    this.hub?.emit(EXPANSION_EVENTS.CRAFTED,
    {
      recipe:id,
      output:recipe.output
    }
    );
    return {
      ok:true,
      record,
      xp:recipe.xp
    }
    ;

  }

    availableRecipes(){
    return [...this.recipes.values()].filter(recipe=>this.unlocked.has(recipe.id)&&recipe.station===this.activeStation).map(recipe=>({
      ...recipe,
      canCraft:this.canCraft(recipe.id).ok
    }
    ));

  }

    stations(){
    return [...new Set([...this.recipes.values()].map(recipe=>recipe.station))];

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      history:[...this.history]
    }
    ;

  }

    restore(data={

  }
  ){
    this.unlocked=new Set(["med_patch",
    "star_cookie",
    ...(data.unlocked||[])]);
    this.history=[...(data.history||[])];

  }


}
