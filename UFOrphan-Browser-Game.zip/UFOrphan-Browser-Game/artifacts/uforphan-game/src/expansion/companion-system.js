import {
   distance,
   EXPANSION_EVENTS
}
 from "./constants.js";

export const COMPANIONS={

    mothlet:{
    name:"Mothlet",
    ability:"scanner",
    description:"Highlights nearby hidden objects.",
    color:"#c7a9ff"
  }
  ,

    pebble:{
    name:"Pebble",
    ability:"guard",
    description:"Occasionally blocks an incoming projectile.",
    color:"#a8d6e9"
  }
  ,

    zip:{
    name:"Zip",
    ability:"spark",
    description:"Adds a little energy to collected stardust.",
    color:"#ffe08b"
  }


}
;

export class CompanionSystem {

    constructor(hub,
  definitions=[]){
    this.hub=hub;
    this.unlocked=new Set(["mothlet"]);
    this.active="mothlet";
    this.followers=definitions;
    this.phase=0;
    this.abilityCooldown=0;
    this.lastPosition={
      x:0,
      y:0
    }
    ;
    this.notifications=[];

  }

    unlock(id){
    if(!COMPANIONS[id])return false;
    this.unlocked.add(id);
    this.hub?.emit("companion:unlocked",
    {
      id
    }
    );
    return true;

  }

    equip(id){
    if(!this.unlocked.has(id))return false;
    this.active=id;
    return true;

  }

    update(player,
  world){
    this.phase+=.07;
    if(this.abilityCooldown>0)this.abilityCooldown--;
    const companion=COMPANIONS[this.active];
    if(!companion)return;
    const targetX=player.x-player.facing*38,
    targetY=player.y-20;
    this.lastPosition.x+=(targetX-this.lastPosition.x)*.12;
    this.lastPosition.y+=(targetY-this.lastPosition.y)*.12;
    if(companion.ability==="guard"&&this.abilityCooldown===0){
      const projectile=world.projectiles.find(item=>item.owner==="enemy"&&distance(item,
      player)<95);
      if(projectile){
        projectile.life=0;
        this.abilityCooldown=260;
        this.hub?.emit("companion:guard",
        {
          id:this.active
        }
        );

      }

    }

  }

    bonusStars(){
    return this.active==="zip"?1:0;

  }

    draw(ctx,
  camera){
    const companion=COMPANIONS[this.active];
    if(!companion)return;
    const x=this.lastPosition.x-camera,
    y=this.lastPosition.y+Math.sin(this.phase)*5;
    ctx.save();
    ctx.fillStyle=companion.color;
    ctx.shadowColor=companion.color;
    ctx.shadowBlur=14;
    ctx.beginPath();
    ctx.arc(x,
    y,
    10,
    0,
    Math.PI*2);
    ctx.fill();
    ctx.shadowBlur=0;
    ctx.fillStyle="#1c2749";
    ctx.fillRect(x-4,
    y-2,
    3,
    3);
    ctx.fillRect(x+2,
    y-2,
    3,
    3);
    ctx.restore();

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      active:this.active
    }
    ;

  }

    restore(data={

  }
  ){
    this.unlocked=new Set(["mothlet",
    ...(data.unlocked||[])]);
    this.active=this.unlocked.has(data.active)?data.active:"mothlet";

  }


}
