/** Applies quest rewards as a single validated operation. */
export class QuestRewardService {

    constructor(inventory,
  economy,
  progression){
    this.inventory=inventory;
    this.economy=economy;
    this.progression=progression;
    this.claimed=new Set();

  }

    claim(quest){
    if(!quest||this.claimed.has(quest.id))return {
      ok:false,
      reason:"already-claimed"
    }
    ;
    const rewards=quest.rewards||[];
    const itemRewards=rewards.filter(item=>item.item);
    const requiredSlots=itemRewards.reduce((sum,
    item)=>sum+Math.ceil(item.count/(this.inventory.definition(item.item).stack||99)),
    0);
    if(requiredSlots>this.inventory.freeSlots())return {
      ok:false,
      reason:"inventory-capacity"
    }
    ;
    for(const reward of rewards){
      if(reward.item){
        const result=this.inventory.add(reward.item,
        reward.count||1);
        if(!result.ok)return {
          ok:false,
          reason:"inventory-full"
        }
        ;

      }
      if(reward.credits)this.economy?.earn(reward.credits,
      `quest:${quest.id}`);
      if(reward.xp)this.progression?.addXP(reward.xp);

    }
    this.claimed.add(quest.id);
    return {
      ok:true,
      rewards
    }
    ;

  }

    serialize(){
    return [...this.claimed];

  }

    restore(data=[]){
    this.claimed=new Set(data);

  }


}
