/** Static checks for authored platform levels; used by tests and content tools. */
export function validateLevel(level){
  const errors=[],
  warnings=[];
  if(!level?.id)errors.push("missing id");
  if(!Number.isFinite(level?.width)||level.width<960)errors.push("invalid world width");
  if(!Array.isArray(level?.platforms)||!level.platforms.length)errors.push("no platforms");
  if(!Array.isArray(level?.stars))warnings.push("no collectibles");
  if(!Array.isArray(level?.keys))warnings.push("no keycards");
  if(!Array.isArray(level?.enemies))warnings.push("no enemies");
  for(const [index,
  p] of (level?.platforms||[]).entries()){
    if(p.length!==4||p.some(value=>!Number.isFinite(value)))errors.push(`platform ${index} has invalid coordinates`);
    else if(p[2]<=0||p[3]<=0)errors.push(`platform ${index} has non-positive dimensions`);
    else if(p[0]+p[2]>level.width+1)errors.push(`platform ${index} exceeds world width`);

  }
  for(const [index,
  point] of (level?.stars||[]).entries())if(point[0]<0||point[0]>level.width||point[1]<0||point[1]>540)warnings.push(`star ${index} is outside visible bounds`);
  if(level?.exit?.[0]>=level.width)errors.push("exit outside world");
  if(!level?.checkpoint)warnings.push("no checkpoint");
  return {
    valid:errors.length===0,
    errors,
    warnings
  }
  ;

}

export function validateLevelSet(levels){
  const ids=new Set(),
  results=[];
  for(const level of levels){
    if(ids.has(level.id))results.push({
      id:level.id,
      valid:false,
      errors:["duplicate level id"],
      warnings:[]
    }
    );
    else{
      ids.add(level.id);
      results.push({
        id:level.id,
        ...validateLevel(level)
      }
      );

    }

  }
  return {
    valid:results.every(result=>result.valid),
    results,
    summary:{
      levels:results.length,
      errors:results.reduce((sum,
      result)=>sum+result.errors.length,
      0),
      warnings:results.reduce((sum,
      result)=>sum+result.warnings.length,
      0)
    }

  }
  ;

}
