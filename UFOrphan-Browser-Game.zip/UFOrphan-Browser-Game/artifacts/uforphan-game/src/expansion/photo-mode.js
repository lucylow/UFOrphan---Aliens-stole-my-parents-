/** Photo-mode camera and composition helpers. Rendering stays in the canvas renderer. */
import {
   clamp
}
 from "./constants.js";

export class PhotoMode {

    constructor(){
    this.enabled=false;
    this.camera={
      x:0,
      y:0,
      zoom:1
    }
    ;
    this.filters=["none",
    "warm",
    "cool",
    "mono",
    "dream",
    "ion"];
    this.filter="none";
    this.frame="none";
    this.hideHUD=false;
    this.stickers=[];
    this.snapshotName="Fiona's field notes";

  }

    enter(player){
    this.enabled=true;
    this.camera.x=player.x;
    this.camera.y=player.y;
    return this.state();

  }

    exit(){
    this.enabled=false;
    return this.state();

  }

    move(dx,
  dy){
    if(!this.enabled)return false;
    this.camera.x+=dx;
    this.camera.y+=dy;
    return true;

  }

    zoom(delta){
    if(!this.enabled)return false;
    this.camera.zoom=clamp(this.camera.zoom+delta,
    .5,
    2.5);
    return true;

  }

    setFilter(filter){
    if(!this.filters.includes(filter))return false;
    this.filter=filter;
    return true;

  }

    addSticker(sticker,
  x,
  y){
    if(!this.enabled||this.stickers.length>=12)return false;
    this.stickers.push({
      sticker,
      x,
      y
    }
    );
    return true;

  }

    clearStickers(){
    this.stickers.length=0;

  }

    state(){
    return {
      enabled:this.enabled,
      camera:{
        ...this.camera
      }
      ,
      filter:this.filter,
      frame:this.frame,
      hideHUD:this.hideHUD,
      stickers:this.stickers.slice()
    }
    ;

  }

    cssFilter(){
    return ({
      warm:"sepia(.28) saturate(1.2)",
      cool:"hue-rotate(18deg) saturate(.9)",
      mono:"grayscale(1)",
      dream:"saturate(1.4) brightness(1.08)",
      ion:"hue-rotate(145deg) contrast(1.15)"
    }
    )[this.filter]||"none";

  }


}
