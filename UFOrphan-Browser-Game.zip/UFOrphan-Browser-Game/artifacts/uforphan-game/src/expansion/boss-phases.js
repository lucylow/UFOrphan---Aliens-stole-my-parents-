export const BOSS_PHASES={

    warden:[{
    healthAbove:.66,
    name:"Patrol",
    speed:1,
    attack:"single"
  }
  ,
  {
    healthAbove:.33,
    name:"Overload",
    speed:1.3,
    attack:"fan"
  }
  ,
  {
    healthAbove:0,
    name:"Critical",
    speed:1.6,
    attack:"sweep"
  }
  ],

    queen:[{
    healthAbove:.7,
    name:"Guarded",
    speed:.9,
    attack:"orb"
  }
  ,
  {
    healthAbove:.35,
    name:"Awakened",
    speed:1.2,
    attack:"summon"
  }
  ,
  {
    healthAbove:0,
    name:"Unbound",
    speed:1.5,
    attack:"rain"
  }
  ]

}
;

export class BossPhaseController {

    constructor(type="warden",
  hub=null){
    this.type=type;
    this.hub=hub;
    this.phases=BOSS_PHASES[type]||BOSS_PHASES.warden;
    this.index=-1;
    this.elapsed=0;
    this.attackCooldown=0;
    this.enraged=false;

  }

    update(boss,
  world,
  player){
    this.elapsed++;
    const ratio=boss.health/boss.maxHealth;
    let next=this.phases.findIndex(phase=>ratio>phase.healthAbove);
    if(next<0)next=this.phases.length-1;
    if(next!==this.index){
      this.index=next;
      const phase=this.current();
      this.hub?.emit("boss:phase",
      {
        boss:this.type,
        index:next,
        name:phase.name
      }
      );
      boss.phaseName=phase.name;
      this.attackCooldown=45;

    }
    if(this.attackCooldown>0)this.attackCooldown--;
    else this.attack(boss,
    world,
    player);

  }

    current(){
    return this.phases[Math.max(0,
    this.index)]||this.phases[0];

  }

    attack(boss,
  world,
  player){
    const phase=this.current();
    const direction=player.x<boss.x?-1:1;
    const spawn=(vx,
    vy)=>world.projectiles.push({
      x:boss.x+boss.w/2,
      y:boss.y+boss.h/2,
      w:12,
      h:12,
      vx,
      vy,
      life:120,
      owner:"enemy",
      damage:1
    }
    );
    if(phase.attack==="single")spawn(direction*4,
    0);
    else if(phase.attack==="fan"){
      for(const angle of [-.45,
      0,
      .45])spawn(direction*4,
      angle*4);

    }
    else if(phase.attack==="sweep"){
      spawn(direction*5,
      -1);
      spawn(direction*5,
      1);

    }
    else if(phase.attack==="orb")spawn(direction*3,
    Math.sign(player.y-boss.y)*2);
    else if(phase.attack==="rain"){
      for(let i=0;
      i<3;
      i++)spawn(direction*(3+i),
      -1+i);

    }
    else spawn(direction*3,
    0);
    this.attackCooldown=Math.max(28,
    90-phase.speed*24);

  }


}
