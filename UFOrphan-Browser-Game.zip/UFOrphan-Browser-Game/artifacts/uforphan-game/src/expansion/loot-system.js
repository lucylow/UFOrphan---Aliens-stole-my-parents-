import {
   uid,
   EXPANSION_EVENTS
}
 from "./constants.js";

export const LOOT_TABLES={

    drone:[{
    id:"ion_cell",
    weight:55,
    min:1,
    max:2
  }
  ,
  {
    id:"relay_chip",
    weight:25,
    min:1,
    max:1
  }
  ,
  {
    id:"stardust",
    weight:20,
    min:2,
    max:4
  }
  ],

    brute:[{
    id:"copper_coil",
    weight:45,
    min:1,
    max:3
  }
  ,
  {
    id:"ion_cell",
    weight:35,
    min:1,
    max:2
  }
  ,
  {
    id:"resonant_crystal",
    weight:20,
    min:1,
    max:1
  }
  ],

    boss:[{
    id:"resonant_crystal",
    weight:50,
    min:2,
    max:4
  }
  ,
  {
    id:"relay_chip",
    weight:35,
    min:2,
    max:3
  }
  ,
  {
    id:"plasma_lens",
    weight:15,
    min:1,
    max:1
  }
  ]

}
;

export class SeededRandom {

    constructor(seed=Date.now()){
    this.seed=(seed>>>0)||1;

  }

    next(){
    this.seed=(1664525*this.seed+1013904223)>>>0;
    return this.seed/4294967296;

  }

    int(min,
  max){
    return Math.floor(this.next()*(max-min+1))+min;

  }

    pickWeighted(entries){
    const total=entries.reduce((sum,
    item)=>sum+item.weight,
    0);
    let roll=this.next()*total;
    for(const item of entries){
      roll-=item.weight;
      if(roll<=0)return item;

    }
    return entries[entries.length-1];

  }


}

export class LootSystem {

    constructor(hub,
  inventory,
  seed=12345){
    this.hub=hub;
    this.inventory=inventory;
    this.random=new SeededRandom(seed);
    this.drops=[];
    this.collected=[];
    this.pity={
      rare:0
    }
    ;

  }

    dropFrom(source,
  x,
  y){
    const table=LOOT_TABLES[source]||LOOT_TABLES.drone;
    const entry=this.random.pickWeighted(table);
    const count=this.random.int(entry.min,
    entry.max);
    const drop={
      id:uid("drop"),
      item:entry.id,
      count,
      x,
      y,
      vx:this.random.next()*2-1,
      vy:-2.2,
      life:1200,
      bob:this.random.next()*6
    }
    ;
    this.drops.push(drop);
    return drop;

  }

    update(player,
  world){
    for(const drop of this.drops){
      drop.x+=drop.vx;
      drop.y+=drop.vy;
      drop.vy=Math.min(4,
      drop.vy+.12);
      drop.life--;
      drop.bob+=.06;
      if(Math.hypot(player.x+player.w/2-drop.x,
      player.y+player.h/2-drop.y)<25){
        const result=this.inventory.add(drop.item,
        drop.count);
        if(result.added===drop.count){
          drop.life=0;
          this.collected.push({
            item:drop.item,
            count:drop.count,
            at:Date.now()
          }
          );
          this.hub?.emit(EXPANSION_EVENTS.ITEM_ADDED,
          {
            id:drop.item,
            count:drop.count,
            source:"loot"
          }
          );
          world.particles.burst(drop.x,
          drop.y,
          "#ffd76d",
          8);

        }
        else drop.blocked=true;

      }

    }

        this.drops=this.drops.filter(drop=>drop.life>0);

  }

    draw(ctx,
  camera){
    for(const drop of this.drops){
      ctx.save();
      ctx.translate(drop.x-camera,
      drop.y+Math.sin(drop.bob)*3);
      ctx.fillStyle=drop.blocked?"#ff778c":"#ffd76d";
      ctx.shadowColor=ctx.fillStyle;
      ctx.shadowBlur=10;
      ctx.beginPath();
      ctx.arc(0,
      0,
      7,
      0,
      Math.PI*2);
      ctx.fill();
      ctx.shadowBlur=0;
      ctx.fillStyle="#182343";
      ctx.font="9px sans-serif";
      ctx.textAlign="center";
      ctx.fillText(drop.count,
      0,
      3);
      ctx.restore();

    }

  }

    serialize(){
    return {
      seed:this.random.seed,
      collected:this.collected.slice(-100)
    }
    ;

  }

    restore(data={

  }
  ){
    this.random.seed=data.seed||this.random.seed;
    this.collected=data.collected||[];

  }


}
