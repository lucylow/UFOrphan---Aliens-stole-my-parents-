import {
   clamp
}
 from "./constants.js";

export const SKILL_TREE={

    mobility:[{
    id:"light_feet",
    name:"Light Feet",
    max:3,
    description:"Move faster through the galaxy.",
    cost:[1,
    2,
    3]
  }
  ,
  {
    id:"extra_jump",
    name:"Second Chance",
    max:1,
    description:"Unlock an extra jump.",
    cost:[4]
  }
  ],

    blaster:[{
    id:"charged_shot",
    name:"Charged Shot",
    max:3,
    description:"Increase star-blaster damage.",
    cost:[1,
    2,
    3]
  }
  ,
  {
    id:"quick_draw",
    name:"Quick Draw",
    max:3,
    description:"Reduce weapon cooldown.",
    cost:[1,
    2,
    3]
  }
  ],

    survival:[{
    id:"toughened",
    name:"Toughened Jacket",
    max:2,
    description:"Increase maximum hearts.",
    cost:[2,
    4]
  }
  ,
  {
    id:"recovery",
    name:"Fast Recovery",
    max:2,
    description:"Shorten the damage recovery window.",
    cost:[2,
    3]
  }
  ]

}
;

export class ProgressionSystem {

    constructor(saved={

  }
  ){
    this.xp=saved.xp||0;
    this.level=saved.level||1;
    this.skillPoints=saved.skillPoints||0;
    this.skills={
      ...(saved.skills||{

      }
      )
    }
    ;
    this.lifetimeXp=saved.lifetimeXp||this.xp;

  }

    xpForNext(){
    return Math.floor(80+this.level*35+this.level*this.level*4);

  }

    addXP(amount){
    if(amount<=0)return {
      gained:0,
      levels:0
    }
    ;
    this.xp+=amount;
    this.lifetimeXp+=amount;
    let levels=0;
    while(this.xp>=this.xpForNext()){
      this.xp-=this.xpForNext();
      this.level++;
      this.skillPoints++;
      levels++;

    }
    return {
      gained:amount,
      levels,
      level:this.level
    }
    ;

  }

    skill(id){
    for(const tree of Object.values(SKILL_TREE)){
      const skill=tree.find(item=>item.id===id);
      if(skill)return skill;

    }
    return null;

  }

    rank(id){
    return this.skills[id]||0;

  }

    purchase(id){
    const skill=this.skill(id);
    if(!skill)return {
      ok:false,
      reason:"unknown-skill"
    }
    ;
    const rank=this.rank(id);
    if(rank>=skill.max)return {
      ok:false,
      reason:"maxed"
    }
    ;
    const cost=skill.cost[rank];
    if(this.skillPoints<cost)return {
      ok:false,
      reason:"not-enough-points"
    }
    ;
    this.skillPoints-=cost;
    this.skills[id]=rank+1;
    return {
      ok:true,
      id,
      rank:rank+1,
      cost
    }
    ;

  }

    apply(player){
    const speed=this.rank("light_feet");
    player.speedMultiplier=1+speed*.06;
    if(this.rank("extra_jump"))player.extraJumpUnlocked=true;
    player.maxHealth=3+this.rank("toughened");
    player.health=Math.min(player.health,
    player.maxHealth);
    player.damageRecovery=Math.max(50,
    90-this.rank("recovery")*12);

  }

    tree(){
    return Object.entries(SKILL_TREE).map(([category,
    skills])=>({
      category,
      skills:skills.map(skill=>({
        ...skill,
        rank:this.rank(skill.id),
        nextCost:skill.cost[this.rank(skill.id)]??null
      }
      ))
    }
    ));

  }

    serialize(){
    return {
      xp:this.xp,
      level:this.level,
      skillPoints:this.skillPoints,
      skills:{
        ...this.skills
      }
      ,
      lifetimeXp:this.lifetimeXp
    }
    ;

  }

    restore(data={

  }
  ){
    this.xp=data.xp||0;
    this.level=data.level||1;
    this.skillPoints=data.skillPoints||0;
    this.skills={
      ...(data.skills||{

      }
      )
    }
    ;
    this.lifetimeXp=data.lifetimeXp||this.xp;

  }


}
