import {
   clamp,
   intersects,
   EXPANSION_EVENTS
}
 from "./constants.js";

export class EnvironmentSystem {

    constructor(hub,
  definition={

  }
  ){
    this.hub=hub;
    this.weather=definition.weather||"clear";
    this.hazards=(definition.hazards||[]).map((hazard,
    index)=>({
      id:hazard.id||`env-${index}`,
      active:true,
      phase:0,
      cooldown:0,
      damage:hazard.damage??1,
      ...hazard
    }
    ));
    this.zones=(definition.zones||[]).map(zone=>({
      ...zone,
      entered:false
    }
    ));
    this.wind=definition.wind||{
      x:0,
      y:0
    }
    ;
    this.time=0;
    this.modifiers={
      gravity:1,
      friction:1,
      visibility:1
    }
    ;
    this.particles=[];

  }

    update(player,
  world){
    this.time++;
    this.updateWeather();
    for(const hazard of this.hazards){
      hazard.phase++;
      if(hazard.cooldown>0)hazard.cooldown--;
      if(hazard.active&&hazard.cooldown===0&&intersects(player,
      hazard)){
        if(hazard.kind==="vent")player.vx+=Math.sign(hazard.force||1)*1.5;
        if(hazard.kind==="geyser"&&hazard.phase%180<70){
          player.takeDamage(world.audio,
          world.particles);
          hazard.cooldown=80;

        }
        if(hazard.kind==="electric"&&hazard.phase%120<60){
          player.takeDamage(world.audio,
          world.particles);
          hazard.cooldown=90;

        }

      }

    }

        for(const zone of this.zones){
      const inside=intersects(player,
      zone);
      if(inside&&!zone.entered){
        zone.entered=true;
        this.hub?.emit(EXPANSION_EVENTS.REGION_ENTERED,
        {
          zone:zone.id,
          name:zone.name
        }
        );

      }
      if(!inside)zone.entered=false;

    }

  }

    updateWeather(){
    const cycle=this.time%2400;
    if(this.weather==="ion-storm"){
      this.modifiers.gravity=cycle>500&&cycle<1700?1.12:1;
      this.modifiers.visibility=cycle>500&&cycle<1700?.68:1;
      this.wind.x=Math.sin(this.time*.018)*.18;

    }
    else if(this.weather==="low-gravity"){
      this.modifiers.gravity=.62;
      this.wind.x=Math.sin(this.time*.008)*.06;

    }
    else{
      this.modifiers.gravity=1;
      this.modifiers.visibility=1;
      this.wind.x=0;

    }

  }

    applyToPlayer(player){
    player.vx+=this.wind.x;
    player.vy+=this.wind.y;
    player.vy=clamp(player.vy,
    -18,
    16);

  }

    draw(ctx,
  camera){
    this.drawHazards(ctx,
    camera);
    this.drawWeather(ctx);

  }

    drawHazards(ctx,
  camera){
    for(const hazard of this.hazards){
      const x=hazard.x-camera,
      y=hazard.y;
      if(hazard.kind==="geyser"){
        ctx.fillStyle=hazard.phase%180<70?"rgba(255,115,125,.65)":"rgba(255,115,125,.18)";
        ctx.fillRect(x,
        y,
         hazard.w,
        hazard.h);

      }
      else if(hazard.kind==="electric"){
        ctx.strokeStyle="#8cf4ff";
        ctx.lineWidth=3;
        ctx.beginPath();
        ctx.moveTo(x,
        y);
        ctx.lineTo(x+hazard.w,
        y+hazard.h);
        ctx.moveTo(x+hazard.w,
        y);
        ctx.lineTo(x,
        y+hazard.h);
        ctx.stroke();

      }
      else{
        ctx.fillStyle="#a5b4d8";
        ctx.fillRect(x,
        y,
        hazard.w,
        hazard.h);

      }

    }

  }

    drawWeather(ctx){
    if(this.weather==="ion-storm"&&this.modifiers.visibility<1){
      ctx.fillStyle="rgba(101,213,239,.08)";
      ctx.fillRect(0,
      0,
      960,
      540);
      for(let i=0;
      i<18;
      i++){
        const x=(i*71+this.time*4)%980;
        ctx.strokeStyle="rgba(169,239,255,.28)";
        ctx.beginPath();
        ctx.moveTo(x,
        0);
        ctx.lineTo(x-35,
        80);
        ctx.stroke();

      }

    }

  }

    activate(id){
    const hazard=this.hazards.find(item=>item.id===id);
    if(!hazard)return false;
    hazard.active=!hazard.active;
    return hazard.active;

  }

    serialize(){
    return {
      weather:this.weather,
      time:this.time,
      hazards:this.hazards.map(({
        id,
        active,
        phase,
        cooldown
      }
      )=>({
        id,
        active,
        phase,
        cooldown
      }
      )),
      zones:this.zones.map(({
        id,
        entered
      }
      )=>({
        id,
        entered
      }
      ))
    }
    ;

  }

    restore(data={

  }
  ){
    this.time=data.time||0;
    for(const state of data.hazards||[]){
      const hazard=this.hazards.find(item=>item.id===state.id);
      if(hazard)Object.assign(hazard,
      state);

    }
    for(const state of data.zones||[]){
      const zone=this.zones.find(item=>item.id===state.id);
      if(zone)zone.entered=Boolean(state.entered);

    }

  }


}

export class DynamicPlatformSystem {

    constructor(definitions=[]){
    this.platforms=definitions.map((platform,
    index)=>({
      id:platform.id||`moving-${index}`,
      originX:platform.x,
      originY:platform.y,
      phase:index*.7,
      ...platform
    }
    ));

  }

    update(){
    for(const platform of this.platforms){
      platform.phase+=platform.speed||.02;
      platform.x=platform.originX+Math.sin(platform.phase)* (platform.rangeX||0);
      platform.y=platform.originY+Math.cos(platform.phase)*(platform.rangeY||0);

    }

  }

    carryPlayer(player,
  previous){
    for(const platform of this.platforms){
      if(player.onGround&&Math.abs(player.y+player.h-platform.y)<3&&player.x+player.w>platform.x&&player.x<platform.x+platform.w){
        player.x+=platform.x-previous.get(platform.id).x;
        player.y+=platform.y-previous.get(platform.id).y;

      }

    }

  }

    snapshot(){
    return new Map(this.platforms.map(platform=>[platform.id,
    {
      x:platform.x,
      y:platform.y
    }
    ]));

  }

    draw(ctx,
  camera){
    for(const p of this.platforms){
      ctx.fillStyle="#4a6a9b";
      ctx.fillRect(p.x-camera,
      p.y,
      p.w,
      p.h);
      ctx.fillStyle="#93eff0";
      ctx.fillRect(p.x-camera,
      p.y,
      p.w,
      4);

    }

  }


}
