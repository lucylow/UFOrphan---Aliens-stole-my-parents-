/** Optional input buffering and coyote-time helpers for more forgiving platforming. */
export class InputAssist {

    constructor({
    bufferFrames=8,
    coyoteFrames=7
  }
  ={

  }
  ){
    this.bufferFrames=bufferFrames;
    this.coyoteFrames=coyoteFrames;
    this.jumpBuffer=0;
    this.coyote=0;
    this.previousGrounded=false;
    this.enabled=true;

  }

    update(input,
  player){
    if(!this.enabled)return;
    this.jumpBuffer=input.wasPressed("jump")?this.bufferFrames:Math.max(0,
    this.jumpBuffer-1);
    this.coyote=player.onGround?this.coyoteFrames:Math.max(0,
    this.coyote-1);
    this.previousGrounded=player.onGround;

  }

    consumeJump(){
    if(!this.enabled)return false;
    if(this.jumpBuffer>0&&this.coyote>0){
      this.jumpBuffer=0;
      this.coyote=0;
      return true;

    }
    return false;

  }

    serialize(){
    return {
      enabled:this.enabled
    }
    ;

  }


}
