/** Repeatable bounty board and multi-stage expedition tracking. */
export const BOUNTIES=[
 {
  id:"drone_bounty",
  title:"Drone Disruption",
  target:5,
  metric:"drone",
  reward:{
    credits:90,
    ion_cell:2
  }
  ,
  refresh:1
}
,

 {
  id:"crystal_delivery",
  title:"Crystal Courier",
  target:4,
  metric:"crystal",
  reward:{
    credits:120,
    resonant_crystal:1
  }
  ,
  refresh:2
}
,

 {
  id:"scrap_recovery",
  title:"Scrap Recovery",
  target:8,
  metric:"scrap",
  reward:{
    credits:75,
    copper_coil:3
  }
  ,
  refresh:3
}
,

 {
  id:"stardust_route",
  title:"Stardust Route",
  target:15,
  metric:"stardust",
  reward:{
    credits:150,
    relay_chip:1
  }
  ,
  refresh:4
}

];

export class MissionBoard {

    constructor(saved={

  }
  ){
    this.day=saved.day||0;
    this.offers=[];
    this.accepted=new Map();
    this.completed=new Set(saved.completed||[]);
    this.refresh(this.day);
    this.restore(saved);

  }

    refresh(day){
    this.day=day;
    this.offers=BOUNTIES.filter((_,
    index)=>(index+day)%2===0).map(item=>({
      ...item,
      progress:0,
      accepted:false
    }
    ));

  }

    accept(id){
    const offer=this.offers.find(item=>item.id===id);
    if(!offer||offer.accepted||this.accepted.size>=3)return {
      ok:false,
      reason:"unavailable"
    }
    ;
    offer.accepted=true;
    this.accepted.set(id,
    {
      ...offer
    }
    );
    return {
      ok:true,
      mission:offer
    }
    ;

  }

    progress(metric,
  amount=1){
    const finished=[];
    for(const [id,
    mission] of this.accepted){
      if(mission.metric!==metric)continue;
      mission.progress=Math.min(mission.target,
      mission.progress+amount);
      if(mission.progress>=mission.target){
        this.accepted.delete(id);
        this.completed.add(id);
        finished.push(mission);

      }

    }
    return finished;

  }

    abandon(id){
    const mission=this.accepted.get(id);
    if(!mission)return false;
    this.accepted.delete(id);
    const offer=this.offers.find(item=>item.id===id);
    if(offer)offer.accepted=false;
    return true;

  }

    list(){
    return {
      offers:this.offers.map(item=>({
        ...item
      }
      )),
      accepted:[...this.accepted.values()].map(item=>({
        ...item
      }
      )),
      completed:[...this.completed]
    }
    ;

  }

    serialize(){
    return {
      day:this.day,
      completed:[...this.completed],
      accepted:[...this.accepted.values()]
    }
    ;

  }

    restore(data={

  }
  ){
    this.day=data.day||this.day;
    this.completed=new Set(data.completed||[]);
    for(const mission of data.accepted||[])this.accepted.set(mission.id,
    {
      ...mission
    }
    );

  }


}
