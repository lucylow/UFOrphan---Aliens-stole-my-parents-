import {
   EXPANSION_EVENTS,
   clamp
}
 from "./constants.js";

export const CHALLENGES=[
  {
  id:"time_trial_relay",
  name:"Relay Rush",
  description:"Reach the relay before the countdown expires.",
  duration:75,
  goal:1,
  metric:"finish",
  reward:{
    credits:120,
    stardust:10
  }

}
,

  {
  id:"drone_sweep",
  name:"Drone Sweep",
  description:"Disable six drones without losing all your hearts.",
  duration:100,
  goal:6,
  metric:"kills",
  reward:{
    ion_cell:4
  }

}
,

  {
  id:"star_hunt",
  name:"Stardust Sprint",
  description:"Collect twelve stardust fragments in one run.",
  duration:90,
  goal:12,
  metric:"stars",
  reward:{
    resonant_crystal:2
  }

}

];

export class ChallengeSystem {

    constructor(hub){
    this.hub=hub;
    this.active=null;
    this.results=[];
    this.elapsed=0;
    this.progress=0;
    this.startHealth=0;this.damageTaken=0;

  }

    start(id,
  player){
    const definition=CHALLENGES.find(item=>item.id===id);
    if(!definition||this.active)return {
      ok:false,
      reason:"unavailable"
    }
    ;
    this.active=definition;
    this.elapsed=0;
    this.progress=0;
    this.startHealth=player.health;
    this.damageTaken=0;
    this.hub?.emit(EXPANSION_EVENTS.CHALLENGE_STARTED,
    {
      id
    }
    );
    return {
      ok:true,
      challenge:definition
    }
    ;

  }

    recordDamage(amount=1){
    if(this.active)this.damageTaken+=amount;
  }

    addProgress(metric,
  amount=1){
    if(!this.active||this.active.metric!==metric)return false;
    this.progress=clamp(this.progress+amount,
    0,
    this.active.goal);
    if(this.progress>=this.active.goal)this.finish(true);
    return true;

  }

    update(){
    if(!this.active)return;
    this.elapsed+=1/60;
    if(this.elapsed>=this.active.duration)this.finish(false);

  }

    finish(success){
    if(!this.active)return null;
    const result={
      id:this.active.id,
      success,
      elapsed:this.elapsed,
      progress:this.progress,
      completedAt:Date.now(),
      flawless:success&&this.damageTaken===0
    }
    ;
    this.results.push(result);
    this.hub?.emit(EXPANSION_EVENTS.CHALLENGE_ENDED,
    result);
    this.active=null;
    return result;

  }

    abandon(){
    return this.finish(false);

  }

    remaining(){
    return this.active?Math.max(0,
    this.active.duration-this.elapsed):0;

  }

    state(){
    return this.active?{
      ...this.active,
      elapsed:this.elapsed,
      remaining:this.remaining(),
      progress:this.progress,
      ratio:this.progress/this.active.goal
    }
    :null;

  }

    serialize(){
    return {
      results:this.results.slice(-50)
    }
    ;

  }

    restore(data={

  }
  ){
    this.results=data.results||[];
    this.active=null;

  }


}
