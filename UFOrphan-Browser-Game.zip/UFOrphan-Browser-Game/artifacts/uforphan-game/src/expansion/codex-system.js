import {
   EXPANSION_EVENTS
}
 from "./constants.js";

export const CODEX_ENTRIES=[
  {
  id:"fiona",
  category:"people",
  title:"Fiona Gallegar",
  text:"A stubborn young explorer who refuses to let a tractor beam decide where her family belongs.",
  unlock:"start"
}
,

  {
  id:"pip",
  category:"people",
  title:"Pip",
  text:"A retired Moon Mall security bot whose badge opens more doors than its owner remembers.",
  unlock:"meet:pip"
}
,

  {
  id:"rivet",
  category:"people",
  title:"Rivet",
  text:"A pirate mechanic with a soft spot for broken machines and impossible projects.",
  unlock:"meet:rivet"
}
,

  {
  id:"mothlet",
  category:"creatures",
  title:"Mothlet",
  text:"A tiny navigation drone that defected after reading the employee handbook.",
  unlock:"companion:mothlet"
}
,

  {
  id:"ion_storm",
  category:"phenomena",
  title:"Ion Storm",
  text:"Electrical weather that bends trajectories and makes old antenna arrays sing.",
  unlock:"region:ion-storm"
}
,

  {
  id:"mothership",
  category:"places",
  title:"The Mothership",
  text:"A modular command vessel with a surprisingly small cafeteria and a very large detention wing.",
  unlock:"level:3"
}
,

  {
  id:"crystal_grove",
  category:"places",
  title:"Crystal Grove",
  text:"A quiet valley where resonant crystals grow toward sound and remember old melodies.",
  unlock:"level:6"
}
,

  {
  id:"family_signal",
  category:"technology",
  title:"Family Frequency",
  text:"A low-power transmission pattern tuned to the familiar rhythms of home.",
  unlock:"quest:family_frequency"
}

];

export class CodexSystem {

    constructor(hub,
  saved=[]){
    this.hub=hub;
    this.entries=new Map(CODEX_ENTRIES.map(entry=>[entry.id,
    entry]));
    this.unlocked=new Set(["fiona"]);
    this.read=new Set();
    this.restore(saved);

  }

    unlock(id){
    if(!this.entries.has(id)||this.unlocked.has(id))return false;
    this.unlocked.add(id);
    this.hub?.emit("codex:unlocked",
    {
      id,
      entry:this.entries.get(id)
    }
    );
    return true;

  }

    unlockByTrigger(trigger){
    let count=0;
    for(const entry of this.entries.values())if(entry.unlock===trigger&&this.unlock(entry.id))count++;
    return count;

  }

    markRead(id){
    if(!this.unlocked.has(id))return false;
    this.read.add(id);
    return true;

  }

    list(category=null){
    return [...this.entries.values()].filter(entry=>this.unlocked.has(entry.id)&&(!category||entry.category===category)).map(entry=>({
      ...entry,
      read:this.read.has(entry.id)
    }
    ));

  }

    progress(){
    return {
      unlocked:this.unlocked.size,
      total:this.entries.size,
      percent:Math.round(this.unlocked.size/this.entries.size*100)
    }
    ;

  }

    serialize(){
    return {
      unlocked:[...this.unlocked],
      read:[...this.read]
    }
    ;

  }

    restore(data={

  }
  ){
    for(const id of data.unlocked||[])if(this.entries.has(id))this.unlocked.add(id);
    for(const id of data.read||[])if(this.entries.has(id))this.read.add(id);

  }


}
