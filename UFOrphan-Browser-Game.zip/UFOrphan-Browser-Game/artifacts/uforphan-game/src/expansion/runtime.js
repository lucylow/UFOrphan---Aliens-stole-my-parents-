import {
   NPCSystem
}
 from "./npc-system.js";

import {
   EnvironmentSystem,
   DynamicPlatformSystem
}
 from "./environment.js";

import {
   LootSystem
}
 from "./loot-system.js";

import {
   CombatSystem
}
 from "./combat-system.js";

import {
   CompanionSystem
}
 from "./companion-system.js";

import {
   MapSystem
}
 from "./map-system.js";

import {
   GameDirector
}
 from "./game-director.js";

import {
   WorldEventSystem
}
 from "./world-event-system.js";

import {
   WeatherSystem
}
 from "./weather-system.js";

import {
   CheckpointSystem
}
 from "./checkpoint-system.js";

import {
   BossPhaseController
}
 from "./boss-phases.js";

import {
   PhotoMode
}
 from "./photo-mode.js";

export class ExpansionRuntime {

    constructor(world,
  profile) {

        this.world=world;

        this.profile=profile;

        const definition=world.data.expansion||{

    }
    ;

        this.npcs=new NPCSystem(profile.events,
    definition.npcs||[]);

        this.beacons=(definition.beacons||[]).map(beacon=>({...beacon}));

        this.environment=new EnvironmentSystem(profile.events,
    definition.environment||{

    }
    );

        this.platforms=new DynamicPlatformSystem(definition.movingPlatforms||[]);

        this.loot=new LootSystem(profile.events,
    profile.inventory,
    (world.index+1)*9271);

        this.combat=new CombatSystem(profile.events);

        this.companion=profile.companions;

        this.map=new MapSystem(profile.events,
    world.data);

        this.director=new GameDirector();

        this.worldEvents=new WorldEventSystem(profile.events);

        this.weather=new WeatherSystem(definition.weather==="low-gravity"?"low_gravity":definition.weather||"clear",
    world.index+11);

        this.checkpoints=new CheckpointSystem();

        this.photoMode=new PhotoMode();

        this.bossController=world.boss?new BossPhaseController(definition.bossType||"warden",
    profile.events):null;

        this.previousPlatforms=this.platforms.snapshot();

        this.platforms.platforms.forEach(platform=>world.platforms.push(platform));

        this.interactionHint=null;

        this.lastCheckpoint=false;

        this.profile.events.on("combat:kill",
    event=>{

            const target=event.payload.target;

            this.loot.dropFrom(target==="boss"?"boss":target==="brute"?"brute":"drone",
      event.payload.x||world.camera+480,
      390);


    }
    );

        this.profile.events.on("world:checkpoint",
    ()=>this.lastCheckpoint=true);


  }

    update(player) {

        this.previousPlatforms=this.platforms.snapshot();

        this.platforms.update();

        this.platforms.carryPlayer(player,
    this.previousPlatforms);

        this.environment.update(player,
    this.world);

        this.weather.update();

        this.weather.apply(player);

        this.companion.update(player,
    this.world);

        this.npcs.update(player);

        this.loot.update(player,
    this.world);

        this.map.update(player);

        this.combat.update();

        this.director.update(player,
    this.world);

        this.worldEvents.update();

        this.profile.challenges.update();

        this.profile.upgrades.update();

        if(this.bossController&&this.world.boss&&!this.world.boss.dead)this.bossController.update(this.world.boss,
    this.world,
    player);

        this.profile.statistics.update(player);

        this.profile.applyPlayer(player);

        if(this.world.checkpoint.active&&!this.lastCheckpoint){

            this.checkpoints.activate(`level-${this.world.index}`,
      player,
      this.world);

            this.profile.events.emit("world:checkpoint",
      {
        level:this.world.index
      }
      );

            this.lastCheckpoint=true;


    }

        if(this.npcs.nearby)this.interactionHint=this.npcs.nearby;

        else this.interactionHint=null;


  }

    interact(player) {

        const npc=this.npcs.interact(player,
    this.profile.quests);

        if(npc)return {
      type:"npc",
      ...npc
    }
    ;

        const station=(this.world.data.expansion?.stations||[]).find(item=>Math.abs(item.x-player.x)<55&&Math.abs(item.y-player.y)<70);

        if(station){
      this.profile.crafting.setStation(station.type);
      return {
        type:"station",
        station,
        recipes:this.profile.crafting.availableRecipes()
      }
      ;

    }

        const beacon=this.beacons.find(item=>!item.active&&Math.abs(item.x-player.x)<60);

        if(beacon){
      beacon.active=true;
      this.profile.quests.addProgressByTag("beacon",
      1);
      if(beacon.kind==="transmitter")this.profile.quests.addProgressByTag("transmitter",
      1);
      if(beacon.kind==="badge"){
        this.profile.inventory.add("old_badge",
        1);
        this.profile.quests.addProgressByTag("badge_returned",
        1);

      }
      if(beacon.kind==="dish"){
        this.profile.quests.addProgressByTag("dish_aligned",
        1);
        if(this.beacons.filter(item=>item.kind==="dish"&&item.active).length===3)this.profile.quests.addProgressByTag("signal_sent",
        1);

      }
      this.profile.events.emit("beacon:activated",
      {
        id:beacon.id
      }
      );
      return {
        type:"beacon",
        beacon
      }
      ;

    }

        return null;


  }

    draw(ctx,
  camera) {

        this.platforms.draw(ctx,
    camera);

        this.environment.draw(ctx,
    camera);

        this.npcs.draw(ctx,
    camera);

        this.loot.draw(ctx,
    camera);

        this.companion.draw(ctx,
    camera);

        this.combat.draw(ctx,
    camera);

        this.worldEvents.draw(ctx);

        this.weather.draw(ctx);

        if(this.interactionHint){

            ctx.save();

            ctx.fillStyle="rgba(12,20,48,.8)";

            ctx.fillRect(this.interactionHint.x-camera-42,
      this.interactionHint.y-55,
      84,
      24);

            ctx.fillStyle="#ffffff";

            ctx.font="bold 11px sans-serif";

            ctx.textAlign="center";

            ctx.fillText("E  TALK",
      this.interactionHint.x-camera,
      this.interactionHint.y-39);

            ctx.restore();


    }


  }

    serialize() {

        return {

            npcs:this.npcs.serialize(),
      beacons:this.beacons.map(beacon=>({id:beacon.id,active:beacon.active})),
      environment:this.environment.serialize(),

            loot:this.loot.serialize(),
      combat:this.combat.serialize(),
      map:this.map.serialize(),

            director:this.director.snapshot(),
      worldEvents:this.worldEvents.serialize(),

            weather:this.weather.serialize(),
      checkpoints:this.checkpoints.serialize()

    }
    ;


  }

    restore(data={

  }
  ) {

        this.npcs.restore(data.npcs||[]);
        for(const state of data.beacons||[]){
      const beacon=this.beacons.find(item=>item.id===state.id);
      if(beacon)beacon.active=Boolean(state.active);
    }

        this.environment.restore(data.environment||{

    }
    );

        this.loot.restore(data.loot||{

    }
    );

        this.combat.restore(data.combat||{

    }
    );

        this.map.restore(data.map||{

    }
    );

        this.director.restore(data.director||{

    }
    );

        this.worldEvents.restore(data.worldEvents||{

    }
    );

        this.weather.restore(data.weather||{

    }
    );

        this.checkpoints.restoreData(data.checkpoints||{

    }
    );


  }


}
