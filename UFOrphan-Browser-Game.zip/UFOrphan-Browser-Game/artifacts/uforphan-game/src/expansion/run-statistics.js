/** Session metrics used for score screens and optional achievements. */
export class RunStatistics {

    constructor(){
    this.reset();

  }

    reset(){
    this.startedAt=Date.now();
    this.frames=0;
    this.distance=0;
    this.stars=0;
    this.keys=0;
    this.damageTaken=0;
    this.enemiesDefeated=0;
    this.secretsFound=0;
    this.deaths=0;
    this.timePaused=0;
    this.lastX=null;

  }

    update(player){
    this.frames++;
    if(this.lastX!==null)this.distance+=Math.abs(player.x-this.lastX);
    this.lastX=player.x;

  }

    collect(type,
  count=1){
    if(type==="star")this.stars+=count;
    else if(type==="key")this.keys+=count;
    else if(type==="secret")this.secretsFound+=count;

  }

    damage(amount=1){
    this.damageTaken+=amount;

  }

    kill(){
    this.enemiesDefeated++;

  }

    death(){
    this.deaths++;

  }

    elapsed(){
    return Math.max(0,
    (Date.now()-this.startedAt-this.timePaused)/1000);

  }

    score(){
    return Math.round(this.stars*100+this.keys*250+this.enemiesDefeated*50+this.secretsFound*500-this.damageTaken*35-this.deaths*200+Math.max(0,
    600-this.elapsed())*2);

  }

    summary(){
    return {
      score:this.score(),
      seconds:this.elapsed(),
      stars:this.stars,
      keys:this.keys,
      enemies:this.enemiesDefeated,
      secrets:this.secretsFound,
      damage:this.damageTaken,
      deaths:this.deaths,
      distance:Math.round(this.distance)
    }
    ;

  }



  restore(data={}) {
    this.stars=data.stars||0;
    this.keys=data.keys||0;
    this.enemiesDefeated=data.enemies||0;
    this.secretsFound=data.secrets||0;
    this.damageTaken=data.damage||0;
    this.deaths=data.deaths||0;
    this.distance=data.distance||0;
    this.startedAt=Date.now()-(data.seconds||0)*1000;
  }

}
