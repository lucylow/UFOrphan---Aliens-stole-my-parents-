/** Checkpoint snapshots restore the player safely without rewinding story flags. */
export class CheckpointSystem {

    constructor(){
    this.current=null;
    this.history=[];
    this.deathCount=0;

  }

    activate(id,
  player,
  world){
    this.current={
      id,
      x:player.x,
      y:player.y,
      health:player.health,
      stars:player.stars,
      keys:player.keys,
      at:Date.now(),
      worldIndex:world.index
    }
    ;
    this.history.push({
      ...this.current
    }
    );
    return this.current;

  }

    restore(player,
  world){
    if(!this.current)return false;
    player.x=this.current.x;
    player.y=this.current.y;
    player.vx=0;
    player.vy=0;
    player.health=Math.max(1,
    Math.min(player.maxHealth,
    this.current.health));
    player.dead=false;
    player.invulnerable=90;
    this.deathCount++;
    world.projectiles.length=0;
    return true;

  }

    reset(){
    this.current=null;
    this.history.length=0;
    this.deathCount=0;

  }

    serialize(){
    return {
      current:this.current,
      history:this.history.slice(-20),
      deathCount:this.deathCount
    }
    ;

  }

    restoreData(data={

  }
  ){
    this.current=data.current||null;
    this.history=data.history||[];
    this.deathCount=data.deathCount||0;

  }


}
