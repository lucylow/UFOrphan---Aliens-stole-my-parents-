/** Weather patterns are cosmetic plus a small set of predictable physics modifiers. */
export const WEATHER={
  clear:{
    wind:0,
    gravity:1,
    visibility:1
  }
  ,
  ion:{
    wind:.12,
    gravity:1,
    visibility:.75
  }
  ,
  low_gravity:{
    wind:.03,
    gravity:.7,
    visibility:1
  }
  ,
  dust:{
    wind:.2,
    gravity:1,
    visibility:.62
  }
  ,
  aurora:{
    wind:0,
    gravity:1,
    visibility:1
  }

}
;

export class WeatherSystem {

    constructor(type="clear",
  seed=1){
    this.type=WEATHER[type]?type:"clear";
    this.seed=seed;
    this.elapsed=0;
    this.intensity=0;
    this.transition=null;

  }

    set(type,
  duration=3){
    if(!WEATHER[type])return false;
    this.transition={
      from:this.type,
      to:type,
      duration,
      elapsed:0
    }
    ;
    return true;

  }

    update(delta=1/60){
    this.elapsed+=delta;
    if(this.transition){
      this.transition.elapsed+=delta;
      if(this.transition.elapsed>=this.transition.duration){
        this.type=this.transition.to;
        this.transition=null;

      }

    }
    this.intensity=(Math.sin(this.elapsed*.17)+1)/2;
    return this.modifiers();

  }

    modifiers(){
    return WEATHER[this.type];

  }

    apply(player){
    const weather=this.modifiers();
    player.vx+=weather.wind*.05;
    player.vy*=weather.gravity===1?1:weather.gravity;

  }

    draw(ctx){
    if(this.type==="dust"){
      ctx.fillStyle="rgba(215,184,139,.07)";
      ctx.fillRect(0,
      0,
      960,
      540);

    }
    else if(this.type==="aurora"){
      const gradient=ctx.createLinearGradient(0,
      0,
      960,
      0);
      gradient.addColorStop(0,
      "rgba(92,245,221,.04)");
      gradient.addColorStop(.5,
      `rgba(173,111,245,${.06+this.intensity*.08})`);
      gradient.addColorStop(1,
      "rgba(92,245,221,.04)");
      ctx.fillStyle=gradient;
      ctx.fillRect(0,
      0,
      960,
      220);

    }

  }

    serialize(){
    return {
      type:this.type,
      seed:this.seed,
      elapsed:this.elapsed
    }
    ;

  }

    restore(data={

  }
  ){
    this.type=WEATHER[data.type]?data.type:"clear";
    this.seed=data.seed||1;
    this.elapsed=data.elapsed||0;

  }


}
