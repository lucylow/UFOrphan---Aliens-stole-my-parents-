import { GAME, COLORS } from "./config.js";
import { LEVELS } from "./levels.js";
import { Enemy, Boss } from "./enemies.js";
import { hit } from "./player.js";
import { ExpansionRuntime } from "./expansion/runtime.js";

export class World {
  constructor(index, audio, particles, profile=null) {
    this.index=index;this.data=LEVELS[index];this.width=this.data.width;
    this.audio=audio;this.particles=particles;
    this.platforms=this.data.platforms.map(([x,y,w,h])=>({x,y,w,h}));
    this.stars=this.data.stars.map(([x,y])=>({x,y,r:9,collected:false,phase:Math.random()*5}));
    this.keys=this.data.keys.map(([x,y])=>({x,y,w:16,h:20,collected:false}));
    this.enemies=this.data.enemies.map(([type,x,y])=>new Enemy(type,x,y));
    this.hazards=this.data.hazards.map(([x,y,w,h])=>({x,y,w,h}));
    this.projectiles=[];this.checkpoint={x:this.data.checkpoint[0],y:this.data.checkpoint[1],active:false};
    this.exit={x:this.data.exit[0],y:this.data.exit[1],w:38,h:80};
    this.boss=this.data.boss?new Boss(this.data.boss):null;
    this.camera=0;this.elapsed=0;
    this.profile=profile;
    this.expansion=profile?new ExpansionRuntime(this,profile):null;
  }

  update(player) {
    this.elapsed++;
    this.enemies.forEach(e=>{if(!e.dead)e.update(this,player);});
    this.enemies=this.enemies.filter(e=>!e.dead);
    if(this.boss&&!this.boss.dead)this.boss.update(this,player);
    for(const p of this.projectiles) {
      p.x+=p.vx;p.y+=p.vy;p.life--;
      if(p.owner==="enemy"&&hit(p,player)) {player.takeDamage(this.audio,this.particles);p.life=0;}
      if(p.owner==="player") {
        for(const enemy of this.enemies) if(!enemy.dead&&hit(p,enemy)){const amount=p.damage||1;enemy.damage(this,amount);this.expansion?.combat.onDamage(enemy,amount,enemy.x+enemy.w/2,enemy.y);if(enemy.dead)this.expansion?.combat.onKill({type:enemy.type,x:enemy.x,y:enemy.y});if((p.pierce||0)>0)p.pierce--;else p.life=0;break;}
        if(this.boss&&!this.boss.dead&&hit(p,this.boss)){const amount=p.damage||1;this.boss.damage(this,amount);this.expansion?.combat.onDamage(this.boss,amount,this.boss.x+this.boss.w/2,this.boss.y);if(this.boss.dead)this.expansion?.combat.onKill({type:"boss",x:this.boss.x,y:this.boss.y});if((p.pierce||0)>0)p.pierce--;else p.life=0;}
      }
    }
    this.projectiles=this.projectiles.filter(p=>p.life>0&&p.x>-50&&p.x<this.width+50);
    for(const star of this.stars) {
      star.phase+=.06;
      if(!star.collected&&Math.hypot(player.x+player.w/2-star.x,player.y+player.h/2-star.y)<25) {
        star.collected=true;player.stars++;this.profile?.statistics.collect("star",1);this.profile?.inventory.add("stardust",1);this.profile?.challenges.addProgress("stars",1);this.profile?.evaluateAchievements();this.audio.collect();this.particles.burst(star.x,star.y,COLORS.gold,8);
      }
    }
    for(const key of this.keys) if(!key.collected&&hit(player,{x:key.x,y:key.y,w:key.w,h:key.h})) {
      key.collected=true;player.keys++;this.profile?.statistics.collect("key",1);this.audio.collect();this.particles.burst(key.x,key.y,COLORS.cyan,9);
    }
    for(const hazard of this.hazards) if(hit(player,hazard)) player.takeDamage(this.audio,this.particles);
    if(!this.checkpoint.active&&player.x>this.checkpoint.x) {
      this.checkpoint.active=true;this.particles.burst(this.checkpoint.x,this.checkpoint.y,"#73f0ed",18);
    }
    if(this.expansion)this.expansion.update(player);
    this.camera=Math.max(0,Math.min(this.width-GAME.width,player.x-GAME.width*.36));
  }

  canExit() {
    const keysNeeded=this.keys.length;
    const keysCollected=this.keys.filter(k=>k.collected).length;
    const bossDone=!this.boss||this.boss.dead;
    return keysCollected>=keysNeeded&&bossDone;
  }

  draw(ctx) {
    this.drawBackground(ctx);
    ctx.save();ctx.translate(-this.camera,0);
    this.drawPlatforms(ctx);
    this.drawHazards(ctx);
    this.drawDecorations(ctx);
    this.drawCheckpoint(ctx);
    this.drawExit(ctx);
    this.stars.forEach(s=>{if(!s.collected)this.drawStar(ctx,s);});
    this.keys.forEach(k=>{if(!k.collected)this.drawKey(ctx,k);});
    this.enemies.forEach(e=>e.draw(ctx,this.camera));
    if(this.boss&&!this.boss.dead)this.boss.draw(ctx,this.camera);
    this.projectiles.forEach(p=>this.drawProjectile(ctx,p));
    if(this.expansion)this.expansion.draw(ctx,this.camera);
    ctx.restore();
  }

  interact(player){return this.expansion?this.expansion.interact(player):null;}

  drawBackground(ctx) {
    const gradient=ctx.createLinearGradient(0,0,0,GAME.height);
    gradient.addColorStop(0,this.data.sky[0]);gradient.addColorStop(1,this.data.sky[1]);
    ctx.fillStyle=gradient;ctx.fillRect(0,0,GAME.width,GAME.height);
    for(let i=0;i<100;i++) {
      const x=((i*173+Math.floor(this.camera*.18))%(GAME.width+40))-20;
      const y=(i*83)%360;
      ctx.globalAlpha=.25+((i*7)%10)/20;
      ctx.fillStyle=i%8===0?COLORS.cyan:"#e7eaff";
      ctx.fillRect(x,y, i%6===0?3:2, i%6===0?3:2);
    }
    ctx.globalAlpha=1;
    this.drawPlanet(ctx);
  }

  drawPlanet(ctx) {
    const type=this.data.background;
    if(type==="suburb") {
      ctx.fillStyle="#202d54";ctx.fillRect(0,405,960,75);
      for(let i=0;i<6;i++){ctx.fillStyle=i%2?"#35446f":"#29375e";ctx.fillRect(i*190-30,355,145,80);ctx.fillStyle="#ffd76d";ctx.fillRect(i*190+10,380,14,17);}
      ctx.fillStyle="#7187b7";ctx.beginPath();ctx.arc(780,125,48,0,Math.PI*2);ctx.fill();
    } else {
      const palettes={mall:"#1c5370",scrap:"#442d50",crystal:"#315a79",archive:"#2d426b",organic:"#2f684e",command:"#43254f",ship:"#2c3159"};
      ctx.fillStyle=palettes[type]||"#2c3159";
      ctx.beginPath();ctx.arc(780,150,92,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle="rgba(142,239,237,.25)";ctx.lineWidth=10;ctx.beginPath();ctx.ellipse(780,150,135,35,-.2,0,Math.PI*2);ctx.stroke();
    }
  }

  drawPlatforms(ctx) {
    for(const p of this.platforms) {
      ctx.fillStyle="#25345d";ctx.fillRect(p.x,p.y,p.w,p.h);
      ctx.fillStyle="#7187bd";ctx.fillRect(p.x,p.y,p.w,5);
      ctx.fillStyle="rgba(130,162,230,.16)";
      for(let x=p.x+12;x<p.x+p.w-8;x+=28)ctx.fillRect(x,p.y+14,12,3);
    }
  }

  drawHazards(ctx) {
    for(const h of this.hazards) {
      ctx.fillStyle="#311d4b";ctx.fillRect(h.x,h.y,h.w,h.h);
      ctx.fillStyle="#ff668c";
      for(let x=h.x;x<h.x+h.w;x+=16){ctx.beginPath();ctx.moveTo(x,h.y);ctx.lineTo(x+8,h.y-13);ctx.lineTo(x+16,h.y);ctx.fill();}
    }
  }

  drawDecorations(ctx) {
    for(let x=80;x<this.width;x+=260) {
      const y=440+Math.sin(x)*6;
      ctx.fillStyle="rgba(109,240,237,.13)";ctx.fillRect(x,y,22,40);
      ctx.fillStyle="rgba(109,240,237,.32)";ctx.fillRect(x+7,y-10,8,12);
    }
  }

  drawCheckpoint(ctx) {
    const c=this.checkpoint;
    ctx.fillStyle=c.active?"#73f0ed":"#64739b";
    ctx.fillRect(c.x,c.y-55,4,55);
    ctx.beginPath();ctx.moveTo(c.x+4,c.y-54);ctx.lineTo(c.x+35,c.y-43);ctx.lineTo(c.x+4,c.y-32);ctx.fill();
  }

  drawExit(ctx) {
    const ready=this.canExit();
    ctx.save();ctx.globalAlpha=ready?1:.35;
    ctx.fillStyle=ready?"#73f0ed":"#7a83a8";
    ctx.beginPath();ctx.ellipse(this.exit.x+19,this.exit.y+40,22,40,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#152247";ctx.beginPath();ctx.ellipse(this.exit.x+19,this.exit.y+40,13,31,0,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  drawStar(ctx,s) {
    const pulse=Math.sin(s.phase)*2;
    ctx.save();ctx.translate(s.x,s.y);ctx.rotate(s.phase*.2);
    ctx.fillStyle=COLORS.gold;ctx.shadowColor=COLORS.gold;ctx.shadowBlur=15;
    ctx.beginPath();
    for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5;const r=i%2?4:10+pulse;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}
    ctx.closePath();ctx.fill();ctx.restore();
  }

  drawKey(ctx,k) {
    ctx.fillStyle=COLORS.cyan;ctx.fillRect(k.x,k.y,7,20);ctx.fillRect(k.x+5,k.y+2,12,5);ctx.fillRect(k.x+11,k.y+7,5,5);
  }

  drawProjectile(ctx,p) {
    ctx.fillStyle=p.color||(p.owner==="player"?"#73f0ed":"#ff6a94");
    ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=12;
    ctx.beginPath();ctx.arc(p.x,p.y,5,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }
}
