import { GAME } from "./config.js";
import { Input } from "./input.js";
import { AudioSystem } from "./audio.js";
import { SaveManager } from "./save.js";
import { ParticleSystem } from "./particles.js";
import { Player } from "./player.js";
import { World } from "./world.js";
import { Renderer } from "./renderer.js";
import { UI } from "./ui.js";
import { LEVELS, LEVEL_COUNT } from "./levels.js";
import { STORY } from "./dialogue.js";
import { ExpansionProfile } from "./expansion/profile.js";

const canvas=document.getElementById("game");
const input=new Input();
const audio=new AudioSystem();
const save=new SaveManager();
let profile=new ExpansionProfile(save.data.expansion||{});
const particles=new ParticleSystem();
const renderer=new Renderer(canvas);
const ui=new UI();
let world=null,player=null,levelIndex=0;
let mode="menu",lastTime=0,accumulator=0;
const STEP=1000/60;

audio.enabled=save.data.sound;
document.getElementById("soundButton").addEventListener("click",()=>{
  const enabled=audio.toggle();save.setSound(enabled);
  document.getElementById("soundButton").textContent=enabled?"♫":"♪";
});
document.getElementById("pauseButton").addEventListener("click",togglePause);

function bootLevel(index) {
  levelIndex=Math.min(index,LEVEL_COUNT-1);
  world=new World(levelIndex,audio,particles,profile);
  player=new Player(55,420);
  player.onDamage=()=>{profile.challenges.recordDamage();profile.statistics.damage();};
  profile.applyPlayer(player);
  mode="playing";
  ui.hidePanel();ui.updateHUD(player,world);
  audio.unlock();
}

function startGame() {
  levelIndex=Math.min(save.data.unlockedLevel,LEVEL_COUNT-1);
  if(levelIndex>=LEVEL_COUNT)levelIndex=0;
  bootLevel(levelIndex);
  ui.showPanel({
    eyebrow:`CHAPTER ${LEVELS[levelIndex].chapter}`,
    title:LEVELS[levelIndex].name,
    text:LEVELS[levelIndex].dialogue.join(" "),
    symbol:"✦",
    actions:[{label:"LET'S GO →",primary:true,onClick:()=>{audio.click();ui.hidePanel();}}]
  });
}

function togglePause() {
  if(mode==="playing") {
    mode="paused";
    ui.showPanel({eyebrow:"PAUSED",title:"Catch your breath, space ranger.",text:"The aliens are probably arguing about parking. Take your time.",symbol:"Ⅱ",
      actions:[
        {label:"FIELD PACK",onClick:showInventory},
        {label:"MISSION LOG",onClick:showMissions},
        {label:"RESUME",primary:true,onClick:()=>{mode="playing";ui.hidePanel();}},
        {label:"RESTART LEVEL",onClick:()=>bootLevel(levelIndex)},
        {label:"MAIN MENU",onClick:showMenu}
      ]});
  } else if(mode==="paused") {mode="playing";ui.hidePanel();}
}

function showMenu() {
  mode="menu";
  ui.showPanel({eyebrow:"A VERY BAD NIGHT",title:STORY.intro.title,text:STORY.intro.text,symbol:"✦",
    actions:[
      {label:"START RESCUE →",primary:true,onClick:startGame},
      {label:"HOW TO PLAY",onClick:showInstructions},
      {label:"RESET SAVE",onClick:()=>{save.reset();profile=new ExpansionProfile();showMenu();}}
    ]});
}

function showInstructions() {
  ui.showPanel({eyebrow:"FIELD MANUAL",title:"A few things Fiona should know.",text:"Move with ← → or A / D; jump with SPACE, W or ↑; and fire with X or J. Press E / ENTER near a character, beacon, or station to interact. Use the field-pack icon to manage items and the mission icon to track objectives. Collect every keycard to unlock the portal. On phones, use the on-screen controls.",
    symbol:"⌁",actions:[{label:"GOT IT",primary:true,onClick:showMenu}]});
}

function persistProfile() {
  save.data.expansion=profile.serialize();
  ui.setSaved(save.write());
}

function showInventory() {
  if(mode==="playing")mode="paused";
  const items=profile.inventory.list();
  const text=items.length?items.map(slot=>`${slot.item.name} × ${slot.count} — ${slot.item.description}`).join("\n"):`Your field pack is empty. Find materials and supplies while exploring.`;
  const actions=[{label:"USE MED PATCH",onClick:()=>{profile.inventory.use("med_patch",{player});persistProfile();showInventory();}}];
  if(profile.inventory.has("plasma_lens"))actions.push({label:"EQUIP PLASMA LENS",onClick:()=>{profile.inventory.equip("plasma_lens","weapon");profile.applyPlayer(player);persistProfile();showInventory();}});
  if(profile.inventory.has("double_jump"))actions.push({label:"EQUIP JUMP SERVO",onClick:()=>{profile.inventory.equip("double_jump","boots");profile.applyPlayer(player);persistProfile();showInventory();}});
  actions.push({label:"CLOSE",primary:true,onClick:()=>{mode=world?"playing":"menu";ui.hidePanel();}});
  ui.showPanel({eyebrow:"FIELD PACK",title:`${profile.inventory.slotsUsed()} / ${profile.inventory.capacity} SLOTS`,text,symbol:"▣",actions});
}

function showMissions() {
  if(mode==="playing")mode="paused";
  const quests=profile.quests.list();
  const text=quests.map(quest=>{const objectives=profile.quests.objectiveSummary(quest.id).map(item=>`${item.done?"✓":"○"} ${item.description}: ${item.progress}/${item.target}`).join("\n");return `${quest.title} [${quest.state.status.toUpperCase()}]\n${quest.description}\n${objectives}`;}).join("\n\n");
  ui.showPanel({eyebrow:"MISSION LOG",title:"Promises made across the galaxy",text:text||"No missions discovered yet. Talk to the locals.",symbol:"☷",actions:[{label:"CLOSE",primary:true,onClick:()=>{mode=world?"playing":"menu";ui.hidePanel();}}]});
}

function showInteraction(result) {
  if(!result)return;
  mode="paused";
  if(result.type==="npc"){
    const questText=result.questResult?.ok?"\n\nNEW MISSION ADDED TO YOUR LOG.":"";
    ui.showPanel({eyebrow:result.role.toUpperCase(),title:result.npc.kind.toUpperCase(),text:result.line+questText,symbol:"✦",actions:[{label:"FIELD PACK",onClick:showInventory},{label:"MISSION LOG",onClick:showMissions},{label:"CONTINUE",primary:true,onClick:()=>{mode="playing";ui.hidePanel();}}]});
  } else if(result.type==="station"){
    const recipes=result.recipes||[];
    ui.showPanel({eyebrow:"CRAFTING STATION",title:result.station.type.toUpperCase(),text:recipes.map(recipe=>`${recipe.name}: ${Object.entries(recipe.ingredients).map(([id,count])=>`${id} × ${count}`).join(", ")} — ${recipe.canCraft?"READY":"MISSING MATERIALS"}`).join("\n")||"No recipes available at this station.",symbol:"⚒",actions:[...recipes.slice(0,3).map(recipe=>({label:`CRAFT ${recipe.name.toUpperCase()}`,onClick:()=>{const crafted=profile.crafting.craft(recipe.id);persistProfile();showInteraction({type:"station",station:result.station,recipes:profile.crafting.availableRecipes()});}})),{label:"CLOSE",primary:true,onClick:()=>{mode="playing";ui.hidePanel();}}]});
  } else if(result.type==="beacon"){
    ui.showPanel({eyebrow:"RELAY BEACON",title:"Signal strengthened",text:"The relay hums to life. Somewhere, a navigation display just gained a little more hope.",symbol:"⌁",actions:[{label:"CONTINUE",primary:true,onClick:()=>{mode="playing";ui.hidePanel();}}]});
  }
}

function levelComplete() {
  mode="transition";
  profile.challenges.addProgress("finish",1);
  const stars=world.stars.filter(s=>s.collected).length;
  save.completeLevel(levelIndex,stars);
  profile.completeLevel(levelIndex);
  profile.progression.addXP(80+stars*10);
  profile.codex.unlockByTrigger(`level:${levelIndex}`);
  persistProfile();
  if(levelIndex===LEVEL_COUNT-1) {
    save.data.totalRescued=true;save.write();audio.win();
    ui.showPanel({eyebrow:"MISSION ACCOMPLISHED",title:STORY.ending.title,text:STORY.ending.text,symbol:"♥",
      actions:[
        {label:"PLAY AGAIN",primary:true,onClick:()=>{save.reset();profile=new ExpansionProfile();bootLevel(0);}},
        {label:"MAIN MENU",onClick:showMenu}
      ]});
  } else {
    audio.win();
    ui.showPanel({eyebrow:"SECTOR CLEARED",title:"One step closer to home.",text:`${LEVELS[levelIndex].name} complete. Fiona collected ${stars} of ${world.stars.length} stardust fragments. ${STORY.chapters[levelIndex+1]?.text || "The signal points deeper into the galaxy. Fiona keeps moving."}`,
      symbol:"✦",actions:[{label:"NEXT CHAPTER →",primary:true,onClick:()=>bootLevel(levelIndex+1)},{label:"REPLAY",onClick:()=>bootLevel(levelIndex)}]});
  }
}

function gameOver() {
  mode="gameover";
  profile.statistics.death();
  ui.showPanel({eyebrow:"SIGNAL LOST",title:"Fiona needs a minute.",text:"The galaxy is still out there, and so are your parents. Give it another try.",symbol:"♡",
    actions:[{label:"TRY AGAIN",primary:true,onClick:()=>bootLevel(levelIndex)},{label:"MAIN MENU",onClick:showMenu}]});
}

function update() {
  if(mode!=="playing"||!world||!player)return;
  player.update(input,world,audio,particles);
  world.update(player);
  if(input.wasPressed("interact"))showInteraction(world.interact(player));
  particles.update();
  if(player.dead){gameOver();return;}
  const portal={...world.exit};
  if(player.x+player.w>portal.x&&player.x<portal.x+portal.w&&player.y+player.h>portal.y&&player.y<portal.y+portal.h&&world.canExit()) {
    levelComplete();return;
  }
  ui.updateHUD(player,world);
}

function render() {
  if(world&&player)renderer.draw(world,player,particles);
  else drawTitleScene();
}

function drawTitleScene() {
  const ctx=renderer.ctx;
  renderer.clear();
  const g=ctx.createLinearGradient(0,0,960,540);
  g.addColorStop(0,"#111c43");g.addColorStop(1,"#3a2358");
  ctx.fillStyle=g;ctx.fillRect(0,0,960,540);
  for(let i=0;i<120;i++){ctx.fillStyle=i%7===0?"#73f0ed":"#d9e9ff";ctx.globalAlpha=.3+(i%5)*.12;ctx.fillRect((i*137)%960,(i*79)%470,2,2);}
  ctx.globalAlpha=1;
  ctx.fillStyle="#27355d";ctx.fillRect(0,470,960,70);
  ctx.fillStyle="#7187bd";ctx.fillRect(0,470,960,5);
  // Stylized tractor beam and UFO.
  ctx.fillStyle="rgba(115,240,237,.13)";ctx.beginPath();ctx.moveTo(420,120);ctx.lineTo(540,120);ctx.lineTo(640,470);ctx.lineTo(320,470);ctx.fill();
  ctx.fillStyle="#9bb5e8";ctx.beginPath();ctx.ellipse(480,120,120,34,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#73f0ed";ctx.beginPath();ctx.ellipse(480,105,48,25,0,Math.PI,Math.PI*2);ctx.fill();
  ctx.fillStyle="#ff77bd";ctx.fillRect(450,115,60,5);
  ctx.fillStyle="#ffd0ae";ctx.beginPath();ctx.arc(460,420,15,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#a65b43";ctx.fillRect(445,405,30,10);
  ctx.fillStyle="#54cbd0";ctx.fillRect(446,436,28,27);
  ctx.fillStyle="#f2c66d";ctx.fillRect(448,462,9,9);ctx.fillRect(464,462,9,9);
}

function frame(time) {
  if(!lastTime)lastTime=time;
  accumulator+=Math.min(100,time-lastTime);lastTime=time;
  while(accumulator>=STEP){update();accumulator-=STEP;}
  render();
  input.endFrame();
  requestAnimationFrame(frame);
}

document.getElementById("startButton").addEventListener("click",startGame);
document.getElementById("howButton").addEventListener("click",showInstructions);
document.getElementById("inventoryButton").addEventListener("click",showInventory);
document.getElementById("missionsButton").addEventListener("click",showMissions);
window.addEventListener("beforeunload",persistProfile);
showMenu();
requestAnimationFrame(frame);
