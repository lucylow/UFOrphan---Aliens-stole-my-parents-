/** Chapters 05–08: the second half of Fiona's rescue journey. */
export const EXPANSION_LEVELS = [
  {
    id:"crystal-grove", name:"THE CRYSTAL GROVE", chapter:"05",
    subtitle:"A valley that remembers every song", width:2850,
    sky:["#102b43","#385a79"], background:"crystal",
    objective:"Tune the three singing relays",
    platforms:[
      [0,480,420,60],[490,480,350,60],[910,480,420,60],[1400,480,370,60],[1840,480,430,60],[2330,480,520,60],
      [180,380,170,18],[430,320,160,18],[720,390,170,18],[1020,315,170,18],[1290,370,160,18],
      [1580,300,170,18],[1880,380,170,18],[2150,315,170,18],[2500,380,170,18]
    ],
    stars:[[220,340],[470,280],[760,350],[1060,275],[1330,330],[1620,260],[1920,340],[2190,275],[2540,340]],
    keys:[[800,435],[1740,435]],
    enemies:[["slime",570,438],["drone",1150,280],["slime",1990,438],["drone",2420,330]],
    hazards:[[420,480,70,60],[840,480,70,60],[1330,480,70,60],[1770,480,70,60],[2270,480,60,60]],
    checkpoint:[1840,420],exit:[2740,400],boss:null,
    dialogue:["The crystals are singing.","They are harmonizing with the relay signal.","Then let's give them a chorus."],
    expansion:{weather:"aurora",bossType:"warden",
      npcs:[{id:"noa-grove",kind:"noa",x:325,y:440},{id:"rivet-grove",kind:"rivet",x:1510,y:440}],
      stations:[{id:"grove-camp",type:"campfire",x:360,y:440},{id:"grove-kit",type:"field_kit",x:430,y:440}],
      beacons:[{id:"grove-relay-a",x:740,y:430,active:false},{id:"grove-relay-b",x:1450,y:430,active:false},{id:"grove-relay-c",x:2200,y:430,active:false}],
      environment:{weather:"clear",hazards:[{id:"singing-vent",kind:"vent",x:970,y:445,w:36,h:35,force:1},{id:"crystal-geyser",kind:"geyser",x:2030,y:445,w:45,h:35}],zones:[{id:"crystal-heart",name:"Crystal Heart",x:1800,y:0,w:500,h:540}]},
      movingPlatforms:[{id:"crystal-lift",x:1130,y:410,w:100,h:14,rangeY:55,speed:.018}]
    }
  },
  {
    id:"orbital-archive",name:"THE ORBITAL ARCHIVE",chapter:"06",
    subtitle:"Every secret has a filing cabinet",width:3150,
    sky:["#101d3d","#3c426e"],background:"archive",
    objective:"Recover the navigation records",
    platforms:[
      [0,480,380,60],[450,480,340,60],[860,480,400,60],[1330,480,370,60],[1770,480,390,60],[2230,480,390,60],[2690,480,460,60],
      [150,365,160,18],[410,300,170,18],[690,365,160,18],[970,290,170,18],[1240,355,160,18],
      [1510,290,170,18],[1800,355,170,18],[2080,285,170,18],[2370,355,170,18],[2700,290,170,18]
    ],
    stars:[[190,325],[450,260],[730,325],[1010,250],[1280,315],[1550,250],[1840,315],[2120,245],[2410,315],[2740,250]],
    keys:[[600,435],[1630,435],[2520,435]],
    enemies:[["drone",520,270],["drone",1080,260],["slime",1450,438],["drone",1940,300],["slime",2440,438],["drone",2850,260]],
    hazards:[[380,480,70,60],[790,480,70,60],[1260,480,70,60],[1700,480,70,60],[2160,480,70,60],[2620,480,70,60]],
    checkpoint:[1770,420],exit:[3050,400],boss:null,
    dialogue:["The archive stores every transmission in the sector.","Including the abduction orders?","Especially the abduction orders."],
    expansion:{weather:"low_gravity",
      npcs:[{id:"moth-archive",kind:"moth",x:260,y:440},{id:"pip-archive",kind:"pip",x:1880,y:440}],
      stations:[{id:"archive-bench",type:"workbench",x:300,y:440},{id:"archive-bench-two",type:"workbench",x:2300,y:440}],
      beacons:[{id:"archive-transmitter-a",kind:"transmitter",x:1360,y:430,active:false},{id:"archive-transmitter-b",kind:"transmitter",x:2160,y:430,active:false},{id:"archive-transmitter-c",kind:"transmitter",x:2800,y:430,active:false},{id:"archive-badge",kind:"badge",x:2500,y:430,active:false}],
      environment:{weather:"low-gravity",hazards:[{id:"archive-laser-a",kind:"electric",x:1120,y:410,w:65,h:45},{id:"archive-laser-b",kind:"electric",x:2190,y:410,w:65,h:45}],zones:[{id:"restricted-stack",name:"Restricted Stack",x:1400,y:0,w:900,h:540}]},
      movingPlatforms:[{id:"archive-platform-a",x:800,y:410,w:95,h:14,rangeX:55,speed:.014},{id:"archive-platform-b",x:2010,y:390,w:95,h:14,rangeY:65,speed:.02}]
    }
  },
  {
    id:"bio-dome",name:"THE BIO-DOME",chapter:"07",
    subtitle:"The plants are friendly. Mostly.",width:3300,
    sky:["#123b3c","#477b69"],background:"organic",
    objective:"Free the captured navigation crew",
    platforms:[
      [0,480,400,60],[470,480,350,60],[890,480,380,60],[1340,480,390,60],[1800,480,390,60],[2260,480,420,60],[2750,480,550,60],
      [130,370,170,18],[390,300,170,18],[670,370,170,18],[960,300,170,18],[1240,370,170,18],
      [1530,300,170,18],[1840,370,170,18],[2130,300,170,18],[2460,370,170,18],[2820,300,170,18]
    ],
    stars:[[170,330],[430,260],[710,330],[1000,260],[1280,330],[1570,260],[1880,330],[2170,260],[2500,330],[2860,260]],
    keys:[[760,435],[1690,435],[2600,435]],
    enemies:[["slime",560,438],["drone",1080,260],["slime",1450,438],["drone",2020,330],["slime",2380,438],["drone",2940,260]],
    hazards:[[400,480,70,60],[820,480,70,60],[1270,480,70,60],[1730,480,70,60],[2220,480,70,60],[2680,480,70,60]],
    checkpoint:[2260,420],exit:[3200,400],boss:null,
    dialogue:["The plants are reacting to the ship's signal.","They're scared.","Then we'll turn the signal off."],
    expansion:{weather:"clear",
      npcs:[{id:"noa-dome",kind:"noa",x:320,y:440},{id:"moth-dome",kind:"moth",x:1830,y:440}],
      stations:[{id:"dome-camp",type:"campfire",x:350,y:440}],
      environment:{weather:"clear",hazards:[{id:"vine-a",kind:"vent",x:1040,y:440,w:42,h:40,force:-1},{id:"vine-b",kind:"vent",x:2100,y:440,w:42,h:40,force:1},{id:"spore-cloud",kind:"geyser",x:2810,y:445,w:55,h:35}],zones:[{id:"garden-core",name:"Garden Core",x:2200,y:0,w:700,h:540}]},
      movingPlatforms:[{id:"leaf-lift-a",x:890,y:405,w:105,h:14,rangeY:65,speed:.015},{id:"leaf-lift-b",x:2460,y:410,w:105,h:14,rangeY:48,speed:.021}]
    }
  },
  {
    id:"eclipse-core",name:"THE ECLIPSE CORE",chapter:"08",
    subtitle:"The last door is a very large robot",width:2900,
    sky:["#120f2a","#4b2854"],background:"command",
    objective:"Defeat the Core Warden and choose your ending",
    platforms:[
      [0,480,470,60],[530,480,430,60],[1030,480,420,60],[1520,480,420,60],[2010,480,890,60],
      [180,365,170,18],[490,300,170,18],[810,365,170,18],[1130,300,170,18],[1450,365,170,18],
      [1760,300,170,18],[2070,365,170,18],[2400,300,170,18]
    ],
    stars:[[220,325],[530,260],[850,325],[1170,260],[1490,325],[1800,260],[2110,325],[2440,260]],
    keys:[[900,435],[1950,435]],
    enemies:[["drone",650,260],["slime",1080,438],["drone",1610,330],["slime",2190,438]],
    hazards:[[470,480,60,60],[960,480,70,60],[1450,480,70,60],[1940,480,70,60]],
    checkpoint:[1520,420],exit:[2780,400],boss:{x:2380,y:350,health:18},
    dialogue:["The Core Warden is the one who ordered the abduction.","Then it gets to explain itself.","Fiona, the signal is ready when you are."],
    expansion:{bossType:"queen",weather:"ion",
      npcs:[{id:"moth-core",kind:"moth",x:280,y:440},{id:"rivet-core",kind:"rivet",x:1580,y:440}],
      stations:[{id:"core-bench",type:"workbench",x:330,y:440}],
      beacons:[{id:"dish-a",kind:"dish",x:800,y:430,active:false},{id:"dish-b",kind:"dish",x:1550,y:430,active:false},{id:"dish-c",kind:"dish",x:2100,y:430,active:false}],
      environment:{weather:"ion-storm",hazards:[{id:"core-arc-a",kind:"electric",x:980,y:410,w:60,h:48},{id:"core-arc-b",kind:"electric",x:1850,y:410,w:60,h:48}],zones:[{id:"warden-arena",name:"Warden Arena",x:2200,y:0,w:680,h:540}]},
      movingPlatforms:[{id:"core-lift",x:1300,y:400,w:110,h:14,rangeY:45,speed:.022}]
    }
  }
];
