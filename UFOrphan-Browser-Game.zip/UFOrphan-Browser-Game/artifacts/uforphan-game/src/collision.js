/**
 * Reusable geometry helpers. All rectangles use top-left origin and positive dimensions.
 */
export const intersects = (a,b) =>
  a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;

export function overlapArea(a,b) {
  const width=Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x));
  const height=Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y));
  return width*height;
}
export function centerOf(rect) { return {x:rect.x+rect.w/2,y:rect.y+rect.h/2}; }
export function distance(a,b) { return Math.hypot(a.x-b.x,a.y-b.y); }
export function containsPoint(rect,point) {
  return point.x>=rect.x&&point.x<=rect.x+rect.w&&point.y>=rect.y&&point.y<=rect.y+rect.h;
}
export function expanded(rect,padding) {
  return {x:rect.x-padding,y:rect.y-padding,w:rect.w+padding*2,h:rect.h+padding*2};
}
export function sweptAABB(moving,dx,dy,target) {
  const xEntry=dx>0?(target.x-(moving.x+moving.w))/dx:(target.x+target.w-moving.x)/dx;
  const yEntry=dy>0?(target.y-(moving.y+moving.h))/dy:(target.y+target.h-moving.y)/dy;
  const xExit=dx>0?(target.x+target.w-moving.x)/dx:(target.x-(moving.x+moving.w))/dx;
  const yExit=dy>0?(target.y+target.h-moving.y)/dy:(target.y-(moving.y+moving.h))/dy;
  const entry=Math.max(Math.min(xEntry,xExit),Math.min(yEntry,yExit));
  const exit=Math.min(Math.max(xEntry,xExit),Math.max(yEntry,yExit));
  if(entry>exit||entry<0||entry>1)return null;
  return {time:entry,normal:Math.abs(xEntry)>Math.abs(yEntry)?{x:0,y:dy>0?-1:1}:{x:dx>0?-1:1,y:0}};
}
export function clampRect(rect,bounds) {
  return {x:Math.max(bounds.x,Math.min(bounds.x+bounds.w-rect.w,rect.x)),
    y:Math.max(bounds.y,Math.min(bounds.y+bounds.h-rect.h,rect.y)),w:rect.w,h:rect.h};
}
export function lineIntersectsRect(a,b,r) {
  const dx=b.x-a.x,dy=b.y-a.y;
  let t0=0,t1=1;
  const tests=[[-dx,a.x-r.x],[dx,r.x+r.w-a.x],[-dy,a.y-r.y],[dy,r.y+r.h-a.y]];
  for(const [p,q] of tests) {
    if(p===0&&q<0)return false;
    if(p!==0) {
      const t=q/p;
      if(p<0)t0=Math.max(t0,t);else t1=Math.min(t1,t);
      if(t0>t1)return false;
    }
  }
  return true;
}
export function nearest(rect,items,maxDistance=Infinity) {
  const origin=centerOf(rect);
  let winner=null,best=maxDistance;
  for(const item of items) {
    const d=distance(origin,centerOf(item));
    if(d<best){winner=item;best=d;}
  }
  return winner;
}
