import { GAME } from "./config.js";

export class Player {
  constructor(x,y) {
    this.x=x; this.y=y; this.w=27; this.h=39;
    this.vx=0; this.vy=0; this.onGround=false;
    this.health=3; this.invulnerable=0; this.facing=1;
    this.cooldown=0; this.stars=0; this.keys=0;
    this.anim=0; this.dead=false;
    this.maxHealth=3;this.shieldTicks=0;this.extraJumpUnlocked=false;this.extraJumpAvailable=false;this.speedMultiplier=1;this.damageRecovery=90;this.weapon="star_blaster";
  }

  update(input, world, audio, particles) {
    if (this.dead) return;
    const left=input.isDown("left"), right=input.isDown("right");
    if (left !== right) {
      this.vx += left ? -.78 : .78;
      this.facing = left ? -1 : 1;
    } else this.vx *= GAME.friction;
    this.vx = Math.max(-GAME.playerSpeed*this.speedMultiplier,Math.min(GAME.playerSpeed*this.speedMultiplier,this.vx));

    if (input.wasPressed("jump") && (this.onGround || (this.extraJumpUnlocked && this.extraJumpAvailable))) {
      const wasGrounded=this.onGround;
      this.vy = -GAME.jumpPower; this.onGround=false;
      if(wasGrounded)this.extraJumpAvailable=this.extraJumpUnlocked;
      else this.extraJumpAvailable=false;
      audio.jump();
    }
    if(world.expansion){
      world.expansion.combat.configure(world.profile.inventory);
      if(input.wasPressed("blast"))world.expansion.combat.fire(this,world,audio);
    } else if (input.wasPressed("blast") && this.cooldown <= 0) {
      world.projectiles.push({x:this.x+(this.facing>0?this.w:-12),y:this.y+15,w:10,h:10,vx:this.facing*8.5,vy:0,life:65,owner:"player"});
      this.cooldown=GAME.blastCooldown; audio.blast();
    }

    this.vy=Math.min(GAME.maxFall,this.vy+GAME.gravity);
    this.x+=this.vx;
    this.resolveHorizontal(world.platforms);
    this.y+=this.vy;
    this.onGround=false;
    this.resolveVertical(world.platforms);
    if(this.onGround)this.extraJumpAvailable=this.extraJumpUnlocked;

    this.x=Math.max(0,Math.min(world.width-this.w,this.x));
    if (this.y>GAME.height+100) this.takeDamage(audio,particles,true);
    if (this.invulnerable>0) this.invulnerable--;
    if(this.shieldTicks>0)this.shieldTicks--;
    if (this.cooldown>0) this.cooldown--;
    this.anim += Math.abs(this.vx)*.12;
  }

  resolveHorizontal(platforms) {
    for (const p of platforms) {
      if (!hit(this,p)) continue;
      if (this.vx>0) this.x=p.x-this.w;
      else if (this.vx<0) this.x=p.x+p.w;
      this.vx=0;
    }
  }

  resolveVertical(platforms) {
    for (const p of platforms) {
      if (!hit(this,p)) continue;
      if (this.vy>0) { this.y=p.y-this.h; this.onGround=true; }
      else if (this.vy<0) this.y=p.y+p.h;
      this.vy=0;
    }
  }

  takeDamage(audio,particles,force=false) {
    if (this.invulnerable>0 && !force) return;
    if (this.shieldTicks>0 && !force) {
      this.shieldTicks=0;
      this.invulnerable=30;
      return;
    }
    this.onDamage?.();
    this.health--;
    this.invulnerable=this.damageRecovery||90;
    this.vy=-7; this.vx=-this.facing*4;
    audio.hurt(); particles.burst(this.x+this.w/2,this.y+this.h/2,"#ff668a",12);
    if (this.health<=0) this.dead=true;
  }

  draw(ctx,camera) {
    const x=Math.round(this.x-camera), y=Math.round(this.y);
    if (this.invulnerable>0 && Math.floor(this.invulnerable/6)%2===0) return;
    ctx.save();
    ctx.translate(x+this.w/2,y);
    ctx.scale(this.facing,1);
    // Backpack
    rounded(ctx,-17,15,8,17,3,"#526b9d");
    // Hair
    rounded(ctx,-12,-2,25,13,6,"#a65b43");
    // Face
    rounded(ctx,-11,4,22,20,7,"#ffd0ae");
    ctx.fillStyle="#273052";ctx.fillRect(3,11,3,3);
    ctx.fillStyle="#e88c78";ctx.fillRect(-3,18,7,2);
    // Jacket and boots
    rounded(ctx,-12,22,24,13,4,"#54cbd0");
    ctx.fillStyle="#f2c66d";ctx.fillRect(-8,34,7,5);ctx.fillRect(3,34,7,5);
    // Hair fringe
    ctx.fillStyle="#b66b4b";ctx.beginPath();ctx.moveTo(-12,6);ctx.lineTo(-10,-3);ctx.lineTo(5,-5);ctx.lineTo(12,4);ctx.lineTo(3,3);ctx.lineTo(-3,8);ctx.closePath();ctx.fill();
    // Visor
    ctx.strokeStyle="#a9f6ef";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,12,13,-.25,Math.PI+.25);ctx.stroke();
    ctx.restore();
  }
}

export function hit(a,b) {
  return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;
}

function rounded(ctx,x,y,w,h,r,color) {
  ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();
}
