export class ParticleSystem {
  constructor() { this.items = []; }

  burst(x, y, color, count = 10, speed = 3) {
    for (let i=0;i<count;i++) {
      const angle = Math.random() * Math.PI * 2;
      const force = .5 + Math.random() * speed;
      this.items.push({
        x,y,vx:Math.cos(angle)*force,vy:Math.sin(angle)*force,
        life:18+Math.random()*20,max:38,size:2+Math.random()*4,color
      });
    }
  }

  update() {
    for (const p of this.items) {
      p.x += p.vx; p.y += p.vy; p.vy += .08; p.life--;
    }
    this.items = this.items.filter(p => p.life > 0);
  }

  draw(ctx) {
    for (const p of this.items) {
      ctx.globalAlpha = Math.max(0,p.life/p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x,p.y,p.size,p.size);
    }
    ctx.globalAlpha = 1;
  }
}
