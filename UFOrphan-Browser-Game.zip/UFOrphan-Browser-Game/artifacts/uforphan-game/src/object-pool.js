/**
 * Reusable object pool for projectiles and short-lived effects.
 */
export class ObjectPool {
  constructor(factory,reset=(item,data)=>Object.assign(item,data),initialSize=0) {
    this.factory=factory;this.resetItem=reset;this.free=[];this.used=new Set();
    for(let i=0;i<initialSize;i++)this.free.push(factory());
  }
  acquire(data={}) {
    const item=this.free.pop()||this.factory();
    this.resetItem(item,data);this.used.add(item);return item;
  }
  release(item) {
    if(!this.used.delete(item))return false;
    this.free.push(item);return true;
  }
  releaseAll() { for(const item of this.used)this.free.push(item);this.used.clear(); }
  forEach(callback) { this.used.forEach(callback); }
  get activeCount() { return this.used.size; }
  get pooledCount() { return this.free.length; }
}
