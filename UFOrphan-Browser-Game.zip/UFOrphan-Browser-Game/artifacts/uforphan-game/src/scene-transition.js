/**
 * Scene transition controller with fade-out, swap and fade-in phases.
 */
export class SceneTransition {
  constructor({duration=24,onSwap=()=>{}}={}) {
    this.duration=duration;this.onSwap=onSwap;this.phase="idle";this.frame=0;this.nextScene=null;
  }
  start(scene) {
    if(this.phase!=="idle")return false;
    this.nextScene=scene;this.phase="out";this.frame=0;return true;
  }
  update() {
    if(this.phase==="idle")return;
    this.frame++;
    if(this.frame>=this.duration) {
      this.frame=0;
      if(this.phase==="out") {this.onSwap(this.nextScene);this.phase="in";}
      else {this.phase="idle";this.nextScene=null;}
    }
  }
  get alpha() {
    if(this.phase==="idle")return 0;
    const t=this.frame/this.duration;
    return this.phase==="out"?t:1-t;
  }
  draw(ctx,width,height,color="#050817") {
    if(this.alpha<=0)return;
    ctx.save();ctx.globalAlpha=this.alpha;ctx.fillStyle=color;ctx.fillRect(0,0,width,height);ctx.restore();
  }
}
