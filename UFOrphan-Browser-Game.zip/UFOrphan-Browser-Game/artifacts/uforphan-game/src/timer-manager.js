/**
 * Frame-based timers. The game loop calls update(1) once per fixed simulation step.
 */
export class TimerManager {
  constructor() { this.timers=new Map();this.nextId=1;this.paused=false; }
  after(frames,callback,{repeat=false,tag=null}={}) {
    if(!Number.isFinite(frames)||frames<0)throw new RangeError("frames must be non-negative");
    if(typeof callback!=="function")throw new TypeError("callback must be a function");
    const id=this.nextId++;
    this.timers.set(id,{id,remaining:frames,period:frames,callback,repeat,tag});
    return id;
  }
  cancel(id) { return this.timers.delete(id); }
  cancelTag(tag) {
    let count=0;
    for(const [id,timer] of this.timers)if(timer.tag===tag){this.timers.delete(id);count++;}
    return count;
  }
  update(delta=1) {
    if(this.paused)return;
    for(const [id,timer] of [...this.timers]) {
      timer.remaining-=delta;
      if(timer.remaining<=0) {
        timer.callback(timer);
        if(timer.repeat&&this.timers.has(id))timer.remaining=Math.max(1,timer.period);
        else this.timers.delete(id);
      }
    }
  }
  pause() { this.paused=true; }
  resume() { this.paused=false; }
  clear() { this.timers.clear(); }
  get size() { return this.timers.size; }
}
