/**
 * Weather subsystem for UFOrphan.
 *
 * This module is intentionally independent of the canvas renderer. It can be
 * tested in isolation and connected to the game loop through events.
 */
export class WeatherSystem {
  constructor(options = {}) {
    this.clock = options.clock || (() => Date.now());
    this.storage = options.storage || null;
    this.events = new Map();
    this.records = new Map();
    this.sequence = 0;
    this.revision = 0;
    this.maxRecords = options.maxRecords || 500;
    this.namespace = "weatherStates";
  }

  makeId(prefix = "weather") {
    this.sequence += 1;
    return `${prefix}_${this.clock().toString(36)}_${this.sequence.toString(36)}`;
  }

  validate(record) {
    if (!record || typeof record !== "object" || Array.isArray(record)) {
      throw new TypeError("Weather: record must be an object");
    }
    if (record.id !== undefined && typeof record.id !== "string") {
      throw new TypeError("Weather: id must be a string");
    }
    if (record.climate !== undefined && typeof record.climate !== "string") {
      throw new TypeError("Weather: climate must be a string");
    }
    return true;
  }

  normalize(record) {
    this.validate(record);
    return {
      ...structuredCloneSafe(record),
      id: record.id || this.makeId(),
      createdAt: record.createdAt || this.clock(),
      updatedAt: this.clock(),
      revision: this.revision + 1
    };
  }

  create(record) {
    const item = this.normalize(record);
    if (this.records.has(item.id)) throw new Error(`Duplicate id: ${item.id}`);
    this.records.set(item.id, item);
    this.changed("created", item);
    return structuredCloneSafe(item);
  }

  get(id) {
    const item = this.records.get(id);
    return item ? structuredCloneSafe(item) : null;
  }

  list(predicate = () => true) {
    return [...this.records.values()]
      .filter(predicate)
      .map(structuredCloneSafe);
  }

  update(id, patch) {
    const current = this.records.get(id);
    if (!current) return null;
    const next = { ...current, ...structuredCloneSafe(patch), id, updatedAt: this.clock() };
    this.validate(next);
    this.records.set(id, next);
    this.changed("updated", next);
    return structuredCloneSafe(next);
  }

  remove(id) {
    const current = this.records.get(id);
    if (!current) return false;
    this.records.delete(id);
    this.changed("removed", current);
    return true;
  }

  clear() {
    const previous = this.records.size;
    this.records.clear();
    this.changed("cleared", { count: previous });
    return previous;
  }

  subscribe(eventName, callback) {
    if (typeof callback !== "function") throw new TypeError("callback must be a function");
    const listeners = this.events.get(eventName) || new Set();
    listeners.add(callback);
    this.events.set(eventName, listeners);
    return () => listeners.delete(callback);
  }

  changed(action, payload) {
    this.revision += 1;
    const event = { namespace: this.namespace, action, payload: structuredCloneSafe(payload), revision: this.revision };
    for (const listener of this.events.get(action) || []) listener(event);
    for (const listener of this.events.get("*") || []) listener(event);
  }

  transaction(work) {
    if (typeof work !== "function") throw new TypeError("transaction requires a function");
    const before = new Map([...this.records].map(([id, item]) => [id, structuredCloneSafe(item)]));
    const revisionBefore = this.revision;
    try {
      const result = work(this);
      return result;
    } catch (error) {
      this.records = before;
      this.revision = revisionBefore;
      throw error;
    }
  }

  exportState() {
    return {
      namespace: this.namespace,
      sequence: this.sequence,
      revision: this.revision,
      records: this.list()
    };
  }

  importState(snapshot) {
    if (!snapshot || snapshot.namespace !== this.namespace || !Array.isArray(snapshot.records)) {
      throw new Error(`Invalid ${this.namespace} snapshot`);
    }
    const next = new Map();
    for (const record of snapshot.records) {
      this.validate(record);
      if (!record.id || next.has(record.id)) throw new Error("Invalid or duplicate record id");
      next.set(record.id, structuredCloneSafe(record));
    }
    this.records = next;
    this.sequence = Number(snapshot.sequence) || 0;
    this.revision = Number(snapshot.revision) || 0;
    this.changed("restored", { count: next.size });
    return next.size;
  }

  persist() {
    if (!this.storage || typeof this.storage.setItem !== "function") return false;
    this.storage.setItem(this.namespace, JSON.stringify(this.exportState()));
    return true;
  }

  hydrate() {
    if (!this.storage || typeof this.storage.getItem !== "function") return 0;
    const raw = this.storage.getItem(this.namespace);
    if (!raw) return 0;
    return this.importState(JSON.parse(raw));
  }

  setWeather(record) {
    return this.create({ ...record, status: record.status || "active" });
  }

  advanceWeather(id, amount = 1) {
    const item = this.records.get(id);
    if (!item) return null;
    const current = Number(item.progress || 0);
    const delta = Number(amount);
    if (!Number.isFinite(delta)) throw new TypeError("amount must be finite");
    return this.update(id, { progress: Math.max(0, current + delta) });
  }

  forecast(id) {
    const item = this.records.get(id);
    if (!item) return false;
    this.update(id, { status: "completed", completedAt: this.clock() });
    return true;
  }

  findByStatus(status) {
    return this.list(item => item.status === status);
  }

  countByStatus() {
    return this.list().reduce((counts, item) => {
      const key = item.status || "unspecified";
      counts[key] = (counts[key] || 0) + 1;
      return counts;
    }, {});
  }

  prune(olderThan) {
    const threshold = Number(olderThan);
    if (!Number.isFinite(threshold)) throw new TypeError("olderThan must be a timestamp");
    let removed = 0;
    for (const [id, item] of this.records) {
      if (Number(item.updatedAt) < threshold) {
        this.records.delete(id);
        removed += 1;
      }
    }
    if (removed) this.changed("pruned", { count: removed });
    return removed;
  }

  assertCapacity() {
    if (this.records.size <= this.maxRecords) return true;
    throw new Error(`${this.namespace} capacity exceeded`);
  }

  summary() {
    return {
      namespace: this.namespace,
      total: this.records.size,
      revision: this.revision,
      statuses: this.countByStatus()
    };
  }
}

function structuredCloneSafe(value) {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}
