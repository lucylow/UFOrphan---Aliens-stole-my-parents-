/**
 * Minimal event bus with wildcard listeners and deterministic unsubscribe.
 */
export class EventBus {
  constructor() { this.listeners=new Map();this.queue=[];this.dispatching=false; }
  on(type,handler) {
    if(typeof handler!=="function")throw new TypeError("handler must be a function");
    const set=this.listeners.get(type)||new Set();set.add(handler);this.listeners.set(type,set);
    return ()=>this.off(type,handler);
  }
  once(type,handler) {
    let dispose;
    dispose=this.on(type,event=>{dispose();handler(event);});
    return dispose;
  }
  off(type,handler) {
    const set=this.listeners.get(type);if(!set)return false;
    const removed=set.delete(handler);if(!set.size)this.listeners.delete(type);return removed;
  }
  emit(type,payload) {
    this.queue.push({type,payload,createdAt:Date.now()});
    if(this.dispatching)return;
    this.dispatching=true;
    try {
      while(this.queue.length) {
        const event=this.queue.shift();
        const handlers=[...(this.listeners.get(event.type)||[]),...(this.listeners.get("*")||[])];
        for(const handler of handlers)handler(event);
      }
    } finally { this.dispatching=false; }
  }
  clear(type) { if(type)this.listeners.delete(type);else this.listeners.clear(); }
  listenerCount(type) { return this.listeners.get(type)?.size||0; }
}
