/**
 * Tracks level-specific performance without coupling it to the HUD.
 */
export class LevelMetrics {
  constructor() { this.reset(); }
  reset() {
    this.startedAt=Date.now();this.elapsedFrames=0;this.damageTaken=0;
    this.starsCollected=0;this.keysCollected=0;this.enemiesDefeated=0;
    this.deaths=0;this.projectilesFired=0;this.checkpointsUsed=0;
  }
  updateFrame() { this.elapsedFrames++; }
  recordDamage() { this.damageTaken++; }
  recordStar() { this.starsCollected++; }
  recordKey() { this.keysCollected++; }
  recordEnemy() { this.enemiesDefeated++; }
  recordDeath() { this.deaths++; }
  recordShot() { this.projectilesFired++; }
  recordCheckpoint() { this.checkpointsUsed++; }
  finish({totalStars=0,totalKeys=0}={}) {
    return {durationMs:Date.now()-this.startedAt,elapsedSeconds:this.elapsedFrames/60,
      damageTaken:this.damageTaken,starsCollected:this.starsCollected,keysCollected:this.keysCollected,
      enemiesDefeated:this.enemiesDefeated,deaths:this.deaths,projectilesFired:this.projectilesFired,
      checkpointsUsed:this.checkpointsUsed,perfectHealth:this.damageTaken===0,
      allStars:this.starsCollected>=totalStars,allKeys:this.keysCollected>=totalKeys};
  }
}
