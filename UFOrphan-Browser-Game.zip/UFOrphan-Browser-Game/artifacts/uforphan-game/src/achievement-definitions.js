/**
 * Initial achievement catalogue. Progress is updated by game events.
 */
export const ACHIEVEMENTS = [
  {id:"first-steps",title:"First Steps",description:"Move Fiona for the first time.",goal:1,metric:"distance"},
  {id:"star-gazer",title:"Star Gazer",description:"Collect 10 pieces of stardust.",goal:10,metric:"stars"},
  {id:"key-master",title:"Key Master",description:"Collect 5 keycards.",goal:5,metric:"keys"},
  {id:"not-so-fast",title:"Not So Fast",description:"Defeat 10 alien enemies.",goal:10,metric:"defeats"},
  {id:"family-first",title:"Family First",description:"Complete the rescue.",goal:1,metric:"rescues"},
  {id:"untouchable",title:"Untouchable",description:"Finish a chapter without taking damage.",goal:1,metric:"perfect-chapters"},
  {id:"explorer",title:"Cosmic Explorer",description:"Complete all four chapters.",goal:4,metric:"chapters"},
  {id:"collector",title:"Shiny Things",description:"Collect every stardust fragment in a chapter.",goal:1,metric:"perfect-collectibles"}
];
