/**
 * Object-pooled particle emitter for bursts, trails and ambient effects.
 */
export class ParticleEmitter {
  constructor({capacity=400,random=Math.random}={}) {
    this.capacity=capacity;this.random=random;this.pool=[];this.active=[];this.emitters=new Map();
  }
  configure(name,settings) { this.emitters.set(name,{...settings}); }
  emit(name,x,y,overrides={}) {
    const settings={...(this.emitters.get(name)||{}),...overrides};
    const count=settings.count||1;
    for(let i=0;i<count;i++) {
      if(this.active.length>=this.capacity)this.active.shift();
      const angle=(settings.angle??0)+(this.random()-.5)*(settings.spread??Math.PI*2);
      const speed=(settings.speed??2)*(0.5+this.random());
      this.active.push({x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,
        life:settings.life||30,maxLife:settings.life||30,size:settings.size||3,
        gravity:settings.gravity??.04,color:settings.color||"#ffffff",alpha:1});
    }
  }
  update(delta=1) {
    for(const p of this.active) {
      p.x+=p.vx*delta;p.y+=p.vy*delta;p.vy+=p.gravity*delta;
      p.life-=delta;p.alpha=Math.max(0,p.life/p.maxLife);
    }
    this.active=this.active.filter(p=>p.life>0);
  }
  draw(ctx) {
    for(const p of this.active) {
      ctx.globalAlpha=p.alpha;ctx.fillStyle=p.color;
      ctx.fillRect(Math.round(p.x),Math.round(p.y),p.size,p.size);
    }
    ctx.globalAlpha=1;
  }
  clear() { this.active.length=0; }
}
