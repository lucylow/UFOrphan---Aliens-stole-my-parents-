/**
 * Camera controller with smooth follow, dead-zone tracking and bounded scrolling.
 */
export class Camera {
  constructor({width=960,height=540,worldWidth=960,worldHeight=540,smoothing=.12}={}) {
    this.width=width;this.height=height;this.worldWidth=worldWidth;this.worldHeight=worldHeight;
    this.x=0;this.y=0;this.targetX=0;this.targetY=0;this.smoothing=smoothing;
    this.deadZone={left:width*.32,right:width*.68,top:height*.25,bottom:height*.72};
    this.shake={time:0,power:0,offsetX:0,offsetY:0};
  }
  setWorldSize(width,height=this.worldHeight) {
    this.worldWidth=Math.max(this.width,width);this.worldHeight=Math.max(this.height,height);
    this.clamp();
  }
  follow(target) {
    const screenX=target.x-this.x;
    const screenY=target.y-this.y;
    if(screenX<this.deadZone.left)this.targetX=target.x-this.deadZone.left;
    else if(screenX>this.deadZone.right)this.targetX=target.x-this.deadZone.right;
    else this.targetX=this.x;
    if(screenY<this.deadZone.top)this.targetY=target.y-this.deadZone.top;
    else if(screenY>this.deadZone.bottom)this.targetY=target.y-this.deadZone.bottom;
    else this.targetY=this.y;
  }
  update() {
    this.x+=(this.targetX-this.x)*this.smoothing;
    this.y+=(this.targetY-this.y)*this.smoothing;
    this.clamp();
    if(this.shake.time>0) {
      this.shake.time--;
      this.shake.offsetX=(Math.random()-.5)*this.shake.power;
      this.shake.offsetY=(Math.random()-.5)*this.shake.power;
      this.shake.power*=.94;
    } else {
      this.shake.offsetX=0;this.shake.offsetY=0;this.shake.power=0;
    }
  }
  clamp() {
    this.x=Math.max(0,Math.min(this.worldWidth-this.width,this.x));
    this.y=Math.max(0,Math.min(this.worldHeight-this.height,this.y));
    this.targetX=Math.max(0,Math.min(this.worldWidth-this.width,this.targetX));
    this.targetY=Math.max(0,Math.min(this.worldHeight-this.height,this.targetY));
  }
  kick(power=8,frames=12) { this.shake.power=power;this.shake.time=frames; }
  worldToScreen(point) { return {x:point.x-this.x+this.shake.offsetX,y:point.y-this.y+this.shake.offsetY}; }
  screenToWorld(point) { return {x:point.x+this.x-this.shake.offsetX,y:point.y+this.y-this.shake.offsetY}; }
  snapshot() { return {x:this.x,y:this.y,targetX:this.targetX,targetY:this.targetY}; }
  restore(state) { Object.assign(this,state);this.clamp(); }
}
