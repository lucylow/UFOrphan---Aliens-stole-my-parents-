export class AudioSystem {
  constructor() {
    this.enabled = true;
    this.context = null;
  }

  unlock() {
    if (!this.context) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) this.context = new AudioContext();
    }
    if (this.context?.state === "suspended") this.context.resume();
  }

  toggle() { this.enabled = !this.enabled; return this.enabled; }

  tone(frequency, duration = 0.08, type = "sine", volume = 0.04, slide = 0) {
    if (!this.enabled) return;
    this.unlock();
    if (!this.context) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, now);
    if (slide) oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, frequency + slide), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  jump() { this.tone(260, .11, "triangle", .035, 240); }
  collect() { this.tone(620, .12, "sine", .04, 350); }
  blast() { this.tone(180, .13, "sawtooth", .025, 420); }
  hurt() { this.tone(150, .24, "square", .035, -90); }
  win() { [440,550,660,880].forEach((n,i)=>setTimeout(()=>this.tone(n,.18,"sine",.035),i*100)); }
  click() { this.tone(500,.04,"sine",.025); }
}
