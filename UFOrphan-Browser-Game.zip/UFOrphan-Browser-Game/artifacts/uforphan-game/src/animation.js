/**
 * Lightweight animation clock for sprite-like procedural actors.
 */
export class AnimationClip {
  constructor({name,frames=[],frameDuration=8,loop=true,events={}}={}) {
    this.name=name;this.frames=frames;this.frameDuration=Math.max(1,frameDuration);
    this.loop=loop;this.events=events;this.elapsed=0;this.frameIndex=0;this.finished=false;
  }
  reset() { this.elapsed=0;this.frameIndex=0;this.finished=false; }
  update(delta=1) {
    if(this.finished||!this.frames.length)return null;
    this.elapsed+=delta;
    const next=Math.floor(this.elapsed/this.frameDuration);
    if(next>=this.frames.length) {
      if(this.loop)this.frameIndex=next%this.frames.length;
      else {this.frameIndex=this.frames.length-1;this.finished=true;}
    } else this.frameIndex=next;
    return this.events[this.frameIndex]||null;
  }
  get frame() { return this.frames[this.frameIndex]??null; }
}
export class AnimationController {
  constructor(clips={}) { this.clips=new Map(Object.entries(clips));this.current=null;this.playing=false; }
  add(clip) { this.clips.set(clip.name,clip);return clip; }
  play(name,{restart=false}={}) {
    const clip=this.clips.get(name);
    if(!clip)throw new Error(`Unknown animation: ${name}`);
    if(this.current!==clip||restart)clip.reset();
    this.current=clip;this.playing=true;return clip;
  }
  update(delta=1) { return this.playing&&this.current?this.current.update(delta):null; }
  stop() { this.playing=false; }
  get frame() { return this.current?.frame??null; }
}
