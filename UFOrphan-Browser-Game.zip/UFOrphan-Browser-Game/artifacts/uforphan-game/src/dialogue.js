export const STORY = {
  intro: {
    title:"Aliens stole my parents.",
    text:"Fiona Gallegar was halfway through a bowl of cereal when a purple tractor beam lifted her parents, the house cat, and the family minivan into the sky. The cat came back. The parents did not.",
    lines:["MUM?! DAD?!","Fiona, stay back! It's an alien ship!","I am absolutely not staying back."]
  },
  chapters: [
    {title:"The backyard beacon",text:"A strange signal is pulsing beside the old trampoline. Fiona grabs her homemade star-blaster and follows it into the night."},
    {title:"Moon Mall",text:"The signal leads to a shopping complex built into a moon. The aliens have excellent retail space and terrible security."},
    {title:"The scrap belt",text:"A pirate crew has sold the family ship for parts. Fiona must cross a field of drifting junk to reach the cruiser."},
    {title:"The mothership",text:"At last, the mothership. The abduction commander stands between Fiona and the family reunion."}
  ],
  ending: {
    title:"Family, reassembled.",
    text:"The commander is defeated. The ship's tractor beam switches off, and Fiona's parents tumble into a very awkward hug. The cat has already claimed the captain's chair.",
    lines:["We knew you'd find us.","Obviously. I had a map.","You drew that map on a pizza box.","It was a very good pizza box."]
  }
};

export function typewriter(text, element, speed=18) {
  element.textContent="";
  let index=0;
  return new Promise(resolve=>{
    const timer=setInterval(()=>{
      element.textContent=text.slice(0,++index);
      if(index>=text.length){clearInterval(timer);resolve();}
    },speed);
  });
}
