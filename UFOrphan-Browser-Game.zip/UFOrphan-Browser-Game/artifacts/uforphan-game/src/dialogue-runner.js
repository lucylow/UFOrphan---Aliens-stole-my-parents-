/**
 * Dialogue runner supports speaker labels, choices and explicit advancement.
 */
export class DialogueRunner {
  constructor({onLine=()=>{},onEnd=()=>{}}={}) {
    this.onLine=onLine;this.onEnd=onEnd;this.script=[];this.index=-1;this.active=false;this.variables={};
  }
  start(script,variables={}) {
    if(!Array.isArray(script)||!script.length)throw new TypeError("Dialogue script must be a non-empty array");
    this.script=script;this.variables={...variables};this.index=-1;this.active=true;
    return this.next();
  }
  next() {
    if(!this.active)return null;
    this.index++;
    if(this.index>=this.script.length) {
      this.active=false;this.onEnd();return null;
    }
    const raw=this.script[this.index];
    const line={speaker:raw.speaker||"Fiona",text:this.interpolate(raw.text||""),choices:raw.choices||[]};
    this.onLine(line,this.index);return line;
  }
  choose(choiceIndex) {
    const line=this.script[this.index];
    const choice=line?.choices?.[choiceIndex];
    if(!choice)throw new RangeError("Invalid dialogue choice");
    if(choice.set)this.variables[choice.set.key]=choice.set.value;
    if(choice.jump!==undefined)this.index=choice.jump-1;
    return this.next();
  }
  interpolate(text) {
    return String(text).replace(/\\{([a-zA-Z0-9_]+)\\}/g,(_,key)=>String(this.variables[key]??""));
  }
  stop() { this.active=false;this.script=[];this.index=-1; }
}
