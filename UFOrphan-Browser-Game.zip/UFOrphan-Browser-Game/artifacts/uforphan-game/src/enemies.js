import { hit } from "./player.js";

export class Enemy {
  constructor(type,x,y) {
    this.type=type;this.x=x;this.y=y;this.w=type==="drone"?34:31;this.h=type==="drone"?25:28;
    this.startX=x;this.vx=type==="drone"?1.15:0.8;this.range=type==="drone"?95:65;
    this.health=type==="drone"?2:1;this.phase=Math.random()*6;this.dead=false;
  }

  update(world,player) {
    this.phase+=.08;
    this.x+=this.vx;
    if (Math.abs(this.x-this.startX)>this.range) this.vx*=-1;
    if (this.type==="drone") this.y += Math.sin(this.phase)*.55;
    if (hit(this,player)) player.takeDamage(world.audio,world.particles);
  }

  damage(world,amount=1) {
    this.health-=amount;
    world.particles.burst(this.x+this.w/2,this.y+this.h/2,"#ff8bcb",7);
    if (this.health<=0) this.dead=true;
  }

  draw(ctx,camera) {
    const x=this.x-camera,y=this.y;
    ctx.save();
    if (this.type==="drone") {
      ctx.fillStyle="#a2b8e9";ctx.beginPath();ctx.ellipse(x+17,y+12,17,10,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle="#ff688f";ctx.fillRect(x+9,y+9,5,4);ctx.fillRect(x+21,y+9,5,4);
      ctx.strokeStyle="#6ef2e9";ctx.beginPath();ctx.moveTo(x+5,y+22);ctx.lineTo(x+1,y+29);ctx.moveTo(x+29,y+22);ctx.lineTo(x+33,y+29);ctx.stroke();
    } else {
      ctx.fillStyle="#9e6bd2";ctx.beginPath();ctx.ellipse(x+15,y+17,15,11,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle="#f7b8ed";ctx.fillRect(x+7,y+12,5,4);ctx.fillRect(x+19,y+12,5,4);
      ctx.fillStyle="#d6a5ee";ctx.fillRect(x+3,y+24,5,4);ctx.fillRect(x+22,y+24,5,4);
    }
    ctx.restore();
  }
}

export class Boss {
  constructor(data) { this.x=data.x;this.y=data.y;this.w=90;this.h=88;this.health=data.health;this.maxHealth=data.health;this.phase=0;this.cooldown=80;this.dead=false; }
  update(world,player) {
    this.phase+=.035;this.y=365+Math.sin(this.phase)*22;
    this.cooldown--;
    if(this.cooldown<=0) {
      world.projectiles.push({x:this.x,y:this.y+40,w:10,h:10,vx:-4.4,vy:Math.sin(this.phase)*1.5,life:100,owner:"enemy"});
      this.cooldown=85;
    }
    if(hit(this,player)) player.takeDamage(world.audio,world.particles);
  }
  damage(world,amount=1) {
    this.health-=amount;world.particles.burst(this.x+45,this.y+40,"#ffcf6c",12);
    if(this.health<=0)this.dead=true;
  }
  draw(ctx,camera) {
    const x=this.x-camera,y=this.y;
    ctx.fillStyle="#9b75c9";ctx.beginPath();ctx.roundRect(x,y,90,70,18);ctx.fill();
    ctx.fillStyle="#d5c6ff";ctx.fillRect(x+12,y+12,66,12);
    ctx.fillStyle="#ff668d";ctx.fillRect(x+20,y+28,15,9);ctx.fillRect(x+55,y+28,15,9);
    ctx.fillStyle="#5b477e";ctx.fillRect(x+35,y+51,20,7);
    ctx.strokeStyle="#8df4ee";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+12,y+65);ctx.lineTo(x+2,y+83);ctx.moveTo(x+78,y+65);ctx.lineTo(x+88,y+83);ctx.stroke();
    ctx.fillStyle="#281b42";ctx.fillRect(x,y-14,90,6);
    ctx.fillStyle="#ff668d";ctx.fillRect(x,y-14,90*(this.health/this.maxHealth),6);
  }
}
