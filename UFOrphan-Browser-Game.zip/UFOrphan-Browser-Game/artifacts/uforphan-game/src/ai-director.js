/**
 * Deterministic encounter director. It chooses from authored spawn waves,
 * never from arbitrary executable strings.
 */
export class EncounterDirector {
  constructor({random,spawn=()=>{}}={}) {
    this.random=random||(()=>Math.random());this.spawn=spawn;
    this.waves=[];this.current=0;this.cooldown=0;this.active=false;this.history=[];
  }
  load(waves) {
    if(!Array.isArray(waves))throw new TypeError("waves must be an array");
    this.waves=waves.map(w=>({...w,remaining:w.delay||0,dispatched:false}));
    this.current=0;this.active=true;this.history=[];
  }
  update(delta=1,context={}) {
    if(!this.active||this.current>=this.waves.length)return;
    const wave=this.waves[this.current];wave.remaining-=delta;
    if(wave.remaining>0)return;
    if(wave.condition&&!wave.condition(context))return;
    const count=Math.max(0,Number(wave.count)||0);
    for(let i=0;i<count;i++) {
      const entry=wave.entries[Math.floor(this.random()*wave.entries.length)];
      if(entry)this.spawn({...entry,wave:this.current});
    }
    wave.dispatched=true;this.history.push({index:this.current,at:Date.now(),count});
    this.current++;
  }
  stop() { this.active=false; }
  complete() { return this.current>=this.waves.length; }
  snapshot() { return {current:this.current,active:this.active,history:[...this.history]}; }
}
