/**
 * Lightweight frame-time monitor for local profiling.
 */
export class PerformanceMonitor {
  constructor({sampleSize=120}={}) {
    this.sampleSize=sampleSize;this.samples=[];this.last=0;this.frames=0;
    this.counters=new Map();this.enabled=true;
  }
  begin(now=performance.now()) { this.last=now; }
  end(now=performance.now()) {
    if(!this.enabled)return null;
    const duration=now-this.last;
    this.samples.push(duration);if(this.samples.length>this.sampleSize)this.samples.shift();
    this.frames++;return duration;
  }
  increment(name,amount=1) { this.counters.set(name,(this.counters.get(name)||0)+amount); }
  average() { return this.samples.length?this.samples.reduce((a,b)=>a+b,0)/this.samples.length:0; }
  percentile(p=95) {
    if(!this.samples.length)return 0;
    const sorted=[...this.samples].sort((a,b)=>a-b);
    return sorted[Math.min(sorted.length-1,Math.floor((p/100)*sorted.length))];
  }
  report() {
    return {frames:this.frames,averageMs:this.average(),p95Ms:this.percentile(95),
      fps:this.average()?1000/this.average():0,counters:Object.fromEntries(this.counters)};
  }
  reset() { this.samples.length=0;this.frames=0;this.counters.clear(); }
}
