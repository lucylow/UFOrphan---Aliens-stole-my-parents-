/**
 * Records frame-level input for deterministic replay and bug reports.
 */
export class InputRecorder {
  constructor() { this.frames=[];this.recording=false;this.playbackIndex=0; }
  start() { this.frames=[];this.recording=true;this.playbackIndex=0; }
  record(state) {
    if(!this.recording)return;
    this.frames.push({left:!!state.left,right:!!state.right,jump:!!state.jump,blast:!!state.blast});
  }
  stop() { this.recording=false;return this.export(); }
  export() { return JSON.stringify({version:1,frames:this.frames}); }
  import(serialized) {
    const data=typeof serialized==="string"?JSON.parse(serialized):serialized;
    if(data?.version!==1||!Array.isArray(data.frames))throw new Error("Unsupported replay");
    this.frames=data.frames.map(frame=>({left:!!frame.left,right:!!frame.right,jump:!!frame.jump,blast:!!frame.blast}));
    this.playbackIndex=0;this.recording=false;return this.frames.length;
  }
  next() { return this.frames[this.playbackIndex++]||null; }
  rewind() { this.playbackIndex=0; }
  get finished() { return this.playbackIndex>=this.frames.length; }
}
