/**
 * Asset manifest for the procedural-art prototype and future sprite replacement.
 */
export const ASSET_MANIFEST = Object.freeze({
  characters: {
    fiona: {kind:"procedural",module:"player.js",description:"Fiona Gallegar, cyan jacket and homemade blaster"},
    drone: {kind:"procedural",module:"enemies.js",description:"Small hovering alien security drone"},
    slime: {kind:"procedural",module:"enemies.js",description:"Purple moon slime"},
    commander: {kind:"procedural",module:"enemies.js",description:"Abduction commander boss"}
  },
  environments: {
    backyard:{kind:"procedural",module:"world.js",palette:["#111b42","#342b65"]},
    mall:{kind:"procedural",module:"world.js",palette:["#0b2340","#174d68"]},
    scrap:{kind:"procedural",module:"world.js",palette:["#241735","#5b315d"]},
    ship:{kind:"procedural",module:"world.js",palette:["#17162d","#39234c"]}
  },
  effects: {
    starburst:{kind:"procedural",module:"particles.js"},
    playerBlast:{kind:"procedural",module:"world.js"},
    hitFlash:{kind:"procedural",module:"player.js"}
  }
});
