/**
 * Development-only command registry. Commands are explicit functions and
 * never evaluate user-provided JavaScript strings.
 */
export class DebugConsole {
  constructor() { this.commands=new Map();this.history=[]; }
  register(name,handler,description="") {
    if(this.commands.has(name))throw new Error(`Command already exists: ${name}`);
    this.commands.set(name,{handler,description});
  }
  execute(name,args=[]) {
    const command=this.commands.get(name);
    if(!command)throw new Error(`Unknown debug command: ${name}`);
    const result=command.handler(...args);
    this.history.push({name,args,result,at:Date.now()});
    return result;
  }
  help() { return [...this.commands].map(([name,entry])=>({name,description:entry.description})); }
  recent(limit=20) { return this.history.slice(-limit); }
  clearHistory() { this.history=[]; }
}
