/**
 * Optional collision overlay for development builds.
 */
export class HitboxDebug {
  constructor({enabled=false,fill="rgba(255,80,120,.14)",stroke="#ff6688"}={}) {
    this.enabled=enabled;this.fill=fill;this.stroke=stroke;this.items=[];
  }
  add(rect,label="") { this.items.push({rect:{...rect},label}); }
  clear() { this.items.length=0; }
  draw(ctx,cameraX=0,cameraY=0) {
    if(!this.enabled)return;
    ctx.save();ctx.lineWidth=1;
    for(const item of this.items) {
      const r=item.rect;ctx.fillStyle=this.fill;ctx.strokeStyle=this.stroke;
      ctx.fillRect(r.x-cameraX,r.y-cameraY,r.w,r.h);
      ctx.strokeRect(r.x-cameraX,r.y-cameraY,r.w,r.h);
      if(item.label){ctx.fillStyle="#ffffff";ctx.font="10px monospace";ctx.fillText(item.label,r.x-cameraX,r.y-cameraY-3);}
    }
    ctx.restore();
  }
}
