/**
 * Static validation for designer-authored level records.
 */
export function validateLevel(level) {
  const errors=[];
  const requireField=(field)=>{if(level[field]===undefined)errors.push(`Missing ${field}`);};
  ["id","name","width","platforms","stars","keys","enemies","hazards","checkpoint","exit"].forEach(requireField);
  if(typeof level.id!=="string"||!level.id)errors.push("id must be a non-empty string");
  if(!Number.isFinite(level.width)||level.width<960)errors.push("width must be at least 960");
  const rectangles=[...(level.platforms||[]),...(level.hazards||[])];
  rectangles.forEach((rect,index)=>{
    if(!Array.isArray(rect)||rect.length!==4)errors.push(`rectangle ${index} must have four values`);
    else if(!rect.every(Number.isFinite)||rect[2]<=0||rect[3]<=0)errors.push(`rectangle ${index} has invalid dimensions`);
  });
  for(const [index,point] of (level.stars||[]).entries()) {
    if(!Array.isArray(point)||point.length!==2||!point.every(Number.isFinite))errors.push(`star ${index} is invalid`);
  }
  for(const [index,point] of (level.keys||[]).entries()) {
    if(!Array.isArray(point)||point.length!==2||!point.every(Number.isFinite))errors.push(`key ${index} is invalid`);
  }
  if(level.exit&&(!Array.isArray(level.exit)||level.exit.length!==2))errors.push("exit must be [x,y]");
  if(level.checkpoint&&(!Array.isArray(level.checkpoint)||level.checkpoint.length!==2))errors.push("checkpoint must be [x,y]");
  for(const [index,enemy] of (level.enemies||[]).entries()) {
    if(!Array.isArray(enemy)||enemy.length!==3||!["slime","drone"].includes(enemy[0]))errors.push(`enemy ${index} is invalid`);
  }
  return {valid:errors.length===0,errors};
}
export function validateAllLevels(levels) {
  const seen=new Set();
  return levels.map(level=>{
    const result=validateLevel(level);
    if(seen.has(level.id))result.errors.push(`Duplicate level id ${level.id}`);
    seen.add(level.id);
    result.valid=result.errors.length===0;
    return {id:level.id,...result};
  });
}
