/**
 * Runtime subsystem map.
 *
 * Core gameplay modules:
 * - player.js, world.js, enemies.js, levels.js, renderer.js
 *
 * Optional feature modules:
 * - inventory.js, quest.js, achievement.js, dialogue.js and the other
 *   domain systems in this folder.
 *
 * Engineering utilities:
 * - collision.js, camera.js, event-bus.js, timer-manager.js,
 *   state-machine.js, random.js, object-pool.js, performance-monitor.js.
 *
 * The optional modules are provided as an extensible foundation. They are
 * deliberately not all wired into the first playable chapter loop. This
 * keeps the prototype understandable and prevents optional systems from
 * making the main game harder to run.
 */
