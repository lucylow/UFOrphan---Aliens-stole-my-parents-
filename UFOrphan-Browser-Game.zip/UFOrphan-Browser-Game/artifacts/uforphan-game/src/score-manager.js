/**
 * Score calculation with explicit awards and anti-duplicate event identifiers.
 */
export class ScoreManager {
  constructor({baseLifeBonus=250,starValue=100,keyValue=300,enemyValue=150}={}) {
    this.values={baseLifeBonus,starValue,keyValue,enemyValue};this.score=0;this.events=new Set();this.breakdown=[];
  }
  award(kind,amount,sourceId) {
    const key=sourceId?`${kind}:${sourceId}`:null;
    if(key&&this.events.has(key))return 0;
    if(key)this.events.add(key);
    const value=Math.max(0,Number(amount)||0);this.score+=value;
    this.breakdown.push({kind,value,sourceId,at:Date.now()});return value;
  }
  star(id) { return this.award("star",this.values.starValue,id); }
  key(id) { return this.award("key",this.values.keyValue,id); }
  enemy(id) { return this.award("enemy",this.values.enemyValue,id); }
  lifeBonus(hearts) { return this.award("life",Math.max(0,hearts)*this.values.baseLifeBonus); }
  reset() { this.score=0;this.events.clear();this.breakdown=[]; }
  summary() { return {score:this.score,events:this.breakdown.length,breakdown:[...this.breakdown]}; }
}
