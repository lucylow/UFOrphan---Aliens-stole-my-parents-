/**
 * User-configurable input bindings with conflict checks.
 */
export class InputBindings {
  constructor(defaults={}) {
    this.defaults=structuredClone(defaults);
    this.bindings=structuredClone(defaults);
  }
  actions() { return Object.keys(this.bindings); }
  get(action) { return [...(this.bindings[action]||[])]; }
  set(action,codes,{allowShared=false}={}) {
    if(!this.bindings[action])throw new Error(`Unknown action: ${action}`);
    if(!Array.isArray(codes)||!codes.length)throw new TypeError("At least one key is required");
    const normalized=[...new Set(codes.map(String))];
    if(!allowShared) {
      for(const [other,keys] of Object.entries(this.bindings)) {
        if(other!==action&&keys.some(key=>normalized.includes(key)))throw new Error(`Binding conflicts with ${other}`);
      }
    }
    this.bindings[action]=normalized;return this.get(action);
  }
  reset(action=null) {
    if(action)this.bindings[action]=[...(this.defaults[action]||[])];
    else this.bindings=structuredClone(this.defaults);
  }
  resolve(code) { return this.actions().filter(action=>this.bindings[action].includes(code)); }
  export() { return structuredClone(this.bindings); }
  import(data) {
    if(!data||typeof data!=="object")throw new TypeError("Invalid bindings");
    for(const action of Object.keys(data))if(this.bindings[action])this.set(action,data[action],{allowShared:true});
  }
}
