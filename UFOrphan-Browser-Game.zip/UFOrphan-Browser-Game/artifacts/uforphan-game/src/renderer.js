import { GAME } from "./config.js";

export class Renderer {
  constructor(canvas) {
    this.canvas=canvas;this.ctx=canvas.getContext("2d");
    this.ctx.imageSmoothingEnabled=false;
  }
  clear() {
    this.ctx.clearRect(0,0,GAME.width,GAME.height);
  }
  draw(world,player,particles) {
    this.clear();
    world.draw(this.ctx);
    particles.draw(this.ctx);
    player.draw(this.ctx,world.camera);
    this.drawVignette();
  }
  drawVignette() {
    const g=this.ctx.createRadialGradient(480,260,180,480,260,650);
    g.addColorStop(0,"rgba(0,0,0,0)");
    g.addColorStop(1,"rgba(0,0,0,.24)");
    this.ctx.fillStyle=g;this.ctx.fillRect(0,0,GAME.width,GAME.height);
  }
}
