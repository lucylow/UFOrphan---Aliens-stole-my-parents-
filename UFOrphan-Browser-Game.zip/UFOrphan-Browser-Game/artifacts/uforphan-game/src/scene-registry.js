/**
 * Scene registry with lifecycle hooks and safe replacement.
 */
export class SceneRegistry {
  constructor(context={}) { this.context=context;this.factories=new Map();this.current=null;this.currentName=null; }
  register(name,factory) {
    if(this.factories.has(name))throw new Error(`Scene already registered: ${name}`);
    this.factories.set(name,factory);
  }
  switch(name,payload={}) {
    const factory=this.factories.get(name);
    if(!factory)throw new Error(`Unknown scene: ${name}`);
    this.current?.exit?.();
    const scene=factory(this.context,payload);
    if(!scene||typeof scene!=="object")throw new TypeError("Scene factory must return an object");
    this.current=scene;this.currentName=name;scene.enter?.(payload);
    return scene;
  }
  update(delta) { this.current?.update?.(delta); }
  draw(ctx) { this.current?.draw?.(ctx); }
  dispose() { this.current?.exit?.();this.current=null;this.currentName=null; }
}
