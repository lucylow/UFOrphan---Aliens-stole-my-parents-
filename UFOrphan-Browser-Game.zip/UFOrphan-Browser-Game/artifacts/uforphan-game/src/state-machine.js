/**
 * Explicit state machine for menus, play, pause, transition and terminal states.
 */
export class StateMachine {
  constructor({initial,transitions={},onEnter={},onExit={}}={}) {
    this.state=initial;this.transitions=transitions;this.onEnter=onEnter;this.onExit=onExit;
    this.history=[{state:initial,at:Date.now()}];
  }
  can(next) { return (this.transitions[this.state]||[]).includes(next); }
  transition(next,payload={}) {
    if(!this.can(next))throw new Error(`Invalid transition: ${this.state} -> ${next}`);
    const previous=this.state;
    this.onExit[previous]?.({next,payload});
    this.state=next;
    this.history.push({state:next,at:Date.now(),payload});
    this.onEnter[next]?.({previous,payload});
    return this.state;
  }
  is(...states) { return states.includes(this.state); }
  reset(state) { this.state=state;this.history=[{state,at:Date.now()}]; }
  snapshot() { return {state:this.state,history:[...this.history]}; }
}
