/**
 * Seeded pseudo-random generator for reproducible decoration and test encounters.
 */
export class Random {
  constructor(seed=Date.now()) { this.seed=(Number(seed)>>>0)||1; }
  next() {
    this.seed=(this.seed*1664525+1013904223)>>>0;
    return this.seed/4294967296;
  }
  range(min,max) { return min+(max-min)*this.next(); }
  integer(min,max) { return Math.floor(this.range(min,max+1)); }
  pick(items) { return items.length?items[this.integer(0,items.length-1)]:undefined; }
  chance(probability) { return this.next()<Math.max(0,Math.min(1,probability)); }
  shuffle(items) {
    const copy=[...items];
    for(let i=copy.length-1;i>0;i--) {
      const j=this.integer(0,i);[copy[i],copy[j]]=[copy[j],copy[i]];
    }
    return copy;
  }
  fork(salt=1) { return new Random((this.seed^Number(salt))>>>0); }
}
