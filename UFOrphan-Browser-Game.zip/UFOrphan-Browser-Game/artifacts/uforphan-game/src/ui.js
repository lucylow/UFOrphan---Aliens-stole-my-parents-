export class UI {
  constructor() {
    this.overlay=document.getElementById("overlay");
    this.panelTitle=document.getElementById("panelTitle");
    this.panelText=document.getElementById("panelText");
    this.panelEyebrow=document.getElementById("panelEyebrow");
    this.panelSymbol=document.getElementById("panelSymbol");
    this.panelActions=document.getElementById("panelActions");
    this.startButton=document.getElementById("startButton");
    this.howButton=document.getElementById("howButton");
    this.health=document.getElementById("healthValue");
    this.stars=document.getElementById("starValue");
    this.keys=document.getElementById("keyValue");
    this.levelName=document.getElementById("levelName");
    this.objective=document.getElementById("objective");
    this.title=document.getElementById("screenTitle");
    this.subtitle=document.getElementById("screenSubtitle");
    this.chapter=document.getElementById("chapterLabel");
    this.chapterPill=document.getElementById("chapterPill");
    this.saveStatus=document.getElementById("saveStatus");
  }

  showPanel({eyebrow="MISSION CONTROL",title,text,symbol="✦",actions=[]}) {
    this.panelEyebrow.textContent=eyebrow;this.panelTitle.textContent=title;
    this.panelText.textContent=text;this.panelSymbol.textContent=symbol;
    this.panelActions.innerHTML="";
    for(const action of actions) {
      const button=document.createElement("button");
      button.className=action.primary?"primary-button":"secondary-button";
      button.textContent=action.label;
      button.addEventListener("click",action.onClick);
      this.panelActions.append(button);
    }
    this.overlay.classList.remove("hidden");
  }

  hidePanel() { this.overlay.classList.add("hidden"); }

  updateHUD(player,world) {
    this.health.textContent=player.health;
    this.stars.textContent=player.stars;
    this.keys.textContent=player.keys;
    this.levelName.textContent=world.data.name;
    const remaining=world.keys.filter(k=>!k.collected).length;
    this.objective.textContent=remaining?`${remaining} keycard${remaining===1?"":"s"} left`:
      (world.boss&&!world.boss.dead?"Defeat the commander":"Find the portal");
    this.chapter.textContent=`CHAPTER ${world.data.chapter} · ${world.data.subtitle.toUpperCase()}`;
    this.chapterPill.textContent=`CHAPTER ${world.data.chapter}`;
    this.title.textContent=world.data.name;
    this.subtitle.textContent=world.data.subtitle;
  }

  setSaved(ok) { this.saveStatus.textContent=ok?"LOCAL SAVE":"SAVE UNAVAILABLE"; }
}
