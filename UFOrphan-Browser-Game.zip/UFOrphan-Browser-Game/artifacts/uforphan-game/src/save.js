import { GAME } from "./config.js";

const freshSave = () => ({
  version: GAME.version,
  unlockedLevel: 0,
  bestStars: {},
  totalRescued: false,
  sound: true,
  expansion: {}
});

export class SaveManager {
  constructor() { this.data = this.load(); }

  load() {
    try {
      const parsed = JSON.parse(localStorage.getItem(GAME.saveKey) || "null");
      if(!parsed)return freshSave();
      // Version 1 saves are upgraded in place so existing chapter progress survives.
      return { ...freshSave(), ...parsed, version: GAME.version, expansion: parsed.expansion || {} };
    } catch { return freshSave(); }
  }

  write() {
    try {
      localStorage.setItem(GAME.saveKey, JSON.stringify(this.data));
      return true;
    } catch { return false; }
  }

  completeLevel(index, stars) {
    this.data.unlockedLevel = Math.max(this.data.unlockedLevel, index + 1);
    this.data.bestStars[index] = Math.max(this.data.bestStars[index] || 0, stars);
    this.write();
  }

  setSound(enabled) { this.data.sound = enabled; this.write(); }
  reset() { this.data = freshSave(); this.write(); }
}
