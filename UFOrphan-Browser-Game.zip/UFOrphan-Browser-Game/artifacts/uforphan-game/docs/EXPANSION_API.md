# Expansion API Reference

## ExpansionProfile

`new ExpansionProfile(savedData)` constructs the player-wide profile. The profile owns one `EventHub` and shared instances of inventory, quests, crafting, progression, economy, companions, codex, achievements, challenges, mission board, upgrades, ending, rewards, accessibility, tutorials, and run statistics.

Primary methods:

- `applyPlayer(player)` applies permanent movement, health, recovery, pickup, and jump upgrades.
- `completeLevel(index)` records a completed chapter and evaluates achievements.
- `evaluateAchievements(extraStats)` evaluates the current profile metrics.
- `serialize()` returns a JSON-safe object suitable for local storage.

## ExpansionRuntime

`new ExpansionRuntime(world, profile)` creates the level-scoped systems. The world passes the profile into the runtime when it is constructed.

- `update(player)` advances environment, weather, moving platforms, NPC proximity, loot, map discovery, combat pacing, challenges, and boss phases.
- `interact(player)` resolves the closest NPC, a nearby crafting station, or an inactive beacon.
- `draw(ctx, camera)` draws the expansion's world-space and screen-space overlays.
- `serialize()` and `restore(data)` persist the level-scoped state.

## EventHub

The event hub supports `on`, `once`, `off`, `emit`, `clear`, `listenerCount`, `recent`, and `waitFor`. `on` and `once` return disposer functions. Events carry an ID, type, payload, timestamp, and cancellation flags. `EventTransaction` buffers events until commit or rollback.

Important event names are listed in `src/expansion/constants.js`, including `quest:started`, `quest:updated`, `quest:completed`, `item:added`, `item:removed`, `item:crafted`, `npc:met`, `secret:found`, `region:entered`, `boss:phase`, `challenge:started`, `challenge:ended`, and `world:checkpoint`.

## QuestEngine

Register definitions with `register` or `registerMany`. A definition includes:

```js
{
  id: "repair_the_relay",
  title: "Repair the Relay",
  description: "Bring the signal back online.",
  prerequisites: [],
  objectives: [
    { id: "find_cells", tag: "ion_cell", target: 3, description: "Find ion cells" }
  ],
  rewards: [{ item: "relay_chip", count: 1 }]
}
```

Call `start(id)`, `updateObjective(questId, objectiveId, amount)`, or `addProgressByTag(tag, amount)`. Use `get`, `list`, `active`, `objectiveSummary`, `serialize`, and `restore` to inspect or persist state.

## Inventory

The inventory API includes `add`, `remove`, `count`, `has`, `use`, `equip`, `unequip`, `transferTo`, `sort`, `list`, `serialize`, `restore`, and `validate`. The item catalogue is exported as `ITEM_CATALOG`.

## CraftingSystem

A recipe contains `id`, `name`, `station`, `ingredients`, `output`, `time`, and `xp`. Use `unlock(id)` to reveal a recipe, `setStation(type)` to set the active station, `canCraft(id)` to check materials, and `craft(id)` to perform the transaction.

## NPCSystem

NPC definitions are data records: `{ id, kind, x, y }`. `update(player)` calculates the closest NPC in range. `interact(player, questEngine)` returns a dialogue result and may start an available character quest. `draw(ctx, camera)` renders the characters and first-meeting marker.

## EnvironmentSystem and DynamicPlatformSystem

Environment definitions include `weather`, `hazards`, and `zones`. Hazard records include `id`, `kind`, `x`, `y`, `w`, `h`, and optional `damage`, `force`, and cooldown state. Moving platform records include an origin, width, height, speed, and horizontal or vertical range.

## CombatSystem

Weapon definitions live in `WEAPON_DEFINITIONS`. The default star-blaster, Plasma Lens, and Sonic Burst specify damage, cooldown, projectile speed, color, spread, and pierce count. `fire(player, world, audio)` emits projectiles. `onDamage` and `onKill` update combat statistics and emit events.

## Extending the level schema

The original fields remain unchanged. New optional fields live under `level.expansion`:

```js
expansion: {
  weather: "aurora",
  bossType: "warden",
  npcs: [{ id: "guide-01", kind: "noa", x: 360, y: 440 }],
  stations: [{ id: "bench-01", type: "workbench", x: 420, y: 440 }],
  beacons: [{ id: "relay-01", kind: "dish", x: 900, y: 430, active: false }],
  environment: { weather: "clear", hazards: [], zones: [] },
  movingPlatforms: []
}
```

The level validator can be imported from `src/expansion/level-validator.js` and run across the full `LEVELS` array.
