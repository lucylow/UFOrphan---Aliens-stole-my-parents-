# Developer API reference
This reference describes the public modules in the prototype and how they fit together.
## Game configuration
`GAME` — Logical dimensions, gravity, movement speed, jump strength, cooldown and save key.

### Responsibilities
- Keep GAME focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Input manager
`Input` — Tracks held keys, one-frame key presses and pointer-based touch controls.

### Responsibilities
- Keep Input focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Audio system
`AudioSystem` — Unlocks Web Audio on user gesture and synthesizes short sound effects.

### Responsibilities
- Keep AudioSystem focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Save manager
`SaveManager` — Loads versioned localStorage data and records chapter progression.

### Responsibilities
- Keep SaveManager focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Player
`Player` — Owns movement, collision resolution, damage, invulnerability and Fiona rendering.

### Responsibilities
- Keep Player focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Enemy
`Enemy` — Patrols within a home range and applies contact damage.

### Responsibilities
- Keep Enemy focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Boss
`Boss` — Maintains health, oscillates vertically and fires hostile projectiles.

### Responsibilities
- Keep Boss focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## World
`World` — Owns platforms, hazards, collectibles, checkpoints, portals, enemies and projectiles.

### Responsibilities
- Keep World focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Renderer
`Renderer` — Draws world, particles and player in logical canvas coordinates.

### Responsibilities
- Keep Renderer focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## UI
`UI` — Owns overlays, chapter labels and the live HUD.

### Responsibilities
- Keep UI focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Particle system
`ParticleSystem` — Creates and updates short-lived coloured particles.

### Responsibilities
- Keep ParticleSystem focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Level definitions
`LEVELS` — Defines chapter geometry and encounter placement as data.

### Responsibilities
- Keep LEVELS focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

## Story text
`STORY` — Contains intro, chapter and ending copy.

### Responsibilities
- Keep STORY focused on the responsibility above.
- Prefer passing dependencies explicitly rather than reaching into global state.
- Keep simulation state separate from DOM presentation state.
- Use world coordinates for gameplay and camera-relative coordinates only for drawing.

### Change procedure
1. Make the smallest change that satisfies the new behavior.
2. Check how the change interacts with the fixed-step update loop.
3. Test both a fresh save and an existing save.
4. Test at desktop and mobile viewport widths.
5. Update this reference and the manual acceptance checklist when behavior changes.

