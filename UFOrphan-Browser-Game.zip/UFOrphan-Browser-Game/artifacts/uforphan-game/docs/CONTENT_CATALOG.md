# Content catalog

## Fiona Gallegar
- Role: protagonist and playable character.
- Visual motif: homemade star-blaster, cyan jacket, compact backpack.
- Motivation: rescue her parents and get home.
- Voice: brave, practical, dryly funny.

## Threats
- Moon slime: short patrol range, ground-based contact threat.
- Security drone: hovering patrol enemy with contact damage.
- Abduction commander: final encounter with a visible health bar and periodic energy shots.

## World objects
- Stardust: optional collectible.
- Keycard: required to activate each chapter portal.
- Hazard: damaging floor spike strip.
- Checkpoint: visual progress marker.
- Portal: exit unlocked when required objectives are complete.

## Chapter progression
1. The Backyard — introduces the basic controls.
2. Moon Mall — introduces denser platform layouts and two keycards.
3. The Scrap Belt — longer route, multiple enemy types and a checkpoint.
4. The Mothership — boss encounter and family reunion.

## Narrative beats
- Inciting incident: the parents are abducted by a tractor beam.
- First clue: a signal beacon in the backyard.
- Escalation: the trail leads to an alien mall and a pirate scrap belt.
- Climax: Fiona confronts the commander on the mothership.
- Resolution: the family is reunited and the cat takes the captain's chair.
