# Implementation notes and design decisions

## Why Canvas 2D
The project is a compact 2D platform game. Canvas 2D keeps the rendering path simple and avoids a
large engine dependency. It is suitable for a prototype where the main value is a playable loop and
a distinctive premise.

## Why ES modules
Each gameplay responsibility has a separate file. Native ES modules work in current browsers when
served over HTTP. There is no build step, bundler or package manager to configure.

## Fixed-step simulation
The simulation advances at 60 updates per second. Rendering uses `requestAnimationFrame`. This
separation avoids making jump height depend directly on a monitor's refresh rate.

## Logical resolution
The canvas uses 960 × 540 logical pixels and CSS scales it to the available width. The 16:9 ratio
keeps the camera and level layout predictable. The game uses simple shapes and a pixel-like rendering
style; CSS `image-rendering` reinforces the visual direction.

## Collision simplification
Platforms are axis-aligned rectangles. Horizontal and vertical collision are resolved separately.
This is not a general physics engine, but it is understandable and easy to extend for this game.

## Procedural art
Fiona, enemies, the UFO, planets, platforms and pickups are drawn with Canvas primitives. This keeps
the zip self-contained and avoids broken paths to external art assets. A later art pass can replace
these methods with sprite sheets while preserving the same entity interfaces.

## Audio
The AudioSystem creates short oscillator tones. Browsers require a user gesture before audio starts,
so the system unlocks its AudioContext on the first start action. Audio can be disabled from the
header.

## Save model
Progress is local to the current browser profile. This is intentionally not a cloud save and does not
sync between devices. A production release would need an authenticated backend and explicit privacy
documentation.

## Known prototype limitations
- No server-side account or cloud synchronization.
- No external sprite art or cinematic animation.
- Level collision is rectangle-based.
- The story is presented in concise panels rather than voiced cutscenes.
- The boss uses one attack pattern.
- Touch controls are basic and do not include remapping.
- There is no formal automated browser test runner.

These limitations are intentional boundaries for a self-contained first playable build.
