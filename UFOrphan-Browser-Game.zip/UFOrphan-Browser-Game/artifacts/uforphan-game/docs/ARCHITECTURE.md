# Architecture notes

## Runtime model
The game runs as a single browser page with an animation loop driven by `requestAnimationFrame`.
The simulation uses a fixed 60 Hz step. Rendering may happen more often than simulation updates,
which keeps movement stable across displays with different refresh rates.

## Main loop responsibilities
1. Accumulate elapsed wall-clock time.
2. Run zero or more fixed simulation steps.
3. Update input-driven player movement.
4. Update world actors, collectibles and projectiles.
5. Update particles.
6. Check game state transitions.
7. Render the world and HUD.
8. Clear one-frame input edges.

## Coordinate system
The logical canvas is 960 by 540 units. The world uses positive x to the right and positive y down.
The camera is a horizontal offset. World entities retain world coordinates; drawing subtracts the
camera offset. Collision tests always use world coordinates, avoiding camera-dependent physics.

## Collision strategy
The player uses an axis-aligned bounding rectangle. Horizontal movement is integrated and resolved
against platforms before vertical movement. Vertical movement is then integrated and resolved.
This separation makes it straightforward to identify floor contact and reset vertical velocity.

The prototype deliberately uses simple rectangles rather than a complex tilemap collision engine.
Level designers can edit the platform arrays in `src/levels.js` without changing physics code.

## Entity lifecycle
Enemies and the boss own their health and movement. Projectiles are plain data records because they
have little independent behavior. A projectile is removed when its lifetime expires, it leaves the
level bounds, or it hits a valid target.

## Persistence
Only durable progression preferences are saved. The active position and transient combat state are
not saved. The save payload is versioned so future schema changes can safely reset incompatible
local data rather than crashing the game.

## Extending the prototype
- Add a level object to `LEVELS`.
- Add any new enemy behavior to `Enemy`.
- Add a matching draw branch for new world objects.
- Add UI states through `UI.showPanel`.
- Keep external side effects behind a user-triggered interaction.
