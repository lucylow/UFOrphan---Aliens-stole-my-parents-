# Extension cookbook

## Adding a chapter
1. Create a new object in `src/levels.js`.
2. Give it a unique id, readable name, chapter number and objective.
3. Set a world width and a two-colour sky gradient.
4. Add ground and floating platforms as `[x, y, width, height]`.
5. Place stars and keycards above reachable surfaces.
6. Place enemies with `['slime'|'drone', x, y]`.
7. Add hazards as rectangles and choose a checkpoint and exit.
8. If it is the final chapter, define a boss object with x, y and health.
9. Test the portal with every keycard collected and with one still missing.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding an enemy type
1. Extend the constructor in `Enemy` to assign dimensions and movement values.
2. Add a behavior branch in `Enemy.update`.
3. Add a rendering branch in `Enemy.draw`.
4. Choose a clear collision shape and keep its dimensions aligned with the drawing.
5. Add at least one instance to a test level.
6. Verify projectile damage and contact damage independently.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding a collectible
1. Define its data in the world constructor.
2. Give it a stable world-space position and a collected flag.
3. Check overlap during `World.update`.
4. Increment a player statistic only once.
5. Play a short collection sound and emit particles.
6. Draw the item only while it remains uncollected.
7. Add the item to the HUD if it is a required objective.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding a hazard
1. Represent the hazard as a rectangle.
2. Add it to the level hazard array.
3. Check player overlap once per simulation step.
4. Use the player's invulnerability window to avoid draining all hearts in one frame.
5. Give the hazard a distinctive visual treatment.
6. Verify that the player can understand how to avoid it.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding a UI panel
1. Use `UI.showPanel` with a concise eyebrow, title and description.
2. Provide at least one action that exits the panel.
3. Use the primary style for the most important action only.
4. Do not mark unverified work as complete.
5. Check the panel at narrow viewport sizes.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding an audio cue
1. Add a named method to `AudioSystem`.
2. Use a short envelope so tones do not click.
3. Call the method from a user-visible gameplay event.
4. Respect the enabled flag.
5. Keep the game playable when Web Audio is unavailable.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Changing player physics
1. Change constants in `config.js` rather than scattering magic numbers.
2. Test jump height and horizontal travel distance.
3. Check platform gaps at the beginning and end of every chapter.
4. Test both keyboard and touch controls.
5. Check that the camera remains smooth.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding save data
1. Add a default field to `freshSave`.
2. Keep the save version stable only for backward-compatible changes.
3. Increment the version for incompatible schema changes.
4. Validate loaded data before using it.
5. Avoid storing sensitive information in localStorage.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.

## Adding a boss phase
1. Keep the boss state local to the Boss class.
2. Use explicit phase and cooldown values.
3. Expose attacks as world projectiles so collision handling stays centralized.
4. Render a readable health bar.
5. Ensure the boss can always be defeated with the available player controls.

### Verification notes
- Test the normal path and at least one failure or edge case.
- Test after refreshing the browser.
- Confirm the game remains responsive while the feature is active.
- Keep the visual language consistent with the existing HUD and world.
