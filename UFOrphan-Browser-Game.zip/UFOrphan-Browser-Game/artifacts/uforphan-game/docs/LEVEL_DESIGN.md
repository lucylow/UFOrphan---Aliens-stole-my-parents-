# Level designer's notebook

## Chapter 1: The Backyard
- **Role:** Tutorial
- **Learning objective:** Teach the player to move, jump, collect a star, avoid a hazard and fire at a drone.
- **Route note:** Keep the first gap small. Put the first star directly above the first safe platform.
- **Readability:** Keep the next safe platform visible whenever possible.
- **Combat:** Place enemies where the player has enough room to react.
- **Collectibles:** Use stardust to reward optional exploration, not to block progress.
- **Checkpoint:** Place checkpoints before longer or more demanding sequences.

## Chapter 2: Moon Mall
- **Role:** Traversal
- **Learning objective:** Introduce repeated keycard gates and more frequent enemy combinations.
- **Route note:** Alternate low and high platforms so the player can choose a safer route.
- **Readability:** Keep the next safe platform visible whenever possible.
- **Combat:** Place enemies where the player has enough room to react.
- **Collectibles:** Use stardust to reward optional exploration, not to block progress.
- **Checkpoint:** Place checkpoints before longer or more demanding sequences.

## Chapter 3: The Scrap Belt
- **Role:** Challenge
- **Learning objective:** Ask the player to chain jumps and manage several enemies in open terrain.
- **Route note:** Keep a clear landing zone after every long jump. Use the checkpoint before the last stretch.
- **Readability:** Keep the next safe platform visible whenever possible.
- **Combat:** Place enemies where the player has enough room to react.
- **Collectibles:** Use stardust to reward optional exploration, not to block progress.
- **Checkpoint:** Place checkpoints before longer or more demanding sequences.

## Chapter 4: The Mothership
- **Role:** Finale
- **Learning objective:** Combine keycard collection with a boss encounter and a final portal.
- **Route note:** Place keys before the boss arena so the player can focus on the commander.
- **Readability:** Keep the next safe platform visible whenever possible.
- **Combat:** Place enemies where the player has enough room to react.
- **Collectibles:** Use stardust to reward optional exploration, not to block progress.
- **Checkpoint:** Place checkpoints before longer or more demanding sequences.
