# UFOrphan Expansion Guide

## What this expansion adds

The expansion extends the original four-chapter rescue adventure into an eight-chapter story. It adds persistent player systems that survive chapter transitions and a local save migration path for existing version-one saves.

### New story chapters

| Chapter | Region | Main activity | New feature |
|---|---|---|---|
| 05 | The Crystal Grove | Tune relay beacons and traverse a resonant valley | Aurora weather, singing relays, moving crystal lift |
| 06 | The Orbital Archive | Recover navigation records and security data | Low gravity, laser barriers, security and navigation NPCs |
| 07 | The Bio-Dome | Cross an overgrown research habitat | Moving leaf lifts, vent hazards, garden characters |
| 08 | The Eclipse Core | Disable the final command system and defeat the Warden | Ion storm, multi-phase boss, ending choice foundation |

Each new chapter uses the original level data format: world width, sky palette, platforms, collectibles, keycards, enemies, hazards, checkpoint, exit, and optional boss. The `expansion` object adds region-specific NPCs, stations, beacons, weather, environmental hazards, and moving platforms.

## Player systems

### Field pack

The inventory uses stackable slots. Items have a type, rarity, stack limit, description, and optional metadata. The default capacity is 24 slots. The initial catalogue includes:

- Materials: Ion Cells, Relay Chips, Copper Coils, Resonant Crystals, Stardust.
- Consumables: Med Patches, Shield Bubbles, Star Cookies.
- Upgrades: Plasma Lens and Jump Servo.
- Quest objects: Moon Mall Badge and Family Photo.

A full inventory blocks a loot pickup rather than silently deleting the item. Items can be transferred between inventories, sorted, equipped, used, and serialized.

### Equipment and upgrades

The Plasma Lens modifies the star-blaster projectile, and the Jump Servo unlocks a second jump. Permanent upgrade definitions also support reinforced boots, a heart module, and a magnet coil. Skill progression tracks experience, player level, skill points, and ranks in mobility, blaster, and survival branches.

### Crafting

Crafting is station-gated. Recipes are unlocked through progression and require all listed ingredients. The station types are `field_kit`, `workbench`, and `campfire`. A crafting transaction checks materials and available inventory capacity before consuming the ingredients.

### Quest engine

Quests have stable IDs, prerequisite lists, required and optional objectives, status, progress, rewards, and repeatability. Objectives can be updated directly or by semantic tags. Required objectives complete a quest automatically. The profile listens for quest completion and applies rewards once.

The four narrative quests are:

1. **Signal in the Static** — activate relay beacons and recover a transmitter.
2. **Mall Cop Duty** — disable rogue drones and return Pip's security badge.
3. **Scrap Symphony** — gather coils and resonant crystals for Rivet.
4. **Family Frequency** — align the antenna dishes and transmit the rescue signal.

The final quest is locked until the first three are complete.

### NPC conversations

NPCs are defined by a stable ID, a character kind, and world coordinates. Character catalog entries define their name, role, color, interaction radius, dialogue lines, and associated quest. Fiona can approach a character and press E or Enter to talk. The NPC system tracks first meetings and dialogue rotation.

### Combat and loot

The combat system supports weapon definitions, cooldown modifiers, projectile damage, piercing, combo tracking, damage numbers, and screen-shake intensity. Enemy and boss projectiles use the same world projectile list as the original game. Defeated enemies can drop items from weighted loot tables.

### World simulation

Region-specific simulation supports:

- Weather patterns: clear, aurora, ion, low gravity, and dust.
- Environmental hazards: vents, geysers, and electric arcs.
- Moving platforms with horizontal or vertical motion.
- Region triggers that emit events when Fiona enters a zone.
- A pacing director that estimates pressure and recommends a quiet beat or warning.
- Timed world events such as meteor showers, supply pods, patrols, and auroras.

### Supporting systems

The expansion also includes a sector map, checkpoint snapshots, codex entries, achievement tracking, repeatable bounty board, credit economy, companion abilities, branching dialogue graphs, cutscene beats, photo-mode camera controls, localization dictionaries, tutorial cards, accessibility preferences, run statistics, and an ending resolver.

Some of these systems are reusable foundations rather than full menu screens. The active game loop currently wires the profile, NPC, inventory, quest, crafting, combat, environment, map, loot, companion, weather, checkpoint, and boss-phase systems into play. The remaining systems are available for subsequent UI and content passes.

## Progression flow

1. Clear the original chapters to unlock the expansion chapters.
2. Meet Rivet in the Crystal Grove and start Scrap Symphony.
3. Reach the Orbital Archive, meet Pip and MOTH-7, and start the two archive quests.
4. Disable drones, activate archive transmitters, and return the security badge.
5. Collect crafting materials from exploration and enemy loot.
6. Finish the three prerequisite quests to unlock Family Frequency.
7. Align all three dishes in the Eclipse Core and defeat the Core Warden.
8. Resolve the ending with the existing rescue conclusion and the optional ending-system data.

## Save compatibility

The save version advances to `2.0.0`. The loader reads the existing save object, preserves its unlocked level, best star counts, rescue state, and sound preference, then supplies an empty expansion profile when no expansion data exists. The expansion profile serializes inventory, quests, crafting unlocks, progression, credits, companions, codex, achievements, challenges, mission board, upgrades, ending flags, claimed rewards, accessibility options, tutorial history, NPC meetings, and completed levels.

## Content authoring

Use `src/levels-expansion.js` as a reference for the new chapter schema. Keep all platform rectangles positive and within the world width. Place keycards before the exit. For a boss chapter, set a boss object with a health value and define a boss type in the expansion metadata. The level validator checks geometry and emits warnings for optional content omissions.
