# Game design brief

## Premise
Fiona Gallegar's parents have been abducted by aliens. She follows the trail through increasingly
strange places to bring them home. The tone is playful science-fiction adventure with a family
comedy at its centre.

## Core loop
Explore a side-scrolling level, avoid hazards, collect stardust, find all keycards, defeat enemies,
and enter the portal. The last chapter adds a boss fight.

## Player fantasy
The player should feel resourceful rather than powerful. Fiona is a regular kid with a homemade
star-blaster, quick reflexes and a strong sense of family loyalty.

## Progression
Chapter 1 introduces movement, jumps, collectibles and basic enemies.
Chapter 2 increases platform density and introduces multiple keycards.
Chapter 3 expands traversal and enemy combinations.
Chapter 4 combines the established mechanics and introduces the abduction commander.

## Collectibles
Stardust is optional and rewards exploration. Keycards are mandatory and gate the portal.
The distinction makes the main objective clear while leaving room for optional mastery.

## Combat
Fiona's star-blaster fires a short-lived energy projectile. A cooldown prevents holding the fire key
from producing an overwhelming stream of shots. Enemies have small health pools; the commander
requires repeated hits.

## Failure
Damage removes one heart and grants a brief invulnerability window. When health reaches zero,
the player can restart the chapter or return to the menu. The prototype does not punish failure by
deleting unlocked chapters.

## Accessibility and usability goals
Controls are keyboard-first but touch controls are provided. The game uses text labels in the HUD,
not colour alone. The interface scales down for smaller screens. Future work should add remappable
controls, captions for audio cues, reduced-motion preferences and a high-contrast option.
