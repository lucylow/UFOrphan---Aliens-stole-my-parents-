# UFOrphan Expansion Pack — installation

This is an additive source update for the original **UFOrphan — Aliens Stole My Parents** project.

## Install over the original source

1. Make a backup copy of your original `uforphan-web-game` folder.
2. Extract `UFOrphan_Expansion_AddOn.zip` into the original project folder.
3. Allow the archive to merge the `src`, `tests`, and `docs` folders and replace the listed integration files.
4. Keep the original project root. The expansion does not require a build step or third-party packages.
5. Start a local web server from the project root:

   ```bash
   python -m http.server 8000
   ```

6. Open `http://localhost:8000` in a modern browser.

Do not open `index.html` directly with a `file://` URL. ES module imports are intended to be served over HTTP.

## Files added

- `src/levels-expansion.js` — four additional chapter layouts.
- `src/expansion/` — persistent progression, quests, inventory, crafting, NPCs, environment, combat, map, loot, challenges, codex, accessibility, and other reusable systems.
- `tests/expansion-tests.js` — expansion and world-integration checks.
- `tests/node-level-tests.js` — chapter and content validation.
- `docs/EXPANSION_GUIDE.md` — gameplay and content reference.
- `docs/EXPANSION_API.md` — system interfaces and extension points.

## Existing files updated

- `index.html` — field-pack and mission-log controls, plus touch interaction.
- `src/config.js` — version updated to 2.0.0.
- `src/save.js` — version-one save data is migrated without discarding unlocked chapter progress.
- `src/levels.js` — appends chapters 05–08.
- `src/main.js` — initializes the persistent profile and adds inventory, mission, crafting, and NPC interactions.
- `src/world.js` — connects expansion systems to the existing world loop.
- `src/player.js` — equipment, shield, movement upgrade, and double-jump support.
- `src/enemies.js` — damage values can be applied to enemies and bosses.
- `src/input.js` — touch interaction edge detection.

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Move | A/D or arrow keys | Left / right buttons |
| Jump | Space, W, or Up | Up button |
| Star-blaster | X or J | Star button |
| Talk / activate | E or Enter | E button |
| Field pack | Top-bar pack icon | Top-bar pack icon |
| Mission log | Top-bar list icon | Top-bar list icon |
| Pause | Escape or P | Pause icon |

## Tests

The project has no external runtime dependencies. With Node.js installed, run:

```bash
npm test
node -e "import('./tests/runtime-tests.js').then(m => console.log(m.runUtilityTests()))"
```

The browser game itself still runs as static HTML, CSS, and JavaScript modules.
