# UFOrphan — Aliens Stole My Parents

A self-contained, original 2D browser platform adventure starring Fiona Gallegar.

## Run it on Replit

The game runs as the Replit web preview. To start it from the workspace shell:

```bash
pnpm --filter @workspace/uforphan-game run dev
```

The artifact serves the original JavaScript modules and Canvas game. No backend or database is required.

Run the included expansion and level checks with:

```bash
pnpm --filter @workspace/uforphan-game run test
```

## Run it locally

This project uses native browser JavaScript modules and the Canvas 2D API. If you run the source outside Replit, use a local server because browsers restrict modules opened directly from `file://`:

```bash
python -m http.server 8000
```

Then open <http://localhost:8000>.

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Move | Left / Right or A / D | ◀ / ▶ |
| Jump | Space, W or Up | ↑ |
| Fire star-blaster | X or J | ✦ |
| Talk / activate | E or Enter | E button |
| Field pack | Top-bar pack icon | Top-bar pack icon |
| Mission log | Top-bar list icon | Top-bar list icon |
| Pause | Escape or P | Pause button |

Collect all keycards in a level to activate its portal. Collect stardust for score. Avoid hazards and enemies. Talk to locals with E / Enter, activate relays, craft upgrades, and track side missions in the field pack. Defeat the chapter bosses before using their portals.

## Included

- Eight handcrafted chapters: The Backyard, Moon Mall, The Scrap Belt, The Mothership, The Crystal Grove, The Orbital Archive, The Bio-Dome and The Eclipse Core
- Platform collision, gravity, jumping and camera scrolling
- Enemy patrol AI, projectiles, damage and boss health
- Collectibles, keycards, checkpoints and gated exits
- Particle effects and synthesized sound effects
- Keyboard and touch controls
- Pause, instructions, chapter transitions, victory and game-over screens
- Local browser save for unlocked chapters, best stardust, sound preference, inventory, quests, crafting, progression and profile systems
- Persistent field pack, item stacks, consumables, weapon upgrades and double-jump equipment
- NPC conversations, four story quests, relay beacons, workbench/campfire crafting and mission log
- Dynamic weather, moving platforms, environmental hazards, weighted enemy loot, combat combos and multi-phase boss controller
- Sector map, codex, achievements, companions, bounty board, credits economy, photo-mode foundation and accessibility preferences
- Save migration from version 1.0.0 to 2.0.0

## Project structure

- `index.html` — application shell
- `styles.css` — responsive interface and HUD
- `src/main.js` — game loop and application state
- `src/config.js` — constants and control mapping
- `src/input.js` — keyboard and pointer input
- `src/player.js` — Fiona's movement, collision and rendering
- `src/world.js` — level simulation and drawing
- `src/enemies.js` — enemy and boss behavior
- `src/levels.js` — chapter layouts and encounter data
- `src/particles.js` — particle effects
- `src/audio.js` — Web Audio effects
- `src/save.js` — local persistence
- `src/ui.js` — HUD and overlays
- `src/renderer.js` — canvas rendering
- `src/dialogue.js` — story text
- `src/levels-expansion.js` — four additional chapter layouts
- `src/expansion/` — reusable progression, inventory, quest, crafting, NPC, combat, weather and world systems
- `tests/expansion-tests.js` — 50 expansion and integration assertions
- `EXPANSION_INSTALLATION.md` — add-on merge and run instructions

## Tests

With Node.js installed, run `npm test` for the expansion and chapter checks. Run `node -e "import('./tests/runtime-tests.js').then(m => console.log(m.runUtilityTests()))"` for the original utility suite.

## Notes

The uploaded concept document supplied the working title/name ideas, not a detailed game design specification. The plot, mechanics, art direction and chapter layouts in this playable prototype are original implementation choices based on that premise. All graphics are drawn in code; there are no external image assets or paid dependencies.
