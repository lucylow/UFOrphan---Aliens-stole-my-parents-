import assert from "node:assert/strict";
import { AchievementPoints } from "../core/achievement-points.js";
import { AchievementService } from "../core/achievement-service.js";
import { AnalyticsService } from "../core/analytics-service.js";
import { AsyncLock } from "../core/async-lock.js";
import { AuditLog } from "../core/audit-log.js";
import { BackupScheduler } from "../core/backup-scheduler.js";
import { BeaconService } from "../core/beacon-service.js";
import { BountyService } from "../core/bounty-service.js";
import { CacheService } from "../core/cache-service.js";
import { CalendarReminders } from "../core/calendar-reminders.js";
import { ChallengeRotation } from "../core/challenge-rotation.js";
import { ChallengeScore } from "../core/challenge-score.js";
import { CheckpointNotes } from "../core/checkpoint-notes.js";
import { ClipboardService } from "../core/clipboard-service.js";
import { CodexCategories } from "../core/codex-categories.js";
import { CodexService } from "../core/codex-service.js";
import { CollectionBook } from "../core/collection-book.js";
import { ColorTheme } from "../core/color-theme.js";
import { CombatRecords } from "../core/combat-records.js";
import { CommandPalette } from "../core/command-palette.js";
import { CompanionAffinity } from "../core/companion-affinity.js";
import { CompanionService } from "../core/companion-service.js";
import { CompassService } from "../core/compass-service.js";
import { ConsumableService } from "../core/consumable-service.js";
import { ConversationHistory } from "../core/conversation-history.js";
import { CooldownService } from "../core/cooldown-service.js";
import { CraftingCost } from "../core/crafting-cost.js";
import { CraftingQueue } from "../core/crafting-queue.js";
import { CraftingService } from "../core/crafting-service.js";
import { CurrencyFormatter } from "../core/currency-formatter.js";
import { CutsceneArchive } from "../core/cutscene-archive.js";
import { DailyChallengeService } from "../core/daily-challenges.js";
import { DialogueChoiceLog } from "../core/dialogue-choice-log.js";
import { DialogueConditions } from "../core/dialogue-conditions.js";
import { DialogueNotebook } from "../core/dialogue-notebook.js";
import { DiscoveryFeed } from "../core/discovery-feed.js";
import { EconomyService } from "../core/economy-service.js";
import { EnergyService } from "../core/energy-service.js";
import { EquipmentService } from "../core/equipment-service.js";
import { ErrorReporter } from "../core/error-reporter.js";
import { EventBus } from "../core/event-bus.js";
import { EventCalendar } from "../core/event-calendar.js";
import { EventScheduler } from "../core/event-scheduler.js";
import { ExportQueue } from "../core/export-queue.js";
import { FactionService } from "../core/faction-service.js";
import { FeatureFlags } from "../core/feature-flags.js";
import { FeatureUnlockService } from "../core/feature-unlock-service.js";
import { FileNameService } from "../core/file-name-service.js";
import { FilterEngine } from "../core/filter-engine.js";
import { FocusManager } from "../core/focus-manager.js";
import { FormState } from "../core/form-state.js";
import { GameModeService } from "../core/game-mode-service.js";
import { GameplayMetrics } from "../core/gameplay-metrics.js";
import { HintRotation } from "../core/hint-rotation.js";
import { InputShortcuts } from "../core/input-shortcuts.js";
import { InventoryCapacity } from "../core/inventory-capacity.js";
import { InventoryService } from "../core/inventory-service.js";
import { ItemComparator } from "../core/item-comparator.js";
import { ItemDiscovery } from "../core/item-discovery.js";
import { ItemFavorites } from "../core/item-favorites.js";
import { ItemInspection } from "../core/item-inspection.js";
import { ItemRecipeBook } from "../core/item-recipe-book.js";
import { ItemStackService } from "../core/item-stack-service.js";
import { ItemTradeService } from "../core/item-trade-service.js";
import { JournalService } from "../core/journal-service.js";
import { JournalTagging } from "../core/journal-tagging.js";
import { LocalLeaderboard } from "../core/leaderboard-local.js";
import { LevelUnlockService } from "../core/level-unlock-service.js";
import { LocalSaveInspector } from "../core/local-save-inspector.js";
import { Localization } from "../core/localization.js";
import { LootPreview } from "../core/loot-preview.js";
import { MailService } from "../core/mail-service.js";
import { MapMarkerService } from "../core/map-marker-service.js";
import { MapService } from "../core/map-service.js";
import { MarketWatch } from "../core/market-watch.js";
import { MissionFilter } from "../core/mission-filter.js";
import { MissionRewards } from "../core/mission-rewards.js";
import { MissionService } from "../core/mission-service.js";
import { NotificationDigest } from "../core/notification-digest.js";
import { NotificationPreferences } from "../core/notification-preferences.js";
import { NotificationRules } from "../core/notification-rules.js";
import { NotificationThrottle } from "../core/notification-throttle.js";
import { NotificationCenter } from "../core/notifications.js";
import { ObjectiveTracker } from "../core/objective-tracker.js";
import { OfflineQueue } from "../core/offline-queue.js";
import { Pagination } from "../core/pagination.js";
import { PartyBonus } from "../core/party-bonus.js";
import { PartyPlanner } from "../core/party-planner.js";
import { PhotoGallery } from "../core/photo-gallery.js";
import { PhotoMetadata } from "../core/photo-metadata.js";
import { PlaytimeTracker } from "../core/playtime-tracker.js";
import { PriceHistory } from "../core/price-history.js";
import { ProfileName } from "../core/profile-name.js";
import { ProfileService } from "../core/profile-service.js";
import { ProfileSlots } from "../core/profile-slots.js";
import { ProfileValidator } from "../core/profile-validator.js";
import { ProgressionTrack } from "../core/progression-track.js";
import { PurchaseCart } from "../core/purchase-cart.js";
import { QuestBoard } from "../core/quest-board.js";
import { QuestDependencyCheck } from "../core/quest-dependency-check.js";
import { QuestGraph } from "../core/quest-graph.js";
import { QuestReplay } from "../core/quest-replay.js";
import { QuestRewardPreview } from "../core/quest-reward-preview.js";
import { ReportBuilder } from "../core/report-builder.js";
import { ReputationGates } from "../core/reputation-gates.js";
import { ReputationService } from "../core/reputation-service.js";
import { RewardBundle } from "../core/reward-bundle.js";
import { RewardClaimGuard } from "../core/reward-claim-guard.js";
import { RoutePlanner } from "../core/route-planner.js";
import { Router } from "../core/router.js";
import { SaveIntegrity } from "../core/save-integrity.js";
import { SaveMigration } from "../core/save-migration.js";
import { SearchService } from "../core/search-service.js";
import { SectorDanger } from "../core/sector-danger.js";
import { SectorSignal } from "../core/sector-signal.js";
import { SectorSurvey } from "../core/sector-survey.js";
import { SessionAchievements } from "../core/session-achievements.js";
import { SessionService } from "../core/session-service.js";
import { SettingsPresets } from "../core/settings-presets.js";
import { SettingsService } from "../core/settings-service.js";
import { SignalDecoder } from "../core/signal-decoder.js";
import { SignalHistory } from "../core/signal-history.js";
import { Soundscape } from "../core/soundscape.js";
import { TerminalStorage } from "../core/storage.js";
import { StoryFlagService } from "../core/story-flag-service.js";
import { StoryRecap } from "../core/story-recap.js";
import { StoryTimeline } from "../core/story-timeline.js";
import { SupplyDemand } from "../core/supply-demand.js";
import { SupplyInventory } from "../core/supply-inventory.js";
import { TimelineService } from "../core/timeline-service.js";
import { TutorialHints } from "../core/tutorial-hints.js";
import { TutorialService } from "../core/tutorial-service.js";
import { UndoStack } from "../core/undo-stack.js";
import { URLState } from "../core/url-state.js";
import { Validator } from "../core/validation.js";
import { VendorRotation } from "../core/vendor-rotation.js";
import { VendorService } from "../core/vendor-service.js";
import { ViewLifecycle } from "../core/view-lifecycle.js";
import { WorldEventLog } from "../core/world-event-log.js";
import { WorldStateQuery } from "../core/world-state-query.js";
import { WorldState } from "../core/world-state.js";

const exportedServices = [
  AchievementPoints,
  AchievementService,
  AnalyticsService,
  AsyncLock,
  AuditLog,
  BackupScheduler,
  BeaconService,
  BountyService,
  CacheService,
  CalendarReminders,
  ChallengeRotation,
  ChallengeScore,
  CheckpointNotes,
  ClipboardService,
  CodexCategories,
  CodexService,
  CollectionBook,
  ColorTheme,
  CombatRecords,
  CommandPalette,
  CompanionAffinity,
  CompanionService,
  CompassService,
  ConsumableService,
  ConversationHistory,
  CooldownService,
  CraftingCost,
  CraftingQueue,
  CraftingService,
  CurrencyFormatter,
  CutsceneArchive,
  DailyChallengeService,
  DialogueChoiceLog,
  DialogueConditions,
  DialogueNotebook,
  DiscoveryFeed,
  EconomyService,
  EnergyService,
  EquipmentService,
  ErrorReporter,
  EventBus,
  EventCalendar,
  EventScheduler,
  ExportQueue,
  FactionService,
  FeatureFlags,
  FeatureUnlockService,
  FileNameService,
  FilterEngine,
  FocusManager,
  FormState,
  GameModeService,
  GameplayMetrics,
  HintRotation,
  InputShortcuts,
  InventoryCapacity,
  InventoryService,
  ItemComparator,
  ItemDiscovery,
  ItemFavorites,
  ItemInspection,
  ItemRecipeBook,
  ItemStackService,
  ItemTradeService,
  JournalService,
  JournalTagging,
  LocalLeaderboard,
  LevelUnlockService,
  LocalSaveInspector,
  Localization,
  LootPreview,
  MailService,
  MapMarkerService,
  MapService,
  MarketWatch,
  MissionFilter,
  MissionRewards,
  MissionService,
  NotificationDigest,
  NotificationPreferences,
  NotificationRules,
  NotificationThrottle,
  NotificationCenter,
  ObjectiveTracker,
  OfflineQueue,
  Pagination,
  PartyBonus,
  PartyPlanner,
  PhotoGallery,
  PhotoMetadata,
  PlaytimeTracker,
  PriceHistory,
  ProfileName,
  ProfileService,
  ProfileSlots,
  ProfileValidator,
  ProgressionTrack,
  PurchaseCart,
  QuestBoard,
  QuestDependencyCheck,
  QuestGraph,
  QuestReplay,
  QuestRewardPreview,
  ReportBuilder,
  ReputationGates,
  ReputationService,
  RewardBundle,
  RewardClaimGuard,
  RoutePlanner,
  Router,
  SaveIntegrity,
  SaveMigration,
  SearchService,
  SectorDanger,
  SectorSignal,
  SectorSurvey,
  SessionAchievements,
  SessionService,
  SettingsPresets,
  SettingsService,
  SignalDecoder,
  SignalHistory,
  Soundscape,
  TerminalStorage,
  StoryFlagService,
  StoryRecap,
  StoryTimeline,
  SupplyDemand,
  SupplyInventory,
  TimelineService,
  TutorialHints,
  TutorialService,
  UndoStack,
  URLState,
  Validator,
  VendorRotation,
  VendorService,
  ViewLifecycle,
  WorldEventLog,
  WorldStateQuery,
  WorldState,
];
assert.ok(exportedServices.length >= 100);
for (const service of exportedServices) {
  assert.equal(typeof service, "function");
  assert.ok(service.name.length > 0);
}

const requiredModules = [
  "achievement-points",
  "achievement-service",
  "analytics-service",
  "async-lock",
  "audit-log",
  "backup-scheduler",
  "beacon-service",
  "bounty-service",
  "cache-service",
  "calendar-reminders",
  "challenge-rotation",
  "challenge-score",
  "checkpoint-notes",
  "clipboard-service",
  "codex-categories",
  "codex-service",
  "collection-book",
  "color-theme",
  "combat-records",
  "command-palette",
  "companion-affinity",
  "companion-service",
  "compass-service",
  "consumable-service",
  "conversation-history",
  "cooldown-service",
  "crafting-cost",
  "crafting-queue",
  "crafting-service",
  "currency-formatter",
  "cutscene-archive",
  "daily-challenges",
  "dialogue-choice-log",
  "dialogue-conditions",
  "dialogue-notebook",
  "discovery-feed",
  "economy-service",
  "energy-service",
  "equipment-service",
  "error-reporter",
  "event-bus",
  "event-calendar",
  "event-scheduler",
  "export-queue",
  "faction-service",
  "feature-flags",
  "feature-unlock-service",
  "file-name-service",
  "filter-engine",
  "focus-manager",
  "form-state",
  "game-mode-service",
  "gameplay-metrics",
  "hint-rotation",
  "input-shortcuts",
  "inventory-capacity",
  "inventory-service",
  "item-comparator",
  "item-discovery",
  "item-favorites",
  "item-inspection",
  "item-recipe-book",
  "item-stack-service",
  "item-trade-service",
  "journal-service",
  "journal-tagging",
  "leaderboard-local",
  "level-unlock-service",
  "local-save-inspector",
  "localization",
  "loot-preview",
  "mail-service",
  "map-marker-service",
  "map-service",
  "market-watch",
  "mission-filter",
  "mission-rewards",
  "mission-service",
  "notification-digest",
  "notification-preferences",
  "notification-rules",
  "notification-throttle",
  "notifications",
  "objective-tracker",
  "offline-queue",
  "pagination",
  "party-bonus",
  "party-planner",
  "photo-gallery",
  "photo-metadata",
  "playtime-tracker",
  "price-history",
  "profile-name",
  "profile-service",
  "profile-slots",
  "profile-validator",
  "progression-track",
  "purchase-cart",
  "quest-board",
  "quest-dependency-check",
  "quest-graph",
  "quest-replay",
  "quest-reward-preview",
  "report-builder",
  "reputation-gates",
  "reputation-service",
  "reward-bundle",
  "reward-claim-guard",
  "route-planner",
  "router",
  "save-integrity",
  "save-migration",
  "search-service",
  "sector-danger",
  "sector-signal",
  "sector-survey",
  "session-achievements",
  "session-service",
  "settings-presets",
  "settings-service",
  "signal-decoder",
  "signal-history",
  "soundscape",
  "storage",
  "story-flag-service",
  "story-recap",
  "story-timeline",
  "supply-demand",
  "supply-inventory",
  "timeline-service",
  "tutorial-hints",
  "tutorial-service",
  "undo-stack",
  "url-state",
  "validation",
  "vendor-rotation",
  "vendor-service",
  "view-lifecycle",
  "world-event-log",
  "world-state-query",
  "world-state",
];
assert.equal(new Set(requiredModules).size, requiredModules.length);
assert.ok(requiredModules.includes("inventory-service"));
assert.ok(requiredModules.includes("mission-service"));
assert.ok(requiredModules.includes("map-service"));
assert.ok(requiredModules.includes("profile-service"));
console.log("Field Terminal public service API contract passed.");
