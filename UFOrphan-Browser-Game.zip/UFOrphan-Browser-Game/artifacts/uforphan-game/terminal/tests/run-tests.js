import "./core.test.js";
import assert from "node:assert/strict";
import { ITEMS,RECIPES,EQUIPMENT } from "../data/catalog.js";
import { SECTORS } from "../data/sectors.js";
import { MISSION_DATA } from "../data/missions.js";
import { CODEX_ENTRIES } from "../data/codex.js";
import { ACHIEVEMENTS } from "../data/achievements.js";
assert.equal(SECTORS.length,8);assert.equal(MISSION_DATA.length,6);assert.ok(ITEMS.length>=15);assert.ok(RECIPES.length>=6);assert.ok(EQUIPMENT.length>=6);assert.ok(CODEX_ENTRIES.length>=8);assert.ok(ACHIEVEMENTS.length>=8);for(const recipe of RECIPES){assert.ok(ITEMS.some(item=>item.id===recipe.output),`Missing recipe output ${recipe.output}`);for(const id of Object.keys(recipe.cost))assert.ok(ITEMS.some(item=>item.id===id),`Missing ingredient ${id}`);}for(const mission of MISSION_DATA){assert.ok(mission.objectives.length>0);assert.ok(mission.rewards.credits>=0);}console.log("Field Terminal catalog tests passed.");

import "./extended.test.js";

import "./edge-cases.test.js";

import "./scenario-invariants.test.js";

import "./service-smoke.test.js";

import "./api-contract.test.js";
