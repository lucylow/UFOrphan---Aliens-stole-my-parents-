# Fiona's Field Terminal — Add-on 3

This add-on adds a complete in-game application suite to UFOrphan. It is an additive browser module and does not replace the platformer engine.

## Install

1. Back up the expanded UFOrphan project.
2. Copy the `terminal/` directory from this package into the project root.
3. Add this line to the existing `index.html`, after the current `src/main.js` script tag:

```html
<script type="module" src="terminal/boot.js"></script>
```

4. Run the game from a local web server, for example `python -m http.server 8000`.
5. Click the new `⌘` icon in the top toolbar to open Fiona's Field Terminal.

The add-on uses a separate localStorage key (`uforphan.field-terminal.v1`) and does not overwrite the original game's save data. It also exposes `window.UFOrphanFieldTerminal` for optional integration.

## Included applications

- Overview dashboard and quick-launch tiles
- Field Pack with search, filters, item quantities and weight
- Mission Journal with objective progress and reward claiming
- Galaxy Map with eight sector nodes and discovery status
- Codex with category filtering and entry unlocks
- Equipment Bay with weapon, boots, suit and gadget slots
- Crafting Bench with recipe and ingredient validation
- Supply Exchange with credits, purchases and transaction history
- Achievements and expedition statistics
- Save Profiles with snapshots, JSON export and JSON import
- Accessibility and interface settings
- Toast notifications, event bus, router and persistent state services

## Tests

Run `node terminal/tests/run-tests.js` from the project root. The test suite exercises storage-independent service logic and validates catalog references.

## Notes

The Field Terminal is a management and companion application. It intentionally does not claim to change physics, level geometry, enemy balance or the base platformer's save schema. Existing gameplay integration can be extended through the public `window.UFOrphanFieldTerminal.app` service object.
