import { FieldTerminalApplication } from "./core/application.js";
import { renderView } from "./views/index.js";
import { TABS } from "./core/router.js";
import { escapeHTML } from "./core/utils.js";
const stylesheet = document.createElement("link");
stylesheet.rel = "stylesheet";
stylesheet.href = new URL("./styles/terminal.css", import.meta.url);
document.head.append(stylesheet);
const NAV=[ ["dashboard","⌂","Overview"],["inventory","▤","Field Pack"],["missions","☷","Mission Journal"],["map","⌖","Galaxy Map"],["codex","▧","Codex"],["equipment","⬡","Equipment"],["crafting","⚒","Crafting"],["shop","▦","Supply Shop"],["achievements","✦","Achievements"],["statistics","▥","Statistics"],["profiles","⇧","Save Profiles"],["settings","⚙","Settings"] ];
const app=new FieldTerminalApplication();
const launcher=document.createElement("button");launcher.id="fieldTerminalLauncher";launcher.className="icon-button";launcher.type="button";launcher.title="Open Field Terminal";launcher.setAttribute("aria-label","Open Field Terminal");launcher.textContent="⌘";
const toolbar=document.querySelector(".top-actions");if(toolbar)toolbar.insertBefore(launcher,toolbar.firstChild);
const root=document.createElement("section");root.className="ft-terminal";root.id="fieldTerminal";root.setAttribute("aria-label","Fiona's Field Terminal");root.innerHTML=`<div class="ft-window" role="dialog" aria-modal="true" aria-label="Field Terminal"><header class="ft-topbar"><div class="ft-brand"><span class="ft-brand-mark">✦</span><div>FIONA'S FIELD TERMINAL<small>GALACTIC RESCUE NETWORK / BUILD 01.0</small></div></div><div class="ft-top-actions"><button class="ft-icon-button" id="ft-home" title="Home">⌂</button><button class="ft-icon-button" id="ft-close" title="Close terminal" aria-label="Close terminal">✕</button></div></header><div class="ft-main"><nav class="ft-sidebar" aria-label="Terminal navigation">${NAV.map(([id,icon,label],i)=>`${i===0?'<div class="ft-nav-label">COMMAND CENTER</div>':i===5?'<div class="ft-nav-label">FIELD TOOLS</div>':i===8?'<div class="ft-nav-label">RECORDS</div>':''}<button class="ft-nav-button" data-tab="${id}"><span>${icon}</span><span class="ft-nav-text">${label}</span></button>`).join("")}<div class="ft-sidebar-foot">LOCAL SYSTEM<br>FIONA GALLEGAR<br><span id="ft-save-indicator">AUTOSAVE READY</span></div></nav><div class="ft-content"><main class="ft-view" id="ft-view"></main><footer class="ft-statusbar"><span>✦ SIGNAL LINK STABLE</span><span id="ft-clock">LOCAL TIME</span><span>FIELD TERMINAL v1.0</span></footer></div></div><div class="ft-toast-stack" id="ft-toasts" aria-live="polite"></div></div>`;
document.body.append(root);
const view=root.querySelector("#ft-view");
function navigate(tab){app.router.go(tab);paint();}
function paint(){renderView(app,view,{go:navigate});root.querySelectorAll("[data-tab]").forEach(node=>node.classList.toggle("active",node.dataset.tab===app.router.current()));app.settings.apply(root);}
function open(){root.classList.add("is-open");app.open();paint();root.querySelector("#ft-close").focus();}
function close(){root.classList.remove("is-open");app.close();launcher.focus();}
launcher.addEventListener("click",open);root.querySelector("#ft-close").addEventListener("click",close);root.querySelector("#ft-home").addEventListener("click",()=>{app.router.home();paint();});root.querySelectorAll("[data-tab]").forEach(node=>node.addEventListener("click",()=>navigate(node.dataset.tab)));
root.addEventListener("click",event=>{if(event.target===root)close();});document.addEventListener("keydown",event=>{if(event.key==="Escape"&&root.classList.contains("is-open")){event.preventDefault();close();}});
app.bus.on("notification",item=>{if(!root.classList.contains("is-open"))return;const toast=document.createElement("div");toast.className="ft-toast";toast.innerHTML=`<strong>${escapeHTML(item.title)}</strong><small>${escapeHTML(item.message)}</small>`;root.querySelector("#ft-toasts").append(toast);setTimeout(()=>toast.remove(),3600);});
app.bus.on("state:changed",()=>{const label=root.querySelector("#ft-save-indicator");if(label)label.textContent=app.state.get("settings.autosave")?"AUTOSAVE READY":"MANUAL SAVE";});
setInterval(()=>{const clock=root.querySelector("#ft-clock");if(clock)clock.textContent=new Intl.DateTimeFormat(undefined,{hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(new Date());},1000);
// The launcher is deliberately additive: the existing game's controls and save manager remain untouched.
window.UFOrphanFieldTerminal={app,open,close,navigate,version:"1.0.0"};
