export class PriceHistory {
  constructor(limit = 60) { this.limit = limit; this.rows = new Map(); }
  add(itemId, price, timestamp = Date.now()) {
    const rows = this.rows.get(itemId) || [];
    rows.push({ price: Number(price), timestamp });
    this.rows.set(itemId, rows.slice(-this.limit));
  }
  get(itemId) { return [...(this.rows.get(itemId) || [])]; }
  average(itemId) { const rows = this.get(itemId); return rows.length ? rows.reduce((sum, row) => sum + row.price, 0) / rows.length : null; }
  minimum(itemId) { return Math.min(...this.get(itemId).map(row => row.price)); }
  change(itemId) { const rows = this.get(itemId); return rows.length < 2 ? 0 : rows.at(-1).price - rows[0].price; }
}
