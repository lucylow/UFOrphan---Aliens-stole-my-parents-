export class SignalDecoder {
  constructor() { this.samples = []; }
  add(sample) { if (!Number.isFinite(sample)) return false; this.samples.push(sample); this.samples = this.samples.slice(-256); return true; }
  average() { return this.samples.length ? this.samples.reduce((sum, value) => sum + value, 0) / this.samples.length : 0; }
  variance() { const mean = this.average(); return this.samples.length ? this.samples.reduce((sum, value) => sum + (value - mean) ** 2, 0) / this.samples.length : 0; }
  strength() { return Math.max(0, Math.min(100, Math.round(this.average()))); }
  stable(threshold = 12) { return this.variance() <= threshold; }
  reset() { this.samples = []; }
}
