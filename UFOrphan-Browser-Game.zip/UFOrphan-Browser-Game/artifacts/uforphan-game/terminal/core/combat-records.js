export class CombatRecords {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  record(type, amount = 1) {
    this.state.mutate(data => {
      data.combatRecords ||= { defeats: {}, damageDealt: 0, damageTaken: 0, bossWins: 0 };
      if (type === "damage-dealt") data.combatRecords.damageDealt += amount;
      else if (type === "damage-taken") data.combatRecords.damageTaken += amount;
      else if (type === "boss-win") data.combatRecords.bossWins += 1;
      else data.combatRecords.defeats[type] = (data.combatRecords.defeats[type] || 0) + amount;
    }, "combat:record");
    this.bus.emit("combat:recorded", { type, amount });
  }
  snapshot() { return this.state.get("combatRecords") || { defeats: {}, damageDealt: 0, damageTaken: 0, bossWins: 0 }; }
  totalDefeats() { return Object.values(this.snapshot().defeats).reduce((sum, value) => sum + value, 0); }
}
