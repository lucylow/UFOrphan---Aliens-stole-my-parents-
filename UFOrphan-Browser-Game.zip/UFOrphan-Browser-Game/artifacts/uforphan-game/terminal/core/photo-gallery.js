import { uid, nowISO } from "./utils.js";
export class PhotoGallery {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  photos() {
    return this.state.get("photos") || [];
  }
  add({ title, dataUrl, sector, caption = "" }) {
    if (!dataUrl || !String(dataUrl).startsWith("data:image/")) return { ok: false, reason: "invalid-image" };
    const photo = { id: uid("photo"), title, dataUrl, sector, caption, at: nowISO() };
    this.state.mutate(data => {
      data.photos ||= [];
      data.photos.unshift(photo);
      data.photos = data.photos.slice(0, 40);
    }, "photo:add");
    this.bus.emit("photo:added", photo);
    return { ok: true, photo };
  }
  remove(id) {
    this.state.mutate(data => data.photos = (data.photos || []).filter(photo => photo.id !== id), "photo:remove");
  }
  bySector(sector) {
    return this.photos().filter(photo => photo.sector === sector);
  }
  count() {
    return this.photos().length;
  }
}
