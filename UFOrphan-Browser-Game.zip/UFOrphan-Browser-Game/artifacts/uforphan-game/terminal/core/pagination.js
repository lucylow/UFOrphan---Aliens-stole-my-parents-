export class Pagination {
  constructor(items = [], pageSize = 12) {
    this.items = items;
    this.pageSize = Math.max(1, pageSize);
    this.page = 0;
  }
  setItems(items) {
    this.items = items;
    this.page = Math.min(this.page, this.pageCount - 1);
  }
  get pageCount() {
    return Math.max(1, Math.ceil(this.items.length / this.pageSize));
  }
  get currentItems() {
    const start = this.page * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  }
  go(page) {
    this.page = Math.max(0, Math.min(this.pageCount - 1, Number(page) || 0));
    return this.currentItems;
  }
  next() {
    return this.go(this.page + 1);
  }
  previous() {
    return this.go(this.page - 1);
  }
  first() {
    return this.go(0);
  }
  last() {
    return this.go(this.pageCount - 1);
  }
}
