import { uid, nowISO } from "./utils.js";
export class ConversationHistory {
  constructor(state) { this.state = state; }
  all() { return this.state.get("conversations") || []; }
  append(speaker, text, thread = "main") {
    const entry = { id: uid("line"), speaker, text: String(text), thread, at: nowISO() };
    this.state.mutate(data => { data.conversations ||= []; data.conversations.push(entry); data.conversations = data.conversations.slice(-500); }, "conversation:append");
    return entry;
  }
  thread(id) { return this.all().filter(entry => entry.thread === id); }
  search(term) { const query = String(term).toLowerCase(); return this.all().filter(entry => entry.text.toLowerCase().includes(query)); }
  clearThread(id) { this.state.mutate(data => data.conversations = (data.conversations || []).filter(entry => entry.thread !== id), "conversation:clear"); }
}
