import { clone } from "./utils.js";
export class WorldState {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  flag(id) {
    return Boolean(this.state.get(`worldFlags.${id}`));
  }
  setFlag(id, value = true) {
    this.state.set(`worldFlags.${id}`, Boolean(value));
    this.bus.emit("world:flag", { id, value: Boolean(value) });
  }
  once(id, callback) {
    if (this.flag(id)) return false;
    callback();
    this.setFlag(id, true);
    return true;
  }
  snapshot(prefix = "") {
    const flags = this.state.get("worldFlags") || {};
    return Object.fromEntries(Object.entries(flags).filter(([id]) => id.startsWith(prefix)).map(([id, value]) => [id, clone(value)]));
  }
  clear(prefix = "") {
    this.state.mutate(data => {
      for (const key of Object.keys(data.worldFlags || {})) if (key.startsWith(prefix)) delete data.worldFlags[key];
    }, "world:flags-cleared");
  }
}
