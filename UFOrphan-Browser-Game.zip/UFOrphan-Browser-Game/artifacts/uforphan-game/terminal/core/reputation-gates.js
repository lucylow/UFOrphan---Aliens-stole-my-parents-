export class ReputationGates {
  constructor(reputation) { this.reputation = reputation; }
  check(gate) {
    const score = this.reputation.score(gate.faction);
    return { allowed: score >= gate.minimum, score, minimum: gate.minimum, missing: Math.max(0, gate.minimum - score) };
  }
  filter(options) { return options.filter(option => !option.gate || this.check(option.gate).allowed); }
  explain(gate) { const result = this.check(gate); return result.allowed ? "Access granted" : `Need ${result.missing} more reputation`; }
}
