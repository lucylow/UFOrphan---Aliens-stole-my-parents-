export class CommandPalette {
  constructor(commands = []) {
    this.commands = new Map();
    this.history = [];
    this.registerMany(commands);
  }
  register(command) {
    if (!command || !command.id || typeof command.run !== "function") {
      throw new TypeError("A command needs an id and run function");
    }
    this.commands.set(command.id, { ...command });
    return () => this.commands.delete(command.id);
  }
  registerMany(commands) {
    for (const command of commands) this.register(command);
  }
  search(query = "") {
    const term = query.trim().toLowerCase();
    return [...this.commands.values()]
      .filter(command => `${command.label} ${command.description || ""}`.toLowerCase().includes(term))
      .sort((a, b) => (b.priority || 0) - (a.priority || 0));
  }
  async execute(id, context = {}) {
    const command = this.commands.get(id);
    if (!command) return { ok: false, reason: "unknown-command" };
    if (command.enabled && !command.enabled(context)) return { ok: false, reason: "disabled" };
    const result = await command.run(context);
    this.history.unshift({ id, at: new Date().toISOString() });
    this.history = this.history.slice(0, 20);
    return { ok: true, result };
  }
  recent() {
    return this.history.map(entry => ({ ...entry, command: this.commands.get(entry.id) }));
  }
}
