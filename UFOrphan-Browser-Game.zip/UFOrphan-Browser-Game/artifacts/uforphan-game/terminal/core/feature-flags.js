export class FeatureFlags {
  constructor(initial = {}) {
    this.flags = new Map(Object.entries(initial));
  }
  enabled(name, fallback = false) {
    return this.flags.has(name) ? Boolean(this.flags.get(name)) : fallback;
  }
  set(name, value) {
    this.flags.set(name, Boolean(value));
  }
  toggle(name) {
    const value = !this.enabled(name);
    this.set(name, value);
    return value;
  }
  all() {
    return Object.fromEntries(this.flags);
  }
  reset(values = {}) {
    this.flags = new Map(Object.entries(values));
  }
}
