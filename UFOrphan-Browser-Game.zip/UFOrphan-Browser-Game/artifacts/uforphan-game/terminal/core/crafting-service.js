import { RECIPES } from "../data/catalog.js";
export class CraftingService {
 constructor(state,inventory,bus,notices){this.state=state;this.inventory=inventory;this.bus=bus;this.notices=notices;}
 recipes(){return RECIPES.filter(recipe=>this.state.get("recipesUnlocked").includes(recipe.id));}
 canCraft(recipe){return Object.entries(recipe.cost).every(([id,count])=>this.inventory.has(id,count));}
 craft(id){const recipe=this.recipes().find(item=>item.id===id);if(!recipe)return {ok:false,reason:"recipe-locked"};if(!this.canCraft(recipe))return {ok:false,reason:"missing-materials"};for(const [item,count] of Object.entries(recipe.cost)){const result=this.inventory.remove(item,count);if(!result.ok)throw new Error("Crafting transaction lost atomicity");}this.inventory.add(recipe.output,recipe.amount,"crafted");this.state.mutate(data=>{data.statistics.itemsCrafted+=recipe.amount;data.craftingHistory.push({recipe:id,output:recipe.output,amount:recipe.amount,at:new Date().toISOString()});},"crafting:complete");this.notices.push("Crafting complete",`${recipe.amount} × ${recipe.name} crafted.`,"success");this.bus.emit("crafting:complete",{recipe,amount:recipe.amount});return {ok:true,recipe};}
 unlock(id){if(!RECIPES.some(recipe=>recipe.id===id))return false;this.state.mutate(data=>{if(!data.recipesUnlocked.includes(id))data.recipesUnlocked.push(id);},"crafting:unlock");return true;}
}
