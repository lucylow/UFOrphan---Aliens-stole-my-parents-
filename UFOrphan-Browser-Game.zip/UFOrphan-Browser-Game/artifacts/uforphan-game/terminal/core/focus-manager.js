export class FocusManager {
  constructor(root) {
    this.root = root;
    this.previous = null;
  }
  focusFirst() {
    const target = this.root.querySelector("button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex='0']");
    target?.focus();
    return Boolean(target);
  }
  capture() {
    this.previous = document.activeElement;
  }
  restore() {
    if (this.previous?.isConnected) this.previous.focus();
    this.previous = null;
  }
  trap(event) {
    if (event.key !== "Tab") return;
    const nodes = [...this.root.querySelectorAll("button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex='0']")];
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
}
