export class PartyPlanner {
  constructor(companions) { this.companions = companions; this.slots = 2; }
  roster() { return this.companions.catalog().filter(item => item.recruited); }
  select(ids) {
    const roster = new Set(this.roster().map(item => item.id));
    const unique = [...new Set(ids)].filter(id => roster.has(id));
    if (unique.length > this.slots) return { ok: false, reason: "party-full" };
    return { ok: true, members: unique };
  }
  synergy(ids) {
    const members = this.roster().filter(item => ids.includes(item.id));
    const roles = new Set(members.map(item => item.role));
    return { members, roles: [...roles], bonus: roles.size >= 2 ? "balanced-team" : "specialist-team" };
  }
}
