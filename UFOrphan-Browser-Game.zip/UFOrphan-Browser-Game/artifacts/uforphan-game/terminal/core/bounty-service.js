import { uid } from "./utils.js";
export class BountyService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  all() { return this.state.get("bounties") || []; }
  post({ title, target, reward, sector }) {
    const bounty = { id: uid("bounty"), title, target, reward, sector, status: "open", progress: 0 };
    this.state.mutate(data => { data.bounties ||= []; data.bounties.push(bounty); }, "bounty:post");
    this.bus.emit("bounty:posted", bounty); return bounty;
  }
  advance(id, amount = 1) {
    let completed = false;
    this.state.mutate(data => { const bounty = (data.bounties || []).find(item => item.id === id); if (!bounty || bounty.status !== "open") return; bounty.progress = Math.min(bounty.target, bounty.progress + amount); if (bounty.progress >= bounty.target) { bounty.status = "complete"; completed = true; } }, "bounty:progress");
    if (completed) this.bus.emit("bounty:complete", { id }); return completed;
  }
  open() { return this.all().filter(item => item.status === "open"); }
}
