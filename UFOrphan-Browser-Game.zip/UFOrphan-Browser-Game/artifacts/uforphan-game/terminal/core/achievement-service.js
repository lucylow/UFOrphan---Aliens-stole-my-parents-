import { ACHIEVEMENTS } from "../data/achievements.js";
export class AchievementService {
 constructor(state,bus,notices){this.state=state;this.bus=bus;this.notices=notices;}
 evaluate(){const unlocked=[];for(const achievement of ACHIEVEMENTS){if(this.state.get(`achievements.${achievement.id}`))continue;if(achievement.condition(this.state.data)){this.state.set(`achievements.${achievement.id}`,{unlockedAt:new Date().toISOString(),points:achievement.points});unlocked.push(achievement);this.notices.push("Achievement unlocked",achievement.name,"success");this.bus.emit("achievement:unlocked",achievement);}}return unlocked;}
 list(){return ACHIEVEMENTS.map(item=>({...item,unlocked:Boolean(this.state.get(`achievements.${item.id}`)),record:this.state.get(`achievements.${item.id}`)||null}));}
 points(){return this.list().filter(item=>item.unlocked).reduce((total,item)=>total+item.points,0);}
}
