import { ITEMS } from "../data/catalog.js";
export class ItemInspection {
  constructor(inventory) { this.inventory = inventory; }
  inspect(id) {
    const definition = ITEMS.find(item => item.id === id);
    if (!definition) return { known: false, id, owned: 0 };
    return { known: true, ...definition, owned: this.inventory.count(id), canUse: definition.type === "consumable", canSell: definition.price > 0 };
  }
  compareOwned(id) { const item = this.inspect(id); return { ...item, status: item.owned > 0 ? "owned" : "not-owned" }; }
  categories() { return [...new Set(ITEMS.map(item => item.type))].sort(); }
}
