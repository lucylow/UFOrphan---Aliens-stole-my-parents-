export class QuestRewardPreview {
  constructor(inventory) { this.inventory = inventory; }
  preview(reward) {
    const items = Object.entries(reward.items || {}).map(([id, amount]) => ({ id, amount, alreadyOwned: this.inventory.count(id) }));
    return { credits: reward.credits || 0, xp: reward.xp || 0, items, itemCount: items.reduce((sum, item) => sum + item.amount, 0) };
  }
  describe(reward) {
    const result = this.preview(reward);
    return [`${result.credits} credits`, `${result.xp} XP`, ...result.items.map(item => `${item.id} × ${item.amount}`)].join(" · ");
  }
}
