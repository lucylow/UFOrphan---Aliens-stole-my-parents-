import { uid, nowISO } from "./utils.js";
export class TimelineService {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  entries() {
    return this.state.get("timeline") || [];
  }
  add(type, title, description, metadata = {}) {
    const entry = { id: uid("timeline"), type, title, description, metadata, at: nowISO() };
    this.state.mutate(data => {
      data.timeline ||= [];
      data.timeline.unshift(entry);
      data.timeline = data.timeline.slice(0, 500);
    }, "timeline:add");
    this.bus.emit("timeline:entry", entry);
    return entry;
  }
  range(start, end) {
    const a = new Date(start).getTime();
    const b = new Date(end).getTime();
    return this.entries().filter(entry => {
      const time = new Date(entry.at).getTime();
      return time >= a && time <= b;
    });
  }
  byType(type) {
    return this.entries().filter(entry => entry.type === type);
  }
  latest(limit = 20) {
    return this.entries().slice(0, limit);
  }
}
