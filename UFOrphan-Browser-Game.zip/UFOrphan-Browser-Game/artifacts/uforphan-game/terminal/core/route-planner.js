export class RoutePlanner {
  constructor(sectors) {
    this.sectors = sectors;
  }
  distance(a, b) {
    return Math.hypot(a.coordinates[0] - b.coordinates[0], a.coordinates[1] - b.coordinates[1]);
  }
  neighbors(sector, maxDistance = 3) {
    return this.sectors.filter(candidate => candidate.id !== sector.id && this.distance(sector, candidate) <= maxDistance);
  }
  shortestPath(fromId, toId, discovered = this.sectors.map(item => item.id)) {
    const allowed = new Set(discovered);
    const start = this.sectors.find(item => item.id === fromId);
    const target = this.sectors.find(item => item.id === toId);
    if (!start || !target || !allowed.has(fromId) || !allowed.has(toId)) return null;
    const queue = [[start.id]];
    const visited = new Set([start.id]);
    while (queue.length) {
      const path = queue.shift();
      const current = this.sectors.find(item => item.id === path.at(-1));
      if (current.id === target.id) return path;
      for (const neighbor of this.neighbors(current)) {
        if (!allowed.has(neighbor.id) || visited.has(neighbor.id)) continue;
        visited.add(neighbor.id);
        queue.push([...path, neighbor.id]);
      }
    }
    return null;
  }
  estimate(path) {
    if (!path || path.length < 2) return { jumps: 0, danger: 0 };
    const stops = path.map(id => this.sectors.find(item => item.id === id)).filter(Boolean);
    return { jumps: stops.length - 1, danger: stops.reduce((total, stop) => total + stop.danger, 0) };
  }
}
