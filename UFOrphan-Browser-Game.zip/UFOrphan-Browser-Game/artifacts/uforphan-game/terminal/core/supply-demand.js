export class SupplyDemand {
  constructor(basePrice = 1) { this.basePrice = basePrice; this.supply = 1; this.demand = 1; }
  setSupply(value) { this.supply = Math.max(.1, Number(value) || .1); }
  setDemand(value) { this.demand = Math.max(.1, Number(value) || .1); }
  price() { return Math.max(1, Math.round(this.basePrice * (this.demand / this.supply))); }
  adjust({ supply = 0, demand = 0 }) { this.setSupply(this.supply + supply); this.setDemand(this.demand + demand); return this.price(); }
  snapshot() { return { basePrice: this.basePrice, supply: this.supply, demand: this.demand, currentPrice: this.price() }; }
}
