export class PlaytimeTracker {
  constructor(clock = () => Date.now()) {
    this.clock = clock;
    this.startedAt = null;
    this.totalMs = 0;
  }
  start() {
    if (this.startedAt === null) this.startedAt = this.clock();
  }
  pause() {
    if (this.startedAt === null) return 0;
    const elapsed = Math.max(0, this.clock() - this.startedAt);
    this.totalMs += elapsed;
    this.startedAt = null;
    return elapsed;
  }
  current() {
    return this.totalMs + (this.startedAt === null ? 0 : Math.max(0, this.clock() - this.startedAt));
  }
  formatted() {
    const seconds = Math.floor(this.current() / 1000);
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  }
  reset() {
    this.startedAt = null;
    this.totalMs = 0;
  }
}
