import { uid } from "./utils.js";
export class QuestBoard {
  constructor(bus) {
    this.bus = bus;
    this.contracts = [];
    this.claimed = new Set();
  }
  post(contract) {
    const entry = { ...contract, boardId: uid("contract"), postedAt: new Date().toISOString(), status: "open" };
    this.contracts.push(entry);
    this.bus.emit("board:posted", entry);
    return entry;
  }
  available(filters = {}) {
    return this.contracts.filter(contract => {
      if (contract.status !== "open") return false;
      if (filters.sector && contract.sector !== filters.sector) return false;
      if (filters.type && contract.type !== filters.type) return false;
      return true;
    });
  }
  accept(id) {
    const contract = this.contracts.find(item => item.boardId === id);
    if (!contract || contract.status !== "open") return false;
    contract.status = "accepted";
    this.bus.emit("board:accepted", contract);
    return true;
  }
  complete(id) {
    const contract = this.contracts.find(item => item.boardId === id);
    if (!contract || contract.status !== "accepted") return false;
    contract.status = "complete";
    this.bus.emit("board:completed", contract);
    return true;
  }
  archive(id) {
    this.contracts = this.contracts.filter(item => item.boardId !== id);
  }
}
