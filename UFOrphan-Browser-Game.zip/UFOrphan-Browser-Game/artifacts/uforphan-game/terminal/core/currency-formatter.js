export class CurrencyFormatter {
  constructor(locale = undefined, currency = "CR") {
    this.locale = locale;
    this.currency = currency;
    this.number = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 });
  }
  format(value) {
    return `${this.number.format(Number(value) || 0)} ${this.currency}`;
  }
  compact(value) {
    return new Intl.NumberFormat(this.locale, { notation: "compact", maximumFractionDigits: 1 }).format(Number(value) || 0);
  }
  parse(value) {
    const numeric = Number(String(value).replace(/[^0-9.-]/g, ""));
    return Number.isFinite(numeric) ? numeric : null;
  }
  setLocale(locale) {
    this.locale = locale;
    this.number = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 });
  }
}
