export class AnalyticsService {
  constructor(state) {
    this.state = state;
  }
  increment(metric, amount = 1) {
    if (!Number.isFinite(amount)) return false;
    this.state.mutate(data => {
      data.analytics ||= {};
      data.analytics[metric] = (data.analytics[metric] || 0) + amount;
    }, `analytics:${metric}`);
    return true;
  }
  set(metric, value) {
    this.state.set(`analytics.${metric}`, value);
  }
  value(metric) {
    return this.state.get(`analytics.${metric}`) ?? 0;
  }
  snapshot() {
    return { ...(this.state.get("analytics") || {}) };
  }
  top(limit = 10) {
    return Object.entries(this.snapshot()).sort((a, b) => b[1] - a[1]).slice(0, limit);
  }
  reset() {
    this.state.set("analytics", {});
  }
}
