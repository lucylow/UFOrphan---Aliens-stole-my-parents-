export class GameModeService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  current() { return this.state.get("gameMode") || "story"; }
  set(mode) {
    const modes = ["story", "exploration", "challenge", "practice"];
    if (!modes.includes(mode)) return false;
    const previous = this.current(); this.state.set("gameMode", mode);
    this.bus.emit("mode:changed", { previous, mode }); return true;
  }
  is(mode) { return this.current() === mode; }
  description() { return ({ story: "Follow the rescue story.", exploration: "Explore without pressure.", challenge: "Take on optional trials.", practice: "Practice movement and tools." })[this.current()]; }
}
