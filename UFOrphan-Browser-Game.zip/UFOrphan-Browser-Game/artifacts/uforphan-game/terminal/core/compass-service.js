export class CompassService {
  constructor(mapService) {
    this.map = mapService;
    this.target = null;
  }
  pointTo(sectorId) {
    const sector = this.map.list().find(item => item.id === sectorId && item.discovered);
    if (!sector) return false;
    this.target = sectorId;
    return true;
  }
  bearing(fromId) {
    if (!this.target) return null;
    const route = this.map.route(fromId, this.target);
    if (!route) return null;
    const dx = route.to.coordinates[0] - route.from.coordinates[0];
    const dy = route.to.coordinates[1] - route.from.coordinates[1];
    return (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
  }
  clear() {
    this.target = null;
  }
  destination() {
    return this.target;
  }
}
