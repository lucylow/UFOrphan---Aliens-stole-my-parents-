export class MissionRewards {
  constructor(state, inventory, notices) { this.state = state; this.inventory = inventory; this.notices = notices; }
  preview(rewards) { return { credits: rewards.credits || 0, xp: rewards.xp || 0, items: Object.entries(rewards.items || {}).map(([id, count]) => ({ id, count })) }; }
  grant(rewards, source = "mission") {
    const preview = this.preview(rewards);
    this.state.mutate(data => { data.credits += preview.credits; data.statistics.creditsEarned += preview.credits; data.progression ||= { xp: 0 }; data.progression.xp += preview.xp; }, "reward:grant");
    for (const item of preview.items) this.inventory.add(item.id, item.count, source);
    this.notices.push("Rewards received", `${preview.credits} credits and ${preview.xp} XP added.`, "success");
    return preview;
  }
}
