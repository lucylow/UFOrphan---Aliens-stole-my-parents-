export class ConsumableService {
  constructor(inventory, cooldowns, bus) { this.inventory = inventory; this.cooldowns = cooldowns; this.bus = bus; }
  use(id, context, cooldownMs = 0) {
    if (!this.inventory.has(id)) return { ok: false, reason: "not-owned" };
    if (!this.cooldowns.ready(id)) return { ok: false, reason: "cooldown", remaining: this.cooldowns.remaining(id) };
    const result = this.inventory.use(id, context);
    if (!result.ok) return result;
    if (cooldownMs > 0) this.cooldowns.start(id, cooldownMs);
    this.bus.emit("consumable:used", { id });
    return { ok: true };
  }
  available(ids) { return ids.filter(id => this.inventory.has(id) && this.cooldowns.ready(id)); }
}
