export class EventBus {
  #listeners = new Map();
  on(type, listener) { if (!this.#listeners.has(type)) this.#listeners.set(type,new Set()); this.#listeners.get(type).add(listener); return () => this.off(type,listener); }
  once(type, listener) { const off=this.on(type,payload=>{off();listener(payload);}); return off; }
  off(type, listener) { this.#listeners.get(type)?.delete(listener); }
  emit(type, payload = {}) { const listeners=[...(this.#listeners.get(type)||[])]; for (const listener of listeners) { try { listener(payload); } catch(error) { queueMicrotask(()=>{throw error;}); } } return listeners.length; }
  clear(type) { if(type)this.#listeners.delete(type); else this.#listeners.clear(); }
  count(type) { return this.#listeners.get(type)?.size || 0; }
  waitFor(type, timeout = 5000) { return new Promise((resolve,reject)=>{ const timer=setTimeout(()=>{off();reject(new Error(`Timed out waiting for ${type}`));},timeout); const off=this.once(type,value=>{clearTimeout(timer);resolve(value);}); }); }
}
