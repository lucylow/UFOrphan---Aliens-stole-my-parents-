import { uid, nowISO } from "./utils.js";
export class BeaconService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  list() { return this.state.get("beacons") || []; }
  activate(id, payload = {}) {
    let result = null;
    this.state.mutate(data => {
      data.beacons ||= [];
      let beacon = data.beacons.find(item => item.id === id);
      if (!beacon) { beacon = { id, active: false, history: [] }; data.beacons.push(beacon); }
      if (beacon.active) return;
      beacon.active = true;
      beacon.activatedAt = nowISO();
      beacon.history.push({ eventId: uid("beacon-event"), ...payload, at: nowISO() });
      result = beacon;
    }, "beacon:activate");
    if (result) this.bus.emit("beacon:activated", result);
    return result;
  }
  activeCount() { return this.list().filter(item => item.active).length; }
  reset(id) { this.state.mutate(data => { const item = (data.beacons || []).find(entry => entry.id === id); if (item) item.active = false; }, "beacon:reset"); }
}
