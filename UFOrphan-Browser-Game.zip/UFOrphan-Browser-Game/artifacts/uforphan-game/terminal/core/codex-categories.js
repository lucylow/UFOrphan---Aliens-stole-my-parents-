export class CodexCategories {
  constructor(entries) {
    this.entries = entries;
  }
  all() {
    return [...new Set(this.entries.map(entry => entry.category))].sort();
  }
  count(category, unlocked = null) {
    return this.entries.filter(entry => entry.category === category && (unlocked === null || Boolean(unlocked(entry.id)) === unlocked)).length;
  }
  groups(unlocked = null) {
    return this.all().map(category => ({
      category,
      entries: this.entries.filter(entry => entry.category === category && (unlocked === null || Boolean(unlocked(entry.id)) === unlocked))
    }));
  }
  search(query) {
    const term = String(query || "").toLowerCase();
    return this.entries.filter(entry => `${entry.title} ${entry.body} ${entry.category}`.toLowerCase().includes(term));
  }
}
