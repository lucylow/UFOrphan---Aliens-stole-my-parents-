const PRESETS = {
  balanced: { reduceMotion: false, highContrast: false, largeText: false, showHints: true },
  accessible: { reduceMotion: true, highContrast: true, largeText: true, showHints: true },
  minimal: { reduceMotion: true, highContrast: false, largeText: false, showHints: false }
};
export class SettingsPresets {
  constructor(settings) { this.settings = settings; }
  names() { return Object.keys(PRESETS); }
  apply(name) { const preset = PRESETS[name]; if (!preset) return false; for (const [key, value] of Object.entries(preset)) this.settings.update(key, value); return true; }
  describe(name) { return PRESETS[name] ? { ...PRESETS[name] } : null; }
}
