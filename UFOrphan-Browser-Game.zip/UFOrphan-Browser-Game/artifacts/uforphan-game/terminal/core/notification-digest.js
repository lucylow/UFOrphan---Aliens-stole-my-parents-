export class NotificationDigest {
  constructor(notifications) {
    this.notifications = notifications;
  }
  groupByType() {
    return this.notifications.reduce((groups, item) => {
      const key = item.type || "info";
      (groups[key] ||= []).push(item);
      return groups;
    }, {});
  }
  summary() {
    const groups = this.groupByType();
    return Object.entries(groups).map(([type, items]) => ({
      type,
      count: items.length,
      latest: items[0]?.createdAt || null,
      unread: items.filter(item => !item.read).length
    }));
  }
  unread() {
    return this.notifications.filter(item => !item.read);
  }
  latest(limit = 5) {
    return this.notifications.slice(0, limit);
  }
}
