export class ItemTradeService {
  constructor(inventory, bus) { this.inventory = inventory; this.bus = bus; }
  quote(offer) {
    const give = Object.entries(offer.give || {});
    const receive = Object.entries(offer.receive || {});
    const missing = give.filter(([id, count]) => !this.inventory.has(id, count));
    return { ok: missing.length === 0 && receive.length > 0, give, receive, missing };
  }
  execute(offer) {
    const quote = this.quote(offer);
    if (!quote.ok) return { ok: false, reason: "trade-unavailable", missing: quote.missing };
    for (const [id, count] of quote.give) this.inventory.remove(id, count);
    for (const [id, count] of quote.receive) this.inventory.add(id, count, "trade");
    this.bus.emit("trade:complete", { offer }); return { ok: true };
  }
}
