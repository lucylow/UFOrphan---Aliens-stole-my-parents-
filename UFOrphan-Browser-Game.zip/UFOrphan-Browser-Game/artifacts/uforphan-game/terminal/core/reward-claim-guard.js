export class RewardClaimGuard {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  claimed(id) {
    return Boolean(this.state.get(`claimedRewards.${id}`));
  }
  claim(id, grant) {
    if (this.claimed(id)) return { ok: false, reason: "already-claimed" };
    if (typeof grant !== "function") return { ok: false, reason: "invalid-grant" };
    const result = grant();
    if (result === false || result?.ok === false) return { ok: false, reason: "grant-failed" };
    this.state.set(`claimedRewards.${id}`, new Date().toISOString());
    this.bus.emit("reward:claimed", { id, result });
    return { ok: true, result };
  }
  list() {
    return Object.keys(this.state.get("claimedRewards") || {});
  }
}
