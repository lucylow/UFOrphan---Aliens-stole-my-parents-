export class MissionFilter {
  apply(missions, options = {}) {
    return missions.filter(mission => {
      if (options.type && mission.type !== options.type) return false;
      if (options.sector && mission.sector !== options.sector) return false;
      if (options.status && mission.progress?.status !== options.status) return false;
      if (options.search && !`${mission.title} ${mission.description}`.toLowerCase().includes(options.search.toLowerCase())) return false;
      return true;
    });
  }
  counts(missions) {
    return missions.reduce((counts, mission) => { const status = mission.progress?.status || "available"; counts[status] = (counts[status] || 0) + 1; return counts; }, {});
  }
}
