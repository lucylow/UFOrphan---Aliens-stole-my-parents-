import { uid } from "./utils.js";
export class DailyChallengeService {
  constructor(state, bus, notices) {
    this.state = state;
    this.bus = bus;
    this.notices = notices;
  }
  dateKey(date = new Date()) {
    return date.toISOString().slice(0, 10);
  }
  getToday() {
    const key = this.dateKey();
    return this.state.get(`dailyChallenges.${key}`) || null;
  }
  create(definitions, date = new Date()) {
    const key = this.dateKey(date);
    const existing = this.state.get(`dailyChallenges.${key}`);
    if (existing) return existing;
    const selected = definitions.slice(0, 3).map(definition => ({
      id: uid("daily"),
      definitionId: definition.id,
      title: definition.title,
      target: definition.target,
      progress: 0,
      reward: definition.reward,
      claimed: false
    }));
    this.state.mutate(data => {
      data.dailyChallenges ||= {};
      data.dailyChallenges[key] = selected;
    }, "daily-challenge:create");
    return selected;
  }
  advance(id, amount = 1) {
    const key = this.dateKey();
    let completed = false;
    this.state.mutate(data => {
      const challenge = (data.dailyChallenges?.[key] || []).find(item => item.id === id);
      if (!challenge || challenge.claimed) return;
      challenge.progress = Math.min(challenge.target, challenge.progress + amount);
      completed = challenge.progress >= challenge.target;
    }, "daily-challenge:progress");
    if (completed) this.bus.emit("daily-challenge:complete", { id });
    return completed;
  }
  claim(id) {
    const key = this.dateKey();
    let reward = 0;
    this.state.mutate(data => {
      const challenge = (data.dailyChallenges?.[key] || []).find(item => item.id === id);
      if (!challenge || challenge.claimed || challenge.progress < challenge.target) return;
      challenge.claimed = true;
      reward = challenge.reward;
      data.credits += reward;
      data.statistics.creditsEarned += reward;
    }, "daily-challenge:claim");
    if (reward) this.notices.push("Daily reward", `${reward} credits added.`, "success");
    return reward > 0;
  }
}
