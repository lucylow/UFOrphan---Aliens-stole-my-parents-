export class SectorSignal {
  constructor(sectors) { this.sectors = sectors; }
  strength(id) { return this.sectors.find(item => item.id === id)?.signal ?? 0; }
  strongest(count = 3) { return [...this.sectors].sort((a, b) => b.signal - a.signal).slice(0, count); }
  weakest(count = 3) { return [...this.sectors].sort((a, b) => a.signal - b.signal).slice(0, count); }
  difference(a, b) { return Math.abs(this.strength(a) - this.strength(b)); }
}
