import { uid, nowISO } from "./utils.js";
export class ErrorReporter {
  constructor(limit = 50) {
    this.limit = limit;
    this.errors = [];
  }
  capture(error, context = {}) {
    const record = {
      id: uid("error"),
      name: error?.name || "Error",
      message: error?.message || String(error),
      stack: error?.stack || "",
      context,
      at: nowISO()
    };
    this.errors.unshift(record);
    this.errors = this.errors.slice(0, this.limit);
    return record;
  }
  list() {
    return [...this.errors];
  }
  clear() {
    this.errors = [];
  }
  summary() {
    return this.errors.reduce((result, error) => {
      result[error.name] = (result[error.name] || 0) + 1;
      return result;
    }, {});
  }
}
