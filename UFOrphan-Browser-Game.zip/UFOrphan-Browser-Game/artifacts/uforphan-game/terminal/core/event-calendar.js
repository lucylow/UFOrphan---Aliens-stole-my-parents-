export class EventCalendar {
  constructor(bus) {
    this.bus = bus;
    this.events = [];
  }
  add(event) {
    if (!event || !event.id || !event.title || !event.date) throw new TypeError("Invalid calendar event");
    const normalized = { ...event, date: new Date(event.date).toISOString() };
    this.events.push(normalized);
    this.events.sort((a, b) => a.date.localeCompare(b.date));
    this.bus.emit("calendar:added", normalized);
    return normalized;
  }
  remove(id) {
    const before = this.events.length;
    this.events = this.events.filter(event => event.id !== id);
    return before !== this.events.length;
  }
  upcoming(from = new Date(), limit = 10) {
    const start = from.getTime();
    return this.events.filter(event => new Date(event.date).getTime() >= start).slice(0, limit);
  }
  onDate(date) {
    const key = new Date(date).toISOString().slice(0, 10);
    return this.events.filter(event => event.date.slice(0, 10) === key);
  }
  clearPast(now = new Date()) {
    const before = this.events.length;
    this.events = this.events.filter(event => new Date(event.date) >= now);
    return before - this.events.length;
  }
}
