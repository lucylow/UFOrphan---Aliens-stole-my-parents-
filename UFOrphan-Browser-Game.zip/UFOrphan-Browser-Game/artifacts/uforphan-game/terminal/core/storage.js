import { clone, safeParse, nowISO } from "./utils.js";
export class TerminalStorage {
  constructor(key="uforphan.field-terminal.v1", storage=globalThis.localStorage) { this.key=key; this.storage=storage; this.memory=null; this.listeners=new Set(); }
  read(fallback={}) { try { const raw=this.storage?.getItem(this.key); return safeParse(raw,fallback); } catch { return clone(this.memory ?? fallback); } }
  write(value) { const snapshot={...clone(value),_terminalSavedAt:nowISO()}; this.memory=snapshot; let persistent=false; try { this.storage?.setItem(this.key,JSON.stringify(snapshot)); persistent=true; } catch {} for(const listener of this.listeners) listener(snapshot); return {ok:true,persistent,value:snapshot}; }
  update(mutator,fallback={}) { const current=this.read(fallback); const next=mutator(current) ?? current; return this.write(next); }
  clear() { this.memory=null; try { this.storage?.removeItem(this.key); } catch {} }
  subscribe(listener) { this.listeners.add(listener); return ()=>this.listeners.delete(listener); }
  export() { return this.read({}); }
  import(value) { if(!value || typeof value!=="object" || Array.isArray(value)) throw new TypeError("Invalid terminal save"); return this.write(value); }
}
