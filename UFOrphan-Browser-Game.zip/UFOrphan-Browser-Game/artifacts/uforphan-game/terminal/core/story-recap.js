export class StoryRecap {
  constructor(timeline) {
    this.timeline = timeline;
  }
  build(completedIds) {
    const completed = new Set(completedIds);
    return this.timeline.events
      .filter(event => completed.has(event.id))
      .sort((a, b) => a.order - b.order)
      .map(event => ({
        title: event.title,
        summary: event.summary || event.description,
        order: event.order
      }));
  }
  toText(completedIds) {
    return this.build(completedIds)
      .map((event, index) => `${index + 1}. ${event.title}\n${event.summary}`)
      .join("\n\n");
  }
  count(completedIds) {
    return this.build(completedIds).length;
  }
}
