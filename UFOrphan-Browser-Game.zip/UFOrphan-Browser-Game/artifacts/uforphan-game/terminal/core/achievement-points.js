export class AchievementPoints {
  constructor(achievements) {
    this.achievements = achievements;
  }
  total(unlockedIds) {
    const unlocked = new Set(unlockedIds);
    return this.achievements.filter(item => unlocked.has(item.id)).reduce((sum, item) => sum + item.points, 0);
  }
  nextMilestone(points, milestones) {
    return [...milestones].sort((a, b) => a.points - b.points).find(item => points < item.points) || null;
  }
  rank(points) {
    if (points >= 200) return "galaxy legend";
    if (points >= 100) return "star captain";
    if (points >= 50) return "sector scout";
    if (points >= 20) return "junior explorer";
    return "new arrival";
  }
}
