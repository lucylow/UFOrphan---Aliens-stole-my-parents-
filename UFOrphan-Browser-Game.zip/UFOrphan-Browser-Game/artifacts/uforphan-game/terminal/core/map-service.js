import { SECTORS } from "../data/sectors.js";
export class MapService {
 constructor(state,bus){this.state=state;this.bus=bus;}
 list(){return SECTORS.map(sector=>({...sector,discovered:this.state.get("discoveredSectors").includes(sector.id)}));}
 discover(id){const sector=SECTORS.find(item=>item.id===id);if(!sector)return false;this.state.mutate(data=>{if(!data.discoveredSectors.includes(id))data.discoveredSectors.push(id);},"map:discover");this.bus.emit("sector:discovered",sector);return true;}
 progress(){return {discovered:this.state.get("discoveredSectors").length,total:SECTORS.length};}
 route(from,to){const a=SECTORS.find(item=>item.id===from),b=SECTORS.find(item=>item.id===to);if(!a||!b)return null;return {from:a,to:b,jumps:Math.max(1,Math.abs(a.coordinates[0]-b.coordinates[0])/2),signalDifference:Math.abs(a.signal-b.signal)};}
}
