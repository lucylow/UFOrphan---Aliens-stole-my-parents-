import { nowISO, uid } from "./utils.js";
export class SessionService {
  constructor(bus) {
    this.bus = bus;
    this.current = null;
    this.history = [];
  }
  start(label = "expedition") {
    if (this.current) this.finish();
    this.current = { id: uid("session"), label, startedAt: nowISO(), actions: 0 };
    this.bus.emit("session:started", this.current);
    return this.current;
  }
  action(name) {
    if (!this.current) this.start();
    this.current.actions++;
    this.bus.emit("session:action", { name, session: this.current });
  }
  finish() {
    if (!this.current) return null;
    const finished = { ...this.current, finishedAt: nowISO() };
    finished.durationMs = new Date(finished.finishedAt) - new Date(finished.startedAt);
    this.history.unshift(finished);
    this.history = this.history.slice(0, 30);
    this.current = null;
    this.bus.emit("session:finished", finished);
    return finished;
  }
  summary() {
    return this.history.reduce((total, item) => ({
      sessions: total.sessions + 1,
      actions: total.actions + item.actions,
      durationMs: total.durationMs + item.durationMs
    }), { sessions: 0, actions: 0, durationMs: 0 });
  }
}
