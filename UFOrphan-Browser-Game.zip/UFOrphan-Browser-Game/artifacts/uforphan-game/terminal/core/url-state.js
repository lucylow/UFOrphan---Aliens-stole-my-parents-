export class URLState {
  constructor(location = globalThis.location, history = globalThis.history) {
    this.location = location;
    this.history = history;
  }
  read() {
    const params = new URLSearchParams(this.location.search);
    return Object.fromEntries(params.entries());
  }
  get(key, fallback = null) {
    return new URLSearchParams(this.location.search).get(key) ?? fallback;
  }
  set(key, value, replace = false) {
    const url = new URL(this.location.href);
    if (value === null || value === undefined || value === "") url.searchParams.delete(key);
    else url.searchParams.set(key, String(value));
    const method = replace ? "replaceState" : "pushState";
    this.history[method]({}, "", url);
  }
  clear() {
    this.history.replaceState({}, "", this.location.pathname);
  }
}
