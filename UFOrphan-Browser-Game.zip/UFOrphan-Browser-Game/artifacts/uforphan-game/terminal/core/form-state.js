export class FormState {
  constructor(initial = {}) {
    this.values = { ...initial };
    this.errors = {};
    this.touched = new Set();
    this.dirty = new Set();
  }
  get(name) {
    return this.values[name];
  }
  set(name, value) {
    if (this.values[name] !== value) this.dirty.add(name);
    this.values[name] = value;
    this.touched.add(name);
  }
  setError(name, message) {
    if (message) this.errors[name] = message;
    else delete this.errors[name];
  }
  valid() {
    return Object.keys(this.errors).length === 0;
  }
  reset(values = {}) {
    this.values = { ...values };
    this.errors = {};
    this.touched.clear();
    this.dirty.clear();
  }
  snapshot() {
    return { values: { ...this.values }, errors: { ...this.errors }, dirty: [...this.dirty], touched: [...this.touched] };
  }
}
