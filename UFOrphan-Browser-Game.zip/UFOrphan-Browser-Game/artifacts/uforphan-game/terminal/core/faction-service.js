export class FactionService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  relation(id) { return this.state.get(`factions.${id}`) || "unknown"; }
  setRelation(id, relation) {
    const allowed = ["unknown", "neutral", "friendly", "hostile", "allied"];
    if (!allowed.includes(relation)) return false;
    const previous = this.relation(id);
    this.state.set(`factions.${id}`, relation);
    this.bus.emit("faction:relation", { id, previous, relation });
    return true;
  }
  list() { return Object.entries(this.state.get("factions") || {}).map(([id, relation]) => ({ id, relation })); }
  allied(id) { return ["friendly", "allied"].includes(this.relation(id)); }
}
