import { uid } from "./utils.js";
export class LocalLeaderboard {
  constructor(limit = 25) {
    this.limit = limit;
    this.rows = [];
  }
  submit(name, score, metadata = {}) {
    const row = { id: uid("score"), name: String(name).slice(0, 28), score: Number(score) || 0, metadata, at: new Date().toISOString() };
    this.rows.push(row);
    this.rows.sort((a, b) => b.score - a.score);
    this.rows = this.rows.slice(0, this.limit);
    return row;
  }
  top(limit = 10) {
    return this.rows.slice(0, limit);
  }
  rank(id) {
    const index = this.rows.findIndex(row => row.id === id);
    return index < 0 ? null : index + 1;
  }
  personalBest(name) {
    return Math.max(0, ...this.rows.filter(row => row.name === name).map(row => row.score));
  }
  clear() {
    this.rows = [];
  }
}
