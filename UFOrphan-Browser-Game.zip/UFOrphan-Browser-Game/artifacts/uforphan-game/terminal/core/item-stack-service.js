export class ItemStackService {
  constructor(maxStack = 99) {
    this.maxStack = maxStack;
  }
  split(stack, amount) {
    if (!Number.isInteger(amount) || amount <= 0 || amount >= stack.count) return null;
    stack.count -= amount;
    return { ...stack, id: `${stack.id}-split-${Date.now()}`, count: amount };
  }
  merge(left, right) {
    if (left.itemId !== right.itemId) return { ok: false, reason: "different-items" };
    const capacity = this.maxStack - left.count;
    const moved = Math.min(capacity, right.count);
    left.count += moved;
    right.count -= moved;
    return { ok: true, moved, remaining: right.count };
  }
  normalize(stacks) {
    const output = [];
    for (const stack of stacks) {
      let remaining = Math.max(0, Number(stack.count) || 0);
      while (remaining > 0) {
        const amount = Math.min(this.maxStack, remaining);
        output.push({ ...stack, count: amount });
        remaining -= amount;
      }
    }
    return output;
  }
  total(stacks, itemId) {
    return stacks.filter(stack => stack.itemId === itemId).reduce((sum, stack) => sum + stack.count, 0);
  }
}
