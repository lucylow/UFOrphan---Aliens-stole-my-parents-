export class InventoryCapacity {
  constructor(inventory, maximumSlots = 30, maximumWeight = 100) { this.inventory = inventory; this.maximumSlots = maximumSlots; this.maximumWeight = maximumWeight; }
  slotsUsed() { return this.inventory.list().length; }
  weightUsed() { return this.inventory.weight(); }
  canCarry(weight = 0, slots = 0) { return this.weightUsed() + weight <= this.maximumWeight && this.slotsUsed() + slots <= this.maximumSlots; }
  usage() { return { slots: this.slotsUsed(), maxSlots: this.maximumSlots, weight: this.weightUsed(), maxWeight: this.maximumWeight }; }
  setLimits({ slots, weight }) { if (slots) this.maximumSlots = Math.max(1, slots); if (weight) this.maximumWeight = Math.max(1, weight); }
}
