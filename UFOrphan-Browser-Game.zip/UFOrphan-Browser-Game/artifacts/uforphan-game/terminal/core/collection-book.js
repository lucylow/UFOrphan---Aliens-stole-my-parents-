export class CollectionBook {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  has(id) { return Boolean(this.state.get(`collections.${id}`)); }
  collect(id, metadata = {}) {
    if (this.has(id)) return false;
    this.state.set(`collections.${id}`, { ...metadata, collectedAt: new Date().toISOString() });
    this.bus.emit("collection:added", { id, metadata }); return true;
  }
  list() { return Object.entries(this.state.get("collections") || {}).map(([id, record]) => ({ id, ...record })); }
  completion(catalog) { const count = catalog.filter(item => this.has(item.id)).length; return { count, total: catalog.length, ratio: catalog.length ? count / catalog.length : 1 }; }
}
