export class ExportQueue {
  constructor(exporter) { this.exporter = exporter; this.jobs = []; }
  add(format = "json") { const job = { id: `export-${Date.now()}-${this.jobs.length}`, format, status: "pending" }; this.jobs.push(job); return job; }
  run(id) {
    const job = this.jobs.find(item => item.id === id);
    if (!job || job.status !== "pending") return { ok: false, reason: "not-pending" };
    try { job.payload = this.exporter(job.format); job.status = "complete"; return { ok: true, job }; }
    catch (error) { job.status = "failed"; job.error = String(error.message || error); return { ok: false, job }; }
  }
  list() { return [...this.jobs]; }
  clearFinished() { this.jobs = this.jobs.filter(job => job.status === "pending"); }
}
