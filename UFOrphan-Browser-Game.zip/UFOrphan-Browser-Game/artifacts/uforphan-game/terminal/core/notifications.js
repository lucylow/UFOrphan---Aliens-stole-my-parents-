import { uid, nowISO } from "./utils.js";
export class NotificationCenter {
  constructor(state,bus) { this.state=state; this.bus=bus; }
  push(title,message,type="info",options={}) { const item={id:uid("notice"),title,message,type,createdAt:nowISO(),read:false,expires:options.expires||null}; this.state.mutate(data=>{data.notifications.unshift(item);data.notifications=data.notifications.slice(0,80);},"notification:add"); this.bus.emit("notification",item); return item; }
  unread() { return this.state.get("notifications").filter(item=>!item.read).length; }
  markRead(id) { this.state.mutate(data=>{const item=data.notifications.find(entry=>entry.id===id);if(item)item.read=true;},"notification:read"); }
  markAllRead() { this.state.mutate(data=>data.notifications.forEach(item=>item.read=true),"notification:read-all"); }
  dismiss(id) { this.state.mutate(data=>data.notifications=data.notifications.filter(item=>item.id!==id),"notification:dismiss"); }
  clearRead() { this.state.mutate(data=>data.notifications=data.notifications.filter(item=>!item.read),"notification:clear-read"); }
}
