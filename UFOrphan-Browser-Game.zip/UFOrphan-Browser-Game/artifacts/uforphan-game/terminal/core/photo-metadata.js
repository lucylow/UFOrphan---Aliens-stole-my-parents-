export class PhotoMetadata {
  dimensions(dataUrl) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight, ratio: image.naturalWidth / image.naturalHeight });
      image.onerror = () => reject(new Error("Unable to read image metadata"));
      image.src = dataUrl;
    });
  }
  validate(dataUrl, maxBytes = 2_000_000) {
    if (!String(dataUrl).startsWith("data:image/")) return { ok: false, reason: "not-an-image" };
    const bytes = Math.ceil((dataUrl.length * 3) / 4);
    return bytes <= maxBytes ? { ok: true, bytes } : { ok: false, reason: "image-too-large", bytes };
  }
}
