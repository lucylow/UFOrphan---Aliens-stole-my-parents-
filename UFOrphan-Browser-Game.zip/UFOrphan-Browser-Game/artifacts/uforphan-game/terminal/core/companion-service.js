const COMPANIONS = [
  { id: "moxie", name: "Moxie", role: "scout", perk: "Reveals hidden supply caches." },
  { id: "patch7", name: "Patch-7", role: "mechanic", perk: "Reduces crafting material costs." },
  { id: "sprout", name: "Sprout", role: "medic", perk: "Finds extra bio gel in garden sectors." }
];
export class CompanionService {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  catalog() {
    return COMPANIONS.map(item => ({ ...item, recruited: this.recruited(item.id) }));
  }
  recruited(id) {
    return (this.state.get("companions") || []).includes(id);
  }
  recruit(id) {
    if (!COMPANIONS.some(item => item.id === id)) return false;
    if (this.recruited(id)) return true;
    this.state.mutate(data => {
      data.companions ||= [];
      data.companions.push(id);
    }, "companion:recruit");
    this.bus.emit("companion:recruited", { id });
    return true;
  }
  active() {
    return this.state.get("activeCompanion") || null;
  }
  setActive(id) {
    if (id && !this.recruited(id)) return false;
    this.state.set("activeCompanion", id);
    this.bus.emit("companion:active", { id });
    return true;
  }
  perk() {
    return COMPANIONS.find(item => item.id === this.active()) || null;
  }
}
