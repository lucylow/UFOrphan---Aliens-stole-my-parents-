export class SaveIntegrity {
  canonical(value) {
    if (Array.isArray(value)) return `[${value.map(item => this.canonical(item)).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${this.canonical(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  }
  checksum(value) {
    const text = this.canonical(value);
    let hash = 2166136261;
    for (let index = 0; index < text.length; index++) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  verify(value, expected) {
    return this.checksum(value) === expected;
  }
  envelope(value) {
    return { payload: value, checksum: this.checksum(value), algorithm: "fnv1a-32" };
  }
  open(envelope) {
    if (!envelope?.payload || !this.verify(envelope.payload, envelope.checksum)) return { ok: false, reason: "checksum-mismatch" };
    return { ok: true, payload: envelope.payload };
  }
}
