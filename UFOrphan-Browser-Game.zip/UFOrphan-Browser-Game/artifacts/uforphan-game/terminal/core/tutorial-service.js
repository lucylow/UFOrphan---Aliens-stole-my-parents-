export class TutorialService {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  completed(id) {
    return Boolean(this.state.get(`tutorials.${id}`));
  }
  complete(id) {
    if (this.completed(id)) return false;
    this.state.set(`tutorials.${id}`, new Date().toISOString());
    this.bus.emit("tutorial:completed", { id });
    return true;
  }
  reset(id) {
    this.state.mutate(data => {
      if (id) delete data.tutorials?.[id];
      else data.tutorials = {};
    }, "tutorial:reset");
  }
  progress(definitions) {
    const complete = definitions.filter(item => this.completed(item.id)).length;
    return { complete, total: definitions.length, ratio: definitions.length ? complete / definitions.length : 1 };
  }
  next(definitions) {
    return definitions.find(item => !this.completed(item.id)) || null;
  }
}
