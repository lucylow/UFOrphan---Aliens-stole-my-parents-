import { uid } from "./utils.js";
export class PurchaseCart {
  constructor(economy) {
    this.economy = economy;
    this.lines = new Map();
  }
  add(itemId, quantity = 1) {
    const next = (this.lines.get(itemId) || 0) + quantity;
    if (!Number.isInteger(next) || next < 1 || next > 99) return false;
    this.lines.set(itemId, next);
    return true;
  }
  remove(itemId) {
    this.lines.delete(itemId);
  }
  quote() {
    const lines = [...this.lines].map(([itemId, quantity]) => this.economy.quote(itemId, quantity));
    const invalid = lines.find(line => !line.ok);
    return invalid ? invalid : { ok: true, lines, total: lines.reduce((sum, line) => sum + line.total, 0) };
  }
  checkout() {
    const quote = this.quote();
    if (!quote.ok) return quote;
    if (this.economy.balance() < quote.total) return { ok: false, reason: "insufficient-credits" };
    const results = [];
    for (const line of quote.lines) results.push(this.economy.buy(line.item.id, line.quantity));
    this.lines.clear();
    return { ok: true, receiptId: uid("receipt"), results, total: quote.total };
  }
  clear() {
    this.lines.clear();
  }
}
