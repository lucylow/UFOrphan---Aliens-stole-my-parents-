export class FileNameService {
  sanitize(name, fallback = "uforphan-export") {
    const clean = String(name || "").normalize("NFKD").replace(/[^a-z0-9._-]+/gi, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "");
    return clean.slice(0, 64) || fallback;
  }
  withExtension(name, extension) {
    const safe = this.sanitize(name);
    const ext = String(extension).replace(/^\./, "");
    return safe.toLowerCase().endsWith(`.${ext.toLowerCase()}`) ? safe : `${safe}.${ext}`;
  }
  timestamp(date = new Date()) {
    return date.toISOString().replace(/[:.]/g, "-");
  }
}
