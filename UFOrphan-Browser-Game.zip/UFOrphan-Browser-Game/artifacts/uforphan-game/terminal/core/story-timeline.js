export class StoryTimeline {
  constructor(events = []) { this.events = [...events].sort((a, b) => a.order - b.order); }
  add(event) { if (this.events.some(item => item.id === event.id)) return false; this.events.push(event); this.events.sort((a, b) => a.order - b.order); return true; }
  before(order) { return this.events.filter(event => event.order < order); }
  after(order) { return this.events.filter(event => event.order > order); }
  between(start, end) { return this.events.filter(event => event.order >= start && event.order <= end); }
  next(completed = []) { const done = new Set(completed); return this.events.find(event => !done.has(event.id)) || null; }
}
