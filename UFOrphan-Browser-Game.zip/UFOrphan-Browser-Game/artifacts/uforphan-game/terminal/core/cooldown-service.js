export class CooldownService {
  constructor(clock = () => Date.now()) {
    this.clock = clock;
    this.entries = new Map();
  }
  start(key, durationMs) {
    const end = this.clock() + Math.max(0, durationMs);
    this.entries.set(key, end);
    return end;
  }
  ready(key) {
    return !this.entries.has(key) || this.remaining(key) <= 0;
  }
  remaining(key) {
    return Math.max(0, (this.entries.get(key) || 0) - this.clock());
  }
  consume(key, durationMs) {
    if (!this.ready(key)) return false;
    this.start(key, durationMs);
    return true;
  }
  clear(key) {
    if (key) this.entries.delete(key);
    else this.entries.clear();
  }
  snapshot() {
    return Object.fromEntries(this.entries);
  }
}
