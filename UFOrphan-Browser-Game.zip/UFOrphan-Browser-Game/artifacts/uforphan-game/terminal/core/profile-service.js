import { clone, uid } from "./utils.js";
export class ProfileService {
  constructor(state, storage, notices) {
    this.state = state;
    this.storage = storage;
    this.notices = notices;
  }
  create(name) {
    const clean = String(name || "").trim().slice(0, 28);
    if (!clean) return { ok: false, reason: "name-required" };
    const snapshot = this.state.snapshot();
    delete snapshot.profiles;
    const profile = {
      id: uid("profile"),
      name: clean,
      createdAt: new Date().toISOString(),
      data: snapshot
    };
    this.state.mutate(data => {
      data.profiles ||= [];
      data.profiles.unshift(profile);
      data.profiles = data.profiles.slice(0, 8);
    }, "profile:create");
    this.notices.push("Profile created", `${clean} saved to this browser.`, "success");
    return { ok: true, profile };
  }
  list() {
    return (this.state.get("profiles") || []).map(({ id, name, createdAt }) => ({ id, name, createdAt }));
  }
  load(id) {
    const profiles = this.state.get("profiles") || [];
    const profile = profiles.find(item => item.id === id);
    if (!profile) return { ok: false, reason: "missing-profile" };
    const preservedProfiles = clone(profiles);
    this.state.data = clone(profile.data);
    this.state.data.profiles = preservedProfiles;
    this.state.persist();
    return { ok: true, profile };
  }
  remove(id) {
    let removed = false;
    this.state.mutate(data => {
      const before = (data.profiles || []).length;
      data.profiles = (data.profiles || []).filter(item => item.id !== id);
      removed = data.profiles.length !== before;
    }, "profile:remove");
    return removed;
  }
  export() {
    return {
      application: "UFOrphan Field Terminal",
      version: 1,
      exportedAt: new Date().toISOString(),
      state: this.state.snapshot()
    };
  }
  import(payload) {
    if (payload?.application !== "UFOrphan Field Terminal" || !payload.state || typeof payload.state !== "object") {
      return { ok: false, reason: "invalid-backup" };
    }
    this.state.data = { ...this.state.data, ...clone(payload.state) };
    this.state.persist();
    this.notices.push("Backup restored", "Your terminal data has been imported.", "success");
    return { ok: true };
  }
}
