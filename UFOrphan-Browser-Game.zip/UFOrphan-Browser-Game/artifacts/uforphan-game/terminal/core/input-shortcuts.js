export class InputShortcuts {
  constructor(target = document) {
    this.target = target;
    this.bindings = new Map();
    this.handleKey = this.handleKey.bind(this);
    this.enabled = false;
  }
  normalize(event) {
    const parts = [];
    if (event.ctrlKey) parts.push("ctrl");
    if (event.altKey) parts.push("alt");
    if (event.shiftKey) parts.push("shift");
    if (event.metaKey) parts.push("meta");
    parts.push(event.key.toLowerCase());
    return parts.join("+");
  }
  bind(combo, handler, options = {}) {
    this.bindings.set(combo.toLowerCase(), { handler, allowInput: Boolean(options.allowInput) });
    return () => this.bindings.delete(combo.toLowerCase());
  }
  enable() {
    if (this.enabled) return;
    this.target.addEventListener("keydown", this.handleKey);
    this.enabled = true;
  }
  disable() {
    this.target.removeEventListener("keydown", this.handleKey);
    this.enabled = false;
  }
  handleKey(event) {
    const binding = this.bindings.get(this.normalize(event));
    if (!binding) return;
    const tag = event.target?.tagName?.toLowerCase();
    if (!binding.allowInput && ["input", "textarea", "select"].includes(tag)) return;
    event.preventDefault();
    binding.handler(event);
  }
  clear() {
    this.bindings.clear();
    this.disable();
  }
}
