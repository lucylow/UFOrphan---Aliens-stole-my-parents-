const THEMES = {
  cosmic: { background: "#090e20", panel: "#111a32", accent: "#72eee3", highlight: "#ff83c5" },
  moonlight: { background: "#11172b", panel: "#1a2945", accent: "#b6d5ff", highlight: "#d8b8ff" },
  greenhouse: { background: "#0b1b1a", panel: "#17352e", accent: "#9be4a7", highlight: "#f1d48b" },
  eclipse: { background: "#120d1b", panel: "#241832", accent: "#d1a3ff", highlight: "#ff9bb9" }
};
export class ColorTheme {
  constructor(root) {
    this.root = root;
    this.current = "cosmic";
  }
  names() {
    return Object.keys(THEMES);
  }
  apply(name) {
    const theme = THEMES[name];
    if (!theme) return false;
    this.current = name;
    for (const [key, value] of Object.entries(theme)) this.root.style.setProperty(`--ft-${key}`, value);
    this.root.dataset.theme = name;
    return true;
  }
  reset() {
    this.apply("cosmic");
  }
}
