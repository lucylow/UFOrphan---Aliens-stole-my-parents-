import { uid } from "./utils.js";
export class DialogueChoiceLog {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  choose(sceneId, choiceId, text) {
    const record = { id: uid("choice"), sceneId, choiceId, text, at: new Date().toISOString() };
    this.state.mutate(data => { data.dialogueChoices ||= []; data.dialogueChoices.push(record); }, "dialogue:choice");
    this.bus.emit("dialogue:chosen", record); return record;
  }
  choices(sceneId) { return (this.state.get("dialogueChoices") || []).filter(item => item.sceneId === sceneId); }
  latest() { return (this.state.get("dialogueChoices") || []).at(-1) || null; }
}
