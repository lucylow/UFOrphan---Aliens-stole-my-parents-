export const TABS = ["dashboard","inventory","missions","map","codex","equipment","crafting","shop","achievements","statistics","profiles","settings"];
export class Router {
  constructor(state,bus) { this.state=state; this.bus=bus; this.stack=[]; }
  current() { return this.state.get("activeTab") || "dashboard"; }
  go(tab,params={}) { if(!TABS.includes(tab)) throw new Error(`Unknown terminal tab: ${tab}`); const previous=this.current(); this.stack.push(previous); this.state.set("activeTab",tab); this.bus.emit("route:changed",{tab,previous,params}); }
  back() { const tab=this.stack.pop() || "dashboard"; this.state.set("activeTab",tab); this.bus.emit("route:changed",{tab,back:true}); }
  home() { this.stack=[]; this.go("dashboard"); }
  canBack() { return this.stack.length>0; }
}
