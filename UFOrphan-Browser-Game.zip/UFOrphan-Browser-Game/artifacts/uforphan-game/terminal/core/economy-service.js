import { ITEMS } from "../data/catalog.js";
import { byId } from "./utils.js";
export class EconomyService {
 constructor(state,bus,notices){this.state=state;this.bus=bus;this.notices=notices;}
 balance(){return this.state.get("credits");}
 quote(itemId,quantity=1){const item=byId(ITEMS,itemId);if(!item)return {ok:false,reason:"unknown-item"};if(!Number.isInteger(quantity)||quantity<1||quantity>99)return {ok:false,reason:"invalid-quantity"};return {ok:true,item,quantity,unitPrice:item.price,total:item.price*quantity};}
 buy(itemId,quantity=1){const quote=this.quote(itemId,quantity);if(!quote.ok)return quote;if(quote.item.price<=0)return {ok:false,reason:"not-for-sale"};if(this.balance()<quote.total)return {ok:false,reason:"insufficient-credits",needed:quote.total,balance:this.balance()};this.state.mutate(data=>{data.credits-=quote.total;data.inventory[itemId]=(data.inventory[itemId]||0)+quantity;data.statistics.itemsPurchased+=quantity;data.purchases.push({itemId,quantity,total:quote.total,at:new Date().toISOString()});},"economy:purchase");this.notices.push("Purchase complete",`${quantity} × ${quote.item.name} added to your pack.`,"success");this.bus.emit("shop:purchased",quote);return {ok:true,quote,balance:this.balance()};}
 sell(itemId,quantity=1){const item=byId(ITEMS,itemId);const count=this.state.get(`inventory.${itemId}`)||0;if(!item||count<quantity||quantity<1)return {ok:false,reason:"cannot-sell"};const total=Math.max(1,Math.floor(item.price*.45))*quantity;this.state.mutate(data=>{data.inventory[itemId]-=quantity;if(data.inventory[itemId]===0)delete data.inventory[itemId];data.credits+=total;data.statistics.creditsEarned+=total;},"economy:sale");this.notices.push("Item sold",`${quantity} × ${item.name} sold for ${total} credits.`,"success");return {ok:true,total,balance:this.balance()};}
 ledger(){return [...this.state.get("purchases")].reverse();}
}
