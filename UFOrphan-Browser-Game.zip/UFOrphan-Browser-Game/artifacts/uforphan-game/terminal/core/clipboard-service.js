export class ClipboardService {
  async copy(text) {
    const value = String(text ?? "");
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return { ok: true, method: "clipboard-api" };
    }
    const area = document.createElement("textarea");
    area.value = value;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.append(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    return { ok, method: "legacy" };
  }
  async paste() {
    if (!navigator.clipboard?.readText) return { ok: false, reason: "clipboard-unavailable" };
    try {
      return { ok: true, text: await navigator.clipboard.readText() };
    } catch (error) {
      return { ok: false, reason: String(error.message || error) };
    }
  }
}
