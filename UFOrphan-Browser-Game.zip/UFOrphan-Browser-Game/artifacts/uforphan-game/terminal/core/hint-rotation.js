export class HintRotation {
  constructor(hints, random = Math.random) { this.hints = hints; this.random = random; this.previous = -1; }
  next() {
    if (!this.hints.length) return null;
    if (this.hints.length === 1) return this.hints[0];
    let index = this.previous;
    while (index === this.previous) index = Math.floor(this.random() * this.hints.length);
    this.previous = index; return this.hints[index];
  }
  reset() { this.previous = -1; }
  all() { return [...this.hints]; }
}
