import { DEFAULT_STATE } from "./state.js";
export class SaveMigration {
  constructor(migrations = {}) {
    this.migrations = migrations;
  }
  register(fromVersion, migrate) {
    if (typeof migrate !== "function") throw new TypeError("Migration function required");
    this.migrations[fromVersion] = migrate;
  }
  migrate(input, targetVersion = 1) {
    let state = structuredClone(input || {});
    let version = Number(state.version || 0);
    const applied = [];
    while (version < targetVersion) {
      const migration = this.migrations[version];
      if (!migration) return { ok: false, version, applied, reason: "missing-migration" };
      state = migration(state);
      version++;
      state.version = version;
      applied.push(version);
    }
    return { ok: true, state: { ...structuredClone(DEFAULT_STATE), ...state }, applied };
  }
}
