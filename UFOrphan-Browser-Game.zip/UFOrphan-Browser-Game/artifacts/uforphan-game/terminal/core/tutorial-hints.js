export class TutorialHints {
  constructor(state) { this.state = state; }
  dismissed(id) { return Boolean(this.state.get(`dismissedHints.${id}`)); }
  dismiss(id) { this.state.set(`dismissedHints.${id}`, true); }
  reset(id) { this.state.mutate(data => { if (id) delete data.dismissedHints?.[id]; else data.dismissedHints = {}; }, "hints:reset"); }
  visible(hints) { return hints.filter(hint => !this.dismissed(hint.id)); }
  first(hints) { return this.visible(hints)[0] || null; }
}
