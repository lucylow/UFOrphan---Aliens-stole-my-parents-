import { uid } from "./utils.js";
export class DiscoveryFeed {
  constructor(state, limit = 80) { this.state = state; this.limit = limit; }
  publish(type, title, detail) {
    const entry = { id: uid("discovery"), type, title, detail, at: new Date().toISOString() };
    this.state.mutate(data => { data.discoveryFeed ||= []; data.discoveryFeed.unshift(entry); data.discoveryFeed = data.discoveryFeed.slice(0, this.limit); }, "discovery:publish");
    return entry;
  }
  latest(count = 10) { return (this.state.get("discoveryFeed") || []).slice(0, count); }
  byType(type) { return (this.state.get("discoveryFeed") || []).filter(item => item.type === type); }
}
