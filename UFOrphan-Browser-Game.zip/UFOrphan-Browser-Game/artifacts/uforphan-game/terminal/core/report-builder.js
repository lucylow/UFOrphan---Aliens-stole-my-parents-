import { formatDate, formatNumber } from "./utils.js";
export class ReportBuilder {
  constructor(state) {
    this.state = state;
  }
  build() {
    const data = this.state.snapshot();
    const inventory = Object.entries(data.inventory).map(([id, count]) => ({ id, count }));
    const missions = Object.entries(data.missions).map(([id, record]) => ({ id, status: record.status }));
    return {
      title: "Fiona Gallegar — Expedition Report",
      generatedAt: new Date().toISOString(),
      profile: data.profile,
      credits: data.credits,
      inventory,
      missions,
      discoveries: data.discoveredSectors,
      achievements: Object.keys(data.achievements).filter(id => data.achievements[id]),
      statistics: data.statistics
    };
  }
  toText() {
    const report = this.build();
    const lines = [report.title, `Generated: ${formatDate(report.generatedAt)}`, `Credits: ${formatNumber(report.credits)}`, "", "Inventory"];
    for (const item of report.inventory) lines.push(`- ${item.id}: ${item.count}`);
    lines.push("", "Missions");
    for (const mission of report.missions) lines.push(`- ${mission.id}: ${mission.status}`);
    lines.push("", `Sectors discovered: ${report.discoveries.join(", ")}`);
    return lines.join("\n");
  }
}
