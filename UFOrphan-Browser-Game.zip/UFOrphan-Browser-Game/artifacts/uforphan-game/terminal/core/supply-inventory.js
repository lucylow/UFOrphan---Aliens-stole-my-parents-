export class SupplyInventory {
  constructor(initial = {}) { this.stock = { ...initial }; }
  count(id) { return this.stock[id] || 0; }
  restock(id, amount) { if (amount <= 0) return false; this.stock[id] = this.count(id) + amount; return true; }
  reserve(id, amount) { if (amount <= 0 || this.count(id) < amount) return false; this.stock[id] -= amount; return true; }
  release(id, amount) { this.restock(id, amount); }
  snapshot() { return { ...this.stock }; }
  empty() { return Object.values(this.stock).every(amount => amount <= 0); }
}
