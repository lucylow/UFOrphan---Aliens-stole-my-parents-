export class CraftingCost {
  constructor(inventory) { this.inventory = inventory; }
  quote(recipe, batches = 1) {
    if (!Number.isInteger(batches) || batches < 1) return { ok: false, reason: "invalid-batches" };
    const requirements = Object.fromEntries(Object.entries(recipe.cost).map(([id, count]) => [id, count * batches]));
    const missing = Object.entries(requirements).filter(([id, count]) => !this.inventory.has(id, count)).map(([id, count]) => ({ id, needed: count, owned: this.inventory.count(id) }));
    return { ok: missing.length === 0, requirements, missing, batches, output: recipe.amount * batches };
  }
  maximumBatches(recipe, limit = 99) {
    let maximum = limit;
    for (const [id, count] of Object.entries(recipe.cost)) maximum = Math.min(maximum, Math.floor(this.inventory.count(id) / count));
    return Math.max(0, maximum);
  }
}
