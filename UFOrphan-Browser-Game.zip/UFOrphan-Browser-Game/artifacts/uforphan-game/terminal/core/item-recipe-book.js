export class ItemRecipeBook {
  constructor(recipes) {
    this.recipes = recipes;
  }
  byOutput(itemId) {
    return this.recipes.filter(recipe => recipe.output === itemId);
  }
  byIngredient(itemId) {
    return this.recipes.filter(recipe => Object.hasOwn(recipe.cost, itemId));
  }
  stationTypes() {
    return [...new Set(this.recipes.map(recipe => recipe.station))];
  }
  forStation(station) {
    return this.recipes.filter(recipe => recipe.station === station);
  }
  dependencyTree(recipeId, depth = 0) {
    const recipe = this.recipes.find(item => item.id === recipeId);
    if (!recipe || depth > 8) return null;
    return {
      recipe,
      ingredients: Object.keys(recipe.cost).map(id => ({
        itemId: id,
        recipes: this.byOutput(id).map(item => item.id)
      }))
    };
  }
}
