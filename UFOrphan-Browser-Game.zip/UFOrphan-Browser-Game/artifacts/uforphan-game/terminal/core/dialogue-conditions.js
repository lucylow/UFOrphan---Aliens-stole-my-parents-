export class DialogueConditions {
  constructor(context = {}) { this.context = context; }
  hasItem(id, count = 1) { return (this.context.inventory?.count(id) || 0) >= count; }
  hasFlag(id) { return Boolean(this.context.flags?.get(id)); }
  missionStatus(id, status) { return this.context.missions?.status(id) === status; }
  reputationAtLeast(faction, score) { return (this.context.reputation?.score(faction) || 0) >= score; }
  evaluate(condition) {
    if (!condition) return true;
    const [kind, ...args] = condition;
    const method = this[kind];
    return typeof method === "function" ? Boolean(method.apply(this, args)) : false;
  }
}
