export class UndoStack {
  constructor(limit = 40) {
    this.limit = limit;
    this.undoItems = [];
    this.redoItems = [];
  }
  push(command) {
    if (typeof command.undo !== "function" || typeof command.redo !== "function") throw new TypeError("Undo command needs undo and redo");
    this.undoItems.push(command);
    this.undoItems = this.undoItems.slice(-this.limit);
    this.redoItems = [];
  }
  undo() {
    const command = this.undoItems.pop();
    if (!command) return false;
    command.undo();
    this.redoItems.push(command);
    return true;
  }
  redo() {
    const command = this.redoItems.pop();
    if (!command) return false;
    command.redo();
    this.undoItems.push(command);
    return true;
  }
  clear() {
    this.undoItems = [];
    this.redoItems = [];
  }
  get canUndo() {
    return this.undoItems.length > 0;
  }
  get canRedo() {
    return this.redoItems.length > 0;
  }
}
