export class CompanionAffinity {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  score(id) {
    return this.state.get(`companionAffinity.${id}`) || 0;
  }
  tier(score) {
    if (score >= 100) return "inseparable";
    if (score >= 60) return "best friends";
    if (score >= 25) return "trusted";
    if (score > 0) return "warming up";
    return "new acquaintance";
  }
  add(id, amount = 1, reason = "kindness") {
    const before = this.score(id);
    const after = Math.max(0, Math.min(100, before + amount));
    this.state.set(`companionAffinity.${id}`, after);
    this.bus.emit("companion:affinity", { id, before, after, reason, tier: this.tier(after) });
    return after;
  }
  all() {
    return Object.entries(this.state.get("companionAffinity") || {}).map(([id, score]) => ({ id, score, tier: this.tier(score) }));
  }
}
