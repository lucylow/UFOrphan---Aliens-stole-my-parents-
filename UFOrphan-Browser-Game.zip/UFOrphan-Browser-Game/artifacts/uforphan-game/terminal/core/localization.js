export class Localization {
  constructor(locale = "en", dictionaries = {}) {
    this.locale = locale;
    this.dictionaries = dictionaries;
    this.fallback = "en";
  }
  setLocale(locale) {
    this.locale = locale;
  }
  register(locale, dictionary) {
    this.dictionaries[locale] = { ...(this.dictionaries[locale] || {}), ...dictionary };
  }
  t(key, variables = {}) {
    const dictionary = this.dictionaries[this.locale] || {};
    const fallback = this.dictionaries[this.fallback] || {};
    let value = dictionary[key] ?? fallback[key] ?? key;
    for (const [name, replacement] of Object.entries(variables)) {
      value = value.replaceAll(`{${name}}`, String(replacement));
    }
    return value;
  }
  has(key) {
    return Boolean(this.dictionaries[this.locale]?.[key] || this.dictionaries[this.fallback]?.[key]);
  }
  missing(keys) {
    return keys.filter(key => !this.dictionaries[this.locale]?.[key]);
  }
  availableLocales() {
    return Object.keys(this.dictionaries);
  }
}
