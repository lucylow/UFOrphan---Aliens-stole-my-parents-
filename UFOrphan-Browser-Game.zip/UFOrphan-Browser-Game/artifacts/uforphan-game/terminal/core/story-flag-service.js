export class StoryFlagService {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  get(flag, fallback = false) {
    const value = this.state.get(`storyFlags.${flag}`);
    return value === undefined ? fallback : value;
  }
  set(flag, value = true) {
    const previous = this.get(flag);
    this.state.set(`storyFlags.${flag}`, value);
    this.bus.emit("story-flag:changed", { flag, previous, value });
    return value;
  }
  once(flag, value = true) {
    if (this.get(flag)) return false;
    this.set(flag, value);
    return true;
  }
  all(prefix = "") {
    return Object.fromEntries(Object.entries(this.state.get("storyFlags") || {})
      .filter(([key]) => key.startsWith(prefix)));
  }
}
