export class CacheService {
  constructor(limit = 100) {
    this.limit = limit;
    this.entries = new Map();
  }
  set(key, value, ttl = 0) {
    const expiresAt = ttl > 0 ? Date.now() + ttl : null;
    this.entries.delete(key);
    this.entries.set(key, { value, expiresAt, usedAt: Date.now() });
    while (this.entries.size > this.limit) this.entries.delete(this.entries.keys().next().value);
  }
  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt && entry.expiresAt < Date.now()) {
      this.entries.delete(key);
      return undefined;
    }
    entry.usedAt = Date.now();
    return entry.value;
  }
  has(key) {
    return this.get(key) !== undefined;
  }
  delete(key) {
    return this.entries.delete(key);
  }
  clear() {
    this.entries.clear();
  }
  stats() {
    return { size: this.entries.size, limit: this.limit };
  }
}
