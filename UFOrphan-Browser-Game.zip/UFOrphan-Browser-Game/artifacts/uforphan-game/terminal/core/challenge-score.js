export class ChallengeScore {
  constructor(weights = {}) { this.weights = weights; }
  score(result) {
    const values = Object.entries(result).map(([key, value]) => Number(value) * Number(this.weights[key] ?? 1));
    return values.reduce((total, value) => total + (Number.isFinite(value) ? value : 0), 0);
  }
  grade(score, thresholds = [100, 250, 500]) {
    if (score >= thresholds[2]) return "S";
    if (score >= thresholds[1]) return "A";
    if (score >= thresholds[0]) return "B";
    return "C";
  }
  breakdown(result) {
    return Object.entries(result).map(([key, value]) => ({ key, value, weighted: value * (this.weights[key] ?? 1) }));
  }
}
