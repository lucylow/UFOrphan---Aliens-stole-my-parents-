import { uid, nowISO } from "./utils.js";
export class JournalService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  entries() { return this.state.get("journalEntries") || []; }
  write(title, body, tags = []) {
    const entry = { id: uid("journal"), title: String(title).slice(0, 80), body: String(body), tags, at: nowISO(), pinned: false };
    this.state.mutate(data => { data.journalEntries ||= []; data.journalEntries.unshift(entry); data.journalEntries = data.journalEntries.slice(0, 250); }, "journal:write");
    this.bus.emit("journal:written", entry); return entry;
  }
  pin(id, pinned = true) { this.state.mutate(data => { const entry = (data.journalEntries || []).find(item => item.id === id); if (entry) entry.pinned = pinned; }, "journal:pin"); }
  search(term) { const query = String(term).toLowerCase(); return this.entries().filter(entry => `${entry.title} ${entry.body} ${entry.tags.join(" ")}`.toLowerCase().includes(query)); }
  pinned() { return this.entries().filter(entry => entry.pinned); }
}
