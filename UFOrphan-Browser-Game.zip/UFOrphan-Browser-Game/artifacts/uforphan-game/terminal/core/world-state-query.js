export class WorldStateQuery {
  constructor(flags) { this.flags = flags; }
  all(...ids) { return ids.every(id => this.flags.flag(id)); }
  any(...ids) { return ids.some(id => this.flags.flag(id)); }
  none(...ids) { return ids.every(id => !this.flags.flag(id)); }
  count(ids) { return ids.filter(id => this.flags.flag(id)).length; }
  matches(expression) {
    if (expression.all) return this.all(...expression.all);
    if (expression.any) return this.any(...expression.any);
    if (expression.none) return this.none(...expression.none);
    return true;
  }
}
