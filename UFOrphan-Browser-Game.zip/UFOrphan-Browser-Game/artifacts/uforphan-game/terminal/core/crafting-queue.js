import { uid } from "./utils.js";
export class CraftingQueue {
  constructor(craftingService, bus) {
    this.crafting = craftingService;
    this.bus = bus;
    this.jobs = [];
    this.active = false;
  }
  enqueue(recipeId, batches = 1) {
    if (!Number.isInteger(batches) || batches < 1 || batches > 20) return null;
    const job = { id: uid("craft-job"), recipeId, batches, completed: 0, status: "queued" };
    this.jobs.push(job);
    this.bus.emit("craft-queue:added", job);
    return job;
  }
  next() {
    return this.jobs.find(job => job.status === "queued") || null;
  }
  runOne() {
    const job = this.next();
    if (!job) return { ok: false, reason: "queue-empty" };
    const result = this.crafting.craft(job.recipeId);
    if (!result.ok) {
      job.status = "blocked";
      this.bus.emit("craft-queue:blocked", { job, result });
      return result;
    }
    job.completed++;
    if (job.completed >= job.batches) job.status = "complete";
    this.bus.emit("craft-queue:progress", job);
    return { ok: true, job };
  }
  cancel(id) {
    const job = this.jobs.find(item => item.id === id);
    if (!job || job.status === "complete") return false;
    job.status = "cancelled";
    return true;
  }
  clearFinished() {
    this.jobs = this.jobs.filter(job => !["complete", "cancelled"].includes(job.status));
  }
}
