const DEFAULTS={reduceMotion:false,highContrast:false,largeText:false,confirmPurchases:true,showHints:true,autosave:true};
export class SettingsService {
 constructor(state,bus){this.state=state;this.bus=bus;}
 all(){return {...DEFAULTS,...this.state.get("settings")};}
 update(key,value){if(!(key in DEFAULTS))return false;this.state.set(`settings.${key}`,Boolean(value));this.bus.emit("settings:changed",{key,value:Boolean(value)});return true;}
 reset(){this.state.set("settings",{...DEFAULTS});this.bus.emit("settings:reset",{});}
 apply(root){const settings=this.all();root.classList.toggle("ft-high-contrast",settings.highContrast);root.classList.toggle("ft-large-text",settings.largeText);root.classList.toggle("ft-reduce-motion",settings.reduceMotion);}
}
