export class GameplayMetrics {
  constructor(state) { this.state = state; }
  record(name, value = 1) {
    this.state.mutate(data => {
      data.metrics ||= {};
      const metric = data.metrics[name] ||= { total: 0, samples: 0, maximum: 0 };
      metric.total += value; metric.samples++; metric.maximum = Math.max(metric.maximum, value);
    }, `metric:${name}`);
  }
  get(name) { return this.state.get(`metrics.${name}`) || { total: 0, samples: 0, maximum: 0 }; }
  average(name) { const metric = this.get(name); return metric.samples ? metric.total / metric.samples : 0; }
  reset(name) { this.state.mutate(data => { if (name) delete data.metrics?.[name]; else data.metrics = {}; }, "metrics:reset"); }
}
