export class PartyBonus {
  calculate(companions) {
    const roles = companions.map(item => item.role);
    const unique = new Set(roles);
    return { roleCount: unique.size, members: companions.length, multiplier: 1 + Math.max(0, unique.size - 1) * 0.05, balanced: unique.size >= 3 };
  }
  apply(base, bonus) { return Math.round(base * bonus.multiplier); }
  describe(bonus) { return bonus.balanced ? "Balanced team bonus" : `${bonus.roleCount} companion roles active`; }
}
