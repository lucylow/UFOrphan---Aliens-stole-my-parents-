import { uid, nowISO } from "./utils.js";
export class WorldEventLog {
  constructor(state, limit = 200) { this.state = state; this.limit = limit; }
  record(type, message, sector = "unknown") {
    const entry = { id: uid("world-event"), type, message, sector, at: nowISO() };
    this.state.mutate(data => { data.worldEventLog ||= []; data.worldEventLog.unshift(entry); data.worldEventLog = data.worldEventLog.slice(0, this.limit); }, "world-event:record");
    return entry;
  }
  list(type = null) { const rows = this.state.get("worldEventLog") || []; return type ? rows.filter(item => item.type === type) : rows; }
  clear() { this.state.set("worldEventLog", []); }
}
