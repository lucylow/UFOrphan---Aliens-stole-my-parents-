export class ObjectiveTracker {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  value(questId, objectiveId) { return this.state.get(`objectiveProgress.${questId}.${objectiveId}`) || 0; }
  advance(questId, objectiveId, amount, target) {
    let value = 0;
    this.state.mutate(data => { data.objectiveProgress ||= {}; data.objectiveProgress[questId] ||= {}; const previous = data.objectiveProgress[questId][objectiveId] || 0; value = Math.max(0, Math.min(target, previous + amount)); data.objectiveProgress[questId][objectiveId] = value; }, "objective:progress");
    this.bus.emit("objective:updated", { questId, objectiveId, value, target }); return value;
  }
  complete(questId, objectiveId, target) { return this.value(questId, objectiveId) >= target; }
  reset(questId) { this.state.mutate(data => delete data.objectiveProgress?.[questId], "objective:reset"); }
}
