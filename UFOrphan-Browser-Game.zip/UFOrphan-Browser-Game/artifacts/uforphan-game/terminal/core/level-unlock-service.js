export class LevelUnlockService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  unlocked(index) { return index === 0 || (this.state.get("unlockedLevels") || []).includes(index); }
  unlock(index, reason = "story") {
    if (!Number.isInteger(index) || index < 0) return false;
    if (this.unlocked(index)) return false;
    this.state.mutate(data => { data.unlockedLevels ||= [0]; data.unlockedLevels.push(index); data.unlockedLevels.sort((a, b) => a - b); }, "level:unlock");
    this.bus.emit("level:unlocked", { index, reason }); return true;
  }
  highest() { return Math.max(0, ...(this.state.get("unlockedLevels") || [0])); }
}
