export class Soundscape {
  constructor(audioContext = null) {
    this.context = audioContext;
    this.master = null;
    this.enabled = true;
    this.volume = 0.35;
    this.nodes = new Set();
  }
  attach(context) {
    this.context = context;
    this.master = context.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(context.destination);
  }
  setEnabled(enabled) {
    this.enabled = Boolean(enabled);
    if (this.master) this.master.gain.value = this.enabled ? this.volume : 0;
  }
  setVolume(value) {
    this.volume = Math.max(0, Math.min(1, Number(value) || 0));
    if (this.master && this.enabled) this.master.gain.value = this.volume;
  }
  tone(frequency, duration = 0.12, waveform = "sine") {
    if (!this.enabled || !this.context || !this.master) return false;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = waveform;
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.0001, this.context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.2, this.context.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.context.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(this.master);
    oscillator.start();
    oscillator.stop(this.context.currentTime + duration + 0.02);
    this.nodes.add(oscillator);
    oscillator.onended = () => this.nodes.delete(oscillator);
    return true;
  }
  dispose() {
    for (const node of this.nodes) try { node.stop(); } catch {}
    this.nodes.clear();
    this.master?.disconnect();
    this.master = null;
  }
}
