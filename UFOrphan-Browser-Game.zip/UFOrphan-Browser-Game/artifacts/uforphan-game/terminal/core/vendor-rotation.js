export class VendorRotation {
  constructor(stock, intervalMs = 86400000, clock = () => Date.now()) {
    this.stock = stock;
    this.intervalMs = intervalMs;
    this.clock = clock;
    this.rotation = 0;
  }
  currentIndex() {
    return Math.floor(this.clock() / this.intervalMs) + this.rotation;
  }
  assortment(size = 6) {
    if (!this.stock.length) return [];
    const start = Math.abs(this.currentIndex()) % this.stock.length;
    return Array.from({ length: Math.min(size, this.stock.length) }, (_, index) => {
      return this.stock[(start + index) % this.stock.length];
    });
  }
  rotate() {
    this.rotation++;
    return this.assortment();
  }
  nextRotationAt() {
    return (Math.floor(this.clock() / this.intervalMs) + 1) * this.intervalMs;
  }
}
