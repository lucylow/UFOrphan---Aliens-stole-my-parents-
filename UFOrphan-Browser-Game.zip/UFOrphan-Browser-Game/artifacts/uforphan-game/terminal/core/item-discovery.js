export class ItemDiscovery {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  known(id) {
    return Boolean(this.state.get(`knownItems.${id}`));
  }
  discover(id, source = "unknown") {
    if (this.known(id)) return false;
    this.state.set(`knownItems.${id}`, { source, at: new Date().toISOString() });
    this.bus.emit("item:discovered", { id, source });
    return true;
  }
  list() {
    return Object.entries(this.state.get("knownItems") || {}).map(([id, record]) => ({ id, ...record }));
  }
  forget(id) {
    this.state.mutate(data => delete data.knownItems?.[id], "item:forgotten");
  }
}
