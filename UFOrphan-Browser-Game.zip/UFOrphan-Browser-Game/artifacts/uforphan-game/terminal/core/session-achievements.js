export class SessionAchievements {
  constructor(state, achievements) { this.state = state; this.achievements = achievements; }
  unlocked(id) { return Boolean(this.state.get(`sessionAchievements.${id}`)); }
  evaluate(context) {
    const earned = [];
    for (const achievement of this.achievements) {
      if (!this.unlocked(achievement.id) && achievement.condition(context)) {
        this.state.set(`sessionAchievements.${achievement.id}`, new Date().toISOString());
        earned.push(achievement.id);
      }
    }
    return earned;
  }
}
