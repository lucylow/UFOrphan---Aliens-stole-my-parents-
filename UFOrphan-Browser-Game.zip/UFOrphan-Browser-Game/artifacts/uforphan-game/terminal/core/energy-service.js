export class EnergyService {
  constructor(maximum = 100, initial = maximum) { this.maximum = maximum; this.value = Math.min(maximum, initial); }
  get() { return this.value; }
  spend(amount) { if (amount < 0 || this.value < amount) return false; this.value -= amount; return true; }
  restore(amount) { const before = this.value; this.value = Math.min(this.maximum, this.value + Math.max(0, amount)); return this.value - before; }
  setMaximum(value) { this.maximum = Math.max(1, value); this.value = Math.min(this.value, this.maximum); }
  ratio() { return this.value / this.maximum; }
  full() { return this.value >= this.maximum; }
}
