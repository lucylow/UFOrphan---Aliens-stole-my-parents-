export class SectorDanger {
  constructor(sectors) { this.sectors = sectors; }
  get(id) { return this.sectors.find(item => item.id === id)?.danger ?? null; }
  label(level) { return ["unknown", "low", "moderate", "high", "severe", "extreme"][level] || "unknown"; }
  sort(ids) { return [...ids].sort((a, b) => (this.get(a) || 0) - (this.get(b) || 0)); }
  recommend(ids, maximum = 3) { return this.sort(ids).filter(id => this.get(id) <= maximum); }
}
