export class RewardBundle {
  constructor(entries = []) { this.entries = entries; }
  add(type, id, amount = 1) { this.entries.push({ type, id, amount }); return this; }
  merge(other) { this.entries.push(...other.entries.map(item => ({ ...item }))); return this; }
  totals(type) { return this.entries.filter(item => item.type === type).reduce((sum, item) => sum + item.amount, 0); }
  grouped() { return this.entries.reduce((groups, item) => { (groups[item.type] ||= []).push(item); return groups; }, {}); }
  empty() { return this.entries.length === 0; }
}
