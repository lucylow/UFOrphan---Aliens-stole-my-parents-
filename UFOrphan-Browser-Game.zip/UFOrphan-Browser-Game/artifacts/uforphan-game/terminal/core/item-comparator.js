export class ItemComparator {
  compare(left, right) {
    const keys = new Set([...Object.keys(left.stats || {}), ...Object.keys(right.stats || {})]);
    const rows = [...keys].map(key => ({
      stat: key,
      left: Number(left.stats?.[key] || 0),
      right: Number(right.stats?.[key] || 0),
      difference: Number(right.stats?.[key] || 0) - Number(left.stats?.[key] || 0)
    }));
    return {
      left,
      right,
      rows,
      advantage: rows.filter(row => row.difference > 0).map(row => row.stat),
      disadvantage: rows.filter(row => row.difference < 0).map(row => row.stat)
    };
  }
  score(item, weights = {}) {
    return Object.entries(item.stats || {}).reduce((total, [key, value]) => {
      return total + Number(value) * Number(weights[key] ?? 1);
    }, 0);
  }
  rank(items, weights = {}) {
    return [...items].sort((a, b) => this.score(b, weights) - this.score(a, weights));
  }
}
