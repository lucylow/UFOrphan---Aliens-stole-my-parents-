export class LocalSaveInspector {
  constructor(storage) {
    this.storage = storage;
  }
  inspect() {
    const value = this.storage.export();
    const serialized = JSON.stringify(value);
    return {
      present: Boolean(value && Object.keys(value).length),
      bytes: new Blob([serialized]).size,
      topLevelKeys: Object.keys(value || {}),
      savedAt: value?._terminalSavedAt || null
    };
  }
  estimateUsage() {
    return this.inspect().bytes;
  }
  hasField(path) {
    const value = this.storage.export();
    return path.split(".").every((part, index, parts) => {
      const current = parts.slice(0, index + 1).reduce((node, key) => node?.[key], value);
      return current !== undefined;
    });
  }
}
