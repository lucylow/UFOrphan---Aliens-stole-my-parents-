import { ITEMS } from "../data/catalog.js";
import { byId, clamp } from "./utils.js";
export class InventoryService {
 constructor(state,bus,notices){this.state=state;this.bus=bus;this.notices=notices;}
 catalog(id){return byId(ITEMS,id);}
 count(id){return Number(this.state.get(`inventory.${id}`)||0);}
 has(id,amount=1){return this.count(id)>=amount;}
 add(id,amount=1,reason="found") { if(!Number.isInteger(amount)||amount<=0)return {ok:false,reason:"invalid-amount"}; this.state.mutate(data=>data.inventory[id]=(data.inventory[id]||0)+amount,"inventory:add"); const item=this.catalog(id); this.notices.push(item?.name||id,`Added ${amount} to your field pack.`,"success"); this.bus.emit("inventory:changed",{id,amount,reason}); return {ok:true,count:this.count(id)}; }
 remove(id,amount=1) { if(!this.has(id,amount))return {ok:false,reason:"insufficient-items"}; this.state.mutate(data=>{data.inventory[id]-=amount;if(data.inventory[id]<=0)delete data.inventory[id];},"inventory:remove"); this.bus.emit("inventory:changed",{id,amount:-amount}); return {ok:true,count:this.count(id)}; }
 list(filter="all",search="") { const query=search.toLowerCase(); return Object.entries(this.state.get("inventory")).map(([id,count])=>({item:this.catalog(id)||{id,name:id,type:"unknown",rarity:"common",icon:"?",description:"Uncatalogued item"},count})).filter(slot=>(filter==="all"||slot.item.type===filter)&&(!query||`${slot.item.name} ${slot.item.description}`.toLowerCase().includes(query))).sort((a,b)=>a.item.name.localeCompare(b.item.name)); }
 use(id,context={}) { if(!this.has(id))return {ok:false,reason:"missing"}; const effects={med_patch:()=>{if(!context.player)return false;context.player.health=clamp((context.player.health||0)+1,0,context.player.maxHealth||5);return true;},star_cookie:()=>{if(context.player)context.player.health=clamp((context.player.health||0)+1,0,context.player.maxHealth||5);return true;},shield_bubble:()=>{if(context.player)context.player.shielded=true;return true;}}; const effect=effects[id];if(!effect||!effect())return {ok:false,reason:"not-usable-here"};this.remove(id,1);this.notices.push("Item used",`${this.catalog(id)?.name||id} used successfully.`,"success");return {ok:true}; }
 weight(){return this.list().reduce((n,slot)=>n+(slot.item.weight||0)*slot.count,0);}
 capacity(){return 30;}
}
