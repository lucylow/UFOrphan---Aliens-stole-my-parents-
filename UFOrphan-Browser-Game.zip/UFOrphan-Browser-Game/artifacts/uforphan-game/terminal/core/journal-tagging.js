export class JournalTagging {
  constructor(state) {
    this.state = state;
  }
  tags(entryId) {
    return this.state.get(`journalTags.${entryId}`) || [];
  }
  add(entryId, tag) {
    const clean = String(tag).trim().toLowerCase().slice(0, 24);
    if (!clean) return false;
    this.state.mutate(data => {
      data.journalTags ||= {};
      const tags = data.journalTags[entryId] ||= [];
      if (!tags.includes(clean)) tags.push(clean);
    }, "journal:tag-added");
    return true;
  }
  remove(entryId, tag) {
    this.state.mutate(data => {
      data.journalTags ||= {};
      data.journalTags[entryId] = (data.journalTags[entryId] || []).filter(item => item !== tag);
    }, "journal:tag-removed");
  }
  find(tag) {
    return Object.entries(this.state.get("journalTags") || {})
      .filter(([, tags]) => tags.includes(tag))
      .map(([entryId]) => entryId);
  }
}
