export class CheckpointNotes {
  constructor(state) { this.state = state; }
  get(id) { return this.state.get(`checkpointNotes.${id}`) || ""; }
  save(id, note) { this.state.set(`checkpointNotes.${id}`, String(note).slice(0, 500)); }
  remove(id) { this.state.mutate(data => delete data.checkpointNotes?.[id], "checkpoint:note-removed"); }
  all() { return Object.entries(this.state.get("checkpointNotes") || {}).map(([id, note]) => ({ id, note })); }
  search(term) { const query = String(term).toLowerCase(); return this.all().filter(item => item.note.toLowerCase().includes(query)); }
}
