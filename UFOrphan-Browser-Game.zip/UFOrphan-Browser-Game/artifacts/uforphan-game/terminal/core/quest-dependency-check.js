export class QuestDependencyCheck {
  constructor(quests) { this.quests = quests; }
  check(quest, completed) {
    const done = new Set(completed);
    const missing = (quest.dependencies || []).filter(id => !done.has(id));
    return { ready: missing.length === 0, missing };
  }
  ready(quests, completed) { return quests.filter(quest => this.check(quest, completed).ready); }
  blocked(quests, completed) { return quests.filter(quest => !this.check(quest, completed).ready); }
}
