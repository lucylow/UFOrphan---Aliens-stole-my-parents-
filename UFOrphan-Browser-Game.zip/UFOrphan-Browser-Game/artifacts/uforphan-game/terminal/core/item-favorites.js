export class ItemFavorites {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  has(id) { return (this.state.get("favoriteItems") || []).includes(id); }
  toggle(id) {
    let favorite;
    this.state.mutate(data => {
      data.favoriteItems ||= [];
      favorite = !data.favoriteItems.includes(id);
      data.favoriteItems = favorite ? [...data.favoriteItems, id] : data.favoriteItems.filter(item => item !== id);
    }, "favorites:toggle");
    this.bus.emit("favorites:changed", { id, favorite });
    return favorite;
  }
  list() { return [...(this.state.get("favoriteItems") || [])]; }
  clear() { this.state.set("favoriteItems", []); }
}
