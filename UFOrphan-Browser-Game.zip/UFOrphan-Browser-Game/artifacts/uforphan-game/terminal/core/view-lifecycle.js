export class ViewLifecycle {
  constructor() {
    this.cleanups = [];
    this.mounted = false;
  }
  mount(setup) {
    this.unmount();
    this.mounted = true;
    const cleanup = setup?.();
    if (typeof cleanup === "function") this.cleanups.push(cleanup);
  }
  add(cleanup) {
    if (typeof cleanup !== "function") return;
    if (this.mounted) this.cleanups.push(cleanup);
    else cleanup();
  }
  unmount() {
    for (const cleanup of this.cleanups.splice(0).reverse()) {
      try { cleanup(); } catch (error) { console.warn("View cleanup failed", error); }
    }
    this.mounted = false;
  }
  listen(target, event, handler, options) {
    target.addEventListener(event, handler, options);
    this.add(() => target.removeEventListener(event, handler, options));
  }
  subscribe(bus, event, handler) {
    this.add(bus.on(event, handler));
  }
}
