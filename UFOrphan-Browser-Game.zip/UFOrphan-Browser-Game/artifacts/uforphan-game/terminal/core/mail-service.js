import { uid, nowISO } from "./utils.js";
export class MailService {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  list(folder = "inbox") {
    return (this.state.get("mail") || []).filter(message => message.folder === folder);
  }
  send({ from, subject, body, folder = "inbox", attachments = [] }) {
    const message = { id: uid("mail"), from, subject, body, folder, attachments, read: false, at: nowISO() };
    this.state.mutate(data => {
      data.mail ||= [];
      data.mail.unshift(message);
    }, "mail:received");
    this.bus.emit("mail:message", message);
    return message;
  }
  unreadCount(folder = "inbox") {
    return this.list(folder).filter(message => !message.read).length;
  }
  markRead(id) {
    this.state.mutate(data => {
      const message = (data.mail || []).find(item => item.id === id);
      if (message) message.read = true;
    }, "mail:read");
  }
  archive(id) {
    this.state.mutate(data => {
      const message = (data.mail || []).find(item => item.id === id);
      if (message) message.folder = "archive";
    }, "mail:archive");
  }
  delete(id) {
    this.state.mutate(data => data.mail = (data.mail || []).filter(item => item.id !== id), "mail:delete");
  }
}
