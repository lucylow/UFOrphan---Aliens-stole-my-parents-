import { CODEX_ENTRIES } from "../data/codex.js";
export class CodexService {
 constructor(state,bus,notices){this.state=state;this.bus=bus;this.notices=notices;}
 list(category="all",search=""){const query=search.toLowerCase();return CODEX_ENTRIES.filter(entry=>(category==="all"||entry.category===category)&&(!query||`${entry.title} ${entry.body}`.toLowerCase().includes(query))).map(entry=>({...entry,unlocked:Boolean(this.state.get(`codex.${entry.id}`))}));}
 unlock(id){const entry=CODEX_ENTRIES.find(item=>item.id===id);if(!entry)return false;if(this.state.get(`codex.${id}`))return true;this.state.set(`codex.${id}`,true);this.notices.push("Codex updated",`${entry.title} added to your field notes.`,"info");this.bus.emit("codex:unlocked",entry);return true;}
 completion(){const total=CODEX_ENTRIES.length;const found=this.list().filter(item=>item.unlocked).length;return {found,total,percent:Math.round(found/total*100)};}
}
