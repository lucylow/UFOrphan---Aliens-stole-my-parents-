export class FeatureUnlockService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  unlocked(id) { return Boolean(this.state.get(`unlockedFeatures.${id}`)); }
  unlock(id, source = "progress") {
    if (this.unlocked(id)) return false;
    this.state.set(`unlockedFeatures.${id}`, { source, at: new Date().toISOString() });
    this.bus.emit("feature:unlocked", { id, source }); return true;
  }
  all() { return Object.keys(this.state.get("unlockedFeatures") || {}); }
  lock(id) { this.state.mutate(data => delete data.unlockedFeatures?.[id], "feature:locked"); }
}
