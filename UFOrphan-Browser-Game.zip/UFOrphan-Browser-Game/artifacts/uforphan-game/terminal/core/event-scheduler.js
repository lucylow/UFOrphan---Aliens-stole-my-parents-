import { uid } from "./utils.js";
export class EventScheduler {
  constructor(clock = () => Date.now()) { this.clock = clock; this.events = []; }
  schedule(delayMs, callback, label = "event") {
    const event = { id: uid("scheduled"), at: this.clock() + Math.max(0, delayMs), callback, label, cancelled: false };
    this.events.push(event); return event.id;
  }
  cancel(id) { const event = this.events.find(item => item.id === id); if (!event) return false; event.cancelled = true; return true; }
  tick() {
    const due = this.events.filter(event => !event.cancelled && event.at <= this.clock());
    this.events = this.events.filter(event => event.at > this.clock() && !event.cancelled);
    for (const event of due) event.callback();
    return due.length;
  }
  clear() { this.events = []; }
  pending() { return this.events.filter(event => !event.cancelled).length; }
}
