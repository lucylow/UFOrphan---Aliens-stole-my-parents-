export class ProfileSlots {
  constructor(maximum = 5) { this.maximum = maximum; this.slots = new Map(); }
  save(slot, snapshot) { if (!Number.isInteger(slot) || slot < 0 || slot >= this.maximum) return false; this.slots.set(slot, structuredClone(snapshot)); return true; }
  load(slot) { const value = this.slots.get(slot); return value ? structuredClone(value) : null; }
  delete(slot) { return this.slots.delete(slot); }
  occupied() { return [...this.slots.keys()].sort((a, b) => a - b); }
  empty() { return Array.from({ length: this.maximum }, (_, index) => index).filter(index => !this.slots.has(index)); }
}
