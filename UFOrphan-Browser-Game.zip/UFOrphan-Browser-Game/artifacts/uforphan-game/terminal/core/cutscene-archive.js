import { nowISO } from "./utils.js";
export class CutsceneArchive {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  watched(id) {
    return Boolean(this.state.get(`cutscenes.${id}`));
  }
  markWatched(id, metadata = {}) {
    if (this.watched(id)) return false;
    this.state.set(`cutscenes.${id}`, { watchedAt: nowISO(), ...metadata });
    this.bus.emit("cutscene:watched", { id, metadata });
    return true;
  }
  list(catalog) {
    return catalog.map(item => ({ ...item, watched: this.watched(item.id) }));
  }
  completion(catalog) {
    const watched = catalog.filter(item => this.watched(item.id)).length;
    return { watched, total: catalog.length, percent: catalog.length ? Math.round(watched / catalog.length * 100) : 100 };
  }
}
