export class QuestReplay {
  constructor(state, questDefinitions) { this.state = state; this.definitions = questDefinitions; }
  available(id) { const definition = this.definitions.find(item => item.id === id); return Boolean(definition && this.state.get(`missions.${id}.rewardClaimed`)); }
  reset(id) {
    if (!this.available(id)) return false;
    this.state.mutate(data => { delete data.missions[id]; }, "quest:replay-reset"); return true;
  }
  completedCount() { return Object.values(this.state.get("missions") || {}).filter(item => item.status === "complete").length; }
}
