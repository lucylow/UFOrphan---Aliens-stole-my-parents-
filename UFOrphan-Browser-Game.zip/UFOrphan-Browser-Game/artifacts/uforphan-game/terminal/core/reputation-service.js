export class ReputationService {
  constructor(state, bus, notices) {
    this.state = state;
    this.bus = bus;
    this.notices = notices;
  }
  score(faction) {
    return this.state.get(`reputation.${faction}`) || 0;
  }
  tier(score) {
    if (score >= 500) return "legendary ally";
    if (score >= 250) return "trusted friend";
    if (score >= 100) return "known helper";
    if (score > 0) return "new contact";
    if (score <= -100) return "unwelcome";
    return "neutral";
  }
  adjust(faction, amount, reason = "activity") {
    if (!Number.isFinite(amount)) return { ok: false };
    const before = this.score(faction);
    const after = Math.max(-500, Math.min(1000, before + amount));
    this.state.set(`reputation.${faction}`, after);
    this.bus.emit("reputation:changed", { faction, before, after, reason });
    if (this.tier(before) !== this.tier(after)) this.notices.push("Reputation changed", `${faction}: ${this.tier(after)}.`, "info");
    return { ok: true, score: after, tier: this.tier(after) };
  }
  standings() {
    return Object.entries(this.state.get("reputation") || {}).map(([faction, score]) => ({ faction, score, tier: this.tier(score) }));
  }
}
