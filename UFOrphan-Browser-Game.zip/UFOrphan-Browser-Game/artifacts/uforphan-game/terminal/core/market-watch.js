export class MarketWatch {
  constructor(catalog) {
    this.catalog = catalog;
    this.observations = new Map();
  }
  observe(itemId, price, at = new Date()) {
    if (!this.catalog.some(item => item.id === itemId)) return false;
    const history = this.observations.get(itemId) || [];
    history.push({ price: Number(price), at: at.toISOString() });
    this.observations.set(itemId, history.slice(-50));
    return true;
  }
  history(itemId) {
    return [...(this.observations.get(itemId) || [])];
  }
  trend(itemId) {
    const history = this.history(itemId);
    if (history.length < 2) return "unknown";
    const first = history[0].price;
    const last = history.at(-1).price;
    if (last < first) return "falling";
    if (last > first) return "rising";
    return "stable";
  }
  lowest(itemId) {
    const values = this.history(itemId).map(entry => entry.price);
    return values.length ? Math.min(...values) : null;
  }
  clear() {
    this.observations.clear();
  }
}
