import { uid, nowISO, clone } from "./utils.js";
export class AuditLog {
  constructor(limit = 250) {
    this.limit = limit;
    this.entries = [];
  }
  record(action, subject, details = {}) {
    const entry = {
      id: uid("audit"),
      action: String(action),
      subject: String(subject),
      details: clone(details),
      at: nowISO()
    };
    this.entries.unshift(entry);
    this.entries = this.entries.slice(0, this.limit);
    return entry;
  }
  list(options = {}) {
    const action = options.action || null;
    const subject = options.subject || null;
    const since = options.since ? new Date(options.since).getTime() : 0;
    return this.entries.filter(entry => {
      if (action && entry.action !== action) return false;
      if (subject && entry.subject !== subject) return false;
      return new Date(entry.at).getTime() >= since;
    });
  }
  count(action) {
    return this.entries.filter(entry => entry.action === action).length;
  }
  clear() {
    this.entries = [];
  }
  export() {
    return clone(this.entries);
  }
  restore(entries = []) {
    this.entries = entries.slice(0, this.limit).map(clone);
  }
}
