import { uid } from "./utils.js";
export class CalendarReminders {
  constructor(bus) {
    this.bus = bus;
    this.reminders = [];
  }
  schedule(title, at, metadata = {}) {
    const date = new Date(at);
    if (Number.isNaN(date.getTime())) throw new TypeError("Reminder date is invalid");
    const reminder = { id: uid("reminder"), title, at: date.toISOString(), metadata, delivered: false };
    this.reminders.push(reminder);
    this.reminders.sort((a, b) => a.at.localeCompare(b.at));
    return reminder;
  }
  due(now = new Date()) {
    return this.reminders.filter(item => !item.delivered && new Date(item.at) <= now);
  }
  deliver(now = new Date()) {
    const due = this.due(now);
    for (const reminder of due) {
      reminder.delivered = true;
      this.bus.emit("reminder:due", reminder);
    }
    return due;
  }
  cancel(id) {
    this.reminders = this.reminders.filter(item => item.id !== id);
  }
}
