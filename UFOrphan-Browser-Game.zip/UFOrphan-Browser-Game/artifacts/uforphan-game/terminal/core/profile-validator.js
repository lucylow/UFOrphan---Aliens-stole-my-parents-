import { DEFAULT_STATE } from "./state.js";
export class ProfileValidator {
  validate(payload) {
    const errors = [];
    if (!payload || typeof payload !== "object") return { ok: false, errors: ["Backup must be an object"] };
    if (payload.application !== "UFOrphan Field Terminal") errors.push("Unknown backup application");
    if (!payload.state || typeof payload.state !== "object") errors.push("Backup state is missing");
    if (payload.state && typeof payload.state.credits !== "number") errors.push("Credits must be numeric");
    if (payload.state && typeof payload.state.inventory !== "object") errors.push("Inventory must be an object");
    if (payload.state && Array.isArray(payload.state.discoveredSectors) === false) errors.push("Discovered sectors must be a list");
    return { ok: errors.length === 0, errors };
  }
  normalize(state) {
    return {
      ...structuredClone(DEFAULT_STATE),
      ...state,
      inventory: { ...DEFAULT_STATE.inventory, ...(state.inventory || {}) },
      equipment: { ...DEFAULT_STATE.equipment, ...(state.equipment || {}) },
      settings: { ...DEFAULT_STATE.settings, ...(state.settings || {}) }
    };
  }
}
