export class SectorSurvey {
  constructor(map, state, bus) { this.map = map; this.state = state; this.bus = bus; }
  record(sectorId, featureId) {
    this.state.mutate(data => { data.sectorSurveys ||= {}; data.sectorSurveys[sectorId] ||= []; const list = data.sectorSurveys[sectorId]; if (!list.includes(featureId)) list.push(featureId); }, "survey:feature");
    this.bus.emit("survey:updated", { sectorId, featureId });
  }
  features(sectorId) { return [...(this.state.get(`sectorSurveys.${sectorId}`) || [])]; }
  completion(sectorId, expected) { const found = this.features(sectorId); return { found: found.length, total: expected.length, complete: expected.every(id => found.includes(id)) }; }
  summary() { return Object.entries(this.state.get("sectorSurveys") || {}).map(([sectorId, features]) => ({ sectorId, count: features.length })); }
}
