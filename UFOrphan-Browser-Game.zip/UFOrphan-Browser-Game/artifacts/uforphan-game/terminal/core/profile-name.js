export class ProfileName {
  validate(value) {
    const name = String(value || "").trim();
    if (!name) return { ok: false, reason: "empty" };
    if (name.length > 28) return { ok: false, reason: "too-long" };
    if (/[<>]/.test(name)) return { ok: false, reason: "invalid-characters" };
    return { ok: true, value: name };
  }
  initials(value) { return String(value || "").trim().split(/\s+/).slice(0, 2).map(part => part[0]?.toUpperCase() || "").join(""); }
  slug(value) { return String(value || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); }
}
