export class ChallengeRotation {
  constructor(definitions, seed = 1) {
    this.definitions = definitions;
    this.seed = seed >>> 0;
  }
  random() {
    this.seed = (1664525 * this.seed + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }
  choose(count = 3) {
    const pool = [...this.definitions];
    const chosen = [];
    while (pool.length && chosen.length < count) {
      const index = Math.floor(this.random() * pool.length);
      chosen.push(pool.splice(index, 1)[0]);
    }
    return chosen;
  }
  setSeed(seed) {
    this.seed = seed >>> 0;
  }
}
