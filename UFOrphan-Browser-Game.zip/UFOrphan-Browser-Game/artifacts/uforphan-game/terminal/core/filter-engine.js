export class FilterEngine {
  constructor(definitions = {}) {
    this.definitions = definitions;
  }
  define(name, predicate) {
    if (typeof predicate !== "function") throw new TypeError("Filter must be a function");
    this.definitions[name] = predicate;
    return this;
  }
  apply(items, name, context = {}) {
    const predicate = this.definitions[name];
    if (!predicate) return [...items];
    return items.filter(item => predicate(item, context));
  }
  combine(items, names, context = {}) {
    return items.filter(item => names.every(name => this.definitions[name]?.(item, context) ?? true));
  }
  search(items, query, fields) {
    const term = String(query || "").trim().toLowerCase();
    if (!term) return [...items];
    return items.filter(item => fields.some(field => String(item[field] ?? "").toLowerCase().includes(term)));
  }
  sort(items, key, direction = "asc") {
    const factor = direction === "desc" ? -1 : 1;
    return [...items].sort((a, b) => {
      const left = a[key];
      const right = b[key];
      if (typeof left === "number" && typeof right === "number") return (left - right) * factor;
      return String(left).localeCompare(String(right)) * factor;
    });
  }
}
