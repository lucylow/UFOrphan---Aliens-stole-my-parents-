export class LootPreview {
  constructor(random = Math.random) {
    this.random = random;
  }
  normalize(table) {
    return table.map(entry => ({ ...entry, weight: Math.max(0, Number(entry.weight) || 0) }));
  }
  roll(table) {
    const entries = this.normalize(table);
    const total = entries.reduce((sum, entry) => sum + entry.weight, 0);
    if (!total) return null;
    let cursor = this.random() * total;
    for (const entry of entries) {
      cursor -= entry.weight;
      if (cursor <= 0) return entry;
    }
    return entries.at(-1) || null;
  }
  simulate(table, count = 1000) {
    const results = new Map();
    for (let index = 0; index < count; index++) {
      const result = this.roll(table);
      if (result) results.set(result.id, (results.get(result.id) || 0) + 1);
    }
    return [...results].map(([id, hits]) => ({ id, hits, rate: hits / count }));
  }
}
