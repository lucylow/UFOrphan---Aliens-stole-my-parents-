export class SearchService {
 constructor(bus){this.bus=bus;this.history=[];}
 run(query,collections){const term=String(query||"").trim().toLowerCase();if(!term)return [];const results=[];for(const [type,items] of Object.entries(collections)){for(const item of items){const text=Object.values(item).filter(value=>typeof value==="string").join(" ").toLowerCase();if(text.includes(term))results.push({type,item,score:text.startsWith(term)?2:1});}}results.sort((a,b)=>b.score-a.score);this.history.unshift({query:term,at:new Date().toISOString(),count:results.length});this.history=this.history.slice(0,12);this.bus.emit("search:complete",{query:term,results});return results;}
 suggestions(query,terms){const term=String(query||"").toLowerCase();return terms.filter(value=>value.toLowerCase().includes(term)).slice(0,6);}
}
