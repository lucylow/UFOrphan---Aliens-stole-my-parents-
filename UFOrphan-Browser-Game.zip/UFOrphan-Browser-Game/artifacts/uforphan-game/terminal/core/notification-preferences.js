export class NotificationPreferences {
  constructor(state) { this.state = state; }
  enabled(type) { return this.state.get(`notificationPreferences.${type}`) !== false; }
  set(type, enabled) { this.state.set(`notificationPreferences.${type}`, Boolean(enabled)); }
  filter(notifications) { return notifications.filter(item => this.enabled(item.type || "info")); }
  all(types = ["info", "success", "warning", "error"]) { return Object.fromEntries(types.map(type => [type, this.enabled(type)])); }
  reset() { this.state.set("notificationPreferences", {}); }
}
