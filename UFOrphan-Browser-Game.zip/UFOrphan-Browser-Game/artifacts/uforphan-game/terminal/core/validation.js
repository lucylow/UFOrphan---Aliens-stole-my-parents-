export const validators = {
  nonEmpty: value => String(value ?? "").trim().length > 0,
  maxLength: limit => value => String(value ?? "").length <= limit,
  integer: value => Number.isInteger(Number(value)),
  positive: value => Number(value) > 0,
  emailLike: value => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(value)),
  identifier: value => /^[a-z0-9_-]+$/i.test(String(value))
};
export class Validator {
  constructor(rules = {}) {
    this.rules = rules;
  }
  add(field, name, rule, message) {
    this.rules[field] ||= [];
    this.rules[field].push({ name, rule, message });
    return this;
  }
  validate(data) {
    const errors = {};
    for (const [field, rules] of Object.entries(this.rules)) {
      for (const entry of rules) {
        if (!entry.rule(data[field], data)) {
          (errors[field] ||= []).push(entry.message || `${field} failed ${entry.name}`);
        }
      }
    }
    return { ok: Object.keys(errors).length === 0, errors };
  }
  static required(fields) {
    const validator = new Validator();
    for (const field of fields) validator.add(field, "required", validators.nonEmpty, `${field} is required`);
    return validator;
  }
}
