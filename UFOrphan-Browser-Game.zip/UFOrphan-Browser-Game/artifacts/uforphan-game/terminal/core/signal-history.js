export class SignalHistory {
  constructor(limit = 100) { this.limit = limit; this.samples = []; }
  add(strength, sector) { this.samples.push({ strength, sector, at: new Date().toISOString() }); this.samples = this.samples.slice(-this.limit); }
  latest() { return this.samples.at(-1) || null; }
  bySector(sector) { return this.samples.filter(item => item.sector === sector); }
  peak() { return this.samples.reduce((best, item) => !best || item.strength > best.strength ? item : best, null); }
  average() { return this.samples.length ? this.samples.reduce((sum, item) => sum + item.strength, 0) / this.samples.length : 0; }
}
