export class BackupScheduler {
  constructor(exporter, intervalMs = 600000, clock = () => Date.now()) {
    this.exporter = exporter;
    this.intervalMs = intervalMs;
    this.clock = clock;
    this.lastBackupAt = 0;
    this.backups = [];
  }
  due() {
    return this.clock() - this.lastBackupAt >= this.intervalMs;
  }
  run(force = false) {
    if (!force && !this.due()) return { ok: false, reason: "not-due" };
    const payload = this.exporter();
    const backup = { payload, createdAt: new Date(this.clock()).toISOString() };
    this.backups.unshift(backup);
    this.backups = this.backups.slice(0, 5);
    this.lastBackupAt = this.clock();
    return { ok: true, backup };
  }
  latest() {
    return this.backups[0] || null;
  }
  history() {
    return [...this.backups];
  }
}
