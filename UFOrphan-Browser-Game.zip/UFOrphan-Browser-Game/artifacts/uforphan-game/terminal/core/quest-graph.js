export class QuestGraph {
  constructor(nodes = []) {
    this.nodes = new Map(nodes.map(node => [node.id, { ...node }]));
  }
  add(node) {
    if (!node.id || this.nodes.has(node.id)) throw new Error("Quest node ID must be unique");
    this.nodes.set(node.id, { dependencies: [], ...node });
  }
  get(id) {
    return this.nodes.get(id) || null;
  }
  available(completed = []) {
    const done = new Set(completed);
    return [...this.nodes.values()].filter(node =>
      !done.has(node.id) && (node.dependencies || []).every(id => done.has(id))
    );
  }
  validate() {
    const errors = [];
    for (const node of this.nodes.values()) {
      for (const dependency of node.dependencies || []) {
        if (!this.nodes.has(dependency)) errors.push(`${node.id} depends on missing ${dependency}`);
      }
    }
    if (this.hasCycle()) errors.push("Quest graph contains a dependency cycle");
    return { ok: errors.length === 0, errors };
  }
  hasCycle() {
    const visiting = new Set();
    const visited = new Set();
    const visit = id => {
      if (visiting.has(id)) return true;
      if (visited.has(id)) return false;
      visiting.add(id);
      for (const dependency of this.get(id)?.dependencies || []) if (visit(dependency)) return true;
      visiting.delete(id);
      visited.add(id);
      return false;
    };
    return [...this.nodes.keys()].some(visit);
  }
  pathTo(id) {
    const result = [];
    const seen = new Set();
    const walk = current => {
      if (seen.has(current)) return;
      seen.add(current);
      for (const dependency of this.get(current)?.dependencies || []) walk(dependency);
      result.push(current);
    };
    if (this.nodes.has(id)) walk(id);
    return result;
  }
}
