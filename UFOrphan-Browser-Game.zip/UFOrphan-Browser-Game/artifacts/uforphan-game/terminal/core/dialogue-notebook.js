import { uid, nowISO } from "./utils.js";
export class DialogueNotebook {
  constructor(state, bus) {
    this.state = state;
    this.bus = bus;
  }
  entries() {
    return this.state.get("dialogueNotebook") || [];
  }
  add(speaker, text, context = {}) {
    const entry = {
      id: uid("quote"),
      speaker: String(speaker),
      text: String(text),
      sector: context.sector || "unknown",
      tags: context.tags || [],
      at: nowISO()
    };
    this.state.mutate(data => {
      data.dialogueNotebook ||= [];
      data.dialogueNotebook.unshift(entry);
      data.dialogueNotebook = data.dialogueNotebook.slice(0, 300);
    }, "notebook:add");
    this.bus.emit("notebook:entry", entry);
    return entry;
  }
  search(term) {
    const query = String(term).toLowerCase();
    return this.entries().filter(entry =>
      `${entry.speaker} ${entry.text} ${entry.sector}`.toLowerCase().includes(query)
    );
  }
  bySpeaker(speaker) {
    return this.entries().filter(entry => entry.speaker === speaker);
  }
  remove(id) {
    this.state.mutate(data => {
      data.dialogueNotebook = (data.dialogueNotebook || []).filter(entry => entry.id !== id);
    }, "notebook:remove");
  }
}
