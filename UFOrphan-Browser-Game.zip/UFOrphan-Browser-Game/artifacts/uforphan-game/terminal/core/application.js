import { EventBus } from "./event-bus.js";
import { TerminalStorage } from "./storage.js";
import { TerminalState } from "./state.js";
import { Router } from "./router.js";
import { NotificationCenter } from "./notifications.js";
import { InventoryService } from "./inventory-service.js";
import { EconomyService } from "./economy-service.js";
import { CraftingService } from "./crafting-service.js";
import { MissionService } from "./mission-service.js";
import { EquipmentService } from "./equipment-service.js";
import { ProfileService } from "./profile-service.js";
import { AchievementService } from "./achievement-service.js";
import { CodexService } from "./codex-service.js";
import { MapService } from "./map-service.js";
import { SearchService } from "./search-service.js";
import { SettingsService } from "./settings-service.js";
export class FieldTerminalApplication {
 constructor(){this.bus=new EventBus();this.storage=new TerminalStorage();this.state=new TerminalState(this.storage,this.bus);this.router=new Router(this.state,this.bus);this.notifications=new NotificationCenter(this.state,this.bus);this.inventory=new InventoryService(this.state,this.bus,this.notifications);this.economy=new EconomyService(this.state,this.bus,this.notifications);this.crafting=new CraftingService(this.state,this.inventory,this.bus,this.notifications);this.missions=new MissionService(this.state,this.bus,this.notifications);this.equipment=new EquipmentService(this.state,this.inventory,this.bus,this.notifications);this.profiles=new ProfileService(this.state,this.storage,this.notifications);this.achievements=new AchievementService(this.state,this.bus,this.notifications);this.codex=new CodexService(this.state,this.bus,this.notifications);this.map=new MapService(this.state,this.bus);this.search=new SearchService(this.bus);this.settings=new SettingsService(this.state,this.bus);this.achievements.evaluate();}
 open(){this.state.mutate(data=>data.statistics.terminalVisits++,"terminal:visit");this.achievements.evaluate();}
 close(){this.state.persist();this.bus.emit("terminal:closed",{});}
}
