import { clone, deepMerge, nowISO } from "./utils.js";
export const DEFAULT_STATE = {
  version:1, activeTab:"dashboard", search:"", filter:"all", sort:"name", compact:false,
  credits:240, reputation:0, inventory:{med_patch:2,ion_cell:4,copper_coil:3,stardust:18},
  equipment:{weapon:"starter_blaster",boots:"canvas_boots",suit:"home_jacket",gadget:null},
  recipesUnlocked:["med_patch_recipe","ion_battery_recipe","signal_flare_recipe"],
  discoveredSectors:["backyard","moon_mall","scrap_belt","mothership"],
  missions:{}, achievements:{}, codex:{}, notes:[], mail:[], purchases:[], craftingHistory:[],
  profile:{name:"Fiona Gallegar",callsign:"STARLING",avatar:"✦",createdAt:nowISO()},
  settings:{reduceMotion:false,highContrast:false,largeText:false,confirmPurchases:true,showHints:true,autosave:true},
  statistics:{terminalVisits:0,itemsCrafted:0,itemsPurchased:0,creditsEarned:0,missionsTracked:0},
  notifications:[], seenWelcome:false
};
export class TerminalState {
  constructor(storage,bus) { this.storage=storage; this.bus=bus; this.data=deepMerge(DEFAULT_STATE,storage.read({})); this.revision=0; }
  get(path) { return path.split(".").reduce((value,key)=>value?.[key],this.data); }
  snapshot() { return clone(this.data); }
  set(path,value) { const keys=path.split("."); let target=this.data; for(const key of keys.slice(0,-1)) target=target[key] ||= {}; target[keys.at(-1)]=value; this.#changed(path); return value; }
  mutate(mutator,label="state") { mutator(this.data); this.#changed(label); return this.data; }
  reset() { this.data=clone(DEFAULT_STATE); this.#changed("reset"); }
  persist() { return this.storage.write(this.data); }
  #changed(label) { this.revision++; this.bus.emit("state:changed",{label,revision:this.revision,state:this.data}); if(this.data.settings.autosave)this.persist(); }
}
