import { ITEMS } from "../data/catalog.js";
export class VendorService {
  constructor(economy, stockIds = ITEMS.map(item => item.id)) { this.economy = economy; this.stockIds = new Set(stockIds); }
  stock() { return ITEMS.filter(item => this.stockIds.has(item.id) && item.price > 0); }
  quote(itemId, quantity = 1) { if (!this.stockIds.has(itemId)) return { ok: false, reason: "not-stocked" }; return this.economy.quote(itemId, quantity); }
  buy(itemId, quantity = 1) { const quote = this.quote(itemId, quantity); return quote.ok ? this.economy.buy(itemId, quantity) : quote; }
  addStock(itemId) { if (!ITEMS.some(item => item.id === itemId)) return false; this.stockIds.add(itemId); return true; }
  removeStock(itemId) { return this.stockIds.delete(itemId); }
}
