export class AsyncLock {
  constructor() {
    this.locks = new Map();
  }
  async run(key, task) {
    const previous = this.locks.get(key) || Promise.resolve();
    let release;
    const current = new Promise(resolve => { release = resolve; });
    this.locks.set(key, previous.then(() => current));
    await previous;
    try {
      return await task();
    } finally {
      release();
      if (this.locks.get(key) === current) this.locks.delete(key);
    }
  }
  locked(key) {
    return this.locks.has(key);
  }
  clear() {
    this.locks.clear();
  }
}
