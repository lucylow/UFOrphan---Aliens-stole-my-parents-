export class NotificationRules {
  constructor() {
    this.rules = new Map();
  }
  add(type, predicate, transform = value => value) {
    if (typeof predicate !== "function") throw new TypeError("Rule predicate required");
    const entries = this.rules.get(type) || [];
    const rule = { predicate, transform };
    entries.push(rule);
    this.rules.set(type, entries);
    return () => this.remove(type, rule);
  }
  remove(type, rule) {
    const entries = this.rules.get(type) || [];
    this.rules.set(type, entries.filter(entry => entry !== rule));
  }
  evaluate(type, payload) {
    return (this.rules.get(type) || [])
      .filter(rule => rule.predicate(payload))
      .map(rule => rule.transform(payload));
  }
  clear(type) {
    if (type) this.rules.delete(type);
    else this.rules.clear();
  }
  size(type) {
    return (this.rules.get(type) || []).length;
  }
}
