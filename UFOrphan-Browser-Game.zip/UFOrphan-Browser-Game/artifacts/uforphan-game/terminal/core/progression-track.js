export class ProgressionTrack {
  constructor(levels = []) {
    this.levels = [...levels].sort((a, b) => a.threshold - b.threshold);
  }
  current(points) {
    return this.levels.filter(level => points >= level.threshold).at(-1) || null;
  }
  next(points) {
    return this.levels.find(level => points < level.threshold) || null;
  }
  progress(points) {
    const current = this.current(points);
    const next = this.next(points);
    const floor = current?.threshold || 0;
    const ceiling = next?.threshold || floor;
    const ratio = ceiling > floor ? (points - floor) / (ceiling - floor) : 1;
    return { current, next, ratio: Math.max(0, Math.min(1, ratio)), pointsToNext: Math.max(0, ceiling - points) };
  }
  unlocks(points) {
    return this.levels.filter(level => points >= level.threshold).flatMap(level => level.unlocks || []);
  }
}
