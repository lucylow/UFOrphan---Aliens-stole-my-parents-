import { EQUIPMENT } from "../data/catalog.js";
export class EquipmentService {
 constructor(state,inventory,bus,notices){this.state=state;this.inventory=inventory;this.bus=bus;this.notices=notices;}
 list(slot="all"){return EQUIPMENT.filter(item=>(slot==="all"||item.slot===slot)&&(item.id==="starter_blaster"||item.id==="canvas_boots"||item.id==="home_jacket"||this.inventory.has(item.id)));}
 equipped(){return this.state.get("equipment");}
 equip(id){const item=EQUIPMENT.find(entry=>entry.id===id);if(!item)return {ok:false,reason:"unknown-equipment"};if(!["starter_blaster","canvas_boots","home_jacket"].includes(id)&&!this.inventory.has(id))return {ok:false,reason:"not-owned"};this.state.set(`equipment.${item.slot}`,id);this.notices.push("Equipment updated",`${item.name} equipped in ${item.slot} slot.`,"success");this.bus.emit("equipment:changed",{item});return {ok:true,item};}
 bonuses(){return Object.values(this.equipped()).map(id=>EQUIPMENT.find(item=>item.id===id)).filter(Boolean).reduce((total,item)=>{for(const [key,value] of Object.entries(item.stats))total[key]=(total[key]||0)+value;return total;},{});}
}
