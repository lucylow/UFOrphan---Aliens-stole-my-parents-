import { uid } from "./utils.js";
export class MapMarkerService {
  constructor(state, bus) { this.state = state; this.bus = bus; }
  markers() { return this.state.get("mapMarkers") || []; }
  add(sector, x, y, label, kind = "note") {
    const marker = { id: uid("marker"), sector, x, y, label: String(label).slice(0, 50), kind, createdAt: new Date().toISOString() };
    this.state.mutate(data => { data.mapMarkers ||= []; data.mapMarkers.push(marker); }, "map:marker-added");
    this.bus.emit("map:marker", marker); return marker;
  }
  remove(id) { this.state.mutate(data => data.mapMarkers = (data.mapMarkers || []).filter(item => item.id !== id), "map:marker-removed"); }
  bySector(sector) { return this.markers().filter(marker => marker.sector === sector); }
}
