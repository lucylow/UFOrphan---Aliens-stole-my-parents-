export class NotificationThrottle {
  constructor(intervalMs = 1500, clock = () => Date.now()) { this.intervalMs = intervalMs; this.clock = clock; this.last = new Map(); }
  allow(key) { const now = this.clock(); const previous = this.last.get(key) || 0; if (now - previous < this.intervalMs) return false; this.last.set(key, now); return true; }
  reset(key) { if (key) this.last.delete(key); else this.last.clear(); }
  remaining(key) { return Math.max(0, this.intervalMs - (this.clock() - (this.last.get(key) || 0))); }
}
