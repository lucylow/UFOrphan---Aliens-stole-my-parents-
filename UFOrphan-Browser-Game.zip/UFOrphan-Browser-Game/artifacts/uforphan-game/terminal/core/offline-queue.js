import { uid, nowISO } from "./utils.js";
export class OfflineQueue {
  constructor(bus, limit = 100) {
    this.bus = bus;
    this.limit = limit;
    this.jobs = [];
    this.handlers = new Map();
    this.running = false;
  }
  register(type, handler) {
    this.handlers.set(type, handler);
    return () => this.handlers.delete(type);
  }
  enqueue(type, payload, options = {}) {
    const job = { id: uid("job"), type, payload, createdAt: nowISO(), attempts: 0, status: "pending", priority: options.priority || 0 };
    this.jobs.push(job);
    this.jobs = this.jobs.slice(-this.limit);
    this.bus.emit("queue:added", job);
    return job;
  }
  pending() {
    return this.jobs.filter(job => job.status === "pending").sort((a, b) => b.priority - a.priority);
  }
  async flush(context = {}) {
    if (this.running) return { ok: false, reason: "already-running" };
    this.running = true;
    let completed = 0;
    try {
      for (const job of this.pending()) {
        const handler = this.handlers.get(job.type);
        if (!handler) continue;
        job.attempts++;
        try {
          await handler(job.payload, context);
          job.status = "complete";
          completed++;
          this.bus.emit("queue:complete", job);
        } catch (error) {
          job.lastError = String(error?.message || error);
          this.bus.emit("queue:error", { job, error });
        }
      }
    } finally {
      this.running = false;
    }
    return { ok: true, completed, pending: this.pending().length };
  }
  discard(id) {
    this.jobs = this.jobs.filter(job => job.id !== id);
  }
}
