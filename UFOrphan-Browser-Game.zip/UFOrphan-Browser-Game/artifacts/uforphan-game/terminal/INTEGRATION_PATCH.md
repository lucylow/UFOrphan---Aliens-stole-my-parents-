# Integration patch

Add the following script immediately after the existing game entry point in `index.html`:

```html
<script type="module" src="src/main.js"></script>
<script type="module" src="terminal/boot.js"></script>
```

If your file already has the first script, add only the second. No edits to `src/main.js` are required. The new toolbar button is inserted automatically into `.top-actions`.

## Optional progress bridge

If you later want the game engine to award terminal materials, call:

```js
window.UFOrphanFieldTerminal?.app.inventory.add("relay_chip", 1, "story-reward");
window.UFOrphanFieldTerminal?.app.codex.unlock("tractor_beam");
window.UFOrphanFieldTerminal?.app.map.discover("crystal_grove");
```

The app is loaded asynchronously as a module, so integrations should use optional chaining or wait until `window.UFOrphanFieldTerminal` exists.
