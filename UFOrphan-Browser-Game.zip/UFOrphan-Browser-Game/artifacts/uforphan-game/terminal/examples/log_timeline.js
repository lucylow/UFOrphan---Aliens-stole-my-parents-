/**
 * Add a timeline milestone
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  timeline.add("story", "Signal aligned", "Fiona tuned the relay.");
  return { ok: true, recipe: "log_timeline" };
}
