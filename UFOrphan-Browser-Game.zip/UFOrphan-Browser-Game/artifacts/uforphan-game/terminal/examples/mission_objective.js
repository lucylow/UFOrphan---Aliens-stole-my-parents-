/**
 * Advance a mission objective after an interaction
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.missions.progress("mall_cleanup", "restart_kiosk", 1);
  return { ok: true, recipe: "mission_objective" };
}
