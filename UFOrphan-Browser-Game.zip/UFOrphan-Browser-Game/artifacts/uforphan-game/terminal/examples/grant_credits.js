/**
 * Grant a small credit reward for a side activity
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.state.mutate(data => { data.credits += 25; data.statistics.creditsEarned += 25; }, "reward:side-activity");
  return { ok: true, recipe: "grant_credits" };
}
