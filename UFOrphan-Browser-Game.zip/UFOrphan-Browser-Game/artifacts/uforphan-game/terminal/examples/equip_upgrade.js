/**
 * Equip the plasma lens after it is acquired
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.equipment.equip("plasma_lens");
  return { ok: true, recipe: "equip_upgrade" };
}
