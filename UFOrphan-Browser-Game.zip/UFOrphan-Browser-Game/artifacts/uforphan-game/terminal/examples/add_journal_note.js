/**
 * Record a short story note
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  journal.write("A strange signal", "The family frequency is stronger here.", ["story", "signal"]);
  return { ok: true, recipe: "add_journal_note" };
}
