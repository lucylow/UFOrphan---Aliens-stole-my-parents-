/**
 * Describe the reward before accepting a mission
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const rewardText = rewardPreview.describe(mission.rewards);
  return { ok: true, recipe: "preview_reward" };
}
