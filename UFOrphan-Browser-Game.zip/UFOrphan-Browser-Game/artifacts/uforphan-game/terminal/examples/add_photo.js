/**
 * Store a screenshot data URL in the gallery
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  gallery.add({ title: "Crystal Grove", dataUrl, sector: "crystal_grove" });
  return { ok: true, recipe: "add_photo" };
}
