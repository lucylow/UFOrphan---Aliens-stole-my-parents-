/**
 * Filter inventory to available upgrades
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const upgrades = filterEngine.apply(items, "available-upgrades");
  return { ok: true, recipe: "apply_filter" };
}
