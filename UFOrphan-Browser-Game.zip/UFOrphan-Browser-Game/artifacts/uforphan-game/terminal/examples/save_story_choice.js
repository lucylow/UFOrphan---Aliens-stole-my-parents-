/**
 * Store a dialogue branch decision
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  storyFlags.set("fiona-trusts-nix", true);
  return { ok: true, recipe: "save_story_choice" };
}
