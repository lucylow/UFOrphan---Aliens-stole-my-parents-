/**
 * Summarize unread notices
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const unread = notificationDigest.unread();
  return { ok: true, recipe: "read_notifications" };
}
