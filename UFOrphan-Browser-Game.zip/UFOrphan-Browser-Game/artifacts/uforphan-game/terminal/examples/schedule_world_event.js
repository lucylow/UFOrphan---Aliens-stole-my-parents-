/**
 * Schedule a small event callback
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  scheduler.schedule(5000, () => bus.emit("world:hint", {}), "hint");
  return { ok: true, recipe: "schedule_world_event" };
}
