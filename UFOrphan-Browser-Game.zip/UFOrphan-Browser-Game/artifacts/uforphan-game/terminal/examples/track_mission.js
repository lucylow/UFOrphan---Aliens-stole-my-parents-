/**
 * Track a mission when a character offers it
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.missions.track("mall_cleanup");
  return { ok: true, recipe: "track_mission" };
}
