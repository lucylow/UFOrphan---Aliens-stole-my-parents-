/**
 * Copy a signal coordinate string
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export async function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  await context.clipboard.copy("X: 12 / Y: 4");
  return { ok: true, recipe: "copy_signal" };
}
