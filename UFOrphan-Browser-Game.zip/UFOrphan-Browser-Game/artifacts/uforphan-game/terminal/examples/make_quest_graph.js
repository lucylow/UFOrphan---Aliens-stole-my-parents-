/**
 * Build a dependency graph for a story chain
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const graph = new QuestGraph([{ id: "scan", dependencies: [] }, { id: "decode", dependencies: ["scan"] }]);
  return { ok: true, recipe: "make_quest_graph" };
}
