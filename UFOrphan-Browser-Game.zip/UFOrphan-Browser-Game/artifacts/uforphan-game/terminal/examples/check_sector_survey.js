/**
 * Check a sector survey completion
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const survey = sectorSurvey.completion("crystal_grove", expectedFeatures);
  return { ok: true, recipe: "check_sector_survey" };
}
