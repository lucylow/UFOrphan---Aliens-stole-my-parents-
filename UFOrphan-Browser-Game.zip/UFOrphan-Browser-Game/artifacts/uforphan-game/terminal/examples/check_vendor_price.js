/**
 * Get a quote before purchasing
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const quote = vendor.quote("med_patch", 2);
  return { ok: true, recipe: "check_vendor_price" };
}
