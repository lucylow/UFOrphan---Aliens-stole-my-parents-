/**
 * Award a material when a relay crate is opened
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.inventory.add("relay_chip", 1, "relay-crate");
  return { ok: true, recipe: "award_material" };
}
