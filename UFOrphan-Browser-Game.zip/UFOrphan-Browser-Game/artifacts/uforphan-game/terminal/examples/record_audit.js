/**
 * Record a sensitive inventory change
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  audit.record("item-consumed", "med_patch", { amount: 1 });
  return { ok: true, recipe: "record_audit" };
}
