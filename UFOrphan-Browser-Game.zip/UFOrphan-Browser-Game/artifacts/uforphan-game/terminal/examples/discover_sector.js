/**
 * Discover a sector after its portal animation
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.map.discover("crystal_grove");
  return { ok: true, recipe: "discover_sector" };
}
