/**
 * Start and pause a tracked activity
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  playtime.start(); playtime.pause();
  return { ok: true, recipe: "record_playtime" };
}
