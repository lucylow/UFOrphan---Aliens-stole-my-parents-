/**
 * Unlock a codex entry after scanning a landmark
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.codex.unlock("tractor_beam");
  return { ok: true, recipe: "unlock_codex" };
}
