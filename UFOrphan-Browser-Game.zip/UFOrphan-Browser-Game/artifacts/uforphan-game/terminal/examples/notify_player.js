/**
 * Show a friendly field terminal message
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  app.notifications.push("New signal", "A relay has started transmitting.", "info");
  return { ok: true, recipe: "notify_player" };
}
