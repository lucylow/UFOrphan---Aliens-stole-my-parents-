/**
 * Reward a local faction for helping an NPC
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  reputation.adjust("moon-mall-staff", 10, "helped-kiosk");
  return { ok: true, recipe: "increase_reputation" };
}
