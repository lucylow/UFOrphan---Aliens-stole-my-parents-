/**
 * Record damage dealt during combat
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  combatRecords.record("damage-dealt", 12);
  return { ok: true, recipe: "log_combat" };
}
