/**
 * Schedule a reminder for a later objective
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  reminders.schedule("Check the archive", Date.now() + 60000);
  return { ok: true, recipe: "schedule_reminder" };
}
