/**
 * Place a custom map marker
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  markers.add("orbital_archive", 0.4, 0.7, "Memory vault", "objective");
  return { ok: true, recipe: "add_map_marker" };
}
