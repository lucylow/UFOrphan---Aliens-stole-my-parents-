/**
 * Compare the current and new blaster
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const comparison = comparator.compare(currentBlaster, plasmaLens);
  return { ok: true, recipe: "compare_equipment" };
}
