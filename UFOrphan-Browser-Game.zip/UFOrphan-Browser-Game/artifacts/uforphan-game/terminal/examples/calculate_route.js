/**
 * Estimate a route across discovered sectors
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const path = routePlanner.shortestPath("backyard", "mothership", discovered);
  return { ok: true, recipe: "calculate_route" };
}
