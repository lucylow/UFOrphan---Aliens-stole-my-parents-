/**
 * Check the terminal save size
 *
 * Integration recipe for the UFOrphan Field Terminal add-on.
 * Call from a trusted game event handler after the event is confirmed.
 */
export function runRecipe(context) {
  const { app } = context;
  if (!app) throw new Error("Field Terminal application is not ready");
  const saveInfo = saveInspector.inspect();
  return { ok: true, recipe: "inspect_backup" };
}
