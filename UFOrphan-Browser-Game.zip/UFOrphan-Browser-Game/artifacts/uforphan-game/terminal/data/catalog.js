export const ITEMS = [
 {id:"med_patch",name:"Med Patch",type:"consumable",rarity:"common",price:32,weight:1,icon:"✚",description:"Restores one heart when used.",tags:["healing","field"]},
 {id:"ion_cell",name:"Ion Cell",type:"material",rarity:"common",price:18,weight:1,icon:"▣",description:"A compact battery for alien machinery.",tags:["power","crafting"]},
 {id:"copper_coil",name:"Copper Coil",type:"material",rarity:"common",price:14,weight:1,icon:"〰",description:"Salvaged wire wound into a neat spiral.",tags:["metal","crafting"]},
 {id:"stardust",name:"Stardust",type:"material",rarity:"uncommon",price:8,weight:0,icon:"✦",description:"A glittering trace of the cosmic trail.",tags:["cosmic","crafting"]},
 {id:"relay_chip",name:"Relay Chip",type:"material",rarity:"uncommon",price:45,weight:1,icon:"⌘",description:"A tiny circuit with a very large signal.",tags:["signal","crafting"]},
 {id:"resonant_crystal",name:"Resonant Crystal",type:"material",rarity:"rare",price:110,weight:2,icon:"◆",description:"It hums when nobody is looking.",tags:["crystal","upgrade"]},
 {id:"shield_bubble",name:"Shield Bubble",type:"consumable",rarity:"uncommon",price:75,weight:1,icon:"◉",description:"A temporary protective field.",tags:["defense","field"]},
 {id:"star_cookie",name:"Star Cookie",type:"consumable",rarity:"uncommon",price:24,weight:1,icon:"☼",description:"A snack shaped like a constellation.",tags:["food","field"]},
 {id:"plasma_lens",name:"Plasma Lens",type:"upgrade",rarity:"rare",price:260,weight:2,icon:"◈",description:"Focuses the star-blaster into a stronger beam.",tags:["weapon","upgrade"]},
 {id:"double_jump",name:"Jump Servo",type:"upgrade",rarity:"epic",price:420,weight:3,icon:"⇧",description:"Adds an extra jump before landing.",tags:["movement","upgrade"]},
 {id:"signal_flare",name:"Signal Flare",type:"quest",rarity:"uncommon",price:0,weight:1,icon:"⚑",description:"A bright beacon for lost travellers.",tags:["quest","signal"]},
 {id:"moon_ticket",name:"Moon Mall Ticket",type:"collectible",rarity:"rare",price:0,weight:0,icon:"▤",description:"A ticket to somewhere Fiona would rather not shop.",tags:["collection"]},
 {id:"family_photo",name:"Family Photo",type:"quest",rarity:"legendary",price:0,weight:0,icon:"▧",description:"A reminder of what this whole trip is for.",tags:["story","family"]},
 {id:"star_map_fragment",name:"Star Map Fragment",type:"collectible",rarity:"rare",price:0,weight:0,icon:"⌖",description:"A fragment of a route through the outer systems.",tags:["map","collection"]},
 {id:"scrap_bundle",name:"Scrap Bundle",type:"material",rarity:"common",price:20,weight:2,icon:"⚙",description:"Useful bits rescued from a junk heap.",tags:["metal","crafting"]},
 {id:"bio_gel",name:"Bio Gel",type:"material",rarity:"uncommon",price:52,weight:1,icon:"●",description:"A flexible polymer from the moon gardens.",tags:["organic","crafting"]},
 {id:"void_thread",name:"Void Thread",type:"material",rarity:"rare",price:96,weight:0,icon:"⌁",description:"A strand that seems longer on the inside.",tags:["rare","crafting"]},
 {id:"echo_shell",name:"Echo Shell",type:"collectible",rarity:"epic",price:0,weight:0,icon:"◖",description:"It repeats a voice from somewhere far away.",tags:["story","collection"]}
];
export const RECIPES = [
 {id:"med_patch_recipe",name:"Med Patch",output:"med_patch",amount:1,station:"field",cost:{bio_gel:1,stardust:2},description:"Patch up one heart."},
 {id:"ion_battery_recipe",name:"Ion Battery",output:"ion_cell",amount:3,station:"workbench",cost:{copper_coil:1,stardust:3},description:"Three charged cells for machinery."},
 {id:"signal_flare_recipe",name:"Signal Flare",output:"signal_flare",amount:1,station:"field",cost:{ion_cell:1,stardust:4},description:"A bright emergency signal."},
 {id:"shield_bubble_recipe",name:"Shield Bubble",output:"shield_bubble",amount:1,station:"workbench",cost:{ion_cell:2,resonant_crystal:1},description:"A short-lived defensive field."},
 {id:"scrap_bundle_recipe",name:"Scrap Bundle",output:"scrap_bundle",amount:2,station:"field",cost:{copper_coil:2},description:"Bundle spare coils into useful salvage."},
 {id:"resonance_lens_recipe",name:"Resonance Lens",output:"plasma_lens",amount:1,station:"advanced",cost:{resonant_crystal:2,relay_chip:2,ion_cell:4},description:"A precision blaster upgrade."},
 {id:"star_cookie_recipe",name:"Star Cookie",output:"star_cookie",amount:2,station:"field",cost:{bio_gel:1,stardust:3},description:"Two tiny morale boosters."}
];
export const EQUIPMENT = [
 {id:"starter_blaster",slot:"weapon",name:"Kitchen-Sink Blaster",rarity:"common",icon:"✦",stats:{damage:1,range:1},description:"It was in the garage. It mostly works."},
 {id:"plasma_lens",slot:"weapon",name:"Plasma Lens",rarity:"rare",icon:"◈",stats:{damage:2,range:2},description:"A focused beam with a cleaner punch."},
 {id:"canvas_boots",slot:"boots",name:"Canvas Boots",rarity:"common",icon:"⌁",stats:{speed:0,jumps:0},description:"Comfortable, if not particularly space-proof."},
 {id:"double_jump",slot:"boots",name:"Jump Servo",rarity:"epic",icon:"⇧",stats:{speed:0,jumps:1},description:"A tiny booster that grants another jump."},
 {id:"home_jacket",slot:"suit",name:"Home Jacket",rarity:"common",icon:"▤",stats:{health:0,defense:0},description:"Smells faintly of laundry day."},
 {id:"scrap_armor",slot:"suit",name:"Scrapguard Vest",rarity:"uncommon",icon:"⬡",stats:{health:1,defense:1},description:"A little clunky, but it takes the edge off."},
 {id:"signal_compass",slot:"gadget",name:"Signal Compass",rarity:"rare",icon:"⌖",stats:{scan:1},description:"Points toward active signal sources."}
];
