export const CODEX_ENTRIES = [
 {id:"fiona",category:"people",title:"Fiona Gallegar",icon:"✦",rarity:"known",body:"A determined kid with a homemade star-blaster, a stubborn streak, and two parents to bring home.",hint:"The story follows Fiona's rescue across the galaxy."},
 {id:"tractor_beam",category:"phenomena",title:"Tractor-Beam Residue",icon:"⌁",rarity:"common",body:"A shimmering film left behind where a ship's beam intersects ordinary matter.",hint:"Look for the faint teal shimmer near abduction sites."},
 {id:"moon_mall",category:"places",title:"Moon Mall",icon:"▦",rarity:"known",body:"A retail station that somehow has three floors of novelty moon cheese.",hint:"The security kiosk contains useful local records."},
 {id:"patch7",category:"people",title:"Patch-7",icon:"⚙",rarity:"uncommon",body:"A salvage bot whose serial number is longer than its patience.",hint:"Patch-7 trades practical advice for clean copper coils."},
 {id:"resonance_crystal",category:"materials",title:"Resonant Crystal",icon:"◆",rarity:"rare",body:"A mineral that stores vibration and releases it as a harmonic pulse.",hint:"Crystal Grove is rich in resonant deposits."},
 {id:"memory_vault",category:"technology",title:"Memory Vault",icon:"▤",rarity:"rare",body:"A cold-storage archive for recordings, memories and occasionally embarrassing karaoke.",hint:"The Orbital Archive keeps a vault near its central stacks."},
 {id:"bio_dome",category:"places",title:"Bio-Dome",icon:"❀",rarity:"known",body:"An engineered ecosystem whose maintenance routines have become a little too independent.",hint:"Bio gel can be harvested from the spore gardens."},
 {id:"eclipse_engine",category:"technology",title:"Eclipse Engine",icon:"◉",rarity:"unknown",body:"A machine built around a signal that should not be able to cross empty space.",hint:"The last sector may reveal its purpose."},
 {id:"mothership_captain",category:"people",title:"The Mothership Captain",icon:"♜",rarity:"unknown",body:"The commander responsible for the abduction. Their motives remain unclear.",hint:"Follow the signal trail to learn more."},
 {id:"family_frequency",category:"phenomena",title:"Family Frequency",icon:"♥",rarity:"unknown",body:"A familiar pattern hidden in the background of the alien transmission.",hint:"The signal becomes clearer as more sectors are explored."}
];
