export const ACHIEVEMENTS = [
 {id:"terminal_tour",name:"Button Masher",description:"Open the Field Terminal for the first time.",icon:"▣",points:5,condition:s=>s.statistics.terminalVisits>=1},
 {id:"collector_5",name:"Pocket Universe",description:"Carry at least five different item types.",icon:"▤",points:10,condition:s=>Object.keys(s.inventory).filter(id=>s.inventory[id]>0).length>=5},
 {id:"rich_kid",name:"Cosmic Allowance",description:"Save up 500 credits.",icon:"◉",points:15,condition:s=>s.credits>=500},
 {id:"craft_3",name:"Made in Space",description:"Craft three items.",icon:"⚒",points:15,condition:s=>s.statistics.itemsCrafted>=3},
 {id:"shop_5",name:"Retail Therapy",description:"Purchase five items.",icon:"▦",points:15,condition:s=>s.statistics.itemsPurchased>=5},
 {id:"mission_3",name:"Reliable Contractor",description:"Track three missions.",icon:"☷",points:20,condition:s=>s.statistics.missionsTracked>=3},
 {id:"sector_6",name:"Frequent Flyer",description:"Discover six sectors.",icon:"⌖",points:25,condition:s=>s.discoveredSectors.length>=6},
 {id:"codex_8",name:"Galactic Know-It-All",description:"Unlock eight codex entries.",icon:"▧",points:25,condition:s=>Object.values(s.codex).filter(Boolean).length>=8},
 {id:"saver",name:"Back It Up",description:"Export a terminal profile.",icon:"⇧",points:5,condition:s=>Boolean(s.achievements.saver)},
 {id:"family_first",name:"Home Is a Signal",description:"Unlock the family frequency entry.",icon:"♥",points:50,condition:s=>Boolean(s.codex.family_frequency)}
];
