# Field Terminal Developer Handbook

This reference documents the add-on services, event contracts, view conventions, extension points, state model and integration recipes.

## Application lifecycle

The application owns the event bus, state manager, storage adapter, router, notification center and domain services. `open()` increments visit statistics and evaluates achievements. `close()` persists the state. The base game remains the owner of movement, collisions, combat and level transitions.

## Persistence boundaries

Terminal data is stored under `uforphan.field-terminal.v1`. The original game save key is not read or written. A failed localStorage write falls back to in-memory state for the current page session. Exported backups include the application marker, version, export timestamp and complete terminal state.

## Inventory transactions

Inventory counts are integer quantities. `add` rejects non-positive or non-integer amounts. `remove` verifies sufficient quantity before changing state. `list` supports type filtering and case-insensitive search. Unknown item IDs are represented as uncatalogued entries rather than crashing the view.

## Economy rules

Every item quote uses the catalog price and requested quantity. Purchases reject unknown items, invalid quantities, zero-price quest objects and insufficient balances. Successful purchases update credits, item quantities, purchase history and lifetime purchase statistics in one state mutation.

## Crafting rules

Recipes are visible only after unlock. Each recipe declares an output, output amount, station type and ingredient map. `canCraft` validates every ingredient. A successful craft removes ingredients, adds the output, records the transaction and emits `crafting:complete`.

## Mission rules

Mission progress is keyed by mission ID and objective ID. Objective progress is capped at its target. A mission becomes complete only when every objective reaches its target. Rewards can be claimed once and are stored with a `rewardClaimed` flag.

## Equipment rules

Equipment is assigned to one of four slots: weapon, boots, suit and gadget. Base equipment is always available. Other pieces must exist in the inventory. `bonuses()` aggregates numeric stat contributions from all equipped items.

## Achievement rules

Achievements are declarative records with an ID, title, description, point value and condition function. The evaluator ignores already unlocked achievements. Unlocking is persistent and produces both a notification and an event.

## Codex rules

Codex entries are grouped by people, places, phenomena, technology and materials. Locked entries reveal neither their body nor their field hint. Unlock operations are idempotent.

## Galaxy map rules

The map defines eight sectors and their chapter, region, coordinates, danger, signal strength and features. The map service keeps discovery state separately from catalog definitions. Route estimates are illustrative jump counts based on map coordinates.

## Accessibility rules

Reduce motion, high contrast and large text are applied as classes to the terminal root. Purchase confirmation, hints and autosave are independent settings. Settings are persisted using the same state service.

## Extension practices

New views should be pure render functions receiving `(app, host, actions)`. Use delegated data attributes for repeated controls. Escape untrusted strings before inserting them into HTML. Add domain mutations to service classes rather than implementing business rules inside views.

## Event catalogue

### `state:changed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("state:changed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `notification`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("notification", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `terminal:closed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("terminal:closed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `route:changed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("route:changed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `inventory:changed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("inventory:changed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `shop:purchased`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("shop:purchased", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `crafting:complete`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("crafting:complete", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `mission:tracked`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("mission:tracked", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `mission:progress`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("mission:progress", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `equipment:changed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("equipment:changed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `achievement:unlocked`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("achievement:unlocked", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `codex:unlocked`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("codex:unlocked", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `sector:discovered`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("sector:discovered", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `search:complete`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("search:complete", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `settings:changed`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("settings:changed", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

### `settings:reset`

Emitted by the corresponding service after a successful operation. Subscribe with `app.bus.on("settings:reset", handler)` and retain the returned unsubscribe function when the listener belongs to a temporary view. Event payloads are plain objects and should be treated as read-only snapshots.

## Integration recipes

### Award a material — integration example 1

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 1

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 1

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 1

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 1

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 1

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 1

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 1

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 1

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 1

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 2

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 2

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 2

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 2

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 2

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 2

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 2

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 2

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 2

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 2

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 3

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 3

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 3

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 3

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 3

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 3

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 3

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 3

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 3

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 3

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 4

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 4

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 4

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 4

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 4

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 4

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 4

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 4

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 4

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 4

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 5

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 5

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 5

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 5

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 5

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 5

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 5

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 5

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 5

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 5

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 6

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 6

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 6

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 6

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 6

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 6

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 6

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 6

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 6

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 6

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 7

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 7

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 7

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 7

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 7

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 7

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 7

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 7

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 7

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 7

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 8

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 8

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 8

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 8

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 8

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 8

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 8

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 8

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 8

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 8

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 9

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 9

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 9

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 9

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 9

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 9

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 9

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 9

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 9

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 9

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 10

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 10

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 10

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 10

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 10

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 10

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 10

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 10

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 10

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 10

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 11

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 11

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 11

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 11

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 11

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 11

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 11

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 11

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 11

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 11

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

### Award a material — integration example 12

`app.inventory.add("relay_chip", 2, "quest-reward")` adds two relay chips and emits the inventory event.

### Unlock a recipe — integration example 12

`app.crafting.unlock("shield_bubble_recipe")` makes the shield recipe available in the workshop.

### Advance an objective — integration example 12

`app.missions.progress("first_contact", "scan_yard", 1)` advances the first contact mission.

### Unlock research — integration example 12

`app.codex.unlock("tractor_beam")` reveals the tractor-beam codex record.

### Discover a sector — integration example 12

`app.map.discover("crystal_grove")` marks Crystal Grove as discovered.

### Equip an item — integration example 12

`app.equipment.equip("plasma_lens")` equips the plasma lens if it is owned.

### Award credits — integration example 12

`app.state.mutate(data => { data.credits += 50; data.statistics.creditsEarned += 50; }, "reward")` adds a credit reward.

### Show a toast — integration example 12

`app.notifications.push("New lead", "A signal has appeared.", "info")` creates a terminal notification.

### Navigate to a view — integration example 12

`app.router.go("missions")` opens the mission journal.

### Export a backup — integration example 12

`app.profiles.export()` returns a versioned backup payload suitable for JSON download.

## State schema

### `version`

This field is part of the terminal namespace. Read it through `app.state.get("version")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `activeTab`

This field is part of the terminal namespace. Read it through `app.state.get("activeTab")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `search`

This field is part of the terminal namespace. Read it through `app.state.get("search")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `filter`

This field is part of the terminal namespace. Read it through `app.state.get("filter")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `sort`

This field is part of the terminal namespace. Read it through `app.state.get("sort")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `compact`

This field is part of the terminal namespace. Read it through `app.state.get("compact")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `credits`

This field is part of the terminal namespace. Read it through `app.state.get("credits")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `reputation`

This field is part of the terminal namespace. Read it through `app.state.get("reputation")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `inventory`

This field is part of the terminal namespace. Read it through `app.state.get("inventory")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `equipment`

This field is part of the terminal namespace. Read it through `app.state.get("equipment")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `recipesUnlocked`

This field is part of the terminal namespace. Read it through `app.state.get("recipesUnlocked")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `discoveredSectors`

This field is part of the terminal namespace. Read it through `app.state.get("discoveredSectors")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `missions`

This field is part of the terminal namespace. Read it through `app.state.get("missions")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `achievements`

This field is part of the terminal namespace. Read it through `app.state.get("achievements")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `codex`

This field is part of the terminal namespace. Read it through `app.state.get("codex")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `notes`

This field is part of the terminal namespace. Read it through `app.state.get("notes")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `mail`

This field is part of the terminal namespace. Read it through `app.state.get("mail")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `purchases`

This field is part of the terminal namespace. Read it through `app.state.get("purchases")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `craftingHistory`

This field is part of the terminal namespace. Read it through `app.state.get("craftingHistory")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `profile`

This field is part of the terminal namespace. Read it through `app.state.get("profile")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `settings`

This field is part of the terminal namespace. Read it through `app.state.get("settings")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `statistics`

This field is part of the terminal namespace. Read it through `app.state.get("statistics")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `notifications`

This field is part of the terminal namespace. Read it through `app.state.get("notifications")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

### `seenWelcome`

This field is part of the terminal namespace. Read it through `app.state.get("seenWelcome")`, update it through a service method when one exists, and persist it through the state manager. Avoid mutating the field directly from presentation code.

## View implementation checklist

### View review 001

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 002

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 003

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 004

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 005

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 006

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 007

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 008

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 009

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 010

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 011

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 012

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 013

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 014

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 015

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 016

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 017

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 018

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 019

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 020

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 021

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 022

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 023

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 024

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 025

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 026

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 027

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 028

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 029

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 030

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 031

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 032

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 033

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 034

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 035

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 036

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 037

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 038

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 039

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 040

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 041

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 042

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 043

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 044

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 045

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 046

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 047

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 048

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 049

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 050

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 051

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 052

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 053

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 054

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 055

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 056

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 057

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 058

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 059

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 060

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 061

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 062

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 063

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 064

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 065

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 066

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 067

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 068

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 069

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 070

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 071

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 072

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 073

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 074

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 075

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 076

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 077

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 078

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 079

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 080

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 081

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 082

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 083

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 084

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 085

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 086

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 087

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 088

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 089

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 090

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 091

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 092

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 093

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 094

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 095

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 096

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 097

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 098

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 099

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 100

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 101

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 102

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 103

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 104

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 105

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 106

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 107

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 108

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 109

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 110

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 111

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 112

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 113

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 114

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 115

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 116

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 117

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 118

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 119

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.

### View review 120

- Confirm the view renders inside the supplied host element.
- Escape any player-controlled or imported text before HTML insertion.
- Keep business rules in the service layer.
- Ensure empty, loading and unavailable states have readable messages.
- Keep controls keyboard reachable and label form fields.
- Re-render after successful mutations and preserve focus where practical.


## Additional service recipes

### Service contract 01: `audit-log`

The `audit-log` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { AuditLog } from "../core/audit-log.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 02: `command-palette`

The `command-palette` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { CommandPalette } from "../core/command-palette.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 03: `daily-challenges`

The `daily-challenges` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { DailyChallenges } from "../core/daily-challenges.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 04: `dialogue-notebook`

The `dialogue-notebook` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { DialogueNotebook } from "../core/dialogue-notebook.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 05: `event-calendar`

The `event-calendar` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { EventCalendar } from "../core/event-calendar.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 06: `filter-engine`

The `filter-engine` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { FilterEngine } from "../core/filter-engine.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 07: `input-shortcuts`

The `input-shortcuts` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { InputShortcuts } from "../core/input-shortcuts.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 08: `mail-service`

The `mail-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { MailService } from "../core/mail-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 09: `market-watch`

The `market-watch` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { MarketWatch } from "../core/market-watch.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 10: `offline-queue`

The `offline-queue` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { OfflineQueue } from "../core/offline-queue.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 11: `quest-graph`

The `quest-graph` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { QuestGraph } from "../core/quest-graph.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 12: `reputation-service`

The `reputation-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ReputationService } from "../core/reputation-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 13: `route-planner`

The `route-planner` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { RoutePlanner } from "../core/route-planner.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 14: `session-service`

The `session-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { SessionService } from "../core/session-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 15: `soundscape`

The `soundscape` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { Soundscape } from "../core/soundscape.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 16: `timeline-service`

The `timeline-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { TimelineService } from "../core/timeline-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 17: `tutorial-service`

The `tutorial-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { TutorialService } from "../core/tutorial-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 18: `validation`

The `validation` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { Validation } from "../core/validation.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 19: `world-state`

The `world-state` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { WorldState } from "../core/world-state.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 20: `localization`

The `localization` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { Localization } from "../core/localization.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 21: `analytics-service`

The `analytics-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { AnalyticsService } from "../core/analytics-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 22: `companion-service`

The `companion-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { CompanionService } from "../core/companion-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 23: `photo-gallery`

The `photo-gallery` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { PhotoGallery } from "../core/photo-gallery.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 24: `notification-rules`

The `notification-rules` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { NotificationRules } from "../core/notification-rules.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 25: `progression-track`

The `progression-track` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ProgressionTrack } from "../core/progression-track.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 26: `profile-validator`

The `profile-validator` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ProfileValidator } from "../core/profile-validator.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 27: `report-builder`

The `report-builder` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ReportBuilder } from "../core/report-builder.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 28: `cache-service`

The `cache-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { CacheService } from "../core/cache-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 29: `feature-flags`

The `feature-flags` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { FeatureFlags } from "../core/feature-flags.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 30: `undo-stack`

The `undo-stack` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { UndoStack } from "../core/undo-stack.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 31: `pagination`

The `pagination` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { Pagination } from "../core/pagination.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 32: `clipboard-service`

The `clipboard-service` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ClipboardService } from "../core/clipboard-service.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 33: `error-reporter`

The `error-reporter` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ErrorReporter } from "../core/error-reporter.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 34: `view-lifecycle`

The `view-lifecycle` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ViewLifecycle } from "../core/view-lifecycle.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

### Service contract 35: `color-theme`

The `color-theme` subsystem is isolated from the game simulation. Instantiate it at the application boundary, pass dependencies explicitly, and keep DOM references out of the domain layer. Use its return values to decide whether a view should re-render. Subscribe to emitted events only for the lifetime of the screen that needs them.

```js
import { ColorTheme } from "../core/color-theme.js";
// Construct with the dependencies required by the service.
// Keep all mutations behind a named method so the state change is auditable.
```

## Operational scenarios

### Scenario 01: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 01: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 02: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 03: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 04: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 05: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 06: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 07: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 08: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 09: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 10: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 11: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 12: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 13: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 14: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 15: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 16: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 17: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: The browser storage quota is exceeded while Fiona is crafting an item.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A profile backup was created by a newer version of the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A player navigates away from a view while its event listeners are active.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A mission reward is clicked twice in quick succession.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A sector becomes discovered while the map screen is open.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: The user disables automatic saving before closing the terminal.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A recipe is unlocked by a story reward while the workshop is not visible.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: An item count is corrupted by a hand-edited backup file.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A notification arrives while the terminal is closed.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.

### Scenario 18: A keyboard shortcut is pressed while focus is inside a search field.

Expected handling: validate the input, keep the domain operation atomic, preserve the last valid save, and report a concise message to the player. If the action cannot be completed, return a structured failure result rather than silently changing a different record.


## Extended service reference

### 01. CooldownService

`cooldown-service.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 02. CraftingQueue

`crafting-queue.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 03. ItemComparator

`item-comparator.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 04. ItemStackService

`item-stack-service.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 05. LootPreview

`loot-preview.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 06. QuestBoard

`quest-board.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 07. VendorRotation

`vendor-rotation.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 08. CompanionAffinity

`companion-affinity.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 09. JournalTagging

`journal-tagging.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 10. StoryFlagService

`story-flag-service.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 11. CutsceneArchive

`cutscene-archive.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 12. PlaytimeTracker

`playtime-tracker.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 13. LeaderboardLocal

`leaderboard-local.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 14. RewardClaimGuard

`reward-claim-guard.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 15. SaveIntegrity

`save-integrity.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 16. SaveMigration

`save-migration.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 17. BackupScheduler

`backup-scheduler.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 18. FocusManager

`focus-manager.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 19. NotificationDigest

`notification-digest.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 20. CalendarReminders

`calendar-reminders.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 21. CompassService

`compass-service.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 22. ItemRecipeBook

`item-recipe-book.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 23. ItemDiscovery

`item-discovery.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 24. ChallengeRotation

`challenge-rotation.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 25. CodexCategories

`codex-categories.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 26. LocalSaveInspector

`local-save-inspector.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 27. PurchaseCart

`purchase-cart.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 28. AchievementPoints

`achievement-points.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 29. CurrencyFormatter

`currency-formatter.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 30. FormState

`form-state.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 31. AsyncLock

`async-lock.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

### 32. UrlState

`url-state.js` provides a focused application capability. It is designed for dependency injection and does not import the game canvas or manipulate the platformer loop. Instantiate it from an application composition root, then expose only the operations required by the relevant view.

Operational guidance:

- Validate identifiers and quantities before committing state.
- Return structured failures for expected invalid operations.
- Emit events after a successful mutation, never before it.
- Keep presentation strings in the view layer where possible.
- Keep data snapshots detached from mutable internal collections.

## Regression matrix

### Regression case 01.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 01.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 02.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 03.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 04.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 05.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 06.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 07.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 08.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 09.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 10.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 11.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 12.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 13.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 14.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 15.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 16.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 17.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 18.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 19.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.empty-input

Condition: The service receives an empty identifier or query. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.unknown-identifier

Condition: The requested catalog entry does not exist. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.insufficient-quantity

Condition: The player attempts to spend more items than they own. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.duplicate-operation

Condition: The same reward or unlock is requested more than once. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.boundary-value

Condition: The value is exactly at a minimum or maximum limit. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.stale-record

Condition: A referenced entry was removed after the view was rendered. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.storage-unavailable

Condition: The browser denies persistent storage access. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.invalid-imported-data

Condition: A user-selected backup contains malformed or incomplete data. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.concurrent-action

Condition: Two controls request the same state mutation before the first finishes. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.

### Regression case 20.empty-collection

Condition: A list, category or history has no records. The service must preserve its previous valid state, return a predictable result, and avoid throwing an unhandled exception for this expected input. The calling view should display a short explanation and remain usable.


## Integration recipe index

### 01. Award a material when a relay crate is opened

```js
app.inventory.add("relay_chip", 1, "relay-crate");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 02. Unlock a codex entry after scanning a landmark

```js
app.codex.unlock("tractor_beam");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 03. Discover a sector after its portal animation

```js
app.map.discover("crystal_grove");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 04. Track a mission when a character offers it

```js
app.missions.track("mall_cleanup");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 05. Advance a mission objective after an interaction

```js
app.missions.progress("mall_cleanup", "restart_kiosk", 1);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 06. Grant a small credit reward for a side activity

```js
app.state.mutate(data => { data.credits += 25; data.statistics.creditsEarned += 25; }, "reward:side-activity");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 07. Show a friendly field terminal message

```js
app.notifications.push("New signal", "A relay has started transmitting.", "info");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 08. Equip the plasma lens after it is acquired

```js
app.equipment.equip("plasma_lens");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 09. Record a short story note

```js
journal.write("A strange signal", "The family frequency is stronger here.", ["story", "signal"]);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 10. Record a one-time world event

```js
worldFlags.once("mothership-door-opened", () => openDoor());
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 11. Reward a local faction for helping an NPC

```js
reputation.adjust("moon-mall-staff", 10, "helped-kiosk");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 12. Store a screenshot data URL in the gallery

```js
gallery.add({ title: "Crystal Grove", dataUrl, sector: "crystal_grove" });
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 13. Place a custom map marker

```js
markers.add("orbital_archive", 0.4, 0.7, "Memory vault", "objective");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 14. Mark a tutorial as complete

```js
tutorials.complete("first-crafting-session");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 15. Store a dialogue branch decision

```js
storyFlags.set("fiona-trusts-nix", true);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 16. Recruit a new companion

```js
companions.recruit("patch7");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 17. Set the active companion

```js
companions.setActive("patch7");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 18. Record damage dealt during combat

```js
combatRecords.record("damage-dealt", 12);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 19. Apply an ability cooldown

```js
cooldowns.start("signal-pulse", 2500);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 20. Start and pause a tracked activity

```js
playtime.start(); playtime.pause();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 21. Generate a text expedition report

```js
const reportText = reportBuilder.toText();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 22. Check the terminal save size

```js
const saveInfo = saveInspector.inspect();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 23. Verify an imported save checksum

```js
const verified = integrity.open(envelope);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 24. Send Fiona a new message

```js
mail.send({ from: "Milo", subject: "Kiosk restored", body: "Thanks for the help." });
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 25. Schedule a reminder for a later objective

```js
reminders.schedule("Check the archive", Date.now() + 60000);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 26. Build a dependency graph for a story chain

```js
const graph = new QuestGraph([{ id: "scan", dependencies: [] }, { id: "decode", dependencies: ["scan"] }]);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 27. Calculate missing crafting ingredients

```js
const quote = craftingCost.quote(recipe, 2);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 28. Describe the reward before accepting a mission

```js
const rewardText = rewardPreview.describe(mission.rewards);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 29. Compare the current and new blaster

```js
const comparison = comparator.compare(currentBlaster, plasmaLens);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 30. Search Fiona’s saved field notes

```js
const notes = journal.search("family signal");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 31. List favorite equipment and items

```js
const favorites = itemFavorites.list();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 32. Check a companion relationship tier

```js
const bond = affinity.tier(affinity.score("patch7"));
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 33. Check a sector survey completion

```js
const survey = sectorSurvey.completion("crystal_grove", expectedFeatures);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 34. Apply the accessible terminal preset

```js
settingsPresets.apply("accessible");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 35. Schedule a small event callback

```js
scheduler.schedule(5000, () => bus.emit("world:hint", {}), "hint");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 36. Queue an action to retry when ready

```js
offlineQueue.enqueue("upload-report", report);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 37. Add a timeline milestone

```js
timeline.add("story", "Signal aligned", "Fiona tuned the relay.");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 38. Record a terminal usage metric

```js
analytics.increment("map-opened");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 39. Advance a daily challenge

```js
dailyChallenges.advance(challengeId, 1);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 40. Refresh the rotating vendor assortment

```js
const newStock = vendorRotation.rotate();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 41. Get a quote before purchasing

```js
const quote = vendor.quote("med_patch", 2);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 42. Summarize unread notices

```js
const unread = notificationDigest.unread();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 43. Filter inventory to available upgrades

```js
const upgrades = filterEngine.apply(items, "available-upgrades");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 44. Move to the next result page

```js
const nextPage = pagination.next();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 45. Copy a signal coordinate string

```js
await clipboard.copy("X: 12 / Y: 4");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 46. Record a sensitive inventory change

```js
audit.record("item-consumed", "med_patch", { amount: 1 });
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 47. Gate an experimental terminal tool

```js
if (featureFlags.enabled("advanced-map")) openAdvancedMap();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 48. Dismiss a repeated tutorial hint

```js
tutorialHints.dismiss("inventory-basics");
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 49. Read the local faction standings

```js
const standings = reputation.standings();
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

### 50. Estimate a route across discovered sectors

```js
const path = routePlanner.shortestPath("backyard", "mothership", discovered);
```

Use this operation only after the corresponding game event has been validated. The terminal service is a secondary record of player-facing progress; it should not replace the authoritative physics or combat state.

## State mutation boundaries

### `credits`

Treat `credits` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `inventory`

Treat `inventory` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `equipment`

Treat `equipment` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `missions`

Treat `missions` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `achievements`

Treat `achievements` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `codex`

Treat `codex` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `discoveredSectors`

Treat `discoveredSectors` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `profile`

Treat `profile` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `settings`

Treat `settings` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `statistics`

Treat `statistics` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `notifications`

Treat `notifications` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `purchases`

Treat `purchases` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `craftingHistory`

Treat `craftingHistory` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `journalEntries`

Treat `journalEntries` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `timeline`

Treat `timeline` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `worldFlags`

Treat `worldFlags` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `storyFlags`

Treat `storyFlags` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `companions`

Treat `companions` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `companionAffinity`

Treat `companionAffinity` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `mapMarkers`

Treat `mapMarkers` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `sectorSurveys`

Treat `sectorSurveys` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `dailyChallenges`

Treat `dailyChallenges` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `metrics`

Treat `metrics` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `reputation`

Treat `reputation` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `factions`

Treat `factions` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `photos`

Treat `photos` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `mail`

Treat `mail` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `claimedRewards`

Treat `claimedRewards` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `cutscenes`

Treat `cutscenes` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `tutorials`

Treat `tutorials` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.

### `favoriteItems`

Treat `favoriteItems` as application-owned state. Prefer the dedicated service when one exists. If a direct mutation is necessary, perform it through `app.state.mutate` and use a descriptive change label so observers can identify the source of the update.


## Additional application services

### Service 01: `beacon-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 02: `bounty-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 03: `checkpoint-notes.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 04: `collection-book.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 05: `conversation-history.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 06: `dialogue-choice-log.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 07: `discovery-feed.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 08: `energy-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 09: `export-queue.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 10: `feature-unlock-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 11: `file-name-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 12: `game-mode-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 13: `hint-rotation.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 14: `inventory-capacity.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 15: `item-trade-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 16: `level-unlock-service.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 17: `mission-filter.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 18: `notification-throttle.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 19: `objective-tracker.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 20: `party-bonus.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 21: `profile-name.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 22: `quest-dependency-check.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 23: `quest-replay.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 24: `reward-bundle.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 25: `sector-danger.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 26: `sector-signal.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 27: `session-achievements.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 28: `signal-history.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 29: `story-recap.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 30: `supply-inventory.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

### Service 31: `world-state-query.js`

This service is an isolated unit in the Field Terminal domain layer. It receives its collaborators through the constructor, exposes deterministic operations where possible, and returns explicit results so the calling interface can decide how to present success or failure.

- Keep game-loop operations in the original platformer runtime.
- Keep persistent records in the terminal state namespace.
- Emit a domain event after a successful change when other modules may need to react.
- Avoid depending on a particular DOM view.

## Workflow implementation notes

### Workflow 01

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 02

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 03

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 04

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 05

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 06

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 07

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 08

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 09

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 10

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 11

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 12

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 13

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 14

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 15

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 16

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 17

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 18

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 19

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 20

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 21

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 22

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 23

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 24

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 25

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 26

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 27

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 28

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 29

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

### Workflow 30

The matching example module demonstrates a small event boundary. The `canRun` method rejects invalid or disabled calls, `execute` emits lifecycle events, and `process` contains the workflow-specific implementation. Replace the sample `process` body with a call to a domain service; do not place reward rules directly in the game renderer.

