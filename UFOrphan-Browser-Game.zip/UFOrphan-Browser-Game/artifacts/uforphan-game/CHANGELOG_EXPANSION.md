# Changelog — Expansion 2.0.0

## Added

- Chapters 05–08: Crystal Grove, Orbital Archive, Bio-Dome, and Eclipse Core.
- Persistent expansion profile and save migration from the original save schema.
- Inventory stacks, item catalogue, consumables, equipment slots, upgrade catalogue, and skill progression.
- Tagged objective quest engine, four narrative quests, automatic reward service, and prerequisite unlocking.
- NPC interaction system with dialogue rotation, quest hooks, and touch interaction support.
- Station-based crafting, credit economy, shop stock, and repeatable mission board.
- Plasma Lens weapon, piercing projectiles, combat combos, damage numbers, and loot tables.
- Dynamic weather, environmental hazards, moving platforms, region triggers, world events, and pacing director.
- Sector map, codex, achievements, companions, challenges, checkpoint snapshots, photo mode, cutscene beats, accessibility preferences, tutorials, localization, and run statistics.
- Level geometry validator, deterministic side-room generator, and Node-based regression tests.

## Changed

- Game version updated to 2.0.0 while retaining the original save key for migration.
- Existing chapter unlocks and best-star records are preserved when loading version-one saves.
- World and player update loops now connect to the expansion runtime when an expansion profile is provided.
- Existing base chapters remain in their original order and retain their original level data.

## Validation

- 50 expansion, persistence, narrative, and world integration assertions pass.
- All eight authored chapters pass level geometry validation.
- Original utility test suite passes 20 assertions.
- All JavaScript modules pass Node syntax checks and all 37 expansion modules import successfully.
